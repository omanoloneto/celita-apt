"""Laço principal do agente, espelho do offscreen.js da extensão.

Identidade e pareamento vivem aqui; a extensão no Voges é só o braço para
abas. Comandos que dependem da sessão gráfica correm na sessão controlada
ativa, e sem sessão respondem sem_sessao.
"""

import base64
import grp
import json
import logging
import os
import signal
import sys
import threading
import time
import uuid

from . import VERSION, protocol, session as sess
from .bridge import BridgeServer
from .cloud import CloudClient
from .crypto import (
    derive_session_key,
    generate_private_key,
    new_token,
    private_key_from_b64url,
    private_key_to_b64url,
    public_key_b64url,
)
from .firebase import FirebaseError, FirebaseSession

log = logging.getLogger("controle-de-aula")

STATE_DIR = "/var/lib/controle-de-aula"
STATE_FILE = os.path.join(STATE_DIR, "estado.json")
FIREBASE_CONFIG = "/usr/share/controle-de-aula/firebase.json"
STUCK_CONNECTING_S = 20
MAX_WALLPAPER_BYTES = 10 * 1024 * 1024


class Storage:
    """Estado persistente em um JSON só, gravado atomicamente e legível só por root."""

    def __init__(self, path: str = STATE_FILE):
        self.path = path
        self._lock = threading.Lock()
        self._data = self._load()

    def _load(self) -> dict:
        try:
            with open(self.path, encoding="utf-8") as handle:
                data = json.load(handle)
                return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def get(self, key: str):
        with self._lock:
            return self._data.get(key)

    def set(self, key: str, value):
        with self._lock:
            if value is None:
                self._data.pop(key, None)
            else:
                self._data[key] = value
            os.makedirs(os.path.dirname(self.path), mode=0o700, exist_ok=True)
            temporary = self.path + ".tmp"
            with open(temporary, "w", encoding="utf-8") as handle:
                json.dump(self._data, handle, ensure_ascii=False)
            os.chmod(temporary, 0o600)
            os.replace(temporary, self.path)


class Agent:
    def __init__(self, storage: Storage, firebase_config: dict):
        self.storage = storage
        self.firebase_config = firebase_config
        self.fb = None
        self.identity = None
        self.client = None
        self.bind_watch = None
        self.bind_result = None
        self.bind_event = threading.Event()
        self.sessions = sess.SessionTracker()
        self.state = "connecting"
        self.detail = None
        self.teacher_name = None
        self.state_changed_at = time.monotonic()
        self._restart_requested = threading.Event()
        try:
            gid = grp.getgrnam(sess.CONTROLLED_GROUP).gr_gid
        except KeyError:
            gid = None
        self.bridges = BridgeServer(self._on_bridge_message, gid)

    # ---- Estado ---------------------------------------------------------------

    def _broadcast(self, state: str, detail=None, teacher=None):
        if detail:
            log.info("%s: %s", state, detail)
        if state != self.state:
            self.state = state
            self.state_changed_at = time.monotonic()
        self.detail = detail
        if teacher:
            self.teacher_name = teacher
        self.bridges.broadcast(self._state_message())

    def _state_message(self) -> dict:
        binding = self.storage.get("binding") or {}
        return {
            "t": "state",
            "state": self.state,
            "detail": self.detail,
            "teacher": self.teacher_name,
            "numero": binding.get("numero"),
            "label": self.identity["label"] if self.identity else None,
            "version": VERSION,
        }

    def _pairing_message(self):
        pairing = self.storage.get("pairing") or {}
        if not self.identity or not pairing.get("token"):
            return {"t": "pairing", "dados": None}
        return {
            "t": "pairing",
            "dados": {
                "deviceId": self.identity["deviceId"],
                "pub": self.identity["pub"],
                "token": pairing["token"],
                "label": self.identity["label"],
            },
        }

    # ---- Identidade e Firebase --------------------------------------------------

    def _ensure_identity(self) -> dict:
        if self.identity:
            return self.identity
        saved = self.storage.get("keypair")
        if isinstance(saved, dict) and saved.get("priv"):
            key = private_key_from_b64url(saved["priv"])
            self.identity = {
                "key": key,
                "pub": public_key_b64url(key),
                "deviceId": saved["deviceId"],
                "label": saved.get("label") or "Celita",
            }
            return self.identity
        key = generate_private_key()
        device_id = str(uuid.uuid4())
        label = "Celita-" + device_id[:4]
        self.storage.set("keypair", {
            "priv": private_key_to_b64url(key),
            "deviceId": device_id,
            "label": label,
        })
        self.identity = {"key": key, "pub": public_key_b64url(key), "deviceId": device_id, "label": label}
        return self.identity

    def _ensure_pair_token(self) -> str:
        saved = self.storage.get("pairing")
        if isinstance(saved, dict) and saved.get("token"):
            return saved["token"]
        token = new_token()
        self.storage.set("pairing", {"token": token})
        return token

    def _rotate_token(self) -> str:
        token = new_token()
        self.storage.set("pairing", {"token": token})
        try:
            self.fb.put(f"/devices/{self.identity['deviceId']}/pairing/token", token)
        except Exception as error:  # noqa: BLE001
            log.warning("token não rotacionou no servidor: %s", error)
        return token

    def _ensure_firebase(self) -> FirebaseSession:
        if self.fb and self.fb.id_token:
            return self.fb
        if self.fb:
            self.fb.stop()
        self.fb = FirebaseSession(
            api_key=self.firebase_config["apiKey"],
            database_url=self.firebase_config["databaseURL"],
            load_auth=lambda: self.storage.get("fbauth"),
            save_auth=lambda auth: self.storage.set("fbauth", auth),
        )
        self.fb.sign_in()
        return self.fb

    def _register(self, token: str):
        identity = self.identity
        meta = {
            "uid": self.fb.uid,
            "pub": identity["pub"],
            "label": identity["label"],
            "v": 4,
            "ext": f"celita-{VERSION}",
        }
        try:
            self.fb.patch(f"/devices/{identity['deviceId']}/meta", meta)
        except FirebaseError as error:
            # Rules antigas no console não conhecem meta/ext e negam o PATCH
            # inteiro; ficar sem registrar seria ficar invisível para sempre.
            if error.status != 401:
                raise
            log.warning("rules do Firebase recusam meta/ext; registrando sem a versão")
            meta.pop("ext")
            self.fb.patch(f"/devices/{identity['deviceId']}/meta", meta)
        self.fb.put(f"/devices/{identity['deviceId']}/pairing/token", token)
        self.fb.put(f"/device_uids/{self.fb.uid}", identity["deviceId"])

    def _wait_for_bind(self, token: str):
        self.bind_result = None
        self.bind_event.clear()

        def on_event(event):
            data = event.get("data")
            if event.get("path") != "/" or not isinstance(data, dict):
                return
            if data.get("token") != token:
                log.warning("bind com token divergente, ignorado")
                return
            self.bind_result = {
                "teacherUid": data.get("teacherUid"),
                "teacherPub": data.get("teacherPub"),
                "teacherName": data.get("teacherName") or "Professor",
                "numero": data.get("numero") if isinstance(data.get("numero"), int) else None,
            }
            self.bind_event.set()

        self.bind_watch = self.fb.stream(f"/devices/{self.identity['deviceId']}/bind", on_event)
        try:
            self.bind_event.wait()
        finally:
            self.bind_watch.close()
            self.bind_watch = None
        return self.bind_result

    def _unbind(self):
        if self.client:
            self.client.stop()
        self.storage.set("binding", None)
        self.storage.set("replay", None)
        self.storage.set("classview", None)
        self.teacher_name = None
        if not (self.fb and self.fb.id_token):
            return
        base = f"/devices/{self.identity['deviceId']}"
        for suffix in ("bind", "report", "ack", "presence", "snapshot"):
            try:
                self.fb.delete(f"{base}/{suffix}")
            except Exception:  # noqa: BLE001
                pass
        self._rotate_token()

    def _apply_unit_number(self, numero: int) -> dict:
        binding = self.storage.get("binding")
        if isinstance(binding, dict):
            self.storage.set("binding", {**binding, "numero": numero})
        label = f"Unidade {numero}"
        keypair = self.storage.get("keypair")
        if isinstance(keypair, dict):
            self.storage.set("keypair", {**keypair, "label": label})
        self.identity["label"] = label
        try:
            self.fb.patch(f"/devices/{self.identity['deviceId']}/meta", {"label": label})
        except Exception as error:  # noqa: BLE001
            log.warning("label não subiu: %s", error)
        self.bridges.broadcast(self._state_message())
        return {"ok": True}

    def restart_connection(self, reason: str = "reinício pedido"):
        log.info("reconectando: %s", reason)
        self._restart_requested.set()
        if self.fb:
            self.fb.stop()
            self.fb = None
        self.bind_event.set()
        if self.client:
            self.client.stop()

    # ---- Ponte com o navegador --------------------------------------------------

    def _active_bridge(self):
        session = self.sessions.active()
        if not session:
            return None, None
        return session, self.bridges.client_for_uid(session.uid)

    def _on_bridge_message(self, client, message: dict):
        kind = message.get("t")
        if kind == "hello":
            client.send(self._state_message())
            client.send(self._pairing_message())
            rules = self.storage.get("rules")
            if isinstance(rules, dict):
                client.send({"t": "rules", "rev": rules.get("rev", 0), "rules": rules.get("rules", [])})
            client.send({"t": "classview", "snapshot": self.storage.get("classview")})
        elif kind == "get":
            if message.get("req") == "pairing":
                client.send(self._pairing_message())
            else:
                client.send(self._state_message())
        elif kind == "report":
            if self.client:
                self.client.request_report()
        elif kind == "unbind":
            threading.Thread(target=self._unbind_from_bridge, daemon=True).start()
        elif kind == "reconnect":
            self.restart_connection("botão da extensão")

    def _unbind_from_bridge(self):
        self._unbind()
        self.bind_event.set()
        self._broadcast("pairing", "desvinculado; escaneie o QR para parear de novo")

    # ---- Execução de comandos ---------------------------------------------------

    def _report(self):
        session, bridge = self._active_bridge()
        tabs, events = [], []
        if bridge and bridge.report_is_fresh():
            tabs = bridge.last_report.get("tabs") or []
            events = bridge.last_report.get("events") or []
        apps = sess.list_apps(session) if session else []
        return protocol.make_tab_report(tabs, events, apps=apps, user=session.user if session else None)

    def _execute(self, cmd: dict) -> dict:
        kind = cmd.get("type")
        payload = cmd.get("payload") if isinstance(cmd.get("payload"), dict) else {}
        session, bridge = self._active_bridge()

        if kind == protocol.OPEN_URL:
            url = payload.get("url")
            if not protocol.is_safe_http_url(url):
                return {"ok": False, "error": "url_invalida"}
            if bridge:
                return bridge.exec(kind, payload)
            if session:
                return sess.open_browser(session, url)
            return {"ok": False, "error": "sem_sessao"}

        if kind in (protocol.CLOSE_TABS, protocol.CLOSE_ALL_TABS):
            if bridge:
                return bridge.exec(kind, payload)
            # Navegador fechado: não há aba para fechar, e fechar zero é ok.
            return {"ok": True}

        if kind == protocol.SET_RULES:
            rules = protocol.clean_rules(payload.get("rules"))
            rev = payload.get("rev") if isinstance(payload.get("rev"), (int, float)) else 0
            self.storage.set("rules", {"rev": rev, "rules": rules})
            self.bridges.broadcast({"t": "rules", "rev": rev, "rules": rules})
            return {"ok": True}

        if kind == protocol.SET_CLASS_VIEW:
            snapshot = payload.get("snapshot")
            self.storage.set("classview", {**snapshot, "recebidoEm": int(time.time() * 1000)} if snapshot else None)
            self.bridges.broadcast({"t": "classview", "snapshot": self.storage.get("classview")})
            return {"ok": True}

        if kind == protocol.SET_UNIT:
            return self._apply_unit_number(payload.get("numero"))

        if kind == protocol.SHOW_MESSAGE:
            if bridge:
                return bridge.exec(kind, payload)
            if session:
                title = str(payload.get("title") or "Controle de Aula")[: protocol.MAX_MESSAGE_TITLE]
                body = str(payload.get("body") or "")[: protocol.MAX_MESSAGE_BODY]
                if payload.get("popup") is True and payload.get("de"):
                    title = f"Mensagem de {str(payload['de'])[: protocol.MAX_MESSAGE_FROM]}"
                return sess.notify(session, title, body)
            return {"ok": False, "error": "sem_sessao"}

        if kind == protocol.SET_WALLPAPER:
            if not session:
                return {"ok": False, "error": "sem_sessao"}
            try:
                jpeg = base64.b64decode(payload.get("jpegB64") or "")
            except ValueError:
                return {"ok": False, "error": "blob_invalido"}
            if not jpeg or len(jpeg) > MAX_WALLPAPER_BYTES:
                return {"ok": False, "error": "imagem_grande" if jpeg else "blob_invalido"}
            return sess.set_wallpaper(session, jpeg)

        if kind == protocol.CAPTURE_CAMERA:
            result = sess.capture_camera()
            return {**result, "snapshotType": protocol.CAMERA_SNAPSHOT}

        if kind == protocol.CAPTURE_SCREEN:
            if not session:
                return {"ok": False, "error": "sem_sessao"}
            result = sess.capture_screen(session)
            return {**result, "snapshotType": protocol.SCREEN_SNAPSHOT}

        return {"ok": False, "error": "tipo_desconhecido"}

    # ---- Laço principal -----------------------------------------------------------

    def run(self):
        self.bridges.start()
        threading.Thread(target=self._stuck_watchdog, name="stuck-watchdog", daemon=True).start()
        while True:
            self._restart_requested.clear()
            try:
                self._ensure_identity()
                token = self._ensure_pair_token()
                self._broadcast("connecting", "autenticando no Firebase")
                self._ensure_firebase()
                self._register(token)

                binding = self.storage.get("binding")
                if not (isinstance(binding, dict) and binding.get("teacherPub")):
                    self._broadcast("pairing", "aguardando o professor escanear o QR")
                    self.bridges.broadcast(self._pairing_message())
                    binding = self._wait_for_bind(token)
                    if not binding:
                        continue
                    self.storage.set("binding", binding)
                    self._rotate_token()
                    self.bridges.broadcast(self._pairing_message())
                    log.info("pareado com %s", binding["teacherName"])

                if isinstance(binding.get("numero"), int):
                    label = f"Unidade {binding['numero']}"
                    if self.identity["label"] != label:
                        self._apply_unit_number(binding["numero"])

                session_key = derive_session_key(self.identity["key"], binding["teacherPub"])
                self._broadcast("connected", None, binding["teacherName"])
                self.client = CloudClient(
                    fb=self.fb,
                    device_id=self.identity["deviceId"],
                    session_key=session_key,
                    teacher=binding,
                    on_command=self._execute,
                    get_report=self._report,
                    on_state=lambda ok, detail: self._broadcast(
                        "connected" if ok else "connecting", detail, binding["teacherName"]
                    ),
                    load_replay=lambda: self.storage.get("replay"),
                    save_replay=lambda replay: self.storage.set("replay", replay),
                )
                reason = self.client.run()
                self.client = None
                if reason == "unbound":
                    self._unbind()
                    self._broadcast("pairing", "o professor desvinculou este computador")
                elif reason == "foreign_bind":
                    self._broadcast("connecting", "vínculo divergente no servidor; desvincule pela extensão")
                    time.sleep(5)
            except Exception as error:  # noqa: BLE001 - qualquer falha só reinicia o laço
                self._broadcast("connecting", str(error))
                time.sleep(4)

    def _stuck_watchdog(self):
        # Preso em "connecting" por muito tempo é um socket meio-vivo: refaz do zero.
        while True:
            time.sleep(5)
            if self.state == "connecting" and time.monotonic() - self.state_changed_at > STUCK_CONNECTING_S:
                self.state_changed_at = time.monotonic()
                self.restart_connection("preso em connecting")


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(name)s: %(message)s",
        stream=sys.stderr,
    )
    if os.geteuid() != 0:
        log.error("o agente precisa rodar como root")
        return 1
    try:
        with open(FIREBASE_CONFIG, encoding="utf-8") as handle:
            firebase_config = json.load(handle)
    except (OSError, ValueError) as error:
        log.error("configuração do Firebase ilegível: %s", error)
        return 1
    agent = Agent(Storage(), firebase_config)
    # SIGUSR1 vem do NetworkManager quando a rede volta.
    signal.signal(signal.SIGUSR1, lambda *_: agent.restart_connection("rede mudou"))
    agent.run()
    return 0
