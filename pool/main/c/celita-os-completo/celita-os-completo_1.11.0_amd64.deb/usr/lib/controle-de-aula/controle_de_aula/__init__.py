"""Agente do Controle de Aula para o Celita OS.

Fala o protocolo v4 (Firebase RTDB, E2E X25519/AES-GCM) com o app do professor,
fora do navegador: sobe no boot, independe de login e de janela aberta.
"""

VERSION = "0.6.0"
