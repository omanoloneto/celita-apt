"""Mesma autorização no lançador e no agente; a identidade vem do kernel."""

import grp
import os
import pwd

CONTROLLED_GROUP = "nopasswdlogin"
ADMIN_GROUPS = ("sudo", "admin")


def groups_for_uid(uid: int) -> set[str]:
    try:
        user = pwd.getpwuid(uid)
        gids = set(os.getgrouplist(user.pw_name, user.pw_gid))
        return {group.gr_name for group in grp.getgrall() if group.gr_gid in gids}
    except (KeyError, OSError):
        return set()


def can_manage(uid: int) -> bool:
    if uid == 0:
        return True
    groups = groups_for_uid(uid)
    return CONTROLLED_GROUP not in groups and bool(groups.intersection(ADMIN_GROUPS))


def can_bridge(uid: int) -> bool:
    return uid == 0 or CONTROLLED_GROUP in groups_for_uid(uid)
