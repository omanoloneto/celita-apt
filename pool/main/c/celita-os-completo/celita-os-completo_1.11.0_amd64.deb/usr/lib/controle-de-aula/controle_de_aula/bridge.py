"""Ponte com a extensão no Voges: um socket Unix, mensagens JSON por linha.

O navegador fala com o host de native messaging (browser-bridge), que corre
como o usuário da sessão e repassa tudo para cá. O agente só aceita a ponte
cujo uid é o da sessão controlada ativa; qualquer outra é ignorada.
"""

import json
import logging
import os
import socket
import struct
import threading
import time
import uuid

log = logging.getLogger("controle-de-aula.bridge")

SOCKET_PATH = "/run/controle-de-aula/bridge.sock"
ADMIN_SOCKET_PATH = "/run/controle-de-aula/admin.sock"
EXEC_TIMEOUT_S = 15
REPORT_FRESH_S = 60


class BridgeClient:
    def __init__(self, connection: socket.socket, uid: int):
        self.connection = connection
        self.uid = uid
        self.version = None
        self.last_report = None
        self.last_report_at = 0.0
        self._pending = {}
        self._write_lock = threading.Lock()
        self.alive = True

    def send(self, message: dict) -> bool:
        data = (json.dumps(message, ensure_ascii=False) + "\n").encode("utf-8")
        with self._write_lock:
            try:
                self.connection.sendall(data)
                return True
            except OSError:
                self.alive = False
                return False

    def exec(self, command: str, payload) -> dict:
        request_id = uuid.uuid4().hex
        event = threading.Event()
        slot = {"event": event, "result": None}
        self._pending[request_id] = slot
        if not self.send({"t": "exec", "id": request_id, "cmd": command, "payload": payload}):
            self._pending.pop(request_id, None)
            return {"ok": False, "error": "ponte_caiu"}
        if not event.wait(EXEC_TIMEOUT_S):
            self._pending.pop(request_id, None)
            return {"ok": False, "error": "ponte_sem_resposta"}
        result = slot["result"]
        return result if isinstance(result, dict) else {"ok": False, "error": "resposta_invalida"}

    def resolve(self, request_id: str, result):
        slot = self._pending.pop(request_id, None)
        if slot:
            slot["result"] = result
            slot["event"].set()

    def report_is_fresh(self) -> bool:
        return self.last_report is not None and time.monotonic() - self.last_report_at < REPORT_FRESH_S

    def close(self):
        self.alive = False
        try:
            self.connection.close()
        except OSError:
            pass


class BridgeServer:
    """Aceita pontes e entrega as mensagens delas ao agente por callbacks."""

    def __init__(self, on_request, group_gid: int | None, *,
                 socket_path=SOCKET_PATH, mode=0o660, authorize=None,
                 max_message_bytes=16 * 1024 * 1024):
        self.on_request = on_request  # (client, message) -> None
        self.group_gid = group_gid
        self.socket_path = socket_path
        self.mode = mode
        self.authorize = authorize or (lambda uid: uid == 0)
        self.max_message_bytes = max_message_bytes
        self.clients = []
        self._lock = threading.Lock()
        self._server = None
        self._closed = threading.Event()

    def start(self):
        directory = os.path.dirname(self.socket_path)
        os.makedirs(directory, mode=0o755, exist_ok=True)
        os.chmod(directory, 0o755)
        try:
            os.unlink(self.socket_path)
        except FileNotFoundError:
            pass
        server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        server.bind(self.socket_path)
        os.chmod(self.socket_path, self.mode)
        if self.group_gid is not None:
            os.chown(self.socket_path, 0, self.group_gid)
        server.listen(8)
        self._server = server
        threading.Thread(target=self._accept_loop, name="bridge-accept", daemon=True).start()

    def _accept_loop(self):
        while not self._closed.is_set():
            try:
                connection, _ = self._server.accept()
            except OSError:
                if self._closed.is_set():
                    return
                time.sleep(1)
                continue
            uid = _peer_uid(connection)
            if uid is None or not self.authorize(uid):
                connection.close()
                continue
            client = BridgeClient(connection, uid)
            with self._lock:
                self.clients.append(client)
            threading.Thread(
                target=self._client_loop, args=(client,), name=f"bridge-{uid}", daemon=True
            ).start()

    def stop(self):
        self._closed.set()
        if self._server:
            try:
                self._server.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            self._server.close()
        with self._lock:
            clients = list(self.clients)
        for client in clients:
            client.close()

    def _client_loop(self, client: BridgeClient):
        buffer = b""
        try:
            while client.alive:
                chunk = client.connection.recv(65536)
                if not chunk:
                    break
                buffer += chunk
                if len(buffer) > self.max_message_bytes:
                    break
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    if not line.strip():
                        continue
                    try:
                        message = json.loads(line.decode("utf-8"))
                    except (ValueError, UnicodeDecodeError):
                        continue
                    if isinstance(message, dict):
                        self._handle(client, message)
        except OSError:
            pass
        finally:
            client.close()
            with self._lock:
                if client in self.clients:
                    self.clients.remove(client)
            log.info("ponte do uid %s encerrada", client.uid)

    def _handle(self, client: BridgeClient, message: dict):
        # Revalida também conexões antigas após uma alteração de grupos.
        if not self.authorize(client.uid):
            client.close()
            return
        kind = message.get("t")
        if kind == "hello":
            client.version = str(message.get("ver") or "")[:20]
            log.info("ponte do uid %s conectada (extensão %s)", client.uid, client.version)
        elif kind == "res":
            client.resolve(str(message.get("id")), message.get("res"))
            return
        elif kind == "report":
            report = message.get("report")
            if isinstance(report, dict):
                client.last_report = report
                client.last_report_at = time.monotonic()
        self.on_request(client, message)

    def client_for_uid(self, uid: int) -> BridgeClient | None:
        with self._lock:
            # A mais recente vence: um Voges reaberto substitui a ponte antiga.
            for client in reversed(self.clients):
                if client.uid == uid and client.alive:
                    return client
        return None

    def broadcast(self, message: dict):
        with self._lock:
            clients = list(self.clients)
        for client in clients:
            if self.authorize(client.uid):
                client.send(message)
            else:
                client.close()


def _peer_uid(connection: socket.socket) -> int | None:
    try:
        creds = connection.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, struct.calcsize("3i"))
    except OSError:
        return None
    _pid, uid, _gid = struct.unpack("3i", creds)
    return uid
