"""Mensagens do protocolo v4 e seus limites, espelho de protocol.js e rules.js."""

import math
from urllib.parse import urlsplit

PROTOCOL_VERSION = 1

OPEN_URL = "open_url"
ACK = "ack"
TAB_REPORT = "tab_report"
CLOSE_TABS = "close_tabs"
CLOSE_ALL_TABS = "close_all_tabs"
SET_RULES = "set_rules"
SET_WALLPAPER = "set_wallpaper"
SHOW_MESSAGE = "show_message"
SET_CLASS_VIEW = "set_class_view"
SET_UNIT = "set_unit"
CAPTURE_CAMERA = "capture_camera"
CAMERA_SNAPSHOT = "camera_snapshot"
CAPTURE_SCREEN = "capture_screen"
SCREEN_SNAPSHOT = "screen_snapshot"

MAX_REPORT_TABS = 30
MAX_REPORT_EVENTS = 20
MAX_REPORT_URL = 300
MAX_REPORT_TITLE = 120
MAX_REPORT_APPS = 30
MAX_REPORT_APP_NAME = 40
MAX_REPORT_USER = 32

MAX_RULES = 1000
MAX_RULE_PATTERN = 200

MAX_CLASSVIEW_PCS = 60
MAX_CLASSVIEW_NOME = 40
MAX_CLASSVIEW_ALUNO = 60
MAX_CLASSVIEW_TURMA = 60
MAX_CLASSVIEW_TITULO = 120
MAX_CLASSVIEW_DOMINIO = 100

MAX_MESSAGE_TITLE = 100
MAX_MESSAGE_BODY = 500
MAX_MESSAGE_FROM = 60


def _cut(value, limit: int) -> str:
    return "" if value is None else str(value)[:limit]


def is_safe_http_url(url) -> bool:
    if not isinstance(url, str):
        return False
    try:
        parts = urlsplit(url)
    except ValueError:
        return False
    return parts.scheme in ("http", "https") and bool(parts.netloc)


def make_qr_payload(device_id: str, pub: str, token: str, label: str) -> dict:
    return {"v": 4, "id": device_id, "pub": pub, "tok": token, "label": label or ""}


def make_tab_report(tabs, events, apps=None, user=None) -> dict:
    tabs = [t for t in (tabs or []) if isinstance(t, dict) and is_safe_http_url(t.get("url"))]
    events = [e for e in (events or []) if isinstance(e, dict) and is_safe_http_url(e.get("url"))]
    report = {
        "v": PROTOCOL_VERSION,
        "type": TAB_REPORT,
        "tabs": [
            {
                "url": _cut(t.get("url"), MAX_REPORT_URL),
                "title": _cut(t.get("title"), MAX_REPORT_TITLE),
                "active": t.get("active") is True,
            }
            for t in tabs[:MAX_REPORT_TABS]
        ],
        "events": [
            {
                "url": _cut(e.get("url"), MAX_REPORT_URL),
                "title": _cut(e.get("title"), MAX_REPORT_TITLE),
                "ts": e.get("ts") if isinstance(e.get("ts"), (int, float)) else 0,
            }
            for e in events[-MAX_REPORT_EVENTS:]
        ],
    }
    # Campos além do que a extensão manda: o app ignora chaves desconhecidas.
    if apps is not None:
        report["apps"] = [
            {
                "name": _cut(a.get("name"), MAX_REPORT_APP_NAME),
                "title": _cut(a.get("title"), MAX_REPORT_TITLE),
            }
            for a in apps[:MAX_REPORT_APPS]
            if isinstance(a, dict)
        ]
    if user:
        report["user"] = _cut(user, MAX_REPORT_USER)
    return report


def normalize_pattern(pattern) -> str:
    text = ("" if pattern is None else str(pattern)).strip().lower()
    if text.startswith("http://"):
        text = text[7:]
    elif text.startswith("https://"):
        text = text[8:]
    slash = text.find("/")
    host = text if slash == -1 else text[:slash]
    rest = "" if slash == -1 else text[slash:]
    colon = host.find(":")
    if colon != -1:
        host = host[:colon]
    return (host + rest).rstrip("/")[:MAX_RULE_PATTERN]


def host_matches(host: str, pattern: str) -> bool:
    return host == pattern or host.endswith("." + pattern)


def rule_matches(pattern, url) -> bool:
    if not pattern or not is_safe_http_url(url):
        return False
    parts = urlsplit(url)
    host = (parts.hostname or "").lower()
    slash = pattern.find("/")
    if slash == -1:
        return host_matches(host, pattern)
    return host_matches(host, pattern[:slash]) and (parts.path or "/").lower().startswith(
        pattern[slash:]
    )


def clean_rules(rules) -> list:
    cleaned = []
    for rule in rules if isinstance(rules, list) else []:
        pattern = rule.get("pattern") if isinstance(rule, dict) else None
        if isinstance(pattern, str) and pattern:
            cleaned.append({"pattern": pattern[:MAX_RULE_PATTERN]})
        if len(cleaned) >= MAX_RULES:
            break
    return cleaned


def _positive_number(value) -> bool:
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value)
        and value > 0
    )


def parse_class_view(payload):
    if not isinstance(payload, dict):
        return None
    rev = payload.get("rev")
    if not _positive_number(rev) or not isinstance(payload.get("pcs"), list):
        return None
    aula_raw = payload.get("aula") if isinstance(payload.get("aula"), dict) else {}
    aula = {"ativa": aula_raw.get("ativa") is True}
    if aula["ativa"] and isinstance(aula_raw.get("turma"), str):
        aula["turma"] = _cut(aula_raw["turma"], MAX_CLASSVIEW_TURMA)
    pcs = []
    for pc in payload["pcs"]:
        if not isinstance(pc, dict) or not isinstance(pc.get("nome"), str):
            continue
        item = {"nome": _cut(pc["nome"], MAX_CLASSVIEW_NOME), "online": pc.get("online") is True}
        if isinstance(pc.get("aluno"), str):
            item["aluno"] = _cut(pc["aluno"], MAX_CLASSVIEW_ALUNO)
        aba = pc.get("aba")
        if isinstance(aba, dict) and isinstance(aba.get("dominio"), str):
            item["aba"] = {
                "titulo": _cut(aba.get("titulo"), MAX_CLASSVIEW_TITULO),
                "dominio": _cut(aba["dominio"], MAX_CLASSVIEW_DOMINIO),
            }
        if isinstance(pc.get("alerta"), str):
            item["alerta"] = _cut(pc["alerta"], MAX_CLASSVIEW_DOMINIO)
        pcs.append(item)
        if len(pcs) >= MAX_CLASSVIEW_PCS:
            break
    return {"rev": rev, "aula": aula, "pcs": pcs}
