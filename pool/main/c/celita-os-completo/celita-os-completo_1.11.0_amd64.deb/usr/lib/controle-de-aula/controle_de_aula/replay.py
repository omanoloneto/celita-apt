"""Anti-replay por épocas de sessão (sid/seq), idêntico a replay.js."""

import math

TS_SKEW_MS = 120000


def _finite(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


class ReplayGuard:
    def __init__(self, max_age_ms: int = TS_SKEW_MS, last_sid: int = 0, last_seq: int = 0):
        self.max_age_ms = max_age_ms
        self.last_sid = last_sid
        self.last_seq = last_seq

    def accept(self, sid, seq, ts, now_ms) -> bool:
        if not (_finite(sid) and _finite(seq) and _finite(ts)):
            return False
        if ts < now_ms - self.max_age_ms:
            return False
        if ts > now_ms + TS_SKEW_MS:
            return False
        if sid > self.last_sid:
            self.last_sid = sid
            self.last_seq = seq
            return True
        if sid == self.last_sid and seq > self.last_seq:
            self.last_seq = seq
            return True
        return False

    def to_json(self) -> dict:
        return {"sid": self.last_sid, "seq": self.last_seq}

    @classmethod
    def from_json(cls, data, max_age_ms: int = TS_SKEW_MS) -> "ReplayGuard":
        data = data if isinstance(data, dict) else {}
        return cls(
            max_age_ms=max_age_ms,
            last_sid=_number(data.get("sid")),
            last_seq=_number(data.get("seq")),
        )


def _number(value) -> int:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return 0
    return int(number) if math.isfinite(number) else 0
