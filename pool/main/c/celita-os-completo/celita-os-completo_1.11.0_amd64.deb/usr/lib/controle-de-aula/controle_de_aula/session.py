"""Sessão gráfica controlada: quem está logado e como agir dentro dela.

Conta controlada é conta do grupo nopasswdlogin. O agente roda como root e
executa dentro da sessão por runuser, com DISPLAY, XAUTHORITY e o barramento
lidos do processo líder da sessão.
"""

import base64
import grp
import logging
import os
import pwd
import subprocess
import tempfile
import time

log = logging.getLogger("controle-de-aula.session")

CONTROLLED_GROUP = "nopasswdlogin"
SESSION_CACHE_S = 5
COMMAND_TIMEOUT_S = 20
CAMERA_DEVICE = "/dev/video0"
WALLPAPER_PATH = "/var/lib/controle-de-aula/wallpaper.jpg"


class Session:
    def __init__(self, session_id: str, user: str, uid: int, display: str, leader: int):
        self.id = session_id
        self.user = user
        self.uid = uid
        self.display = display
        self.leader = leader
        self.env = self._read_env()

    def _read_env(self) -> dict:
        env = {
            "DISPLAY": self.display or ":0",
            "XAUTHORITY": os.path.join(pwd.getpwnam(self.user).pw_dir, ".Xauthority"),
            "DBUS_SESSION_BUS_ADDRESS": f"unix:path=/run/user/{self.uid}/bus",
        }
        try:
            with open(f"/proc/{self.leader}/environ", "rb") as handle:
                for item in handle.read().split(b"\0"):
                    key, sep, value = item.partition(b"=")
                    if sep and key.decode() in env and value:
                        env[key.decode()] = value.decode("utf-8", "replace")
        except OSError:
            pass
        return env

    def run(self, argv: list, timeout: float = COMMAND_TIMEOUT_S, capture: bool = True):
        command = ["runuser", "-u", self.user, "--", "env"]
        command += [f"{k}={v}" for k, v in self.env.items()]
        command += argv
        return subprocess.run(
            command,
            capture_output=capture,
            timeout=timeout,
            check=False,
            stdin=subprocess.DEVNULL,
        )

    def spawn(self, argv: list):
        command = ["runuser", "-u", self.user, "--", "env"]
        command += [f"{k}={v}" for k, v in self.env.items()]
        command += argv
        subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )


def _controlled_users() -> set:
    try:
        group = grp.getgrnam(CONTROLLED_GROUP)
    except KeyError:
        return set()
    members = set(group.gr_mem)
    for entry in pwd.getpwall():
        if entry.pw_gid == group.gr_gid:
            members.add(entry.pw_name)
    return members


def _loginctl(*args) -> str:
    try:
        return subprocess.run(
            ["loginctl", *args],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        ).stdout
    except (OSError, subprocess.TimeoutExpired):
        return ""


class SessionTracker:
    """Acha a sessão gráfica ativa de uma conta controlada, com cache curto."""

    def __init__(self):
        self._cached = None
        self._cached_at = 0.0

    def active(self) -> Session | None:
        now = time.monotonic()
        if now - self._cached_at < SESSION_CACHE_S:
            return self._cached
        self._cached = self._lookup()
        self._cached_at = now
        return self._cached

    def _lookup(self) -> Session | None:
        controlled = _controlled_users()
        if not controlled:
            return None
        for line in _loginctl("list-sessions", "--no-legend").splitlines():
            fields = line.split()
            if not fields:
                continue
            session_id = fields[0]
            props = _loginctl(
                "show-session", session_id,
                "-p", "Class", "-p", "State", "-p", "Type", "-p", "Name",
                "-p", "User", "-p", "Display", "-p", "Leader",
            )
            values = dict(
                item.split("=", 1) for item in props.splitlines() if "=" in item
            )
            if values.get("Class") != "user" or values.get("State") != "active":
                continue
            if values.get("Type") not in ("x11", "wayland"):
                continue
            user = values.get("Name", "")
            if user not in controlled:
                continue
            try:
                uid = int(values.get("User", ""))
                leader = int(values.get("Leader", ""))
            except ValueError:
                continue
            return Session(session_id, user, uid, values.get("Display", ""), leader)
        return None


# ---- Ações dentro da sessão --------------------------------------------------


def _read_and_remove(path: str) -> bytes | None:
    try:
        with open(path, "rb") as handle:
            return handle.read()
    except OSError:
        return None
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def capture_screen(session: Session) -> dict:
    # O arquivo nasce em um diretório do próprio usuário, porque o scrot roda
    # como ele; a leitura é do root, que apaga em seguida.
    path = f"/run/user/{session.uid}/controle-de-aula-tela.jpg"
    try:
        result = session.run(["scrot", "-o", "-q", "45", path])
    except (OSError, subprocess.TimeoutExpired) as error:
        return {"ok": False, "error": f"tela_{type(error).__name__}"}
    if result.returncode != 0:
        return {"ok": False, "error": "tela_" + result.stderr.decode("utf-8", "replace").strip()[:80]}
    data = _read_and_remove(path)
    if not data:
        return {"ok": False, "error": "tela_vazia"}
    return {"ok": True, "jpegB64": base64.b64encode(data).decode("ascii")}


def capture_camera() -> dict:
    if not os.path.exists(CAMERA_DEVICE):
        return {"ok": False, "error": "camera_ausente"}
    fd, path = tempfile.mkstemp(prefix="controle-de-aula-", suffix=".jpg")
    os.close(fd)
    try:
        result = subprocess.run(
            ["fswebcam", "-q", "-d", CAMERA_DEVICE, "-r", "640x480", "--no-banner",
             "--jpeg", "60", "-S", "3", path],
            capture_output=True,
            timeout=COMMAND_TIMEOUT_S,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        _read_and_remove(path)
        return {"ok": False, "error": f"camera_{type(error).__name__}"}
    data = _read_and_remove(path)
    if result.returncode != 0 or not data:
        return {"ok": False, "error": "camera_falhou"}
    return {"ok": True, "jpegB64": base64.b64encode(data).decode("ascii")}


def list_apps(session: Session) -> list:
    try:
        result = session.run(["wmctrl", "-lp"], timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        return []
    apps = []
    for line in result.stdout.decode("utf-8", "replace").splitlines():
        parts = line.split(None, 4)
        if len(parts) < 5:
            continue
        try:
            pid = int(parts[2])
        except ValueError:
            continue
        try:
            with open(f"/proc/{pid}/comm", encoding="utf-8", errors="replace") as handle:
                name = handle.read().strip()
        except OSError:
            name = "?"
        apps.append({"name": name, "title": parts[4]})
    return apps


def notify(session: Session, title: str, body: str) -> dict:
    try:
        result = session.run(
            ["notify-send", "-a", "Controle de Aula", "-u", "critical",
             "-i", "dialog-information", title, body],
            timeout=10,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        return {"ok": False, "error": f"aviso_{type(error).__name__}"}
    return {"ok": result.returncode == 0, "error": None if result.returncode == 0 else "aviso_falhou"}


def open_browser(session: Session, url: str) -> dict:
    try:
        session.spawn(["voges", url])
    except OSError as error:
        return {"ok": False, "error": f"voges_{type(error).__name__}"}
    return {"ok": True}


def set_wallpaper(session: Session, jpeg: bytes) -> dict:
    # O xfconf é por usuário, então o arquivo fica em lugar legível por todos e
    # cada propriedade last-image do xfce4-desktop aponta para ele.
    try:
        os.makedirs(os.path.dirname(WALLPAPER_PATH), exist_ok=True)
        with open(WALLPAPER_PATH + ".tmp", "wb") as handle:
            handle.write(jpeg)
        os.chmod(WALLPAPER_PATH + ".tmp", 0o644)
        os.replace(WALLPAPER_PATH + ".tmp", WALLPAPER_PATH)
        listing = session.run(["xfconf-query", "-c", "xfce4-desktop", "-l"], timeout=10)
    except (OSError, subprocess.TimeoutExpired) as error:
        return {"ok": False, "error": f"papel_{type(error).__name__}"}
    properties = [
        line.strip()
        for line in listing.stdout.decode("utf-8", "replace").splitlines()
        if line.strip().endswith("/last-image")
    ]
    if not properties:
        return {"ok": False, "error": "papel_sem_monitor"}
    for prop in properties:
        try:
            session.run(["xfconf-query", "-c", "xfce4-desktop", "-p", prop, "-s", WALLPAPER_PATH], timeout=10)
        except (OSError, subprocess.TimeoutExpired):
            return {"ok": False, "error": "papel_xfconf"}
    return {"ok": True}
