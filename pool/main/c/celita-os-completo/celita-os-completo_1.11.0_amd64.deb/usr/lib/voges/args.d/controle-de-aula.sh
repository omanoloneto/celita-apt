# Fragmento sourceado pelo /usr/bin/voges. Conta controlada é conta sem senha:
# o Gerenciador de Usuários põe essas contas no grupo nopasswdlogin, e é ele o
# critério. Quem instala o pacote é o administrador e tem senha, logo fica fora.
if id -Gn 2>/dev/null | tr ' ' '\n' | grep -qx nopasswdlogin; then
    VOGES_EXTENSIONS="$VOGES_EXTENSIONS,/usr/share/controle-de-aula/extension"
fi
