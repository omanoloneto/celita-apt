const form = document.querySelector("#search-form");
const input = document.querySelector("#search-input");

function destination(value) {
  const text = value.trim();
  if (!text) return null;
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) return text;
  if (!text.includes(" ") && (text.includes(".") || text.startsWith("localhost"))) {
    return `https://${text}`;
  }
  return `https://www.google.com/search?q=${encodeURIComponent(text)}`;
}

form.addEventListener("submit", event => {
  event.preventDefault();
  const target = destination(input.value);
  if (target) window.location.assign(target);
});
