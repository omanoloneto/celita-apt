function showVogesOnInitialTab() {
  chrome.tabs.query({}, tabs => {
    for (const tab of tabs) {
      const url = tab.pendingUrl || tab.url || "";
      if (url === "chrome://newtab/" || url.startsWith("chrome://new-tab-page/")) {
        // A extensão pode terminar de carregar depois da primeira aba. Uma
        // recarga curta aplica a substituição sem expor um endereço interno.
        chrome.tabs.update(tab.id, {url: "chrome://newtab/"});
      }
    }
  });
}

showVogesOnInitialTab();
chrome.runtime.onStartup.addListener(showVogesOnInitialTab);
chrome.tabs.onCreated.addListener(tab => {
  const url = tab.pendingUrl || tab.url || "";
  if (url === "chrome://newtab/" || url.startsWith("chrome://new-tab-page/")) {
    chrome.tabs.update(tab.id, {url: "chrome://newtab/"});
  }
});
