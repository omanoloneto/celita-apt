# xfce4-notifyd com botão de fechar

Fonte oficial: https://archive.xfce.org/src/apps/xfce4-notifyd/0.9/xfce4-notifyd-0.9.7.tar.bz2

SHA-256: `170d18fd5f40cce823ffc7ae3d7e21644007c3f45808ab4835f0401d21b3516a`

Licença GPL-2.0-only, conforme COPYING no arquivo original. O tarball preserva
todo o código-fonte correspondente; `close-button.patch` é a alteração Celita.
Ela acrescenta um GtkButton acessível a todas as notificações e emite o mesmo
sinal de descarte nativo, preservando ações, histórico, sons e o serviço D-Bus.
A janela aceita foco por interação, sem solicitar foco ao aparecer.


O build instala `/usr/libexec/celita-notifyd`, sem substituir os arquivos do
Debian. Os arquivos D-Bus em `/usr/local/share` têm precedência sobre `/usr/share`;
o drop-in da unidade `xfce4-notifyd.service` encaminha a ativação systemd ao mesmo
executável. Antes de iniciar o XFCE, `celita-notifications-prepare` cria o override
por usuário do autostart original, evitando iniciar o daemon sem o botão.

Para reproduzir o binário em Debian 13, instale `build-essential pkg-config
libgtk-3-dev libxfce4panel-2.0-dev libxfce4ui-2-dev libxfce4util-dev libxfconf-0-dev
libsqlite3-dev libnotify-dev libcanberra-gtk3-dev libdbus-1-dev gettext`, extraia o
tarball, aplique `patch -p1 < close-button.patch` e execute:

```sh
./configure --prefix=/usr --disable-wayland --enable-x11 --enable-sound \
  --disable-systemd --disable-xdg-autostart --disable-dbus-start-daemon --disable-debug
make -C common
make -C xfce4-notifyd
```

O executável fica em `xfce4-notifyd/xfce4-notifyd`. O script de empacotamento completo
é `packaging/build-notifyd.sh`; fonte, patch, licença e script também acompanham o
`.deb`, em `/usr/share/doc/explorador-de-arquivos/notifyd`.
