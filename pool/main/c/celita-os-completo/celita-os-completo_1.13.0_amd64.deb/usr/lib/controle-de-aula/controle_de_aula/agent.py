"""Laço principal do agente, espelho do offscreen.js da extensão.

Identidade e pareamento vivem aqui; a extensão no Voges é só o braço para
abas. Comandos que dependem da sessão gráfica correm na sessão controlada
ativa, e sem sessão respondem sem_sessao.
"""

import base64
import grp
import json
import logging
import os
import signal
import sys
import threading
import time
import uuid

from . import VERSION, protocol, session as sess
from .access import can_bridge, can_manage
from .bridge import ADMIN_SOCKET_PATH, BridgeServer
from .cloud import CloudClient
from .crypto import (
    derive_session_key,
    generate_private_key,
    new_token,
    private_key_from_b64url,
    private_key_to_b64url,
    public_key_b64url,
)
from .firebase import FirebaseError, FirebaseSession

log = logging.getLogger("controle-de-aula")

STATE_DIR = "/var/lib/controle-de-aula"
STATE_FILE = os.path.join(STATE_DIR, "estado.json")
FIREBASE_CONFIG = "/usr/share/controle-de-aula/firebase.json"
STUCK_CONNECTING_S = 20
MAX_WALLPAPER_BYTES = 10 * 1024 * 1024


class Storage:
    """Estado persistente em um JSON só, gravado atomicamente e legível só por root."""

    def __init__(self, path: str = STATE_FILE):
        self.path = path
        self._lock = threading.Lock()
        self._data = self._load()

    def _load(self) -> dict:
        try:
            with open(self.path, encoding="utf-8") as handle:
                data = json.load(handle)
                return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def get(self, key: str):
        with self._lock:
            return self._data.get(key)

    def set(self, key: str, value):
        with self._lock:
            if value is None:
                self._data.pop(key, None)
            else:
                self._data[key] = value
            os.makedirs(os.path.dirname(self.path), mode=0o700, exist_ok=True)
            temporary = self.path + ".tmp"
            with open(temporary, "w", encoding="utf-8") as handle:
                json.dump(self._data, handle, ensure_ascii=False)
            os.chmod(temporary, 0o600)
            os.replace(temporary, self.path)


class Agent:
    def __init__(self, storage: Storage, firebase_config: dict):
        self.storage = storage
        self.firebase_config = firebase_config
        self.fb = None
        self.identity = None
        self.client = None
        self.bind_watch = None
        self.bind_result = None
        self.bind_event = threading.Event()
        self.sessions = sess.SessionTracker()
        self.state = "connecting"
        self.detail = None
        self.teacher_name = None
        self.state_changed_at = time.monotonic()
        self._restart_requested = threading.Event()
        try:
            gid = grp.getgrnam(sess.CONTROLLED_GROUP).gr_gid
        except KeyError:
            gid = None
        self.bridges = BridgeServer(self._on_bridge_message, gid, authorize=can_bridge)
        self.admins = BridgeServer(self._on_admin_message, None,
                                  socket_path=ADMIN_SOCKET_PATH, mode=0o666,
                                  authorize=can_manage, max_message_bytes=8192)

    # ---- Estado ---------------------------------------------------------------

    def _broadcast(self, state: str, detail=None, teacher=None):
        if detail:
            log.info("%s: %s", state, detail)
        if state != self.state:
            self.state = state
            self.state_changed_at = time.monotonic()
        self.detail = detail
        if teacher:
            self.teacher_name = teacher
        self.bridges.broadcast(self._state_message())
        self._broadcast_admin()

    def _admin_message(self):
        return {"t": "admin-state", "status": self._state_message(),
                "bound": bool(self.storage.get("binding")),
                "pairing": self._pairing_message()["dados"]
                if self.state == "pairing" and not self.storage.get("binding") else None}

    def _broadcast_admin(self):
        self.admins.broadcast(self._admin_message())

    def _state_message(self) -> dict:
        binding = self.storage.get("binding") or {}
        return {
            "t": "state",
            "state": self.state,
            "detail": self.detail,
            "teacher": self.teacher_name,
            "numero": binding.get("numero"),
            "label": self.identity["label"] if self.identity else None,
            "version": VERSION,
        }

    def _pairing_message(self):
        pairing = self.storage.get("pairing") or {}
        if not self.identity or not pairing.get("token"):
            return {"t": "pairing", "dados": None}
        return {
            "t": "pairing",
            "dados": {
                "deviceId": self.identity["deviceId"],
                "pub": self.identity["pub"],
                "token": pairing["token"],
                "label": self.identity["label"],
            },
        }

    # ---- Identidade e Firebase --------------------------------------------------

    def _ensure_identity(self) -> dict:
        if self.identity:
            return self.identity
        saved = self.storage.get("keypair")
        if isinstance(saved, dict) and saved.get("priv"):
            key = private_key_from_b64url(saved["priv"])
            self.identity = {
                "key": key,
                "pub": public_key_b64url(key),
                "deviceId": saved["deviceId"],
                "label": saved.get("label") or "Celita",
            }
            return self.identity
        key = generate_private_key()
        device_id = str(uuid.uuid4())
        label = "Celita-" + device_id[:4]
        self.storage.set("keypair", {
            "priv": private_key_to_b64url(key),
            "deviceId": device_id,
            "label": label,
        })
        self.identity = {"key": key, "pub": public_key_b64url(key), "deviceId": device_id, "label": label}
        return self.identity

    def _ensure_pair_token(self) -> str:
        saved = self.storage.get("pairing")
        if isinstance(saved, dict) and saved.get("token"):
            return saved["token"]
        token = new_token()
        self.storage.set("pairing", {"token": token})
        return token

    def _rotate_token(self) -> str:
        token = new_token()
        self.storage.set("pairing", {"token": token})
        try:
            self.fb.put(f"/devices/{self.identity['deviceId']}/pairing/token", token)
        except Exception as error:  # noqa: BLE001
            log.warning("token não rotacionou no servidor: %s", error)
        return token

    def _ensure_firebase(self) -> FirebaseSession:
        if self.fb and self.fb.id_token:
            return self.fb
        if self.fb:
            self.fb.stop()
        self.fb = FirebaseSession(
            api_key=self.firebase_config["apiKey"],
            database_url=self.firebase_config["databaseURL"],
            load_auth=lambda: self.storage.get("fbauth"),
            save_auth=lambda auth: self.storage.set("fbauth", auth),
        )
        self.fb.sign_in()
        return self.fb

    def _register(self, token: str):
        identity = self.identity
        meta = {
            "uid": self.fb.uid,
            "pub": identity["pub"],
            "label": identity["label"],
            "v": 4,
            "ext": f"celita-{VERSION}",
        }
        try:
            self.fb.patch(f"/devices/{identity['deviceId']}/meta", meta)
        except FirebaseError as error:
            # Rules antigas no console não conhecem meta/ext e negam o PATCH
            # inteiro; ficar sem registrar seria ficar invisível para sempre.
            if error.status != 401:
                raise
            log.warning("rules do Firebase recusam meta/ext; registrando sem a versão")
            meta.pop("ext")
            self.fb.patch(f"/devices/{identity['deviceId']}/meta", meta)
        self.fb.put(f"/devices/{identity['deviceId']}/pairing/token", token)
        self.fb.put(f"/device_uids/{self.fb.uid}", identity["deviceId"])

    def _wait_for_bind(self, token: str):
        if self._restart_requested.is_set() or self.fb is None:
            return None
        self.bind_result = None
        self.bind_event.clear()
        snapshot = {}

        def on_event(event):
            nonlocal snapshot
            if self._restart_requested.is_set() or self.bind_result is not None:
                return
            data = event.get("data")
            path = event.get("path")
            if path == "/":
                if event.get("type") == "patch" and isinstance(data, dict):
                    snapshot.update(data)
                else:
                    snapshot = dict(data) if isinstance(data, dict) else {}
            elif isinstance(path, str) and path.count("/") == 1:
                snapshot[path[1:]] = data
            else:
                return
            if not snapshot:
                self._broadcast("pairing", "aguardando o professor escanear o QR")
                return
            if snapshot.get("token") != token:
                # Vínculo velho no servidor (desvincular sem rede não apaga o
                # nó). Voltar para "pairing" mantém o QR na tela; sem isso a
                # máquina fica presa em "connecting" e não há como parear.
                self._broadcast("pairing", "aguardando o professor escanear o QR")
                return
            uid, pub = snapshot.get("teacherUid"), snapshot.get("teacherPub")
            if not isinstance(uid, str) or not uid or not isinstance(pub, str):
                return
            try:
                # Rejeita uma chave incompleta/inválida antes de persistir o
                # vínculo; o próximo evento pode completar um patch parcial.
                derive_session_key(self.identity["key"], pub)
            except (ValueError, TypeError):
                return
            name = snapshot.get("teacherName")
            name = name.strip() if isinstance(name, str) and name.strip() else "Professor"
            numero = snapshot.get("numero")
            self.bind_result = {
                "teacherUid": uid,
                "teacherPub": pub,
                "teacherName": name,
                "numero": numero if isinstance(numero, int) and not isinstance(numero, bool)
                and 1 <= numero <= 9999 else None,
            }
            # Atualiza a janela ANTES de fechar o stream/rotacionar o token:
            # essas operações de rede não devem deixar um QR já usado na tela.
            self._broadcast("configuring", "configurando o vínculo com o professor", name)
            self.bind_event.set()

        def on_bind_stream_down(reason: str):
            # Com o QR ainda na tela, a queda do stream não muda nada para o
            # professor: o código continua válido. Sair de "pairing" apagaria
            # o QR, e a renovação de token derruba o stream a cada ~55 min.
            if self.state != "pairing":
                self._broadcast("connecting", reason)

        watch = self.fb.stream(
            f"/devices/{self.identity['deviceId']}/bind", on_event,
            on_down=on_bind_stream_down,
        )
        self.bind_watch = watch
        try:
            if not self._restart_requested.is_set():
                self.bind_event.wait()
        finally:
            watch.close()
            self.bind_watch = None
        return None if self._restart_requested.is_set() else self.bind_result

    def _unbind(self):
        if self.client:
            self.client.stop()
        self.storage.set("binding", None)
        self.storage.set("replay", None)
        self.storage.set("classview", None)
        self.teacher_name = None
        if not (self.fb and self.fb.id_token):
            return
        base = f"/devices/{self.identity['deviceId']}"
        for suffix in ("bind", "report", "ack", "presence", "snapshot"):
            try:
                self.fb.delete(f"{base}/{suffix}")
            except Exception:  # noqa: BLE001
                pass
        self._rotate_token()

    def _apply_unit_number(self, numero: int) -> dict:
        # Mesma validação do bind: sem ela um payload torto virava
        # "Unidade None" gravado no disco e publicado no Firebase.
        if not isinstance(numero, int) or isinstance(numero, bool) or not 1 <= numero <= 9999:
            return {"ok": False, "error": "numero_invalido"}
        binding = self.storage.get("binding")
        if isinstance(binding, dict):
            self.storage.set("binding", {**binding, "numero": numero})
        label = f"Unidade {numero}"
        keypair = self.storage.get("keypair")
        if isinstance(keypair, dict):
            self.storage.set("keypair", {**keypair, "label": label})
        self.identity["label"] = label
        try:
            self.fb.patch(f"/devices/{self.identity['deviceId']}/meta", {"label": label})
        except Exception as error:  # noqa: BLE001
            log.warning("label não subiu: %s", error)
        self.bridges.broadcast(self._state_message())
        self._broadcast_admin()
        return {"ok": True}

    def restart_connection(self, reason: str = "reinício pedido"):
        log.info("reconectando: %s", reason)
        self._restart_requested.set()
        if self.fb:
            self.fb.stop()
            self.fb = None
        self.bind_event.set()
        if self.client:
            self.client.stop()

    # ---- Ponte com o navegador --------------------------------------------------

    def _active_bridge(self):
        session = self.sessions.active()
        if not session:
            return None, None
        return session, self.bridges.client_for_uid(session.uid)

    def _on_bridge_message(self, client, message: dict):
        kind = message.get("t")
        if kind == "hello":
            client.send(self._state_message())
            rules = self.storage.get("rules")
            if isinstance(rules, dict):
                client.send({"t": "rules", "rev": rules.get("rev", 0), "rules": rules.get("rules", [])})
            client.send({"t": "classview", "snapshot": self.storage.get("classview")})
        elif kind == "get":
            if message.get("req") != "pairing":
                client.send(self._state_message())
        elif kind == "report":
            if self.client:
                self.client.request_report()
        # A ponte do aluno só executa abas e entrega relatórios. Nunca recebe
        # o token de pareamento nem administra o vínculo.

    def _on_admin_message(self, client, message: dict):
        if not can_manage(client.uid):
            client.close()
            return
        kind = message.get("t")
        if kind in ("hello", "get"):
            client.send(self._admin_message())
        elif kind == "unbind":
            threading.Thread(target=self._unbind_from_admin, daemon=True).start()
        elif kind == "reconnect":
            self.restart_connection("aplicativo do professor")
            self._broadcast("connecting", "reconectando")

    def _unbind_from_admin(self):
        self._unbind()
        self.bind_event.set()
        self._broadcast("pairing", "desvinculado; escaneie o QR para parear de novo")

    # ---- Execução de comandos ---------------------------------------------------

    def _report(self):
        session, bridge = self._active_bridge()
        tabs, events = [], []
        if bridge and bridge.report_is_fresh():
            tabs = bridge.last_report.get("tabs") or []
            events = bridge.last_report.get("events") or []
        apps = sess.list_apps(session) if session else []
        return protocol.make_tab_report(tabs, events, apps=apps, user=session.user if session else None)

    def _execute(self, cmd: dict) -> dict:
        kind = cmd.get("type")
        payload = cmd.get("payload") if isinstance(cmd.get("payload"), dict) else {}
        session, bridge = self._active_bridge()

        if kind == protocol.OPEN_URL:
            url = payload.get("url")
            if not protocol.is_safe_http_url(url):
                return {"ok": False, "error": "url_invalida"}
            if bridge:
                return bridge.exec(kind, payload)
            if session:
                return sess.open_browser(session, url)
            return {"ok": False, "error": "sem_sessao"}

        if kind in (protocol.CLOSE_TABS, protocol.CLOSE_ALL_TABS):
            if bridge:
                return bridge.exec(kind, payload)
            # Navegador fechado: não há aba para fechar, e fechar zero é ok.
            return {"ok": True}

        if kind == protocol.SET_RULES:
            rules = protocol.clean_rules(payload.get("rules"))
            rev = payload.get("rev") if isinstance(payload.get("rev"), (int, float)) else 0
            self.storage.set("rules", {"rev": rev, "rules": rules})
            self.bridges.broadcast({"t": "rules", "rev": rev, "rules": rules})
            return {"ok": True}

        if kind == protocol.SET_CLASS_VIEW:
            snapshot = payload.get("snapshot")
            self.storage.set("classview", {**snapshot, "recebidoEm": int(time.time() * 1000)} if snapshot else None)
            self.bridges.broadcast({"t": "classview", "snapshot": self.storage.get("classview")})
            return {"ok": True}

        if kind == protocol.SET_UNIT:
            return self._apply_unit_number(payload.get("numero"))

        if kind == protocol.SHOW_MESSAGE:
            if bridge:
                return bridge.exec(kind, payload)
            if session:
                title = str(payload.get("title") or "Controle de Aula")[: protocol.MAX_MESSAGE_TITLE]
                body = str(payload.get("body") or "")[: protocol.MAX_MESSAGE_BODY]
                if payload.get("popup") is True and payload.get("de"):
                    title = f"Mensagem de {str(payload['de'])[: protocol.MAX_MESSAGE_FROM]}"
                return sess.notify(session, title, body)
            return {"ok": False, "error": "sem_sessao"}

        if kind == protocol.SET_WALLPAPER:
            if not session:
                return {"ok": False, "error": "sem_sessao"}
            try:
                jpeg = base64.b64decode(payload.get("jpegB64") or "")
            except ValueError:
                return {"ok": False, "error": "blob_invalido"}
            if not jpeg or len(jpeg) > MAX_WALLPAPER_BYTES:
                return {"ok": False, "error": "imagem_grande" if jpeg else "blob_invalido"}
            return sess.set_wallpaper(session, jpeg)

        if kind == protocol.CAPTURE_CAMERA:
            result = sess.capture_camera()
            return {**result, "snapshotType": protocol.CAMERA_SNAPSHOT}

        if kind == protocol.CAPTURE_SCREEN:
            if not session:
                return {"ok": False, "error": "sem_sessao"}
            result = sess.capture_screen(session)
            return {**result, "snapshotType": protocol.SCREEN_SNAPSHOT}

        return {"ok": False, "error": "tipo_desconhecido"}

    # ---- Laço principal -----------------------------------------------------------

    def run(self):
        self.bridges.start()
        self.admins.start()
        threading.Thread(target=self._stuck_watchdog, name="stuck-watchdog", daemon=True).start()
        while True:
            self._restart_requested.clear()
            try:
                self._ensure_identity()
                token = self._ensure_pair_token()
                self._broadcast("connecting", "autenticando no Firebase")
                self._ensure_firebase()
                self._register(token)

                binding = self.storage.get("binding")
                if not (isinstance(binding, dict) and binding.get("teacherPub")):
                    self._broadcast("pairing", "aguardando o professor escanear o QR")
                    self._broadcast_admin()
                    binding = self._wait_for_bind(token)
                    if not binding:
                        continue
                    self.storage.set("binding", binding)
                    self._broadcast("configuring", "preparando este computador para a aula", binding["teacherName"])
                    self._rotate_token()
                    self._broadcast_admin()
                    log.info("pareado com %s", binding["teacherName"])

                if isinstance(binding.get("numero"), int):
                    label = f"Unidade {binding['numero']}"
                    if self.identity["label"] != label:
                        self._apply_unit_number(binding["numero"])

                session_key = derive_session_key(self.identity["key"], binding["teacherPub"])
                # Só o primeiro evento do canal de comandos confirma conexão.
                self._broadcast("connecting", "conectando ao aplicativo do professor", binding["teacherName"])
                self.client = CloudClient(
                    fb=self.fb,
                    device_id=self.identity["deviceId"],
                    session_key=session_key,
                    teacher=binding,
                    on_command=self._execute,
                    get_report=self._report,
                    on_state=lambda ok, detail: self._broadcast(
                        "connected" if ok else "connecting", detail, binding["teacherName"]
                    ),
                    load_replay=lambda: self.storage.get("replay"),
                    save_replay=lambda replay: self.storage.set("replay", replay),
                )
                reason = self.client.run()
                self.client = None
                if reason == "unbound":
                    self._unbind()
                    self._broadcast("pairing", "o professor desvinculou este computador")
                elif reason == "foreign_bind":
                    self._broadcast("connecting", "vínculo divergente no servidor; desvincule pelo Controle de Aula")
                    time.sleep(5)
            except Exception as error:  # noqa: BLE001 - qualquer falha só reinicia o laço
                self._broadcast("connecting", str(error))
                time.sleep(4)

    def _stuck_watchdog(self):
        # Preso em "connecting" por muito tempo é um socket meio-vivo: refaz do zero.
        while True:
            time.sleep(5)
            if self.state in ("connecting", "configuring") and time.monotonic() - self.state_changed_at > STUCK_CONNECTING_S:
                self.state_changed_at = time.monotonic()
                self.restart_connection("preso em connecting")


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(name)s: %(message)s",
        stream=sys.stderr,
    )
    if os.geteuid() != 0:
        log.error("o agente precisa rodar como root")
        return 1
    try:
        with open(FIREBASE_CONFIG, encoding="utf-8") as handle:
            firebase_config = json.load(handle)
    except (OSError, ValueError) as error:
        log.error("configuração do Firebase ilegível: %s", error)
        return 1
    agent = Agent(Storage(), firebase_config)
    # SIGUSR1 vem do NetworkManager quando a rede volta.
    signal.signal(signal.SIGUSR1, lambda *_: agent.restart_connection("rede mudou"))
    agent.run()
    return 0
