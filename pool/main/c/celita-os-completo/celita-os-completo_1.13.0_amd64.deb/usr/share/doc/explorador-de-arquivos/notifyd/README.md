# Notificações e Central Celita

Fonte oficial: https://archive.xfce.org/src/apps/xfce4-notifyd/0.9/xfce4-notifyd-0.9.7.tar.bz2

SHA-256: `170d18fd5f40cce823ffc7ae3d7e21644007c3f45808ab4835f0401d21b3516a`

Licença GPL-2.0-only, conforme COPYING no arquivo original. O tarball preserva
todo o código-fonte correspondente. As alterações Celita são:

- `close-button.patch`: GtkButton acessível para fechar todas as notificações,
  foco somente por interação e integração com o recorte compartilhado dos cantos.
  O build copia `menu/celita-popup.h` como `xfce4-notifyd/celita-popup-shape.h`.
  A superfície usa alpha real com compositor e X Shape sem compositor; a região
  de entrada exclui os cantos transparentes nos dois casos.
- `notification-center.patch`: reutiliza o SQLite e a API de log oficiais para
  manter notificações pendentes, sem outro daemon. Todas as mensagens recebidas
  são registradas, incluindo transientes, silenciadas e recebidas em Não perturbe.
  As preferências de exibição e som continuam sendo respeitadas. Não há poda
  automática das pendentes.

Expirar o toast conserva a mensagem na Central. O X do toast e `Log.Delete` da
Central removem a mesma entrada; `Log.Clear` só é chamado pelo botão Fechar tudo.
Fechar pela aplicação também remove a entrada, inclusive depois do timeout.
Substituições `replaces_id` mantêm um UUID estável durante a execução do daemon e
atualizam a linha em uma operação SQLite. A abertura e a paginação da Central
não marcam como lido nem apagam mensagens. A paginação desempata timestamp por
UUID para não omitir entradas com o mesmo horário.

Uma migração transacional, marcada na tabela `celita_metadata`, converte somente
os registros `is_read` legados (o daemon anterior marcava os fechados assim).
Registros não lidos/expirados são preservados. A migração não se repete nos
reinícios seguintes, nem passa a tratar novas leituras como fechamento.

O SQLite continua entre sessões. As ações só aparecem enquanto a notificação
FDO correspondente está ativa na execução atual do daemon; a mensagem expirada
ou de sessão anterior continua visível e pode ser fechada pela Central.
`org.xfce.Notifyd.ListActive` informa os UUIDs ativos; `Activate(UUID, ação)`
confere a ação no objeto atual antes de emitir o sinal FDO nativo. A Central
usa `org.xfce.Notifyd.Log.List/GetAppIdCounts/Delete/Clear` e acompanha os sinais
do log, sem polling ou processo residente depois de fechar a janela.

O idle que mostra o toast é cancelado ao fechar ou destruir a notificação.
Assim Notify seguido imediatamente de Clear/Delete/CloseNotification não usa
objetos destruídos nem mostra novamente um toast já fechado.

## Empacotamento e reprodução

O build instala `/usr/libexec/celita-notifyd`, sem substituir os arquivos do
Debian. Os arquivos D-Bus em `/usr/local/share` têm precedência sobre `/usr/share`;
o drop-in da unidade `xfce4-notifyd.service` encaminha a ativação systemd ao mesmo
executável. Antes de iniciar o XFCE, `celita-notifications-prepare` cria o override
por usuário do autostart original.

Para reproduzir o binário em Debian 13, instale `build-essential pkg-config
libgtk-3-dev libxfce4panel-2.0-dev libxfce4ui-2-dev libxfce4util-dev libxfconf-0-dev
libsqlite3-dev libnotify-dev libcanberra-gtk3-dev libdbus-1-dev gettext`, extraia o
tarball, aplique os dois patches com `patch -p1`, copie o header compartilhado
para `xfce4-notifyd/celita-popup-shape.h` e execute:

```sh
./configure --prefix=/usr --disable-wayland --enable-x11 --enable-sound \
  --disable-systemd --disable-xdg-autostart --disable-dbus-start-daemon --disable-debug
make -C common
make -C xfce4-notifyd
```

O executável fica em `xfce4-notifyd/xfce4-notifyd`. O script completo é
`packaging/build-notifyd.sh`; fonte, ambos patches, header, licença e script
acompanham o `.deb` em `/usr/share/doc/explorador-de-arquivos/notifyd`.

## Validação local

Em uma sessão XFCE descartável, com `python3-pyatspi`, `python3-xlib`, `xdotool`
e `scrot`, os testes em `visual/tests` verificam o daemon real por D-Bus/AT-SPI:

- `check_notifications.py`: X visível/clicável, foco, teclado, ações FDO e posição
  inferior direita, nos dois temas.
- `check_notification_center.py --disposable-session`: timeout, IDs distintos,
  substituições, fechamento pelos dois X/pela aplicação, DND/transientes,
  ausência de truncamento, ações válidas/obsoletas, Clear e chegadas posteriores,
  paginação com horários iguais e migração/persistência entre reinícios.
- `check_notification_lifetime.py`: rajadas Notify seguidas de fechamento antes
  do idle, com criticals fatais, sem crash nem toast fantasma.

Os testes que limpam o log ou editam o SQLite só devem rodar em perfil descartável.
