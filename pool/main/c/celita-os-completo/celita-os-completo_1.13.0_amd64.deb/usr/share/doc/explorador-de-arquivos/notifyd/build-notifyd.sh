#!/usr/bin/env bash
# Compila o daemon oficial com a Central de Notificações e os popups Celita.
set -Eeuo pipefail

CELITA_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
PACKAGE_ROOT="${1:?Uso: build-notifyd.sh DIRETORIO_DO_PACOTE}"
SOURCE="$CELITA_ROOT/visual/notifyd"
WORK="$(mktemp -d)"
trap 'rm -rf -- "$WORK"' EXIT

printf '%s  %s\n' \
    170d18fd5f40cce823ffc7ae3d7e21644007c3f45808ab4835f0401d21b3516a \
    "$SOURCE/xfce4-notifyd-0.9.7.tar.bz2" | sha256sum --check --status
tar -xjf "$SOURCE/xfce4-notifyd-0.9.7.tar.bz2" -C "$WORK"
cd "$WORK/xfce4-notifyd-0.9.7"
install -m0644 "$CELITA_ROOT/menu/celita-popup.h" xfce4-notifyd/celita-popup-shape.h
patch --batch --forward -p1 < "$SOURCE/close-button.patch"
patch --batch --forward -p1 < "$SOURCE/notification-center.patch"
# /usr preserva os temas e as traduções do pacote Debian. Não fazemos make
# install: somente o daemon modificado é instalado, em um caminho exclusivo.
./configure --prefix=/usr --disable-wayland --enable-x11 --enable-sound \
    --disable-systemd --disable-xdg-autostart --disable-dbus-start-daemon \
    --disable-debug > "$WORK/configure.log" 2>&1 || {
    cat "$WORK/configure.log" >&2
    exit 1
}
make -C common -j"${CELITA_BUILD_JOBS:-2}" > "$WORK/build.log" 2>&1 && \
make -C xfce4-notifyd -j"${CELITA_BUILD_JOBS:-2}" >> "$WORK/build.log" 2>&1 || {
    cat "$WORK/build.log" >&2
    exit 1
}
install -Dm0755 xfce4-notifyd/xfce4-notifyd "$PACKAGE_ROOT/usr/libexec/celita-notifyd"
strip --strip-unneeded "$PACKAGE_ROOT/usr/libexec/celita-notifyd"
install -Dm0755 "$SOURCE/celita-notifications-prepare" \
    "$PACKAGE_ROOT/usr/libexec/celita-notifications-prepare"

# O diretório local tem precedência no barramento de sessão. O drop-in também
# cobre quem inicia a unidade original diretamente, sem substituir o Debian.
mkdir -p "$PACKAGE_ROOT/usr/local/share/dbus-1/services" \
    "$PACKAGE_ROOT/usr/lib/systemd/user/xfce4-notifyd.service.d"
for bus_name in org.freedesktop.Notifications org.xfce.Notifyd; do
    cat > "$PACKAGE_ROOT/usr/local/share/dbus-1/services/$bus_name.service" <<EOF
[D-BUS Service]
Name=$bus_name
Exec=/usr/libexec/celita-notifyd
SystemdService=xfce4-notifyd.service
EOF
done
cat > "$PACKAGE_ROOT/usr/lib/systemd/user/xfce4-notifyd.service.d/50-celita.conf" <<'EOF'
[Service]
ExecStart=
ExecStart=/usr/libexec/celita-notifyd
EOF

# GPL: o pacote leva a fonte correspondente, a alteração e instruções de build.
DOC="$PACKAGE_ROOT/usr/share/doc/explorador-de-arquivos/notifyd"
mkdir -p "$DOC"
install -m0644 "$SOURCE/xfce4-notifyd-0.9.7.tar.bz2" "$SOURCE/close-button.patch" \
    "$SOURCE/notification-center.patch" "$SOURCE/README.md" COPYING "$DOC/"
install -m0644 "$CELITA_ROOT/packaging/build-notifyd.sh" "$DOC/"
install -m0644 "$CELITA_ROOT/menu/celita-popup.h" "$DOC/celita-popup-shape.h"
