/* Superfície GTK compartilhada com o notifyd. Sem bibliotecas além de GTK/Cairo. */
#ifndef CELITA_POPUP_H
#define CELITA_POPUP_H
#include <gtk/gtk.h>

typedef struct {
    gdouble radius;
    gint width, height, composited;
} CelitaPopupShape;

static void celita_popup_path(cairo_t *cr, gint width, gint height, gdouble radius)
{
    const gdouble pi = G_PI;
    radius = MIN(radius, MIN(width / 2.0, height / 2.0));
    cairo_new_sub_path(cr);
    cairo_arc(cr, width - radius, radius, radius, -pi / 2, 0);
    cairo_arc(cr, width - radius, height - radius, radius, 0, pi / 2);
    cairo_arc(cr, radius, height - radius, radius, pi / 2, pi);
    cairo_arc(cr, radius, radius, radius, pi, 3 * pi / 2);
    cairo_close_path(cr);
}

static void celita_popup_shape_update_full(GtkWidget *widget, gboolean force)
{
    GdkWindow *native = gtk_widget_get_window(widget);
    if (!native)
        return;
    CelitaPopupShape *shape = g_object_get_data(G_OBJECT(widget), "celita-popup-shape");
    gint width = gtk_widget_get_allocated_width(widget), height = gtk_widget_get_allocated_height(widget);
    gboolean composited = gdk_screen_is_composited(gtk_widget_get_screen(widget));
    gboolean changed = shape->width != width || shape->height != height || shape->composited != composited;
    if (!changed && !force)
        return;
    shape->width = width; shape->height = height; shape->composited = composited;
    gdouble radius = MIN(shape->radius, MIN(width / 2.0, height / 2.0));
    cairo_rectangle_int_t full = {0, 0, width, height};
    cairo_region_t *region = cairo_region_create_rectangle(&full);
    for (gint y = 0; y < radius; y++) {
        gint inset = 0;
        while ((inset + .5 - radius) * (inset + .5 - radius) +
               (y + .5 - radius) * (y + .5 - radius) > radius * radius)
            inset++;
        if (!inset)
            continue;
        cairo_rectangle_int_t corners[] = {{0, y, inset, 1}, {width - inset, y, inset, 1},
            {0, height - y - 1, inset, 1}, {width - inset, height - y - 1, inset, 1}};
        for (guint i = 0; i < G_N_ELEMENTS(corners); i++)
            cairo_region_subtract_rectangle(region, &corners[i]);
    }
    gdk_window_input_shape_combine_region(native, region, 0, 0);
    gdk_window_shape_combine_region(native, composited ? NULL : region, 0, 0);
    cairo_region_destroy(region);
    if (changed)
        gtk_widget_queue_draw(widget);
}

static void celita_popup_shape_update(GtkWidget *widget)
{
    celita_popup_shape_update_full(widget, FALSE);
}

static void celita_popup_shape_size(GtkWidget *widget, GtkAllocation *allocation, gpointer data)
{
    (void)allocation; (void)data;
    celita_popup_shape_update(widget);
}

static void celita_popup_shape_screen(GdkScreen *screen, GtkWidget *widget)
{
    (void)screen;
    celita_popup_shape_update(widget);
}

static gboolean celita_popup_clear(GtkWidget *widget, cairo_t *cr, gpointer data)
{
    (void)widget; (void)data;
    cairo_save(cr);
    cairo_set_operator(cr, CAIRO_OPERATOR_CLEAR);
    cairo_paint(cr);
    cairo_restore(cr);
    return FALSE;
}

static gboolean celita_popup_corners(GtkWidget *widget, cairo_t *cr, gpointer data)
{
    (void)data;
    CelitaPopupShape *shape = g_object_get_data(G_OBJECT(widget), "celita-popup-shape");
    gint width = gtk_widget_get_allocated_width(widget), height = gtk_widget_get_allocated_height(widget);
    cairo_save(cr);
    cairo_set_operator(cr, CAIRO_OPERATOR_CLEAR);
    cairo_set_fill_rule(cr, CAIRO_FILL_RULE_EVEN_ODD);
    cairo_rectangle(cr, 0, 0, width, height);
    celita_popup_path(cr, width, height, shape->radius);
    cairo_fill(cr);
    cairo_restore(cr);
    /* GtkWindow atualiza a região de entrada durante o próprio desenho. */
    celita_popup_shape_update_full(widget, TRUE);
    return FALSE;
}

static inline void celita_popup_configure(GtkWidget *widget, gdouble radius)
{
    if (g_object_get_data(G_OBJECT(widget), "celita-popup-shape"))
        return;
    CelitaPopupShape *shape = g_new0(CelitaPopupShape, 1);
    shape->radius = radius;
    shape->composited = -1;
    g_object_set_data_full(G_OBJECT(widget), "celita-popup-shape", shape, g_free);
    GdkScreen *screen = gtk_widget_get_screen(widget);
    GdkVisual *visual = gdk_screen_get_rgba_visual(screen);
    if (visual)
        gtk_widget_set_visual(widget, visual);
    g_signal_connect(widget, "realize", G_CALLBACK(celita_popup_shape_update), NULL);
    g_signal_connect(widget, "size-allocate", G_CALLBACK(celita_popup_shape_size), NULL);
    g_signal_connect(widget, "draw", G_CALLBACK(celita_popup_clear), NULL);
    g_signal_connect_after(widget, "draw", G_CALLBACK(celita_popup_corners), NULL);
    g_signal_connect_object(screen, "composited-changed", G_CALLBACK(celita_popup_shape_screen), widget, 0);
}
#endif
