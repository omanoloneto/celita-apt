// A nova aba mostra o que o professor configurou no app Controle de Aula:
// título, busca e atalhos. A configuração é lida do mesmo nó público que a
// página escolacelita.com/home usa, com cache local para abrir sem rede.
const CONFIG_URL = "https://controle-de-aula-f53bd-default-rtdb.firebaseio.com/home/escola.json";
const CACHE_KEY = "celita-home-config";
const MAX_ATALHOS = 12;
const MAX_LABEL = 24;
const MAX_TITULO = 20;
const BUSCADORES = {
  google: "https://www.google.com/search?q=",
  duckduckgo: "https://duckduckgo.com/?q=",
};
const PADRAO = {
  titulo: "Navegador Voges",
  busca: true,
  buscador: "google",
  atalhos: [
    {label: "Pesquisar", url: "https://www.google.com/"},
    {label: "YouTube", url: "https://www.youtube.com/"},
    {label: "Wikipédia", url: "https://pt.wikipedia.org/"},
  ],
};
// Cores dos quadradinhos sem marca conhecida, escolhidas pela primeira letra.
const CORES = ["#1a73e8", "#d93025", "#188038", "#e37400", "#9334e6", "#0b8043"];

// A configuração vem de um banco que o professor escreve: tudo é tratado como
// texto de fora. Só http(s) vira link e rótulo nunca vira HTML.
function sanitizeAtalho(bruto) {
  if (!bruto || typeof bruto !== "object" || typeof bruto.url !== "string") return null;
  let destino;
  try {
    destino = new URL(bruto.url);
  } catch {
    return null;
  }
  if (destino.protocol !== "https:" && destino.protocol !== "http:") return null;
  const nome = typeof bruto.label === "string" && bruto.label.trim() ? bruto.label.trim() : destino.hostname;
  return {label: nome.slice(0, MAX_LABEL), url: destino.href};
}

function sanitizeConfig(bruto) {
  if (!bruto || typeof bruto !== "object") return null;
  const atalhos = Array.isArray(bruto.atalhos)
    ? bruto.atalhos.map(sanitizeAtalho).filter(Boolean).slice(0, MAX_ATALHOS)
    : [];
  const titulo = typeof bruto.titulo === "string" && bruto.titulo.trim()
    ? bruto.titulo.trim().slice(0, MAX_TITULO)
    : PADRAO.titulo;
  return {
    titulo,
    busca: bruto.busca !== false,
    buscador: bruto.buscador === "duckduckgo" ? "duckduckgo" : "google",
    atalhos,
  };
}

let atual = PADRAO;

function destination(value, config = atual) {
  const text = value.trim();
  if (!text) return null;
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) return text;
  if (!text.includes(" ") && (text.includes(".") || text.startsWith("localhost"))) {
    return `https://${text}`;
  }
  return BUSCADORES[config.buscador] + encodeURIComponent(text);
}

function render(config) {
  atual = config;
  const titulo = document.getElementById("voges-title");
  if (titulo) titulo.textContent = config.titulo;
  const form = document.getElementById("search-form");
  if (form) form.hidden = !config.busca;
  const grade = document.getElementById("favorite-grid");
  if (!grade) return;
  grade.textContent = "";
  for (const atalho of config.atalhos) {
    const link = document.createElement("a");
    link.className = "favorite";
    link.href = atalho.url;
    const tile = document.createElement("span");
    tile.className = "tile letter-tile";
    tile.style.background = CORES[atalho.label.charCodeAt(0) % CORES.length];
    tile.textContent = atalho.label.charAt(0).toUpperCase();
    const nome = document.createElement("span");
    nome.textContent = atalho.label;
    link.append(tile, nome);
    grade.appendChild(link);
  }
}

// Ordem: cache primeiro, para abrir na hora e sem rede; a busca no banco vem
// depois e só redesenha se algo mudou.
function init() {
  if (typeof document.getElementById !== "function") return;
  const storage = typeof chrome !== "undefined" && chrome.storage ? chrome.storage.local : null;
  if (storage) {
    storage.get(CACHE_KEY, guardado => {
      const config = sanitizeConfig(guardado && guardado[CACHE_KEY]);
      if (config) render(config);
    });
  }
  if (typeof fetch !== "function") return;
  fetch(CONFIG_URL, {cache: "no-store"})
    .then(resposta => (resposta.ok ? resposta.json() : null))
    .then(dados => {
      if (!dados || typeof dados.cfg !== "string") return;
      const config = sanitizeConfig(JSON.parse(dados.cfg));
      if (!config) return;
      render(config);
      if (storage) storage.set({[CACHE_KEY]: config});
    })
    .catch(() => {
      // sem rede: fica o que já está na tela
    });
}

const form = document.querySelector("#search-form");
const input = document.querySelector("#search-input");

form.addEventListener("submit", event => {
  event.preventDefault();
  const target = destination(input.value);
  if (target) window.location.assign(target);
});

init();
