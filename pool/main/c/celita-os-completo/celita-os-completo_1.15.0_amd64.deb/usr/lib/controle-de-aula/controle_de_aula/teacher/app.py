"""Janela do professor: Aula (PCs), Sites (regras e página inicial) e Ajustes
(papel de parede, conta Google, escola). Widgets padrão do GTK — o tema do
Celita cuida do visual — e toda rede fora da thread da interface."""

import threading

from .controller import TeacherController
from .rules import ALERT, BLOCK
from .home import SEARCH_DUCKDUCKGO, SEARCH_GOOGLE

WALLPAPER_MAX_SIDE = 1920
WALLPAPER_QUALITY = "85"
WEBCAM_SCAN_ATTEMPTS = 12


def main():
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import GdkPixbuf, Gio, GLib, Gtk, Pango

    def run_async(work, done):
        def runner():
            try:
                result = work()
            except Exception as error:  # noqa: BLE001
                result = error
            GLib.idle_add(done, result)
        threading.Thread(target=runner, daemon=True).start()

    def label(text, size=13, bold=False, dim=False, xalign=0):
        widget = Gtk.Label(label=text, xalign=xalign)
        widget.set_line_wrap(True)
        widget.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        attributes = Pango.AttrList()
        attributes.insert(Pango.attr_size_new_absolute(size * Pango.SCALE))
        if bold:
            attributes.insert(Pango.attr_weight_new(Pango.Weight.SEMIBOLD))
        widget.set_attributes(attributes)
        if dim:
            widget.get_style_context().add_class("dim-label")
        return widget

    def section(title):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.pack_start(label(title, 15, bold=True), False, False, 0)
        return box

    def frame(child):
        holder = Gtk.Frame()
        holder.add(child)
        return holder

    def entry(placeholder, width=24):
        widget = Gtk.Entry()
        widget.set_placeholder_text(placeholder)
        widget.set_width_chars(width)
        return widget

    def ask(parent, title, fields, accept="Salvar"):
        """Diálogo com entradas; devolve lista de textos ou None."""
        dialog = Gtk.Dialog(title=title, transient_for=parent, modal=True)
        dialog.add_button("Cancelar", Gtk.ResponseType.CANCEL)
        dialog.add_button(accept, Gtk.ResponseType.ACCEPT)
        dialog.set_default_response(Gtk.ResponseType.ACCEPT)
        grid = Gtk.Grid(row_spacing=12, column_spacing=12, border_width=24)
        entries = []
        for row, (caption, initial) in enumerate(fields):
            grid.attach(label(caption), 0, row, 1, 1)
            widget = Gtk.Entry(text=initial or "")
            widget.set_width_chars(36)
            widget.set_activates_default(True)
            grid.attach(widget, 1, row, 1, 1)
            entries.append(widget)
        dialog.get_content_area().add(grid)
        dialog.show_all()
        response = dialog.run()
        values = [widget.get_text() for widget in entries]
        dialog.destroy()
        return values if response == Gtk.ResponseType.ACCEPT else None

    def confirm(parent, title, body, accept):
        dialog = Gtk.MessageDialog(transient_for=parent, modal=True, message_type=Gtk.MessageType.QUESTION,
                                   buttons=Gtk.ButtonsType.NONE, text=title)
        dialog.format_secondary_text(body)
        dialog.add_button("Cancelar", Gtk.ResponseType.CANCEL)
        dialog.add_button(accept, Gtk.ResponseType.ACCEPT)
        response = dialog.run()
        dialog.destroy()
        return response == Gtk.ResponseType.ACCEPT

    def notice(parent, text, error=False):
        dialog = Gtk.MessageDialog(transient_for=parent, modal=True,
                                   message_type=Gtk.MessageType.ERROR if error else Gtk.MessageType.INFO,
                                   buttons=Gtk.ButtonsType.OK, text=text)
        dialog.run()
        dialog.destroy()

    def image_to_jpeg(path: str) -> bytes:
        pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, WALLPAPER_MAX_SIDE, WALLPAPER_MAX_SIDE, True)
        ok, data = pixbuf.save_to_bufferv("jpeg", ["quality"], [WALLPAPER_QUALITY])
        if not ok:
            raise ValueError("imagem_invalida")
        return bytes(data)

    class PairDialog(Gtk.Dialog):
        def __init__(self, parent, controller):
            super().__init__(title="Conectar computador", transient_for=parent, modal=True)
            self.controller = controller
            self.scanning = False
            self.add_button("Cancelar", Gtk.ResponseType.CANCEL)
            self.add_button("Conectar", Gtk.ResponseType.ACCEPT)
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16, border_width=24)
            box.pack_start(label("Abra o Controle de Aula no computador do aluno. Aponte a webcam para o código, ou copie o código e cole aqui."), False, False, 0)
            self.code = Gtk.Entry()
            self.code.set_placeholder_text("Código do computador")
            self.code.set_activates_default(True)
            box.pack_start(self.code, False, False, 0)
            row = Gtk.Box(spacing=12)
            self.scan = Gtk.Button.new_with_label("Ler pela webcam")
            self.scan.connect("clicked", self.scan_clicked)
            row.pack_start(self.scan, False, False, 0)
            self.spinner = Gtk.Spinner()
            row.pack_start(self.spinner, False, False, 0)
            self.status = label("", dim=True)
            row.pack_start(self.status, True, True, 0)
            box.pack_start(row, False, False, 0)
            unit_row = Gtk.Box(spacing=12)
            unit_row.pack_start(label("Número da unidade (opcional)"), False, False, 0)
            self.unit = Gtk.SpinButton.new_with_range(0, 999, 1)
            unit_row.pack_start(self.unit, False, False, 0)
            box.pack_start(unit_row, False, False, 0)
            self.get_content_area().add(box)
            self.set_default_response(Gtk.ResponseType.ACCEPT)
            self.connect("destroy", lambda *_: setattr(self, "scanning", False))
            self.show_all()
            self.spinner.hide()

        def scan_clicked(self, _button):
            if self.scanning:
                return
            self.scanning = True
            self.scan.set_sensitive(False)
            self.spinner.show()
            self.spinner.start()
            self.status.set_text("Aponte a webcam para o código…")
            run_async(self._scan_loop, self._scan_done)

        def _scan_loop(self):
            for _ in range(WEBCAM_SCAN_ATTEMPTS):
                if not self.scanning:
                    return None
                text = self.controller.capture_qr_from_webcam()
                if text:
                    return text
            return None

        def _scan_done(self, result):
            self.scanning = False
            self.spinner.stop()
            self.spinner.hide()
            self.scan.set_sensitive(True)
            if isinstance(result, str):
                self.code.set_text(result)
                self.status.set_text("Código lido. Confirme em Conectar.")
            else:
                self.status.set_text("Nenhum código encontrado. Tente de novo ou cole o código.")
            return False

        def values(self):
            unit = int(self.unit.get_value())
            return self.code.get_text().strip(), (unit if unit > 0 else None)

    class AulaPage(Gtk.Box):
        def __init__(self, window, controller):
            super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=16)
            self.window = window
            self.controller = controller
            actions = Gtk.Box(spacing=12)
            for caption, handler in (
                ("Conectar computador", self.pair_clicked),
                ("Abrir site na turma", self.open_all_clicked),
                ("Mensagem para a turma", self.message_all_clicked),
                ("Fechar abas da turma", self.close_all_clicked),
            ):
                button = Gtk.Button.new_with_label(caption)
                button.connect("clicked", handler)
                actions.pack_start(button, False, False, 0)
            self.pack_start(actions, False, False, 0)
            self.empty = label("Nenhum computador conectado ainda. Use \"Conectar computador\".", dim=True)
            self.pack_start(self.empty, False, False, 0)
            self.list = Gtk.ListBox()
            self.list.set_selection_mode(Gtk.SelectionMode.NONE)
            scroller = Gtk.ScrolledWindow()
            scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            scroller.add(self.list)
            self.pack_start(frame(scroller), True, True, 0)
            self.signature = None

        def refresh(self):
            rows = self.controller.pcs()
            signature = repr(rows)
            if signature == self.signature:
                return
            self.signature = signature
            for child in self.list.get_children():
                self.list.remove(child)
            self.empty.set_visible(not rows)
            for pc in rows:
                self.list.add(self.row_for(pc))
            self.list.show_all()

        def row_for(self, pc):
            row = Gtk.ListBoxRow()
            box = Gtk.Box(spacing=16, border_width=12)
            icon = "network-transmit-receive-symbolic" if pc["online"] else "network-offline-symbolic"
            box.pack_start(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
            texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            name = pc["name"] if pc["unit"] is None else f"{pc['name']} · Unidade {pc['unit']}"
            texts.pack_start(label(name, 14, bold=True), False, False, 0)
            detail = pc["tab_title"] or pc["tab_url"] or ("Conectado" if pc["online"] else "Desligado ou sem internet")
            if pc["user"]:
                detail = f"{pc['user']} — {detail}"
            texts.pack_start(label(detail, 12, dim=True), False, False, 0)
            if pc["alert"]:
                warning = Gtk.Box(spacing=6)
                warning.pack_start(Gtk.Image.new_from_icon_name("dialog-warning-symbolic", Gtk.IconSize.MENU), False, False, 0)
                warning.pack_start(label(f"Acessando {pc['alert']}", 12, bold=True), False, False, 0)
                texts.pack_start(warning, False, False, 0)
            box.pack_start(texts, True, True, 0)
            menu = Gtk.MenuButton()
            menu.set_image(Gtk.Image.new_from_icon_name("view-more-symbolic", Gtk.IconSize.BUTTON))
            menu.set_popover(self.popover_for(pc, menu))
            box.pack_end(menu, False, False, 0)
            row.add(box)
            return row

        def popover_for(self, pc, relative):
            popover = Gtk.Popover.new(relative)
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, border_width=8)
            device_id = pc["id"]
            for caption, handler in (
                ("Abrir site", lambda *_: self.open_url(device_id)),
                ("Mensagem", lambda *_: self.message(device_id)),
                ("Fechar abas", lambda *_: self.controller.close_all_tabs(device_id)),
                ("Renomear", lambda *_: self.rename(pc)),
                ("Número da unidade", lambda *_: self.set_unit(pc)),
                ("Desconectar", lambda *_: self.forget(pc)),
            ):
                button = Gtk.ModelButton(text=caption)
                button.connect("clicked", handler)
                box.pack_start(button, False, False, 0)
            box.show_all()
            popover.add(box)
            return popover

        def pair_clicked(self, _button):
            dialog = PairDialog(self.window, self.controller)
            response = dialog.run()
            code, unit = dialog.values()
            dialog.destroy()
            if response != Gtk.ResponseType.ACCEPT:
                return
            self.window.busy(True)
            run_async(lambda: self.controller.pair_code(code, unit), self.after_network)

        def after_network(self, result):
            self.window.busy(False)
            if isinstance(result, Exception):
                notice(self.window, f"Falhou: {result}", error=True)
            elif result:
                notice(self.window, result, error=True)
            return False

        def open_url(self, device_id=None):
            values = ask(self.window, "Abrir site", [("Endereço", "https://")], accept="Abrir")
            if values and values[0].strip():
                run_async(lambda: self.controller.open_url(values[0].strip(), device_id), self.after_network)

        def open_all_clicked(self, _button):
            self.open_url(None)

        def message(self, device_id=None):
            values = ask(self.window, "Mensagem", [("Título", ""), ("Mensagem", "")], accept="Enviar")
            if values and (values[0].strip() or values[1].strip()):
                run_async(lambda: self.controller.message(values[0].strip() or "Professor", values[1].strip(), device_id),
                          self.after_network)

        def message_all_clicked(self, _button):
            self.message(None)

        def close_all_clicked(self, _button):
            if confirm(self.window, "Fechar as abas de toda a turma?", "Todas as abas abertas nos computadores serão fechadas.", "Fechar abas"):
                run_async(lambda: self.controller.close_all_tabs(None), self.after_network)

        def rename(self, pc):
            values = ask(self.window, "Renomear computador", [("Nome", pc["name"])])
            if values is not None:
                self.controller.rename(pc["id"], values[0])

        def set_unit(self, pc):
            values = ask(self.window, "Número da unidade", [("Número", str(pc["unit"] or ""))])
            if values is None:
                return
            try:
                numero = int(values[0].strip())
            except ValueError:
                notice(self.window, "Digite um número.", error=True)
                return
            run_async(lambda: self.controller.set_unit(pc["id"], numero), self.after_network)

        def forget(self, pc):
            if confirm(self.window, f"Desconectar {pc['name']}?", "O computador volta a mostrar o código de pareamento.", "Desconectar"):
                run_async(lambda: self.controller.forget(pc["id"]), self.after_network)

    class SitesPage(Gtk.Box):
        ACTIONS = ((BLOCK, "Bloquear"), (ALERT, "Avisar"))
        ENGINES = ((SEARCH_GOOGLE, "Google"), (SEARCH_DUCKDUCKGO, "DuckDuckGo"))

        def __init__(self, window, controller):
            super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=32)
            self.window = window
            self.controller = controller
            self.signature = None
            self.build_rules()
            self.build_home()

        @staticmethod
        def combo(options, current):
            widget = Gtk.ComboBoxText()
            for key, caption in options:
                widget.append(key, caption)
            widget.set_active_id(current)
            return widget

        def build_rules(self):
            box = section("Regras de sites")
            box.pack_start(label("Bloquear impede o acesso; Avisar deixa entrar e mostra um aviso aqui.", dim=True), False, False, 0)
            self.rules_list = Gtk.ListBox()
            self.rules_list.set_selection_mode(Gtk.SelectionMode.NONE)
            box.pack_start(frame(self.rules_list), False, False, 0)
            add = Gtk.Box(spacing=12)
            self.rule_pattern = entry("Site, por exemplo youtube.com", 32)
            self.rule_action = self.combo(self.ACTIONS, BLOCK)
            button = Gtk.Button.new_with_label("Adicionar")
            button.connect("clicked", self.add_rule_clicked)
            self.rule_pattern.connect("activate", self.add_rule_clicked)
            add.pack_start(self.rule_pattern, True, True, 0)
            add.pack_start(self.rule_action, False, False, 0)
            add.pack_start(button, False, False, 0)
            box.pack_start(add, False, False, 0)
            self.pack_start(box, False, False, 0)

        def build_home(self):
            box = section("Página inicial dos alunos")
            box.pack_start(label("O que aparece na nova aba do Voges em todos os computadores da escola.", dim=True), False, False, 0)
            grid = Gtk.Grid(row_spacing=12, column_spacing=12)
            grid.attach(label("Título"), 0, 0, 1, 1)
            self.home_title = Gtk.Entry()
            self.home_title.connect("activate", self.title_changed)
            self.home_title.connect("focus-out-event", self.title_changed)
            grid.attach(self.home_title, 1, 0, 1, 1)
            grid.attach(label("Busca"), 0, 1, 1, 1)
            search_row = Gtk.Box(spacing=12)
            self.home_search = Gtk.Switch()
            self.home_search.set_valign(Gtk.Align.CENTER)
            self.home_search.connect("state-set", self.search_changed)
            self.home_engine = self.combo(self.ENGINES, SEARCH_GOOGLE)
            self.home_engine.connect("changed", self.engine_changed)
            search_row.pack_start(self.home_search, False, False, 0)
            search_row.pack_start(self.home_engine, False, False, 0)
            grid.attach(search_row, 1, 1, 1, 1)
            box.pack_start(grid, False, False, 0)
            box.pack_start(label("Atalhos", 13, bold=True), False, False, 0)
            self.home_list = Gtk.ListBox()
            self.home_list.set_selection_mode(Gtk.SelectionMode.NONE)
            box.pack_start(frame(self.home_list), False, False, 0)
            add = Gtk.Box(spacing=12)
            self.shortcut_name = entry("Nome", 16)
            self.shortcut_url = entry("https://", 32)
            button = Gtk.Button.new_with_label("Adicionar")
            button.connect("clicked", self.add_shortcut_clicked)
            self.shortcut_url.connect("activate", self.add_shortcut_clicked)
            add.pack_start(self.shortcut_name, False, False, 0)
            add.pack_start(self.shortcut_url, True, True, 0)
            add.pack_start(button, False, False, 0)
            box.pack_start(add, False, False, 0)
            status_row = Gtk.Box(spacing=12)
            self.home_status = label("", dim=True)
            status_row.pack_start(self.home_status, True, True, 0)
            publish = Gtk.Button.new_with_label("Publicar de novo")
            publish.connect("clicked", lambda *_: self.publish())
            status_row.pack_end(publish, False, False, 0)
            box.pack_start(status_row, False, False, 0)
            self.pack_start(box, False, False, 0)
            self.loading = False

        def refresh(self):
            rules = self.controller.rules
            home = self.controller.home.config
            signature = (rules.rev, repr(rules.rules), repr(home), self.controller.home_error)
            if signature == self.signature:
                return
            self.signature = signature
            self.loading = True
            for child in self.rules_list.get_children():
                self.rules_list.remove(child)
            for index, rule in enumerate(rules.rules):
                self.rules_list.add(self.rule_row(index, rule))
            if not rules.rules:
                self.rules_list.add(self.empty_row("Nenhuma regra. Todos os sites estão liberados."))
            self.rules_list.show_all()
            if self.home_title.get_text() != home["titulo"]:
                self.home_title.set_text(home["titulo"])
            self.home_search.set_active(home["busca"])
            self.home_engine.set_active_id(home["buscador"])
            self.home_engine.set_sensitive(home["busca"])
            for child in self.home_list.get_children():
                self.home_list.remove(child)
            for index, shortcut in enumerate(home["atalhos"]):
                self.home_list.add(self.shortcut_row(index, shortcut))
            if not home["atalhos"]:
                self.home_list.add(self.empty_row("Sem atalhos. A página mostra só o título e a busca."))
            self.home_list.show_all()
            self.home_status.set_text(self.controller.home_error or "Publicada para toda a escola.")
            self.loading = False

        @staticmethod
        def empty_row(text):
            row = Gtk.ListBoxRow()
            row.set_activatable(False)
            box = Gtk.Box(border_width=12)
            box.pack_start(label(text, dim=True), True, True, 0)
            row.add(box)
            return row

        def rule_row(self, index, rule):
            row = Gtk.ListBoxRow()
            row.set_activatable(False)
            box = Gtk.Box(spacing=12, border_width=8)
            box.pack_start(label(rule["pattern"]), True, True, 0)
            action = self.combo(self.ACTIONS, rule["action"])
            action.connect("changed", lambda widget: self.controller.update_rule(index, rule["pattern"], widget.get_active_id()))
            box.pack_start(action, False, False, 0)
            remove = Gtk.Button.new_from_icon_name("edit-delete-symbolic", Gtk.IconSize.BUTTON)
            remove.connect("clicked", lambda *_: self.controller.remove_rule(index))
            box.pack_start(remove, False, False, 0)
            row.add(box)
            return row

        def shortcut_row(self, index, shortcut):
            row = Gtk.ListBoxRow()
            row.set_activatable(False)
            box = Gtk.Box(spacing=12, border_width=8)
            texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            texts.pack_start(label(shortcut["label"], bold=True), False, False, 0)
            texts.pack_start(label(shortcut["url"], 12, dim=True), False, False, 0)
            box.pack_start(texts, True, True, 0)
            edit = Gtk.Button.new_from_icon_name("document-edit-symbolic", Gtk.IconSize.BUTTON)
            edit.connect("clicked", lambda *_: self.edit_shortcut(index, shortcut))
            box.pack_start(edit, False, False, 0)
            remove = Gtk.Button.new_from_icon_name("edit-delete-symbolic", Gtk.IconSize.BUTTON)
            remove.connect("clicked", lambda *_: self.mutate_home(lambda: self.controller.home.remove_shortcut(index)))
            box.pack_start(remove, False, False, 0)
            row.add(box)
            return row

        def add_rule_clicked(self, *_):
            if self.controller.add_rule(self.rule_pattern.get_text(), self.rule_action.get_active_id()):
                self.rule_pattern.set_text("")
            else:
                notice(self.window, "Digite um site, por exemplo youtube.com.", error=True)

        def mutate_home(self, change):
            change()
            self.publish()

        def publish(self):
            self.home_status.set_text("Publicando…")
            run_async(self.controller.publish_home, lambda *_: self.refresh() or False)

        def title_changed(self, *_):
            if self.loading:
                return False
            title = self.home_title.get_text().strip()
            if title and title != self.controller.home.config["titulo"]:
                self.mutate_home(lambda: self.controller.home.set_title(title))
            return False

        def search_changed(self, _switch, state):
            if not self.loading and state != self.controller.home.config["busca"]:
                self.mutate_home(lambda: self.controller.home.set_search(state))
            return False

        def engine_changed(self, widget):
            engine = widget.get_active_id()
            if not self.loading and engine and engine != self.controller.home.config["buscador"]:
                self.mutate_home(lambda: self.controller.home.set_search(self.controller.home.config["busca"], engine))

        def add_shortcut_clicked(self, *_):
            if self.controller.home.add_shortcut(self.shortcut_name.get_text(), self.shortcut_url.get_text()):
                self.shortcut_name.set_text("")
                self.shortcut_url.set_text("")
                self.publish()
            else:
                notice(self.window, "Endereço inválido ou limite de 12 atalhos. Use http:// ou https://.", error=True)

        def edit_shortcut(self, index, shortcut):
            values = ask(self.window, "Editar atalho", [("Nome", shortcut["label"]), ("Endereço", shortcut["url"])])
            if values is None:
                return
            if self.controller.home.update_shortcut(index, values[0], values[1]):
                self.publish()
            else:
                notice(self.window, "Endereço inválido. Use http:// ou https://.", error=True)

    class SettingsPage(Gtk.Box):
        def __init__(self, window, controller):
            super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=32)
            self.window = window
            self.controller = controller
            self.signature = None

            name_box = section("Professor")
            row = Gtk.Box(spacing=12)
            row.pack_start(label("Nome mostrado aos alunos"), False, False, 0)
            self.name = Gtk.Entry(text=controller.prefs.teacher_name)
            self.name.connect("activate", self.name_changed)
            self.name.connect("focus-out-event", self.name_changed)
            row.pack_start(self.name, True, True, 0)
            name_box.pack_start(row, False, False, 0)
            self.pack_start(name_box, False, False, 0)

            wallpaper = section("Papel de parede da turma")
            wallpaper.pack_start(label("A imagem vai para todos os computadores conectados, inclusive os que conectarem depois.", dim=True), False, False, 0)
            row = Gtk.Box(spacing=12)
            choose = Gtk.Button.new_with_label("Escolher imagem…")
            choose.connect("clicked", self.wallpaper_clicked)
            row.pack_start(choose, False, False, 0)
            self.wallpaper_status = label("", dim=True)
            row.pack_start(self.wallpaper_status, True, True, 0)
            wallpaper.pack_start(row, False, False, 0)
            self.pack_start(wallpaper, False, False, 0)

            account = section("Conta Google")
            account.pack_start(label("Necessária para publicar a página inicial e para a escola compartilhada.", dim=True), False, False, 0)
            row = Gtk.Box(spacing=12)
            self.login = Gtk.Button.new_with_label("Entrar com Google")
            self.login.connect("clicked", self.login_clicked)
            row.pack_start(self.login, False, False, 0)
            self.account_status = label("", dim=True)
            row.pack_start(self.account_status, True, True, 0)
            account.pack_start(row, False, False, 0)
            self.pack_start(account, False, False, 0)

            school = section("Escola")
            school.pack_start(label("Na escola compartilhada, todos os professores veem os mesmos computadores e regras.", dim=True), False, False, 0)
            row = Gtk.Box(spacing=12)
            self.join = Gtk.Button.new_with_label("Entrar na escola")
            self.join.connect("clicked", lambda *_: self.school_action(controller.join_school))
            self.create = Gtk.Button.new_with_label("Criar a escola")
            self.create.connect("clicked", self.create_clicked)
            row.pack_start(self.join, False, False, 0)
            row.pack_start(self.create, False, False, 0)
            self.school_status = label("", dim=True)
            row.pack_start(self.school_status, True, True, 0)
            school.pack_start(row, False, False, 0)
            self.pack_start(school, False, False, 0)

        def refresh(self):
            controller = self.controller
            signature = (controller.wallpaper.hash, controller.email, controller.school_active, controller.google_available)
            if signature == self.signature:
                return
            self.signature = signature
            self.wallpaper_status.set_text(
                f"Imagem definida ({controller.wallpaper.hash})." if controller.wallpaper.hash else "Nenhuma imagem definida.")
            if controller.email:
                self.account_status.set_text(f"Conectada como {controller.email}.")
                self.login.set_label("Trocar de conta")
            elif not controller.google_available:
                self.account_status.set_text("Indisponível: este pacote veio sem o client id do Google.")
            else:
                self.account_status.set_text("Não conectada.")
            self.login.set_sensitive(controller.google_available)
            self.school_status.set_text("Escola compartilhada ativa." if controller.school_active else "Modo isolado: só este professor.")
            self.join.set_sensitive(not controller.school_active)
            self.create.set_sensitive(not controller.school_active)

        def name_changed(self, *_):
            self.controller.set_teacher_name(self.name.get_text())
            return False

        def wallpaper_clicked(self, _button):
            dialog = Gtk.FileChooserDialog(title="Escolher papel de parede", transient_for=self.window,
                                           action=Gtk.FileChooserAction.OPEN)
            dialog.add_button("Cancelar", Gtk.ResponseType.CANCEL)
            dialog.add_button("Escolher", Gtk.ResponseType.ACCEPT)
            images = Gtk.FileFilter()
            images.set_name("Imagens")
            images.add_mime_type("image/*")
            dialog.add_filter(images)
            response = dialog.run()
            path = dialog.get_filename()
            dialog.destroy()
            if response != Gtk.ResponseType.ACCEPT or not path:
                return
            self.wallpaper_status.set_text("Enviando…")
            self.window.busy(True)
            run_async(lambda: self.controller.set_wallpaper(image_to_jpeg(path)), self.wallpaper_done)

        def wallpaper_done(self, result):
            self.window.busy(False)
            if isinstance(result, Exception):
                self.signature = None
                notice(self.window, f"Não deu para enviar a imagem: {result}", error=True)
            self.refresh()
            return False

        def login_clicked(self, _button):
            self.account_status.set_text("Conclua o login no navegador…")
            self.window.busy(True)
            run_async(self.controller.login_google, self.action_done)

        def create_clicked(self, _button):
            if confirm(self.window, "Criar a escola com a sua chave?",
                       "Os outros professores entram com \"Entrar na escola\" e passam a compartilhar computadores e regras. Isso só pode ser feito uma vez.", "Criar"):
                self.school_action(self.controller.create_school)

        def school_action(self, action):
            self.window.busy(True)
            run_async(action, self.action_done)

        def action_done(self, result):
            self.window.busy(False)
            self.signature = None
            self.refresh()
            if isinstance(result, Exception):
                notice(self.window, f"Falhou: {result}", error=True)
            elif result:
                notice(self.window, result, error=True)
            return False

    class Window(Gtk.ApplicationWindow):
        def __init__(self, app, controller):
            super().__init__(application=app, title="Controle de Aula — Professor")
            self.set_wmclass("controle-de-aula-professor", "controle-de-aula-professor")
            self.set_icon_name("computer")
            self.set_default_size(900, 640)
            self.set_position(Gtk.WindowPosition.CENTER)
            self.controller = controller
            controller.on_change = lambda: GLib.idle_add(self.refresh)

            outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
            outer.set_border_width(24)
            self.add(outer)
            top = Gtk.Box(spacing=16)
            self.stack = Gtk.Stack()
            self.stack.set_transition_type(Gtk.StackTransitionType.NONE)
            switcher = Gtk.StackSwitcher()
            switcher.set_stack(self.stack)
            top.pack_start(switcher, False, False, 0)
            self.status = label("Conectando…", 12, dim=True, xalign=1)
            top.pack_end(self.status, True, True, 0)
            self.spinner = Gtk.Spinner()
            top.pack_end(self.spinner, False, False, 0)
            outer.pack_start(top, False, False, 0)

            self.pages = []
            for name, title, page in (
                ("aula", "Aula", AulaPage(self, controller)),
                ("sites", "Sites", SitesPage(self, controller)),
                ("ajustes", "Ajustes", SettingsPage(self, controller)),
            ):
                scroller = Gtk.ScrolledWindow()
                scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
                scroller.add(page)
                self.stack.add_titled(scroller, name, title)
                self.pages.append(page)
            outer.pack_start(self.stack, True, True, 0)
            self.connect("destroy", lambda *_: threading.Thread(target=controller.stop, daemon=True).start())
            self.show_all()
            self.spinner.hide()
            self.refresh()
            self.busy(True)
            run_async(controller.start, lambda *_: self.busy(False) or False)

        def busy(self, active):
            self.spinner.set_visible(active)
            if active:
                self.spinner.start()
            else:
                self.spinner.stop()

        def refresh(self):
            controller = self.controller
            if controller.error:
                self.status.set_text(controller.error)
            elif controller.connected:
                mode = "escola compartilhada" if controller.school_active else "modo isolado"
                self.status.set_text(f"Conectado · {mode}")
            else:
                self.status.set_text("Conectando…")
            for page in self.pages:
                page.refresh()
            return False

    controller = TeacherController(TeacherController.load_config())
    application = Gtk.Application(application_id="br.escola.celita.ControleDeAulaProfessor",
                                  flags=Gio.ApplicationFlags.FLAGS_NONE)

    def activate(app):
        window = app.get_active_window()
        if window:
            window.present()
        else:
            Window(app, controller)

    application.connect("activate", activate)
    return application.run([])
