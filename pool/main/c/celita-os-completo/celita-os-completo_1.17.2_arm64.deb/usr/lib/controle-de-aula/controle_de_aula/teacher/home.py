"""Página inicial dos alunos: a mesma forma que o celular publica em
`/home/escola` e que a nova aba do Voges sanitiza. Espelho de `home_store.dart`."""

import json
from urllib.parse import urlsplit

MAX_SHORTCUTS = 12
MAX_LABEL = 24
MAX_TITLE = 20
SEARCH_GOOGLE = "google"
SEARCH_DUCKDUCKGO = "duckduckgo"

MAX_URL = 2048

DEFAULT = {"titulo": "Celita", "busca": True, "buscador": SEARCH_GOOGLE, "atalhos": [], "url": ""}


def shortcut_url_valid(url: str) -> bool:
    try:
        parts = urlsplit((url or "").strip())
    except ValueError:
        return False
    return parts.scheme in ("http", "https") and bool(parts.netloc)


def sanitize_shortcut(raw) -> dict | None:
    if not isinstance(raw, dict):
        return None
    url = raw.get("url")
    if not isinstance(url, str) or not url:
        return None
    label = raw.get("label")
    return {"label": label if isinstance(label, str) else url, "url": url}


def sanitize_home(raw) -> dict:
    if not isinstance(raw, dict):
        return dict(DEFAULT, atalhos=[])
    shortcuts = raw.get("atalhos")
    shortcuts = [s for s in map(sanitize_shortcut, shortcuts) if s] if isinstance(shortcuts, list) else []
    title = raw.get("titulo")
    title = title.strip()[:MAX_TITLE] if isinstance(title, str) and title.strip() else DEFAULT["titulo"]
    url = raw.get("url")
    url = url.strip() if isinstance(url, str) else ""
    return {
        "titulo": title,
        "busca": raw.get("busca") is not False,
        "buscador": SEARCH_DUCKDUCKGO if raw.get("buscador") == SEARCH_DUCKDUCKGO else SEARCH_GOOGLE,
        "atalhos": shortcuts[:MAX_SHORTCUTS],
        # Site no lugar da página do Celita; vazio = a página.
        "url": url if len(url) <= MAX_URL and shortcut_url_valid(url) else "",
    }


def shortcut_from_input(name: str, url: str) -> dict | None:
    """Nome vazio vira o host, como no celular. None = URL recusada."""
    url = (url or "").strip()
    if not shortcut_url_valid(url):
        return None
    label = (name or "").strip() or urlsplit(url).hostname or url
    return {"label": label[:MAX_LABEL], "url": url}


def publish_payload(config: dict, rev_ms: int) -> dict:
    return {"rev": rev_ms, "cfg": json.dumps(sanitize_home(config), ensure_ascii=False)}
