"""Cliente mínimo do Firebase: Auth anônima, RTDB por REST e stream SSE.

Espelho de firebase.js. Sem SDK: dois endpoints de auth, cinco verbos REST e
um leitor de SSE cobrem tudo que o protocolo usa. O caminho lateral
(`side_request`, `upload_object`) serve o que não é canal de comandos.
"""

import email.utils
import json
import logging
import socket
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

log = logging.getLogger("controle-de-aula.firebase")

STREAM_WATCHDOG_S = 90
REFRESH_MARGIN_S = 5 * 60
BACKOFF_MIN_S = 1
BACKOFF_MAX_S = 60
FETCH_TIMEOUT_S = 20
# Leitura negada não pode virar laço de refresh: no caminho lateral e nos
# streams, no máximo um refresh a cada 10 min.
DENIED_REFRESH_S = 10 * 60
DENIED_BACKOFF_S = 10 * 60
STORAGE_ORIGIN = "https://firebasestorage.googleapis.com"

# Códigos do Secure Token que significam conta morta de verdade. Erro de rede,
# 5xx ou lixo de portal cativo não entram: trocar de uid por engano prende o
# aparelho para sempre, porque meta/uid é first-write-wins nas rules.
# A conta Google já pertence a outro uid: entrar nela em vez de vincular.
IDP_TAKEN_CODES = {"CREDENTIAL_ALREADY_IN_USE", "EMAIL_EXISTS", "FEDERATED_USER_ID_ALREADY_LINKED"}

AUTH_DEAD_CODES = {
    "INVALID_REFRESH_TOKEN",
    "TOKEN_EXPIRED",
    "USER_NOT_FOUND",
    "USER_DISABLED",
    "INVALID_GRANT",
    "MISSING_REFRESH_TOKEN",
}


class FirebaseError(Exception):
    def __init__(self, message: str, status: int | None = None, auth_dead: bool = False):
        super().__init__(message)
        self.status = status
        self.auth_dead = auth_dead


def parse_stream_event(event_name: str, data_text: str):
    if event_name in ("put", "patch"):
        try:
            body = json.loads(data_text)
        except (TypeError, ValueError):
            return None
        if not isinstance(body, dict) or not isinstance(body.get("path"), str):
            return None
        return {"type": event_name, "path": body["path"], "data": body.get("data")}
    if event_name in ("keep-alive", "cancel", "auth_revoked"):
        return {"type": event_name}
    return None


def _http(method: str, url: str, body: bytes | None, headers: dict, timeout: float):
    status, raw, _headers = _http_full(method, url, body, headers, timeout)
    return status, raw


def _http_full(method: str, url: str, body: bytes | None, headers: dict, timeout: float):
    request = urllib.request.Request(url, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.status, response.read(), response.headers
    except urllib.error.HTTPError as error:
        try:
            return error.code, error.read(), error.headers
        finally:
            error.close()


def server_date_ms(headers) -> int | None:
    """Cabeçalho Date em ms; None quando ausente ou ilegível."""
    value = headers.get("Date") if headers is not None else None
    if not value:
        return None
    try:
        return int(email.utils.parsedate_to_datetime(value).timestamp() * 1000)
    except (TypeError, ValueError, OverflowError):
        return None


class FirebaseSession:
    def __init__(
        self,
        api_key: str,
        database_url: str,
        load_auth,
        save_auth,
        auth_origin: str = "https://identitytoolkit.googleapis.com",
        token_origin: str = "https://securetoken.googleapis.com",
        storage_origin: str = STORAGE_ORIGIN,
    ):
        self.api_key = api_key
        self.database_url = database_url.rstrip("/")
        self.load_auth = load_auth
        self.save_auth = save_auth
        self.auth_origin = auth_origin
        self.token_origin = token_origin
        self.storage_origin = storage_origin.rstrip("/")
        self.uid = None
        self.id_token = None
        # (server_ms, local_ms) -> None; alimenta o desvio do relógio do PC.
        self.on_server_date = None
        self._refresh_token = None
        self._refresh_timer = None
        self._side_refresh_at = None
        self._streams = set()
        self._lock = threading.RLock()

    # ---- Auth -------------------------------------------------------------

    def sign_in(self) -> str:
        saved = self.load_auth() if self.load_auth else None
        if isinstance(saved, dict) and saved.get("refreshToken"):
            try:
                self._refresh(saved["refreshToken"])
                return self.uid
            except FirebaseError as error:
                if not error.auth_dead:
                    raise
                log.warning("conta anônima morta, criando outra: %s", error)
        status, raw = _http(
            "POST",
            f"{self.auth_origin}/v1/accounts:signUp?key={self.api_key}",
            json.dumps({"returnSecureToken": True}).encode(),
            {"Content-Type": "application/json"},
            FETCH_TIMEOUT_S,
        )
        if status != 200:
            raise FirebaseError(f"signup_http_{status}", status)
        data = _json_or_none(raw)
        if not data or not all(data.get(k) for k in ("localId", "idToken", "refreshToken")):
            raise FirebaseError("signup_resposta_invalida")
        self._store_tokens(data["localId"], data["idToken"], data["refreshToken"])
        self._schedule_refresh(_seconds(data.get("expiresIn")))
        return self.uid

    def sign_in_with_idp(self, provider_id: str, id_token: str, link: bool = True) -> dict:
        """Vincula um provedor (Google) à conta atual: o uid não muda. Se a
        conta Google já é de outro aparelho, assume o uid dela — como o celular.
        `link=False` entra direto na conta do provedor (login entregue pelo celular)."""
        with self._lock:
            current = self.id_token if link else None
        body = {
            "postBody": urllib.parse.urlencode({"id_token": id_token, "providerId": provider_id}),
            "requestUri": "http://localhost",
            "returnSecureToken": True,
        }
        if current:
            body["idToken"] = current
        status, raw = self._auth_post("accounts:signInWithIdp", body)
        data = _json_or_none(raw) or {}
        if status != 200 and current:
            message = str((data.get("error") or {}).get("message", "")).split(":")[0].strip()
            if message in IDP_TAKEN_CODES:
                del body["idToken"]
                status, raw = self._auth_post("accounts:signInWithIdp", body)
                data = _json_or_none(raw) or {}
        if status != 200:
            raise FirebaseError(f"idp_http_{status}", status)
        if not all(data.get(k) for k in ("localId", "idToken", "refreshToken")):
            raise FirebaseError("idp_resposta_invalida")
        switched = data["localId"] != self.uid
        self._store_tokens(data["localId"], data["idToken"], data["refreshToken"])
        self._schedule_refresh(_seconds(data.get("expiresIn")))
        if switched:
            for stream in list(self._streams):
                stream.reconnect("conta_trocada")
        return {"uid": self.uid, "email": data.get("email"), "switched": switched}

    def _auth_post(self, method: str, body: dict):
        return _http(
            "POST",
            f"{self.auth_origin}/v1/{method}?key={self.api_key}",
            json.dumps(body).encode(),
            {"Content-Type": "application/json"},
            FETCH_TIMEOUT_S,
        )

    def _refresh(self, refresh_token: str | None = None):
        self._fetch_tokens(refresh_token)
        for stream in list(self._streams):
            stream.reconnect("token_renovado")

    def _fetch_tokens(self, refresh_token: str | None = None):
        with self._lock:
            token = refresh_token or self._refresh_token
        body = urllib.parse.urlencode(
            {"grant_type": "refresh_token", "refresh_token": token or ""}
        ).encode()
        status, raw = _http(
            "POST",
            f"{self.token_origin}/v1/token?key={self.api_key}",
            body,
            {"Content-Type": "application/x-www-form-urlencoded"},
            FETCH_TIMEOUT_S,
        )
        if status != 200:
            data = _json_or_none(raw) or {}
            error = data.get("error")
            code = str(error.get("message") if isinstance(error, dict) else error or "")
            code = code.split(":")[0].strip()
            raise FirebaseError(
                f"refresh_http_{status}" + (f"_{code}" if code else ""),
                status,
                auth_dead=(status == 400 and code in AUTH_DEAD_CODES),
            )
        data = _json_or_none(raw)
        if not data or not all(data.get(k) for k in ("user_id", "id_token", "refresh_token")):
            raise FirebaseError("refresh_resposta_invalida")
        self._store_tokens(data["user_id"], data["id_token"], data["refresh_token"])
        self._schedule_refresh(_seconds(data.get("expires_in")))

    def _store_tokens(self, uid: str, id_token: str, refresh_token: str):
        with self._lock:
            self.uid = uid
            self.id_token = id_token
            self._refresh_token = refresh_token
        if self.save_auth:
            self.save_auth({"uid": uid, "refreshToken": refresh_token})

    def _schedule_refresh(self, lifetime_s: float):
        with self._lock:
            if self._refresh_timer:
                self._refresh_timer.cancel()
            delay = max(60, lifetime_s - REFRESH_MARGIN_S)
            self._refresh_timer = threading.Timer(delay, self._refresh_scheduled)
            self._refresh_timer.daemon = True
            self._refresh_timer.start()

    def _refresh_scheduled(self):
        try:
            self._refresh()
        except Exception as error:  # noqa: BLE001 - qualquer falha só reagenda
            log.warning("refresh agendado falhou, tenta de novo em 60 s: %s", error)
            self._schedule_refresh(REFRESH_MARGIN_S + 60)

    def stop(self):
        with self._lock:
            if self._refresh_timer:
                self._refresh_timer.cancel()
                self._refresh_timer = None
        for stream in list(self._streams):
            stream.close()

    # ---- REST -------------------------------------------------------------

    @staticmethod
    def server_timestamp() -> dict:
        return {".sv": "timestamp"}

    def _url(self, path: str, params: dict | None = None) -> str:
        if not path.startswith("/"):
            path = "/" + path
        with self._lock:
            token = self.id_token
        extra = "".join(f"&{urllib.parse.quote(k)}={urllib.parse.quote(str(v))}" for k, v in (params or {}).items())
        return f"{self.database_url}{path}.json?auth={token}{extra}"

    def _observe_date(self, headers):
        server = server_date_ms(headers)
        callback = self.on_server_date
        if server is not None and callback is not None:
            callback(server, int(time.time() * 1000))

    def _send(self, method: str, url: str, payload: bytes | None, headers: dict):
        try:
            status, raw, response_headers = _http_full(method, url, payload, headers, FETCH_TIMEOUT_S)
        except (OSError, socket.timeout) as error:
            raise FirebaseError(f"rede_{type(error).__name__}") from error
        self._observe_date(response_headers)
        return status, raw

    def _request(self, method: str, path: str, body=None, params: dict | None = None):
        payload = None if body is None else json.dumps(body).encode()
        for attempt in range(2):
            status, raw = self._send(method, self._url(path, params), payload, {"Content-Type": "application/json"})
            if status == 401 and attempt == 0:
                self._refresh()
                continue
            if status < 200 or status >= 300:
                raise FirebaseError(f"rtdb_{method}_{status}", status)
            return _json_or_none(raw)
        return None

    # ---- Caminho lateral --------------------------------------------------

    def _side_refresh_allowed(self) -> bool:
        with self._lock:
            now = time.monotonic()
            if self._side_refresh_at is not None and now - self._side_refresh_at < DENIED_REFRESH_S:
                return False
            self._side_refresh_at = now
            return True

    def _side_call(self, send, what: str):
        """401/403 renova o token sem reconectar os streams, no máximo uma vez
        a cada 10 min; negação persistente sobe como FirebaseError(status)."""
        for attempt in range(2):
            status, raw = send()
            if status in (401, 403) and attempt == 0 and self._side_refresh_allowed():
                try:
                    self._fetch_tokens()
                except FirebaseError:
                    raise FirebaseError(f"{what}_{status}", status)
                continue
            if status < 200 or status >= 300:
                raise FirebaseError(f"{what}_{status}", status)
            return raw
        return None

    def side_request(self, method: str, path: str, body=None, params: dict | None = None):
        """RTDB fora do canal de comandos (arquivo, página inicial, escola)."""
        payload = None if body is None else json.dumps(body).encode()
        raw = self._side_call(
            lambda: self._send(method, self._url(path, params), payload, {"Content-Type": "application/json"}),
            f"rtdb_{method}",
        )
        # Portal cativo responde 200 com HTML: isso não é "nó vazio".
        try:
            return json.loads((raw or b"").decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as error:
            raise FirebaseError(f"rtdb_{method}_resposta_invalida") from error

    def side_get(self, path: str, params: dict | None = None):
        return self.side_request("GET", path, params=params)

    def upload_object(self, bucket: str, name: str, data: bytes):
        """Upload simples do Storage (REST v0). A resposta nunca é lida nem logada."""

        def send():
            with self._lock:
                token = self.id_token
            url = (f"{self.storage_origin}/v0/b/{urllib.parse.quote(bucket, safe='')}/o"
                   f"?name={urllib.parse.quote(name, safe='')}")
            headers = {"Authorization": f"Firebase {token}", "Content-Type": "application/octet-stream"}
            return self._send("POST", url, data, headers)

        self._side_call(send, "storage_POST")

    def get(self, path: str, params: dict | None = None):
        return self._request("GET", path, params=params)

    def put(self, path: str, value):
        return self._request("PUT", path, value)

    def patch(self, path: str, value):
        return self._request("PATCH", path, value)

    def push(self, path: str, value):
        result = self._request("POST", path, value)
        return result.get("name") if isinstance(result, dict) else None

    def delete(self, path: str):
        return self._request("DELETE", path)

    # ---- Stream -----------------------------------------------------------

    def stream(self, path: str, on_event, on_down=None) -> "StreamHandle":
        handle = StreamHandle(self, path, on_event, on_down)
        self._streams.add(handle)
        handle.start()
        return handle


class StreamHandle:
    """Um caminho escutado por SSE, com reconexão e watchdog próprios.

    O watchdog é o timeout de leitura do socket: 90 s sem byte nenhum (os
    keep-alives chegam a cada ~30 s) derruba a conexão e o laço reconecta.
    """

    def __init__(self, session: FirebaseSession, path: str, on_event, on_down):
        self.session = session
        self.path = path
        self.on_event = on_event
        self.on_down = on_down
        self.closed = False
        self.last_event_at = 0.0
        self._backoff = BACKOFF_MIN_S
        self._denied_refresh_at = None
        self._response = None
        self._lock = threading.Lock()
        self._wake = threading.Event()
        self._thread = threading.Thread(target=self._run, name=f"sse{path}", daemon=True)

    def start(self):
        self._thread.start()

    def close(self):
        self.closed = True
        self._wake.set()
        self.session._streams.discard(self)
        self._drop_response()

    def reconnect(self, reason: str):
        if self.closed:
            return
        if self.on_down:
            self.on_down(reason)
        self._wake.set()
        self._drop_response()

    def _drop_response(self):
        with self._lock:
            response, self._response = self._response, None
        if response is not None:
            # HTTPResponse.close() espera a trava do BufferedReader. Se outra
            # thread estiver em readline() num SSE silencioso, close bloqueia
            # até o timeout (90 s), prendendo a aceitação do pareamento.
            # Interromper o transporte primeiro acorda a leitura imediatamente.
            transport = getattr(getattr(getattr(response, "fp", None), "raw", None), "_sock", None)
            if transport is not None:
                try:
                    transport.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
            try:
                response.close()
            except OSError:
                pass

    def age_s(self) -> float:
        return time.monotonic() - self.last_event_at if self.last_event_at else float("inf")

    def _run(self):
        while not self.closed:
            denied = False
            try:
                self._connect_and_read()
                reason = "fim_do_stream"
            except urllib.error.HTTPError as error:
                denied = error.code in (401, 403)
                reason = f"erro_sse_{error.code}"
            except (OSError, socket.timeout, urllib.error.URLError) as error:
                reason = f"erro_sse_{type(error).__name__}"
            except Exception as error:  # noqa: BLE001 - o laço nunca morre por callback
                if not self.closed:
                    log.warning("stream %s: %s", self.path, error)
                reason = "erro_interno"
            if self.closed:
                break
            if self.on_down:
                self.on_down(reason)
            delay = self._backoff
            self._backoff = min(self._backoff * 2, BACKOFF_MAX_S)
            if denied:
                # Token vencido cura com um refresh; leitura negada pelas
                # rules não, e renovar a cada volta reconectaria todo mundo.
                now = time.monotonic()
                if self._denied_refresh_at is not None and now - self._denied_refresh_at < DENIED_REFRESH_S:
                    log.warning("stream %s negado; nova tentativa em 10 min", self.path)
                    delay = DENIED_BACKOFF_S
                else:
                    self._denied_refresh_at = now
                    try:
                        self.session._refresh()
                    except Exception:  # noqa: BLE001
                        pass
            # Backoff no teto significa queda longa; o token pode ter expirado
            # com a rede fora, e stream com token velho é 401 mudo.
            elif delay >= BACKOFF_MAX_S:
                try:
                    self.session._refresh()
                except Exception:  # noqa: BLE001
                    pass
            # O refresh acorda TODOS os streams, inclusive este. Limpar depois
            # dele descarta o próprio aviso: sem isso o wait volta na hora e o
            # backoff no teto vira laço fechado, martelando auth e banco.
            # close() marca closed antes de sinalizar, então a checagem abaixo
            # não perde um fechamento que tenha chegado durante a limpeza.
            self._wake.clear()
            if self.closed:
                break
            self._wake.wait(delay)

    def _connect_and_read(self):
        request = urllib.request.Request(
            self.session._url(self.path), headers={"Accept": "text/event-stream"}
        )
        response = urllib.request.urlopen(request, timeout=STREAM_WATCHDOG_S)
        self.session._observe_date(response.headers)
        with self._lock:
            if self.closed:
                response.close()
                return
            self._response = response
        self.last_event_at = time.monotonic()
        event_name = None
        data_lines = []
        try:
            for raw in response:
                if self.closed:
                    break
                line = raw.decode("utf-8", "replace").rstrip("\r\n")
                if line.startswith("event:"):
                    event_name = line[6:].strip()
                elif line.startswith("data:"):
                    data_lines.append(line[5:].lstrip())
                elif line == "":
                    if event_name:
                        self._dispatch(event_name, "\n".join(data_lines))
                    event_name = None
                    data_lines = []
        finally:
            self._drop_response()

    def _dispatch(self, event_name: str, data_text: str):
        if self.closed:
            return
        self.last_event_at = time.monotonic()
        self._backoff = BACKOFF_MIN_S
        parsed = parse_stream_event(event_name, data_text)
        if not parsed:
            return
        if parsed["type"] == "auth_revoked":
            try:
                self.session._refresh()
            finally:
                self.reconnect("auth_revoked")
        elif parsed["type"] == "cancel":
            self.reconnect("cancel")
        elif parsed["type"] != "keep-alive":
            self.on_event(parsed)


def _json_or_none(raw: bytes):
    try:
        return json.loads(raw.decode("utf-8"))
    except (TypeError, ValueError, UnicodeDecodeError):
        return None


def _seconds(value) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 3600.0
