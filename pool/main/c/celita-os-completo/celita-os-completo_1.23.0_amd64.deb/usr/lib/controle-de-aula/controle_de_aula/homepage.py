"""Página inicial de verdade: o site publicado em `/home/escola` vira política
gerenciada do Chromium (abre com o navegador e no botão Início). A nova aba
continua sendo a página do Celita."""

import json
import logging
import os
import time

from . import protocol
from .firebase import FirebaseError

log = logging.getLogger("controle-de-aula.homepage")

POLICY_PATH = "/etc/chromium/policies/managed/controle-de-aula-inicio.json"
MAX_URL = 2048
REFRESH_S = 60
AUTH_BACKOFF_S = 10 * 60


def home_url(node) -> str | None:
    """URL válida do nó publicado (`cfg` é JSON em texto), ou None."""
    if not isinstance(node, dict) or not isinstance(node.get("cfg"), str):
        return None
    try:
        config = json.loads(node["cfg"])
    except ValueError:
        return None
    url = config.get("url") if isinstance(config, dict) else None
    url = url.strip() if isinstance(url, str) else ""
    return url if url and len(url) <= MAX_URL and protocol.is_safe_http_url(url) else None


def policy_text(url: str) -> str:
    return json.dumps({"HomepageIsNewTabPage": False, "HomepageLocation": url, "ShowHomeButton": True,
                       "RestoreOnStartup": 4, "RestoreOnStartupURLs": [url]})


class HomePolicy:
    def __init__(self, path: str = POLICY_PATH):
        self.path = path
        self._next_at = None
        self._blocked_until = None

    def apply(self, node) -> bool:
        """Grava só se mudou; sem site válido, apaga. Devolve se mexeu no disco."""
        url = home_url(node)
        if url is None:
            try:
                os.unlink(self.path)
            except FileNotFoundError:
                return False
            log.info("página inicial: política removida")
            return True
        text = policy_text(url)
        try:
            with open(self.path, encoding="utf-8") as handle:
                if handle.read() == text:
                    return False
        except OSError:
            pass
        directory = os.path.dirname(self.path)
        os.makedirs(directory, mode=0o755, exist_ok=True)
        temporary = self.path + ".tmp"
        with open(temporary, "w", encoding="utf-8") as handle:
            handle.write(text)
        os.chmod(temporary, 0o644)
        os.replace(temporary, self.path)
        log.info("página inicial: %s", url)
        return True

    def refresh_soon(self):
        self._next_at = None

    def tick(self, fb):
        """Ao conectar, a cada sessão nova e a cada 60 s. Erro de rede ou HTTP não mexe."""
        now = time.monotonic()
        if fb is None or not fb.id_token:
            return
        if self._next_at is not None and now < self._next_at:
            return
        if self._blocked_until is not None and now < self._blocked_until:
            return
        self._next_at = now + REFRESH_S
        try:
            node = fb.side_get("/home/escola")
        except FirebaseError as error:
            if error.status in (401, 403):
                self._blocked_until = now + AUTH_BACKOFF_S
                log.warning("página inicial negada (%s); nova tentativa em 10 min", error.status)
            return
        try:
            self.apply(node)
        except OSError as error:
            log.warning("política da página inicial não foi gravada: %s", error)
