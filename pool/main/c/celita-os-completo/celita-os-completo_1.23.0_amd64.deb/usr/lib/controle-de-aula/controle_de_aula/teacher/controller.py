"""Liga os stores locais, o cliente do professor e o workspace da escola. Sem
GTK: a interface só chama métodos daqui e ouve `on_change`. Todo método que
fala com a rede bloqueia — a interface chama numa thread."""

import json
import logging
import os
import subprocess
import threading
from pathlib import Path
from urllib.parse import urlsplit

from ..firebase import FirebaseError
from . import commands, home as home_rules
from .auth import GoogleLogin
from .client import TeacherClient, parse_qr_payload
from .handoff import LoginHandoff
from .rules import find_rule
from .school import NOT_ALLOWED, SchoolKeys, SchoolSync, school_store_key
from .stores import (
    AuthStore, HomeStore, JsonFile, KeyStore, NameStore, PrefsStore, RulesStore, UnitStore,
    WallpaperStore, forget_if_stale, profile_dir, stamp_session,
)

log = logging.getLogger("controle-de-aula.teacher.controller")

WEBCAM_TIMEOUT_S = 8


class TeacherController:
    def __init__(self, config: dict, directory: Path | None = None, session_factory=None, login_factory=None):
        self.config = config
        self.dir = directory or profile_dir()
        # Sair da conta, reiniciar ou desligar = sair do Controle do Professor.
        self.forgot_previous_session = forget_if_stale(self.dir)
        stamp_session(self.dir)
        self.rules = RulesStore(self.dir)
        self.units = UnitStore(self.dir)
        self.names = NameStore(self.dir)
        self.home = HomeStore(self.dir)
        self.wallpaper = WallpaperStore(self.dir)
        self.prefs = PrefsStore(self.dir)
        self.keys = KeyStore(self.dir)
        self.auth = AuthStore(self.dir)
        self._session_factory = session_factory
        self._login_factory = login_factory or (lambda: GoogleLogin(config["googleClientId"], config.get("googleClientSecret")))
        self.client = None
        self.sync = None
        self.on_change = None
        self.error = None
        # E-mail fora de /school/members: a escola continua salva, sem sincronizar.
        self.not_allowed = False
        self.home_error = None
        self._last_rev = 0
        self._lock = threading.RLock()

    # ---- ciclo de vida ------------------------------------------------------------

    def start(self):
        with self._lock:
            key = self.keys.load_or_create()
            factory = self._session_factory
            self.client = TeacherClient(
                self.config, key, teacher_name=self.prefs.teacher_name, school_uid=self.prefs.school_uid,
                load_auth=self.auth.load, save_auth=self.auth.save,
                session_factory=(lambda: factory(self.auth.load, self.auth.save)) if factory else None,
            )
            self.client.state_commands_for = self.state_commands_for
            self.client.registry.evaluate_alert = self.evaluate_alert
            self.client.registry.on_change = self._changed
            self.not_allowed = False
            try:
                self.client.connect()
                if self.prefs.school_uid and not SchoolKeys(self.client.fb).is_member(self.prefs.school_uid, self.email):
                    self.not_allowed = True
                    self.error = NOT_ALLOWED.format(email=self.email or "sem e-mail")
                    log.warning("escola: e-mail ainda não liberado")
                    self._changed()
                    return
                self.client.start_streams()
                self.error = None
            except Exception as error:  # noqa: BLE001
                self.error = f"Não foi possível conectar: {error}"
                log.warning(self.error)
                self._changed()
                return
            if self.prefs.school_uid:
                self.sync = SchoolSync(school_store_key(key), self.client.now_server_ms, self._read_store, self._write_store)
                self.sync.on_remote = self._store_changed_remotely
                self.sync.start(self.client.fb)
            self._seed_from_cloud()
        self._changed()

    def _seed_from_cloud(self):
        """Depois de um login novo os arquivos locais não existem: a página
        inicial publicada e o papel de parede vigente vêm do banco, senão a
        primeira edição publicaria um padrão por cima do que a escola tinha."""
        if not self.home.file.exists():
            try:
                published = self.client.fb.get("/home/escola")
                if isinstance(published, dict) and isinstance(published.get("cfg"), str):
                    self.home.replace(json.loads(published["cfg"]))
            except (FirebaseError, ValueError) as error:
                log.warning("página inicial publicada indisponível: %s", error)
        if not self.wallpaper.file.exists():
            try:
                hash_hex = self.client.fb.get(f"/wallpapers/{self.client.owner_uid}/hash")
                if isinstance(hash_hex, str) and hash_hex:
                    self.wallpaper.set(hash_hex)
            except FirebaseError:
                pass

    def stop(self):
        with self._lock:
            if self.sync is not None:
                self.sync.stop()
                self.sync = None
            if self.client is not None:
                self.client.stop()
                self.client = None

    def restart(self):
        self.stop()
        self.start()

    def _changed(self):
        if self.on_change is not None:
            self.on_change()

    @property
    def connected(self) -> bool:
        return self.client is not None and self.client.fb is not None and self.error is None

    @property
    def signed_in(self) -> bool:
        """Trocar de conta continua possível com o e-mail ainda não liberado."""
        return self.client is not None and self.client.fb is not None and (self.error is None or self.not_allowed)

    def _read_store(self, name: str):
        return JsonFile(self.dir / name).read_text()

    def _write_store(self, name: str, text: str):
        JsonFile(self.dir / name).write_text(text)

    def _store_changed_remotely(self, kind: str):
        {"rules": self.rules, "units": self.units, "names": self.names}[kind].reload()
        if kind == "rules":
            self._distribute_rules()
        self._changed()

    # ---- estado por PC ------------------------------------------------------------

    def next_rev(self) -> int:
        with self._lock:
            now = self.client.now_server_ms() if self.client else 0
            self._last_rev = now if now > self._last_rev else self._last_rev + 1
            return self._last_rev

    def state_commands_for(self, device_id: str) -> list:
        # set_rules sempre, mesmo vazio, para limpar regras antigas no PC.
        result = [commands.set_rules(self.rules.rules, rev=self.next_rev())]
        numero = self.units.get(device_id)
        if numero is not None:
            result.append(commands.set_unit(rev=self.next_rev(), numero=numero))
        if self.wallpaper.hash:
            result.append(commands.set_wallpaper(self.wallpaper.hash))
        return result

    def evaluate_alert(self, _device_id: str, tabs: list):
        for tab in tabs:
            rule = find_rule(self.rules.rules, tab.get("url", ""))
            if rule is not None:
                return urlsplit(tab.get("url", "")).hostname or rule["pattern"]
        return None

    def pcs(self) -> list:
        if self.client is None:
            return []
        now = self.client.now_server_ms()
        rows = []
        for session in self.client.registry.all:
            tab = session.active_tab or {}
            rows.append({
                "id": session.device_id,
                "name": self.names.get(session.device_id) or session.label,
                "unit": self.units.get(session.device_id),
                "online": session.online(now),
                "tab_title": tab.get("title") or "",
                "tab_url": tab.get("url") or "",
                "alert": session.alert,
                "user": session.user,
            })
        rows.sort(key=lambda row: (row["unit"] is None, row["unit"] or 0, row["name"].lower()))
        return rows

    # ---- pareamento ---------------------------------------------------------------

    def pair_code(self, raw: str, numero: int | None = None) -> str | None:
        qr = parse_qr_payload(raw)
        if qr is None:
            return "Código inválido. Cole o código mostrado na janela Controle de Aula do computador."
        if self.client is None or not self.connected:
            return "Sem conexão com o servidor."
        if numero is not None:
            self._assign_unit(qr["device_id"], numero)
        try:
            self.client.pair(qr, numero)
        except FirebaseError as error:
            return f"O servidor recusou o pareamento ({error}). O código pode ter vencido."
        self._changed()
        return None

    @staticmethod
    def capture_qr_from_webcam() -> str | None:
        """Uma foto da webcam lida pelo zbar; None quando não há QR na foto."""
        try:
            photo = subprocess.run(
                ["fswebcam", "-q", "--no-banner", "-r", "1280x720", "-"],
                capture_output=True, check=True, timeout=WEBCAM_TIMEOUT_S,
            ).stdout
            decoded = subprocess.run(
                ["zbarimg", "-q", "--raw", "-Sdisable", "-Sqrcode.enable", "-"],
                input=photo, capture_output=True, timeout=WEBCAM_TIMEOUT_S,
            ).stdout
        except (OSError, subprocess.SubprocessError):
            return None
        text = decoded.decode("utf-8", "replace").strip()
        return text or None

    def forget(self, device_id: str):
        if self.client is not None:
            self.client.forget(device_id)
        self.units.remove(device_id)
        self.names.remove(device_id)
        self._push("units")
        self._push("names")
        self._changed()

    def rename(self, device_id: str, name: str):
        name = (name or "").strip()
        if name:
            self.names.set(device_id, name)
        else:
            self.names.remove(device_id)
        self._push("names")
        self._changed()

    def set_unit(self, device_id: str, numero: int):
        self._assign_unit(device_id, numero)
        if self.client is not None and self.client.registry.by_id(device_id) is not None:
            self.client.set_state(device_id, commands.set_unit(rev=self.next_rev(), numero=numero))
        self._changed()

    def _assign_unit(self, device_id: str, numero: int):
        # Número já de outro PC: troca, como no celular.
        previous = self.units.owner_of(numero)
        mine = self.units.get(device_id)
        if previous is not None and previous != device_id:
            if mine is not None:
                self.units.set(previous, mine)
            else:
                self.units.remove(previous)
        self.units.set(device_id, numero)
        self._push("units")

    # ---- comandos ------------------------------------------------------------------

    def open_url(self, url: str, device_id: str | None = None):
        command = commands.open_url(url)
        self._send(command, device_id)

    def close_all_tabs(self, device_id: str | None = None):
        self._send(commands.close_all_tabs(), device_id)

    def message(self, title: str, body: str, device_id: str | None = None):
        self._send(commands.show_message(title, body, popup=True, sender=self.prefs.teacher_name), device_id)

    def _send(self, command: dict, device_id: str | None):
        if self.client is None:
            return
        if device_id is None:
            self.client.send_all(command)
        else:
            self.client.send(device_id, command)

    # ---- regras -------------------------------------------------------------------

    def add_rule(self, pattern: str, action: str) -> bool:
        if not self.rules.add(pattern, action):
            return False
        self._rules_changed()
        return True

    def add_rules_bulk(self, text: str, action: str) -> int:
        added = self.rules.add_many((text or "").splitlines(), action)
        if added:
            self._rules_changed()
        return added

    def update_rule(self, index: int, pattern: str, action: str) -> bool:
        if not self.rules.update(index, pattern, action):
            return False
        self._rules_changed()
        return True

    def remove_rule(self, index: int):
        self.rules.remove(index)
        self._rules_changed()

    def _rules_changed(self):
        self._distribute_rules()
        self._push("rules")
        self._changed()

    def _distribute_rules(self):
        if self.client is None or not self.connected:
            return
        try:
            self.client.set_state_all(commands.set_rules(self.rules.rules, rev=self.next_rev()))
        except FirebaseError as error:
            log.warning("regras não chegaram a todos os PCs: %s", error)

    def _push(self, kind: str):
        if self.sync is not None:
            self.sync.schedule_push(kind)

    # ---- papel de parede ----------------------------------------------------------

    def set_wallpaper(self, jpeg: bytes):
        if self.client is None or not self.connected:
            raise FirebaseError("sem_conexao")
        hash_hex = self.client.publish_wallpaper(jpeg)
        self.wallpaper.set(hash_hex)
        self.client.set_state_all(commands.set_wallpaper(hash_hex))
        self._changed()

    # ---- página inicial ----------------------------------------------------------

    def publish_home(self) -> str | None:
        if self.client is None or not self.connected:
            self.home_error = "Sem conexão: a página inicial será publicada quando o app conectar."
        elif not self.email:
            self.home_error = "Entre com a conta Google (em Ajustes) para publicar a página inicial."
        else:
            try:
                self.client.fb.put("/home/escola", home_rules.publish_payload(self.home.config, self.client.now_server_ms()))
                self.home_error = None
            except FirebaseError as error:
                self.home_error = f"A publicação foi recusada ({error})."
        self._changed()
        return self.home_error

    # ---- conta Google e escola -----------------------------------------------------

    @property
    def google_available(self) -> bool:
        return bool(self.config.get("googleClientId"))

    @property
    def email(self) -> str | None:
        saved = self.auth.load() or {}
        value = saved.get("email")
        return value if isinstance(value, str) and value else None

    def login_google(self) -> str | None:
        if not self.google_available:
            return "Conta Google não configurada neste pacote."
        if not self.signed_in:
            return "Sem conexão com o servidor."
        try:
            id_token = self._login_factory().run()
            result = self.client.fb.sign_in_with_idp("google.com", id_token)
        except TimeoutError:
            return "Login cancelado."
        except (OSError, ValueError, FirebaseError) as error:
            return f"Login falhou: {error}"
        self.auth.save({"email": result.get("email") or ""})
        if result.get("switched") or self.not_allowed:
            # A conta Google já era de outro aparelho: o app agora é aquele
            # professor, e o roster é o dele.
            self.restart()
        else:
            self._changed()
        return None

    # ---- login entregue pelo celular ----------------------------------------------

    def begin_phone_login(self, on_done) -> str | None:
        """Abre um canal e devolve o texto do QR; `on_done(error)` é chamado de
        outra thread quando o celular responder (None = entrou)."""
        if not self.signed_in:
            return None
        self.cancel_phone_login()
        handoff = LoginHandoff()
        self._handoff = handoff
        self._handoff_stream = self.client.fb.stream(handoff.path, lambda event: self._on_handoff(handoff, event, on_done))
        return handoff.qr_payload()

    def cancel_phone_login(self):
        stream, self._handoff_stream = getattr(self, "_handoff_stream", None), None
        self._handoff = None
        if stream is not None:
            stream.close()

    def _on_handoff(self, handoff, event: dict, on_done):
        if event.get("path") != "/" or getattr(self, "_handoff", None) is not handoff:
            return
        delivered = handoff.open(event.get("data"))
        if delivered is None:
            return
        self.cancel_phone_login()
        on_done(self._finish_phone_login(handoff, delivered))

    def _finish_phone_login(self, handoff, delivered: dict) -> str | None:
        try:
            result = self.client.fb.sign_in_with_idp("google.com", delivered["idToken"], link=False)
        except FirebaseError as error:
            return f"O servidor não aceitou o login ({error}). Tente de novo pelo celular."
        try:
            self.client.fb.delete(handoff.path)
        except FirebaseError:
            pass
        self.auth.save({"email": result.get("email") or ""})
        try:
            self.keys.adopt(delivered["keys"])
        except (ValueError, TypeError):
            return "A chave recebida do celular é inválida."
        if delivered["teacherName"]:
            self.prefs.set_teacher_name(delivered["teacherName"])
        self.prefs.set_school_uid(delivered["schoolUid"])
        self.restart()
        return None

    @property
    def school_active(self) -> bool:
        return bool(self.prefs.school_uid)

    def join_school(self) -> str | None:
        if self.client is None or not self.connected:
            return "Sem conexão com o servidor."
        if not self.email:
            return "Entre com a conta Google primeiro."
        school_keys = SchoolKeys(self.client.fb)
        try:
            school_uid = school_keys.school_uid()
            if school_uid is None:
                return "A escola ainda não foi criada — peça ao professor fundador."
            if not school_keys.is_member(school_uid, self.email):
                return NOT_ALLOWED.format(email=self.email)
            school = school_keys.download()
        except FirebaseError as error:
            return f"Não foi possível ler a escola ({error})."
        if school is None:
            return "A escola ainda não foi criada — peça ao professor fundador."
        if self.keys.raw() != school["keys"]:
            self.keys.adopt(school["keys"])
        self.prefs.set_school_uid(school["schoolUid"])
        self.restart()
        return None

    def create_school(self) -> str | None:
        if self.client is None or not self.connected:
            return "Sem conexão com o servidor."
        if not self.email:
            return "Entre com a conta Google primeiro."
        uid = self.client.teacher_uid
        try:
            error = SchoolKeys(self.client.fb).publish(uid, self.keys.raw())
            if error:
                return error
            roster = self.client.fb.get(f"/teachers/{uid}/devices")
            if isinstance(roster, dict) and roster:
                self.client.fb.patch("/school/devices", {k: True for k in roster})
        except FirebaseError as error:
            return f"Não foi possível criar a escola ({error})."
        self.prefs.set_school_uid(uid)
        self.restart()
        if self.sync is not None:
            self.sync.push_all()
        return None

    def set_teacher_name(self, name: str):
        self.prefs.set_teacher_name(name)
        if self.client is not None:
            self.client.teacher_name = self.prefs.teacher_name
        self._changed()

    @staticmethod
    def load_config(path: str | None = None) -> dict:
        path = path or os.environ.get("CONTROLE_DE_AULA_CONFIG") or "/usr/share/controle-de-aula/firebase.json"
        with open(path, encoding="utf-8") as handle:
            return json.load(handle)
