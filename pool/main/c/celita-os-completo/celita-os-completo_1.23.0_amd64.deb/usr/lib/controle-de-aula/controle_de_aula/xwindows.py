"""Programas abertos lidos direto do X (python3-xlib), sem fork e sem XFCE.

O critério é o da barra de tarefas: janelas de `_NET_CLIENT_LIST` do tipo
NORMAL (ou sem tipo e sem WM_TRANSIENT_FOR) e sem SKIP_TASKBAR. O agente é
root e o XAUTHORITY vem do ambiente do aluno, então o arquivo é aberto com
cuidado e o cookie vai direto ao Xlib.
"""

import logging
import os
import re
import socket
import stat
import struct
import threading
import time

log = logging.getLogger("controle-de-aula.xwindows")

DISPLAY_RE = re.compile(r"^:([0-9]+)(\.[0-9]+)?$")
X_SOCKET_TIMEOUT_S = 2
CALL_TIMEOUT_S = 3
MAX_XAUTHORITY_BYTES = 64 * 1024
BROWSER_NAME = "Google Chrome"
BROWSER_CLASSES = ("voges", "chromium")
DESKTOP_DIRS = ("/usr/share/applications", "/usr/local/share/applications")
DESKTOP_RESCAN_S = 60
COOKIE_NAME = b"MIT-MAGIC-COOKIE-1"
FAMILY_LOCAL = 256
FAMILY_WILD = 65535

TYPE_NORMAL = "_NET_WM_WINDOW_TYPE_NORMAL"
STATE_SKIP_TASKBAR = "_NET_WM_STATE_SKIP_TASKBAR"


# ---- Filtro puro -----------------------------------------------------------------


def on_taskbar(window: dict) -> bool:
    """`window`: {types: [nomes], transient: bool, states: [nomes]}."""
    types = window.get("types") or []
    keep = TYPE_NORMAL in types if types else not window.get("transient")
    return keep and STATE_SKIP_TASKBAR not in (window.get("states") or [])


def is_browser(wm_class) -> bool:
    for part in wm_class or ():
        text = (part or "").casefold()
        if text in BROWSER_CLASSES or text.startswith("voges ("):
            return True
    return False


def apps_from_windows(windows: list, browser_reported: bool, name_for) -> list:
    """O navegador some quando a extensão já reporta as abas; sem relatório
    fresco ele aparece como programa, para o professor não ficar às cegas."""
    apps = []
    for window in windows:
        if not on_taskbar(window):
            continue
        wm_class = window.get("wm_class") or ()
        if is_browser(wm_class):
            if browser_reported:
                continue
            name = BROWSER_NAME
        else:
            name = name_for(wm_class, window.get("pid"))
        apps.append({"name": name, "title": window.get("title") or ""})
    return apps


# ---- Nomes pelos .desktop ------------------------------------------------------


class DesktopNames:
    """`Name=` do .desktop cujo StartupWMClass (ou nome do arquivo) casa com o WM_CLASS."""

    def __init__(self, directories=DESKTOP_DIRS):
        self.directories = directories
        self._index = {}
        self._checked_at = None
        self._stamp = None

    def _mtimes(self):
        stamps = []
        for directory in self.directories:
            try:
                stamps.append(os.stat(directory).st_mtime_ns)
            except OSError:
                stamps.append(None)
        return tuple(stamps)

    def _refresh(self):
        now = time.monotonic()
        if self._checked_at is not None and now - self._checked_at < DESKTOP_RESCAN_S:
            return
        self._checked_at = now
        stamp = self._mtimes()
        if stamp == self._stamp:
            return
        self._stamp = stamp
        index = {}
        for directory in self.directories:
            try:
                names = sorted(os.listdir(directory))
            except OSError:
                continue
            for filename in names:
                if filename.endswith(".desktop"):
                    self._index_file(index, os.path.join(directory, filename), filename[: -len(".desktop")])
        self._index = index

    @staticmethod
    def _index_file(index: dict, path: str, stem: str):
        name = wm_class = None
        try:
            with open(path, encoding="utf-8", errors="replace") as handle:
                in_entry = False
                for line in handle:
                    line = line.strip()
                    if line.startswith("["):
                        in_entry = line == "[Desktop Entry]"
                    elif in_entry and line.startswith("Name=") and name is None:
                        name = line[5:].strip()
                    elif in_entry and line.startswith("StartupWMClass="):
                        wm_class = line[15:].strip()
        except OSError:
            return
        if not name:
            return
        for key in (wm_class, stem):
            if key:
                index.setdefault(key.casefold(), name)

    def lookup(self, wm_class) -> str | None:
        self._refresh()
        for part in wm_class or ():
            name = self._index.get((part or "").casefold())
            if name:
                return name
        return None


def _comm(pid) -> str | None:
    if not isinstance(pid, int) or pid <= 0:
        return None
    try:
        with open(f"/proc/{pid}/comm", encoding="utf-8", errors="replace") as handle:
            return handle.read().strip() or None
    except OSError:
        return None


# ---- XAUTHORITY -------------------------------------------------------------------


def parse_xauthority(data: bytes, display_number: str) -> bytes | None:
    """Cookie MIT do display pedido; entrada curinga serve de reserva."""
    offset, fallback = 0, None
    try:
        while offset + 2 <= len(data):
            family = struct.unpack_from(">H", data, offset)[0]
            offset += 2
            fields = []
            for _ in range(4):
                size = struct.unpack_from(">H", data, offset)[0]
                offset += 2
                if offset + size > len(data):
                    return fallback
                fields.append(data[offset: offset + size])
                offset += size
            _address, number, name, cookie = fields
            if name != COOKIE_NAME:
                continue
            if number.decode("ascii", "replace") == display_number and family in (FAMILY_LOCAL, FAMILY_WILD):
                return cookie
            if fallback is None and family == FAMILY_WILD:
                fallback = cookie
    except struct.error:
        pass
    return fallback


def read_cookie(path: str, uid: int, display_number: str) -> bytes | None:
    """Arquivo regular do próprio aluno, sem seguir link e sem travar em FIFO."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    except OSError:
        return None
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != uid or info.st_size > MAX_XAUTHORITY_BYTES:
            return None
        data = os.read(fd, MAX_XAUTHORITY_BYTES)
    except OSError:
        return None
    finally:
        os.close(fd)
    return parse_xauthority(data, display_number)


# ---- Conexão X ---------------------------------------------------------------------

# O Xlib lê o cookie do ambiente global; a troca pontual do get_auth fica
# atrás desta trava para duas criações nunca se misturarem.
_create_lock = threading.Lock()


def _open_display(display: str, cookie: bytes | None):
    from Xlib import display as xdisplay
    from Xlib.support import connect

    auth = (COOKIE_NAME, cookie) if cookie else (b"", b"")
    with _create_lock:
        original_auth, original_socket = connect.get_auth, connect.get_socket

        def get_socket(*args):
            sock = original_socket(*args)
            sock.settimeout(X_SOCKET_TIMEOUT_S)
            return sock

        connect.get_auth = lambda *_args: auth
        connect.get_socket = get_socket
        try:
            return xdisplay.Display(display)
        finally:
            connect.get_auth, connect.get_socket = original_auth, original_socket


def _read_windows(connection) -> list:
    from Xlib import X, Xatom
    from Xlib.error import XError

    atoms, known = connection["atoms"], connection["known"]
    display = connection["display"]
    root = display.screen().root
    listing = root.get_full_property(atoms["_NET_CLIENT_LIST"], X.AnyPropertyType)
    windows = []
    for window_id in (listing.value if listing else []):
        window = display.create_resource_object("window", window_id)
        try:
            types = window.get_full_property(atoms["_NET_WM_WINDOW_TYPE"], Xatom.ATOM)
            states = window.get_full_property(atoms["_NET_WM_STATE"], Xatom.ATOM)
            title = window.get_full_property(atoms["_NET_WM_NAME"], atoms["UTF8_STRING"])
            pid = window.get_full_property(atoms["_NET_WM_PID"], Xatom.CARDINAL)
            if title and title.value:
                text = title.value.decode("utf-8", "replace") if isinstance(title.value, bytes) else str(title.value)
            else:
                legacy = window.get_wm_name()
                text = legacy.decode("latin-1") if isinstance(legacy, bytes) else (legacy or "")
            windows.append({
                "types": [known.get(atom, "?") for atom in (types.value if types else [])],
                "states": [known.get(atom, "?") for atom in (states.value if states else [])],
                "transient": window.get_wm_transient_for() is not None,
                "wm_class": window.get_wm_class() or (),
                "title": text,
                "pid": int(pid.value[0]) if pid and len(pid.value) else None,
            })
        except XError:
            continue  # janela fechou no meio da leitura
    return windows


class WindowLister:
    """Uma conexão por sessão, refeita ao trocar de sessão ou em erro. Cada
    leitura corre numa thread de trabalho com espera curta: um X travado não
    pode segurar o relatório."""

    def __init__(self, names: DesktopNames | None = None):
        self.names = names or DesktopNames()
        self._lock = threading.Lock()
        self._connection = None

    def _name_for(self, wm_class, pid) -> str:
        return self.names.lookup(wm_class) or _comm(pid) or (wm_class[-1] if wm_class else "?")

    def list(self, session, browser_reported: bool) -> list:
        display = (session.env or {}).get("DISPLAY") or session.display or ""
        match = DISPLAY_RE.match(display)
        if not match:
            return []
        if self._lock.locked():
            return []  # a leitura anterior ainda não voltou
        box = {}
        worker = threading.Thread(
            target=self._work, args=(session, display, match.group(1), box), name="xwindows", daemon=True,
        )
        worker.start()
        worker.join(CALL_TIMEOUT_S)
        if worker.is_alive():
            self._abandon()
            return []
        windows = box.get("windows")
        if windows is None:
            return []
        return apps_from_windows(windows, browser_reported, self._name_for)

    def _work(self, session, display: str, number: str, box: dict):
        with self._lock:
            try:
                connection = self._connect(session, display, number)
                if connection is None:
                    return
                box["windows"] = _read_windows(connection)
            except ImportError:
                return
            except Exception as error:  # noqa: BLE001 - X caiu: refaz na próxima
                log.debug("leitura das janelas falhou: %s", error)
                self._drop()

    def _connect(self, session, display: str, number: str):
        key = (session.key, display)
        if self._connection is not None and self._connection["key"] == key:
            return self._connection
        self._drop()
        xauthority = (session.env or {}).get("XAUTHORITY") or ""
        cookie = read_cookie(xauthority, session.uid, number) if xauthority else None
        handle = _open_display(display, cookie)
        names = ("_NET_CLIENT_LIST", "_NET_WM_WINDOW_TYPE", "_NET_WM_STATE", "_NET_WM_NAME",
                 "_NET_WM_PID", "UTF8_STRING", TYPE_NORMAL, STATE_SKIP_TASKBAR)
        atoms = {name: handle.intern_atom(name) for name in names}
        known = {atoms[TYPE_NORMAL]: TYPE_NORMAL, atoms[STATE_SKIP_TASKBAR]: STATE_SKIP_TASKBAR}
        self._connection = {"key": key, "display": handle, "atoms": atoms, "known": known}
        return self._connection

    def _drop(self):
        connection, self._connection = self._connection, None
        if connection is not None:
            try:
                connection["display"].close()
            except Exception:  # noqa: BLE001
                pass

    def _abandon(self):
        # A thread presa segura a trava; derrubar o socket acorda o select dela.
        connection = self._connection
        if connection is None:
            return
        try:
            connection["display"].display.socket.shutdown(socket.SHUT_RDWR)
        except Exception:  # noqa: BLE001
            pass


LISTER = WindowLister()
