"""Sessão gráfica: quem está logado e como agir dentro dela.

Conta controlada é conta do grupo nopasswdlogin. O agente roda como root e
executa dentro da sessão por runuser, com DISPLAY, XAUTHORITY e o barramento
lidos do processo líder da sessão.
"""

import base64
import grp
import logging
import os
import pwd
import re
import subprocess
import tempfile
import threading
import time

log = logging.getLogger("controle-de-aula.session")

CONTROLLED_GROUP = "nopasswdlogin"
SESSION_CACHE_S = 5
COMMAND_TIMEOUT_S = 20
CAMERA_DEVICE = "/dev/video0"
# Quadros descartados antes da foto (a câmera ajusta a exposição). Medir no aparelho.
CAMERA_SKIP_FRAMES = 3
CAMERA_REUSE_S = 5
WALLPAPER_PATH = "/var/lib/controle-de-aula/wallpaper.jpg"
LOGIND_SESSIONS_DIR = "/run/systemd/sessions"
BOOT_ID_PATH = "/proc/sys/kernel/random/boot_id"
MIN_HUMAN_UID = 1000


class Session:
    def __init__(self, session_id: str, user: str, uid: int, display: str, leader: int,
                 controlled: bool = True, realtime_ms: int | None = None, boot_id: str = ""):
        self.id = session_id
        self.user = user
        self.uid = uid
        self.display = display
        self.leader = leader
        self.controlled = controlled
        self.realtime_ms = realtime_ms
        self.key = f"{boot_id}:{session_id}"
        self.env = self._read_env()

    def _read_env(self) -> dict:
        env = {
            "DISPLAY": self.display or ":0",
            "XAUTHORITY": os.path.join(pwd.getpwnam(self.user).pw_dir, ".Xauthority"),
            "DBUS_SESSION_BUS_ADDRESS": f"unix:path=/run/user/{self.uid}/bus",
        }
        try:
            with open(f"/proc/{self.leader}/environ", "rb") as handle:
                for item in handle.read().split(b"\0"):
                    key, sep, value = item.partition(b"=")
                    if sep and key.decode() in env and value:
                        env[key.decode()] = value.decode("utf-8", "replace")
        except OSError:
            pass
        return env

    def run(self, argv: list, timeout: float = COMMAND_TIMEOUT_S, capture: bool = True):
        command = ["runuser", "-u", self.user, "--", "env"]
        command += [f"{k}={v}" for k, v in self.env.items()]
        command += argv
        return subprocess.run(
            command,
            capture_output=capture,
            timeout=timeout,
            check=False,
            stdin=subprocess.DEVNULL,
        )

    def spawn(self, argv: list):
        command = ["runuser", "-u", self.user, "--", "env"]
        command += [f"{k}={v}" for k, v in self.env.items()]
        command += argv
        subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )


def _controlled_users() -> set:
    try:
        group = grp.getgrnam(CONTROLLED_GROUP)
    except KeyError:
        return set()
    members = set(group.gr_mem)
    for entry in pwd.getpwall():
        if entry.pw_gid == group.gr_gid:
            members.add(entry.pw_name)
    return members


def _loginctl(*args) -> str:
    try:
        return subprocess.run(
            ["loginctl", *args],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        ).stdout
    except (OSError, subprocess.TimeoutExpired):
        return ""


def _read_key_values(path: str) -> dict:
    with open(path, encoding="utf-8", errors="replace") as handle:
        return dict(line.rstrip("\n").split("=", 1) for line in handle if "=" in line and not line.startswith("#"))


def _boot_id() -> str:
    try:
        with open(BOOT_ID_PATH, encoding="ascii") as handle:
            return handle.read().strip()
    except OSError:
        return ""


def _logind_files(directory: str) -> list | None:
    """Sessões lidas dos arquivos do logind (root, sem fork); None = indisponível."""
    try:
        names = sorted(os.listdir(directory))
    except OSError:
        return None
    sessions = []
    for name in names:
        if "." in name:
            continue
        try:
            values = _read_key_values(os.path.join(directory, name))
        except OSError:
            continue
        sessions.append({
            "id": name,
            "class": values.get("CLASS"),
            "state": values.get("STATE"),
            "type": values.get("TYPE"),
            "user": values.get("USER", ""),
            "uid": values.get("UID", ""),
            "display": values.get("DISPLAY", ""),
            "leader": values.get("LEADER", ""),
            "realtime": values.get("REALTIME", ""),
        })
    return sessions


def _logind_loginctl() -> list:
    sessions = []
    for line in _loginctl("list-sessions", "--no-legend").splitlines():
        fields = line.split()
        if not fields:
            continue
        props = _loginctl(
            "show-session", fields[0],
            "-p", "Class", "-p", "State", "-p", "Type", "-p", "Name",
            "-p", "User", "-p", "Display", "-p", "Leader",
        )
        values = dict(item.split("=", 1) for item in props.splitlines() if "=" in item)
        sessions.append({
            "id": fields[0],
            "class": values.get("Class"),
            "state": values.get("State"),
            "type": values.get("Type"),
            "user": values.get("Name", ""),
            "uid": values.get("User", ""),
            "display": values.get("Display", ""),
            "leader": values.get("Leader", ""),
            "realtime": "",
        })
    return sessions


class SessionTracker:
    """Uma varredura em cache curto serve a sessão controlada ativa e a sessão
    gráfica ativa de qualquer conta humana."""

    def __init__(self, sessions_dir: str = LOGIND_SESSIONS_DIR):
        self.sessions_dir = sessions_dir
        self._cached = []
        self._cached_at = None
        self._lock = threading.Lock()

    def _scan_cached(self) -> list:
        with self._lock:
            now = time.monotonic()
            if self._cached_at is None or now - self._cached_at >= SESSION_CACHE_S:
                self._cached = self._scan()
                self._cached_at = now
            return self._cached

    def active(self) -> Session | None:
        for session in self._scan_cached():
            if session.controlled:
                return session
        return None

    def active_any(self) -> Session | None:
        sessions = self._scan_cached()
        return sessions[0] if sessions else None

    def _scan(self) -> list:
        raw = _logind_files(self.sessions_dir)
        if raw is None:
            raw = _logind_loginctl()
        controlled = _controlled_users()
        boot_id = _boot_id()
        found = []
        for values in raw:
            if values.get("class") != "user" or values.get("state") != "active":
                continue
            if values.get("type") not in ("x11", "wayland"):
                continue
            try:
                uid = int(values.get("uid", ""))
                leader = int(values.get("leader", ""))
            except ValueError:
                continue
            user = values.get("user", "")
            if uid < MIN_HUMAN_UID or not user:
                continue
            try:
                realtime_ms = int(values.get("realtime") or "") // 1000 or None
            except ValueError:
                realtime_ms = None
            try:
                found.append(Session(values["id"], user, uid, values.get("display", ""), leader,
                                     controlled=user in controlled, realtime_ms=realtime_ms, boot_id=boot_id))
            except KeyError:
                continue  # conta sumiu do passwd entre a varredura e o Session
        found.sort(key=lambda session: not session.controlled)
        return found


# ---- Ações dentro da sessão --------------------------------------------------


def _read_and_remove(path: str) -> bytes | None:
    try:
        with open(path, "rb") as handle:
            return handle.read()
    except OSError:
        return None
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def capture_screen(session: Session) -> dict:
    # O arquivo nasce em um diretório do próprio usuário, porque o scrot roda
    # como ele; a leitura é do root, que apaga em seguida.
    path = f"/run/user/{session.uid}/controle-de-aula-tela.jpg"
    try:
        result = session.run(["scrot", "-o", "-q", "45", path])
    except (OSError, subprocess.TimeoutExpired) as error:
        return {"ok": False, "error": f"tela_{type(error).__name__}"}
    if result.returncode != 0:
        return {"ok": False, "error": "tela_" + result.stderr.decode("utf-8", "replace").strip()[:80]}
    data = _read_and_remove(path)
    if not data:
        return {"ok": False, "error": "tela_vazia"}
    return {"ok": True, "jpegB64": base64.b64encode(data).decode("ascii")}


# Uma câmera só: o comando do professor e as fotos do arquivo se revezam, e a
# foto recente serve aos dois.
_camera_lock = threading.Lock()
_camera_last = {"at": None, "jpeg": None}


def _run_fswebcam() -> tuple[bytes | None, str | None]:
    if not os.path.exists(CAMERA_DEVICE):
        return None, "camera_ausente"
    fd, path = tempfile.mkstemp(prefix="controle-de-aula-", suffix=".jpg")
    os.close(fd)
    try:
        result = subprocess.run(
            ["fswebcam", "-q", "-d", CAMERA_DEVICE, "-r", "640x480", "--no-banner",
             "--jpeg", "60", "-S", str(CAMERA_SKIP_FRAMES), path],
            capture_output=True,
            timeout=COMMAND_TIMEOUT_S,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        _read_and_remove(path)
        return None, f"camera_{type(error).__name__}"
    data = _read_and_remove(path)
    if result.returncode != 0 or not data:
        return None, "camera_falhou"
    return data, None


def capture_camera_jpeg() -> tuple[bytes | None, str | None]:
    """(jpeg, None) ou (None, erro)."""
    with _camera_lock:
        at = _camera_last["at"]
        if at is not None and time.monotonic() - at < CAMERA_REUSE_S:
            return _camera_last["jpeg"], None
        jpeg, error = _run_fswebcam()
        if jpeg:
            _camera_last["at"], _camera_last["jpeg"] = time.monotonic(), jpeg
        return jpeg, error


def capture_camera() -> dict:
    jpeg, error = capture_camera_jpeg()
    if not jpeg:
        return {"ok": False, "error": error}
    return {"ok": True, "jpegB64": base64.b64encode(jpeg).decode("ascii")}


def list_apps(session: Session, browser_reported: bool = False) -> list:
    """Janelas da barra de tarefas, lidas do X no próprio processo."""
    from .xwindows import LISTER
    return LISTER.list(session, browser_reported)


def notify(session: Session, title: str, body: str) -> dict:
    try:
        result = session.run(
            ["notify-send", "-a", "Controle de Aula", "-u", "critical",
             "-i", "dialog-information", title, body],
            timeout=10,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        return {"ok": False, "error": f"aviso_{type(error).__name__}"}
    return {"ok": result.returncode == 0, "error": None if result.returncode == 0 else "aviso_falhou"}


def open_browser(session: Session, url: str) -> dict:
    try:
        session.spawn(["voges", url])
    except OSError as error:
        return {"ok": False, "error": f"voges_{type(error).__name__}"}
    return {"ok": True}


def set_wallpaper(session: Session, jpeg: bytes) -> dict:
    # O xfconf é por usuário, então o arquivo fica em lugar legível por todos e
    # cada propriedade last-image do xfce4-desktop aponta para ele.
    try:
        os.makedirs(os.path.dirname(WALLPAPER_PATH), exist_ok=True)
        with open(WALLPAPER_PATH + ".tmp", "wb") as handle:
            handle.write(jpeg)
        os.chmod(WALLPAPER_PATH + ".tmp", 0o644)
        os.replace(WALLPAPER_PATH + ".tmp", WALLPAPER_PATH)
        listing = session.run(["xfconf-query", "-c", "xfce4-desktop", "-l"], timeout=10)
    except (OSError, subprocess.TimeoutExpired) as error:
        return {"ok": False, "error": f"papel_{type(error).__name__}"}
    properties = [
        line.strip()
        for line in listing.stdout.decode("utf-8", "replace").splitlines()
        if line.strip().endswith("/last-image")
    ]
    if not properties:
        return {"ok": False, "error": "papel_sem_monitor"}
    for prop in properties:
        try:
            session.run(["xfconf-query", "-c", "xfce4-desktop", "-p", prop, "-s", WALLPAPER_PATH], timeout=10)
        except (OSError, subprocess.TimeoutExpired):
            return {"ok": False, "error": "papel_xfconf"}
    return {"ok": True}


_VERSAO_VALIDA = re.compile(r"^[0-9A-Za-z.+~-]{1,20}$")
UPDATE_UNIT = "celita-update-manual.service"


def celita_version() -> str | None:
    """Versão instalada do celita-os-completo, ou None fora do Celita."""
    try:
        result = subprocess.run(
            ["dpkg-query", "-W", "-f=${Version}", "celita-os-completo"],
            capture_output=True, text=True, timeout=10, check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    version = result.stdout.strip()
    return version if result.returncode == 0 and _VERSAO_VALIDA.match(version) else None


def start_update() -> dict:
    # A mesma verificação do "Atualizar agora" da Central. --no-block: o apt
    # reinicia este agente no meio, e o ack precisa sair antes.
    try:
        result = subprocess.run(
            ["systemctl", "start", "--no-block", UPDATE_UNIT],
            capture_output=True, timeout=10, check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        return {"ok": False, "error": f"atualizar_{type(error).__name__}"}
    if result.returncode != 0:
        return {"ok": False, "error": "atualizador_ausente"}
    return {"ok": True}
