"""Chat do aluno no Celita: histórico no agente e o socket da janela.

O histórico vive aqui, em memória, por Session.key (≤ 100 itens), e não na
janela: fechar a janela não perde nada, e logout, troca de sessão, fim de aula
ou reinício do agente apagam tudo. A janela `chat-aluno` é só uma vista que
fala com o agente por `/run/controle-de-aula/aluno.sock`, uma mensagem JSON
por linha; só o uid da sessão controlada ativa é atendido.
"""

import logging
import queue
import threading
import time

from . import protocol, up

log = logging.getLogger("controle-de-aula.chat")

ALUNO_SOCKET_PATH = "/run/controle-de-aula/aluno.sock"
ALUNO_MAX_MESSAGE = 4096
CHAT_UNIT = "controle-de-aula-chat"
CHAT_BIN = "/usr/lib/controle-de-aula/chat-aluno"
ABRIR_INTERVALO_S = 5
# Envios esperando a rede; além disso a janela recebe "falhou" na hora.
FILA_MAX = 32
TEXTO_SEM_ENVIO = "Não foi possível enviar agora. Tente de novo."


def hora(ms) -> str:
    try:
        return time.strftime("%H:%M", time.localtime(float(ms) / 1000))
    except (TypeError, ValueError, OverflowError, OSError):
        return ""


def texto_recusa(site: str, motivo: str | None) -> str:
    texto = f"Pedido para abrir {site} não foi liberado."
    if not motivo:
        return texto
    motivo = motivo.strip()
    final = "" if motivo.endswith((".", "!", "?", "…")) else "."
    return f"{texto} Motivo: {motivo}{final}"


def texto_liberado(site: str) -> str:
    return f"O professor liberou {site}."


class Historico:
    """Itens {id, autor: professor|aluno|sistema, de?, texto, ts, estado?}."""

    def __init__(self, limite: int = protocol.CHAT_HISTORICO_PC):
        self.limite = limite
        self._chave = None
        self._itens = []
        self._lock = threading.Lock()

    def _da_sessao(self, chave):
        if chave != self._chave:
            self._chave = chave
            self._itens = []

    def itens(self, chave) -> list:
        with self._lock:
            self._da_sessao(chave)
            return [dict(item) for item in self._itens]

    def adicionar(self, chave, item: dict) -> dict | None:
        """Devolve o item, ou None se o id já existe (reentrega)."""
        with self._lock:
            self._da_sessao(chave)
            if any(i["id"] == item["id"] for i in self._itens):
                return None
            self._itens.append(dict(item))
            del self._itens[: max(0, len(self._itens) - self.limite)]
            return dict(item)

    def achar(self, chave, item_id) -> dict | None:
        with self._lock:
            self._da_sessao(chave)
            for item in self._itens:
                if item["id"] == item_id:
                    return dict(item)
        return None

    def marcar(self, chave, item_id, estado: str):
        with self._lock:
            self._da_sessao(chave)
            for item in self._itens:
                if item["id"] == item_id:
                    item["estado"] = estado

    def ultimo_de(self, chave) -> str | None:
        with self._lock:
            self._da_sessao(chave)
            for item in reversed(self._itens):
                if item["autor"] == "professor" and item.get("de"):
                    return item["de"]
        return None

    def limpar(self):
        with self._lock:
            self._itens = []


class ChatAluno:
    """Lado do agente da janela de chat. Dependências injetadas:

    - `sessions.active()` → sessão controlada ativa ou None;
    - `enviar_up(session, tipo, payload, mid)` → (ok, erro, aviso): o ponto
      único de saída, com limites;
    - `travado()`, `conectado()`, `nome_padrao()`;
    - `abrir(session)`: sobe a janela (serviço transitório, `--sem-foco`).
    """

    def __init__(self, sessions, enviar_up, travado, conectado, nome_padrao, abrir, agora_ms=None,
                 monotonic=time.monotonic):
        self.sessions = sessions
        self.enviar_up = enviar_up
        self.travado = travado
        self.conectado = conectado
        self.nome_padrao = nome_padrao
        self.abrir_janela = abrir
        self.agora_ms = agora_ms or (lambda: int(time.time() * 1000))
        self.monotonic = monotonic
        self.server = None  # BridgeServer do aluno.sock, ligado pelo agente
        self.historico = Historico()
        self._abrir_pendente = False
        self._aberto_em = None
        # Chave da sessão que pediu janela dentro do intervalo entre aberturas:
        # o tique do agente abre quando o intervalo passar.
        self._reabrir = None
        self._ultima_conexao = None
        self._fila = queue.Queue(maxsize=FILA_MAX)
        self._worker = None
        self._worker_lock = threading.Lock()
        self._mao_em = {}

    # ---- janela conectada ------------------------------------------------------------

    def _cliente(self, session=None):
        session = session or self.sessions.active()
        if session is None or self.server is None:
            return None
        return self.server.client_for_uid(session.uid)

    def _enviar_janela(self, message: dict, session=None) -> bool:
        client = self._cliente(session)
        return bool(client and client.send(message))

    def nome(self, session) -> str:
        return self.historico.ultimo_de(session.key) or self.nome_padrao() or "Professor"

    def _abrir(self, session):
        if self.travado():
            self._abrir_pendente = True
            return
        if self._cliente(session) is not None:
            self._reabrir = None
            return
        now = self.monotonic()
        if self._aberto_em is not None and now - self._aberto_em < ABRIR_INTERVALO_S:
            # A janela acabou de subir (ainda conectando) ou o aluno a fechou
            # agora: confere de novo depois do intervalo, para a mensagem nova
            # não ficar sem janela.
            self._reabrir = session.key
            return
        self._aberto_em = now
        self._abrir_pendente = False
        self._reabrir = None
        try:
            self.abrir_janela(session)
        except Exception as error:  # noqa: BLE001
            log.warning("janela de chat não abriu: %s", error)

    def tick(self):
        """Tique do agente (2 s): abre a janela adiada pelo intervalo."""
        chave = self._reabrir
        if chave is None:
            return
        session = self.sessions.active()
        if session is None or session.key != chave:
            self._reabrir = None
            return
        if self._aberto_em is not None and self.monotonic() - self._aberto_em < ABRIR_INTERVALO_S:
            return
        self._abrir(session)

    def _da_sessao_ativa(self, session) -> bool:
        atual = self.sessions.active()
        return atual is not None and atual.key == session.key

    # ---- eventos do agente ---------------------------------------------------------------

    def mensagem_professor(self, session, texto: str, de: str | None, mid: str, ts=None):
        item = {"id": mid, "autor": "professor", "texto": texto,
                "ts": int(ts) if isinstance(ts, (int, float)) and not isinstance(ts, bool) else self.agora_ms()}
        if de:
            item["de"] = de
        novo = self.historico.adicionar(session.key, item)
        if novo is None:
            return
        self._enviar_janela({"t": "chat", "item": novo}, session)
        self._abrir(session)

    def sistema(self, session, texto: str, abrir: bool = False):
        item = self.historico.adicionar(session.key, {"id": up.new_id(), "autor": "sistema", "texto": texto,
                                                     "ts": self.agora_ms()})
        if item is not None:
            self._enviar_janela({"t": "chat", "item": item}, session)
        if abrir:
            self._abrir(session)

    def fim_de_aula(self):
        self.historico.limpar()
        self._abrir_pendente = False
        self._reabrir = None
        self._mao_em = {}
        if self.server is not None:
            self.server.broadcast({"t": "fechar"})

    def estado_conexao(self, conectado: bool):
        if conectado == self._ultima_conexao:
            return
        self._ultima_conexao = conectado
        self._enviar_janela({"t": "conexao", "conectado": conectado})

    def trava(self, on: bool):
        session = self.sessions.active()
        if session is None:
            return
        self._enviar_janela({"t": "trava", "on": on}, session)
        if not on and self._abrir_pendente:
            self._abrir_pendente = False
            self._abrir(session)

    # ---- mensagens da janela (thread do socket) -------------------------------------------

    def on_message(self, client, message: dict):
        session = self.sessions.active()
        if session is None or client.uid != session.uid:
            client.close()
            return
        kind = message.get("t")
        if kind == "hello":
            levantada = self._mao_recente(session)
            client.send({"t": "historico", "de": self.nome(session), "itens": self.historico.itens(session.key)})
            client.send({"t": "conexao", "conectado": bool(self.conectado())})
            client.send({"t": "trava", "on": bool(self.travado())})
            client.send({"t": "mao", "levantada": levantada})
        elif kind == "chat":
            item_id, texto = message.get("id"), message.get("texto")
            payload = up.limpar_payload(protocol.UP_CHAT, {"texto": texto})
            if not up.id_valido(item_id) or payload is None:
                return
            item = self.historico.adicionar(session.key, {"id": item_id, "autor": "aluno", "texto": payload["texto"],
                                                          "ts": self.agora_ms(), "estado": "enviando"})
            if item is not None:
                self._agendar(session, protocol.UP_CHAT, payload, item_id)
        elif kind == "reenviar":
            item = self.historico.achar(session.key, message.get("id"))
            if item and item["autor"] == "aluno" and item.get("estado") == "falhou":
                self.historico.marcar(session.key, item["id"], "enviando")
                client.send({"t": "estado-msg", "id": item["id"], "estado": "enviando"})
                self._agendar(session, protocol.UP_CHAT, {"texto": item["texto"]}, item["id"])
        elif kind == "mao":
            self._agendar(session, protocol.UP_HAND, {}, up.new_id())

    def _mao_recente(self, session) -> bool:
        levantada_em = self._mao_em.get(session.key)
        return levantada_em is not None and self.monotonic() - levantada_em < 10

    # ---- envio (uma thread, na ordem) -----------------------------------------------------

    def _agendar(self, session, tipo, payload, mid):
        with self._worker_lock:
            if self._worker is None:
                self._worker = threading.Thread(target=self._trabalhar, name="chat-up", daemon=True)
                self._worker.start()
        try:
            self._fila.put_nowait((session, tipo, payload, mid))
        except queue.Full:
            # Janela inundando o socket: não acumula, responde já.
            if tipo == protocol.UP_CHAT:
                self.historico.marcar(session.key, mid, "falhou")
                self._enviar_janela({"t": "estado-msg", "id": mid, "estado": "falhou"}, session)

    def _trabalhar(self):
        while True:
            session, tipo, payload, mid = self._fila.get()
            try:
                self._enviar(session, tipo, payload, mid)
            except Exception as error:  # noqa: BLE001 - a fila nunca morre
                log.warning("envio do chat falhou: %s", error)
            finally:
                self._fila.task_done()

    def drenar(self):
        """Espera os envios agendados terminarem (testes)."""
        self._fila.join()

    def _enviar(self, session, tipo, payload, mid):
        ok, erro, aviso = self.enviar_up(session, tipo, payload, mid)
        if not self._da_sessao_ativa(session):
            # A sessão acabou com o envio em voo: o resultado não pode apagar
            # nem sujar a conversa da sessão nova (o histórico é por sessão).
            return
        if tipo == protocol.UP_CHAT:
            self.historico.marcar(session.key, mid, "enviada" if ok else "falhou")
            self._enviar_janela({"t": "estado-msg", "id": mid, "estado": "enviada" if ok else "falhou"}, session)
            if not ok:
                self._enviar_janela({"t": "aviso", "texto": aviso or TEXTO_SEM_ENVIO}, session)
            return
        if tipo == protocol.UP_HAND:
            if ok:
                self._mao_em = {session.key: self.monotonic()}
                self.sistema(session, f"Você levantou a mão às {hora(self.agora_ms())}")
                self._enviar_janela({"t": "mao", "levantada": True}, session)
            elif erro == "limite":
                self._enviar_janela({"t": "mao", "levantada": True}, session)
            else:
                self._enviar_janela({"t": "mao", "levantada": False}, session)
                self._enviar_janela({"t": "aviso", "texto": aviso or TEXTO_SEM_ENVIO}, session)
