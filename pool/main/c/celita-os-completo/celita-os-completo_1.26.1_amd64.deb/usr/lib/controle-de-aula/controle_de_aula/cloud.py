"""Cliente de transporte do protocolo v4, espelho de cloud-client.js.

Um stream SSE em /devices/{id} entrega bind, cmd e state; report e presença
sobem por REST. run() devolve 'unbound', 'foreign_bind' ou 'stopped'.
"""

import collections
import json
import logging
import queue
import threading
import time

from . import protocol
from .crypto import open_envelope, seal
from .firebase import FirebaseError
from .replay import ReplayGuard
from .up import push_id_ms

log = logging.getLogger("controle-de-aula.cloud")

PRESENCE_S = 25
REPORT_TICK_S = 5
REPORT_HEARTBEAT_S = 60
CMD_MAX_AGE_MS = 12 * 3600 * 1000
MAX_ACKS = 20
# Escrita nova negada pelas rules (console atrasado): a funcionalidade fica
# desligada por 10 min, sem nunca reconectar o stream de comandos (§1.3).
UP_DENIED_S = 10 * 60
UP_PRUNE_S = 10 * 60
STATE_ONLY = (protocol.SET_LOCK, protocol.SET_EXAM, protocol.SET_MONITOR)


def now_ms() -> int:
    return int(time.time() * 1000)


class CloudClient:
    def __init__(self, fb, device_id, session_key, teacher, on_command, get_report, on_state,
                 load_replay, save_replay, clock=None):
        self.fb = fb
        self.device_id = device_id
        self.base = f"/devices/{device_id}"
        # Relógio corrigido pelo Date do Firebase (archive.Clock); None = local.
        self.clock = clock
        self.teacher = teacher
        self.key = session_key
        self.on_command = on_command
        self.get_report = get_report
        self.on_state = on_state
        self.load_replay = load_replay
        self.save_replay = save_replay
        self.running = False
        self.sid = 0
        self.out_seq = 0
        self.cmd_guard = None
        self.rules_rev = 0
        self.wallpaper_hash = None
        self.classview_rev = 0
        self.unit_rev = 0
        self.lock_rev = 0
        self.exam_rev = 0
        self.monitor_rev = 0
        self._acks = collections.deque(maxlen=protocol.MAX_APLICADO_ACKS)
        self._up_denied_until = None
        self._up_pruned_at = None
        self._stream = None
        self._queue = queue.Queue()
        self._finished = threading.Event()
        self._reason = None
        self._report_fingerprint = None
        self._report_sent_at = 0.0
        self._report_wake = threading.Event()
        self._seal_lock = threading.Lock()

    # ---- Ciclo de vida -------------------------------------------------------

    def stop(self):
        self._finish("stopped")

    def _finish(self, reason: str):
        if not self.running:
            return
        self.running = False
        self._reason = reason
        if self._stream:
            self._stream.close()
        self._queue.put(None)
        self._report_wake.set()
        self._finished.set()

    def stream_age_s(self) -> float:
        return self._stream.age_s() if self._stream else float("inf")

    def request_report(self):
        self._report_wake.set()

    def run(self) -> str:
        self.sid = now_ms()
        self.out_seq = 0
        saved = self.load_replay() or {}
        self.cmd_guard = ReplayGuard.from_json(saved.get("cmd"), max_age_ms=CMD_MAX_AGE_MS)
        self.rules_rev = _number(saved.get("rulesRev"))
        self.wallpaper_hash = saved.get("wallpaperHash")
        self.classview_rev = _number(saved.get("classviewRev"))
        self.unit_rev = _number(saved.get("unitRev"))
        self.lock_rev = _number(saved.get("lockRev"))
        self.exam_rev = _number(saved.get("examRev"))
        self.monitor_rev = _number(saved.get("monitorRev"))
        self.running = True

        self._stream = self.fb.stream(
            self.base,
            on_event=self._on_event,
            on_down=lambda reason: self.on_state(False, reason),
        )
        threading.Thread(target=self._worker, name="cloud-worker", daemon=True).start()
        threading.Thread(target=self._presence_loop, name="cloud-presence", daemon=True).start()
        threading.Thread(target=self._report_loop, name="cloud-report", daemon=True).start()
        self._finished.wait()
        return self._reason

    def _on_event(self, event: dict):
        # Cada evento do stream, inclusive o put inicial, prova que o canal de
        # comandos está vivo; é isto que afirma "conectado".
        self.on_state(True, None)
        path, data = event["path"], event.get("data")
        if event.get("type") == "patch":
            # patch = put em cada filho citado (o resto não muda), como na
            # extensão. A chave pode ter várias partes ("state/lock") e o filho
            # citado é trocado inteiro: dentro dele, ausência é remoção.
            base = "" if path == "/" else path.rstrip("/")
            for key, value in (data.items() if isinstance(data, dict) else ()):
                self._route(f"{base}/{key}", value)
            return
        self._route(path, data)

    def _enqueue(self, fn):
        self._queue.put(fn)

    def _worker(self):
        while self.running:
            fn = self._queue.get()
            if fn is None:
                break
            try:
                fn()
            except Exception as error:  # noqa: BLE001 - um comando ruim não derruba o laço
                log.warning("processamento falhou: %s", error)

    # ---- Roteamento do stream ----------------------------------------------------

    def _route(self, path: str, data):
        if path == "/":
            node = data if isinstance(data, dict) else {}
            self._route_bind(node.get("bind"))
            state = node.get("state") if isinstance(node.get("state"), dict) else {}
            self._route_state(state)
            self._route_cmds(node.get("cmd"))
            return
        if path == "/bind":
            self._route_bind(data)
        elif path == "/state/rules" and isinstance(data, str):
            self._enqueue(lambda: self._apply_rules(data))
        elif path == "/state/wallpaper" and isinstance(data, str):
            self._enqueue(lambda: self._apply_wallpaper(data))
        elif path == "/state/classview":
            self._enqueue(lambda: self._apply_class_view(data if isinstance(data, str) else None))
        elif path == "/state/unit" and isinstance(data, str):
            self._enqueue(lambda: self._apply_unit(data))
        elif path == "/state/lock" and isinstance(data, str):
            self._enqueue(lambda: self._apply_lock(data))
        elif path == "/state/exam" and isinstance(data, str):
            self._enqueue(lambda: self._apply_exam(data))
        elif path == "/state/monitor":
            self._enqueue(lambda: self._apply_monitor(data if isinstance(data, str) else None))
        elif path == "/state":
            self._route_state(data if isinstance(data, dict) else {})
        elif path.startswith("/cmd/"):
            push_id = path[len("/cmd/"):]
            if isinstance(data, str):
                self._enqueue(lambda: self._handle_cmd(push_id, data))
        elif path == "/cmd" and data:
            self._route_cmds(data)

    def _route_state(self, state: dict):
        """O nó state inteiro (put ou filho trocado por patch)."""
        if isinstance(state.get("rules"), str):
            self._enqueue(lambda: self._apply_rules(state["rules"]))
        if isinstance(state.get("wallpaper"), str):
            self._enqueue(lambda: self._apply_wallpaper(state["wallpaper"]))
        if isinstance(state.get("unit"), str):
            self._enqueue(lambda: self._apply_unit(state["unit"]))
        # Trava e prova: nó nulo ou ilegível não muda nada (destravar é on:false).
        if isinstance(state.get("lock"), str):
            self._enqueue(lambda: self._apply_lock(state["lock"]))
        if isinstance(state.get("exam"), str):
            self._enqueue(lambda: self._apply_exam(state["exam"]))
        # O evento traz o nó inteiro: ausência de monitor/classview é remoção.
        monitor = state.get("monitor")
        self._enqueue(lambda: self._apply_monitor(monitor if isinstance(monitor, str) else None))
        classview = state.get("classview")
        self._enqueue(lambda: self._apply_class_view(classview if isinstance(classview, str) else None))

    def _route_cmds(self, cmds):
        if not isinstance(cmds, dict):
            return
        for push_id in sorted(cmds):
            envelope = cmds[push_id]
            if isinstance(envelope, str):
                self._enqueue(lambda p=push_id, e=envelope: self._handle_cmd(p, e))

    def _route_bind(self, bind):
        if not bind:
            self._finish("unbound")
        elif not isinstance(bind, dict) or bind.get("teacherPub") != self.teacher.get("teacherPub"):
            self._finish("foreign_bind")

    # ---- Saída cifrada -------------------------------------------------------------

    def now_ms(self) -> int:
        """Agora pelo relógio corrigido pelo servidor, quando houver."""
        return self.clock.now_ms() if self.clock is not None else now_ms()

    def _seal(self, obj: dict) -> str:
        with self._seal_lock:
            self.out_seq += 1
            # ts pelo relógio corrigido: o professor confere a janela de ts
            # (up: 12 h para trás, 120 s para frente) com o relógio dele, e um
            # PC adiantado teria os recados descartados calados.
            header = {"sid": self.sid, "seq": self.out_seq, "ts": self.now_ms()}
        return seal(self.key, {**header, **obj})

    def _persist_replay(self):
        try:
            self.save_replay({
                "cmd": self.cmd_guard.to_json(),
                "rulesRev": self.rules_rev,
                "wallpaperHash": self.wallpaper_hash,
                "classviewRev": self.classview_rev,
                "unitRev": self.unit_rev,
                "lockRev": self.lock_rev,
                "examRev": self.exam_rev,
                "monitorRev": self.monitor_rev,
            })
        except Exception as error:  # noqa: BLE001 - o pior caso é repetir um comando idempotente
            log.warning("não persistiu o anti-replay: %s", error)

    # ---- Fila cmd/ ------------------------------------------------------------------

    def _handle_cmd(self, push_id: str, envelope: str):
        try:
            msg = open_envelope(self.key, envelope)
        except Exception:  # noqa: BLE001 - ilegível com a nossa chave: consome
            self._delete_quiet(f"{self.base}/cmd/{push_id}")
            return
        fresh = isinstance(msg, dict) and self.cmd_guard.accept(
            msg.get("sid"), msg.get("seq"), msg.get("ts"), now_ms()
        )
        if not fresh:
            self._delete_quiet(f"{self.base}/cmd/{push_id}")
            return
        try:
            if msg.get("type") in STATE_ONLY:
                # Trava, prova e grade são estado: pela fila pulariam o guard de rev.
                ack = {"ok": False, "error": "tipo_desconhecido"}
            else:
                ack = self.on_command(msg) or {}
        except Exception as error:  # noqa: BLE001 - o erro cru vai só para o log
            log.warning("comando %s falhou: %s", msg.get("type"), error)
            ack = {"ok": False, "error": "executor_falhou"}
        snapshot_type = ack.get("snapshotType")
        if ack.get("jpegB64") and snapshot_type:
            # Imagem grande demais para o ack: vai cifrada no nó snapshot.
            try:
                env = self._seal({
                    "v": protocol.PROTOCOL_VERSION,
                    "type": snapshot_type,
                    "id": msg.get("id"),
                    "jpegB64": ack["jpegB64"],
                })
                self.fb.put(f"{self.base}/snapshot", {"env": env, "ts": self.fb.server_timestamp()})
            except Exception as error:  # noqa: BLE001
                log.warning("snapshot não subiu: %s", error)
                ack = {"ok": False, "error": "snapshot_upload"}
        try:
            env = self._seal({
                "v": protocol.PROTOCOL_VERSION,
                "type": protocol.ACK,
                "id": msg.get("id"),
                "ok": bool(ack.get("ok")),
                "error": ack.get("error"),
            })
            self.fb.put(f"{self.base}/ack/{push_id}", env)
        except Exception as error:  # noqa: BLE001 - ack é best-effort
            log.warning("ack não subiu: %s", error)
        if isinstance(msg.get("id"), str) and msg["id"]:
            # Repetido no tab_report: confirma a entrega mesmo quando um app
            # antigo apagou o ack antes do professor que mandou ler.
            entry = {"id": msg["id"], "ok": bool(ack.get("ok"))}
            if not ack.get("ok") and isinstance(ack.get("error"), str):
                entry["error"] = ack["error"]
            self._acks.append(entry)
            self.request_report()
        self._delete_quiet(f"{self.base}/cmd/{push_id}")
        self._persist_replay()
        self._prune_acks()

    def acks_recentes(self) -> list:
        return list(self._acks)

    def _delete_quiet(self, path: str):
        try:
            self.fb.delete(path)
        except Exception:  # noqa: BLE001
            pass

    def _prune_acks(self):
        try:
            acks = self.fb.get(f"{self.base}/ack") or {}
            ids = sorted(acks)
            for push_id in ids[: max(0, len(ids) - MAX_ACKS)]:
                self.fb.delete(f"{self.base}/ack/{push_id}")
        except Exception:  # noqa: BLE001 - poda é best-effort
            pass

    # ---- Estado state/ --------------------------------------------------------------

    def _open(self, envelope: str, expected_type: str):
        try:
            msg = open_envelope(self.key, envelope)
        except Exception:  # noqa: BLE001
            return None
        return msg if isinstance(msg, dict) and msg.get("type") == expected_type else None

    def _apply_rules(self, envelope: str):
        msg = self._open(envelope, protocol.SET_RULES)
        if not msg:
            return
        payload = msg.get("payload") if isinstance(msg.get("payload"), dict) else {}
        rev = _number(payload.get("rev"))
        if rev <= self.rules_rev:
            return
        if (self.on_command(msg) or {}).get("ok"):
            self.rules_rev = rev
            self._persist_replay()

    def _apply_wallpaper(self, envelope: str):
        msg = self._open(envelope, protocol.SET_WALLPAPER)
        if not msg:
            return
        payload = msg.get("payload") if isinstance(msg.get("payload"), dict) else {}
        digest = str(payload.get("hash") or "")
        if not digest or digest == self.wallpaper_hash:
            return
        try:
            blob = self.fb.get(f"/wallpapers/{self.teacher.get('teacherUid')}")
        except Exception as error:  # noqa: BLE001
            log.warning("blob do papel de parede inacessível: %s", error)
            return
        if not isinstance(blob, dict) or blob.get("hash") != digest or not isinstance(blob.get("jpeg"), str):
            return
        ack = self.on_command({
            "type": protocol.SET_WALLPAPER,
            "id": msg.get("id"),
            "payload": {"hash": digest, "jpegB64": blob["jpeg"]},
        }) or {}
        if ack.get("ok") or ack.get("error") == "so_chromeos":
            self.wallpaper_hash = digest
            self._persist_replay()

    def _apply_unit(self, envelope: str):
        msg = self._open(envelope, protocol.SET_UNIT)
        if not msg:
            return
        payload = msg.get("payload") if isinstance(msg.get("payload"), dict) else {}
        rev = _number(payload.get("rev"))
        if rev <= self.unit_rev:
            return
        numero = payload.get("numero")
        if not isinstance(numero, int) or isinstance(numero, bool) or not 1 <= numero <= 9999:
            return
        ack = self.on_command({"type": protocol.SET_UNIT, "id": msg.get("id"), "payload": {"numero": numero}}) or {}
        if ack.get("ok"):
            self.unit_rev = rev
            self._persist_replay()

    def _apply_lock(self, envelope: str):
        self._apply_held_state(envelope, protocol.SET_LOCK, "lock_rev")

    def _apply_exam(self, envelope: str):
        self._apply_held_state(envelope, protocol.SET_EXAM, "exam_rev")

    def _apply_held_state(self, envelope: str, kind: str, rev_attr: str):
        """Trava e prova: `rev >= guard` (igual reaplica, garante o respawn na
        reentrega); ilegível ou de outro tipo não muda nada."""
        msg = self._open(envelope, kind)
        if not msg:
            return
        payload = msg.get("payload") if isinstance(msg.get("payload"), dict) else {}
        rev = _number(payload.get("rev"))
        if rev <= 0 or rev < getattr(self, rev_attr):
            return
        ack = self.on_command({"type": kind, "id": msg.get("id"), "payload": payload, "ts": msg.get("ts")}) or {}
        if ack.get("ok"):
            if rev != getattr(self, rev_attr):
                setattr(self, rev_attr, rev)
                self._persist_replay()
            self.request_report()

    def _apply_monitor(self, envelope):
        if envelope is None:
            # Nó apagado: a grade fechou, a miniatura para na hora.
            self.on_command({"type": protocol.SET_MONITOR, "payload": None})
            return
        msg = self._open(envelope, protocol.SET_MONITOR)
        if not msg:
            return
        payload = msg.get("payload") if isinstance(msg.get("payload"), dict) else {}
        rev = _number(payload.get("rev"))
        if rev <= self.monitor_rev:
            return
        ts = msg.get("ts")
        # Envelope velho reentregue (reset de replay) não religa a captura.
        if not isinstance(ts, (int, float)) or abs(ts - self.now_ms()) > protocol.MONITOR_JANELA_TS:
            return
        ack = self.on_command({"type": protocol.SET_MONITOR, "id": msg.get("id"), "payload": payload, "ts": ts}) or {}
        if ack.get("ok"):
            self.monitor_rev = rev
            self._persist_replay()

    def _apply_class_view(self, envelope):
        msg = self._open(envelope, protocol.SET_CLASS_VIEW) if envelope is not None else None
        if msg is None:
            # Remoção sempre passa: nó apagado ou envelope ilegível tira o
            # papel de telão, e o snapshot velho não pode ficar exposto.
            self.on_command({"type": protocol.SET_CLASS_VIEW, "payload": {"snapshot": None}})
            if self.classview_rev != 0:
                self.classview_rev = 0
                self._persist_replay()
            return
        payload = msg.get("payload")
        rev = _number(payload.get("rev")) if isinstance(payload, dict) else 0
        if rev <= self.classview_rev:
            return
        snapshot = protocol.parse_class_view(payload)
        if not snapshot:
            return
        ack = self.on_command({"type": protocol.SET_CLASS_VIEW, "id": msg.get("id"), "payload": {"snapshot": snapshot}}) or {}
        if ack.get("ok"):
            self.classview_rev = rev
            self._persist_replay()

    # ---- Canal up/ e miniaturas (caminho lateral) -------------------------------------

    def up_available(self) -> bool:
        until = self._up_denied_until
        return until is None or time.monotonic() >= until

    def send_up(self, kind: str, payload: dict, mid: str) -> tuple:
        """Único ponto de saída aluno → professor: (ok, erro). Vai pelo caminho
        lateral; 401/403 persistente desliga o envio por 10 min."""
        if not self.running:
            return False, "sem_conexao"
        if not self.up_available():
            return False, "negado"
        env = self._seal({"v": protocol.PROTOCOL_VERSION, "type": kind, "mid": mid, "payload": payload})
        if len(env) >= protocol.UP_MAX_ENVELOPE:
            return False, "grande_demais"
        try:
            self.fb.side_request("POST", f"{self.base}/up", env)
        except FirebaseError as error:
            if error.status in (401, 403):
                self._up_denied_until = time.monotonic() + UP_DENIED_S
                log.warning("up negado pelas rules (%s); desligado por 10 min", error.status)
                return False, "negado"
            log.info("up não subiu: %s", error)
            return False, "sem_conexao"
        except Exception as error:  # noqa: BLE001
            log.info("up não subiu: %s", error)
            return False, "sem_conexao"
        self.prune_up()
        return True, None

    def prune_up(self):
        """O próprio PC poda up/: chaves com mais de 2 h e as além de 20."""
        self._up_pruned_at = time.monotonic()
        if not self.up_available():
            return
        try:
            listing = self.fb.side_get(f"{self.base}/up", {"shallow": "true"})
        except FirebaseError as error:
            if error.status in (401, 403):
                self._up_denied_until = time.monotonic() + UP_DENIED_S
            return
        except Exception:  # noqa: BLE001 - poda é best-effort
            return
        keys = sorted(k for k in (listing if isinstance(listing, dict) else {}) if isinstance(k, str))
        limit = self.now_ms() - protocol.UP_IDADE_MAX_PC
        stale = [k for k in keys if (push_id_ms(k) or limit) < limit]
        alive = [k for k in keys if k not in stale]
        doomed = stale + alive[: max(0, len(alive) - protocol.UP_MAX_ENTRADAS)]
        for key in doomed:
            try:
                self.fb.side_request("DELETE", f"{self.base}/up/{key}")
            except Exception:  # noqa: BLE001
                return

    def seal_thumb(self, snapshot: dict) -> str:
        return self._seal(snapshot)

    def put_thumb(self, env: str):
        """Sobrescreve /thumbs/{id}; FirebaseError sobe para quem chamou decidir."""
        self.fb.side_request("PUT", f"/thumbs/{self.device_id}", {"env": env, "ts": self.fb.server_timestamp()})

    def delete_thumb(self):
        self.fb.side_request("DELETE", f"/thumbs/{self.device_id}")

    # ---- Presença e relatório --------------------------------------------------------

    def _presence_loop(self):
        while self.running:
            try:
                self.fb.put(f"{self.base}/presence", {"lastSeen": self.fb.server_timestamp()})
            except Exception as error:  # noqa: BLE001
                # Só a falha diz algo: o sucesso do PUT não prova o stream vivo.
                self.on_state(False, str(error))
            pruned = self._up_pruned_at
            if pruned is None or time.monotonic() - pruned >= UP_PRUNE_S:
                self.prune_up()
            self._finished.wait(PRESENCE_S)

    def _report_loop(self):
        while self.running:
            self._maybe_report()
            self._report_wake.wait(REPORT_TICK_S)
            self._report_wake.clear()

    def _maybe_report(self):
        try:
            report = self.get_report()
        except Exception as error:  # noqa: BLE001
            log.warning("relatório falhou: %s", error)
            return
        if not report:
            return
        fingerprint = json.dumps(
            [[t.get("url"), t.get("active")] for t in report.get("tabs", [])]
            + [[a.get("name"), a.get("title")] for a in report.get("apps", [])]
            + [report.get("user"), report.get("iasLiberadas"), report.get("aplicado")]
            + [e.get("bloqueio") for e in (report.get("events") or [])[-3:]],
            ensure_ascii=False,
        ) + "|" + str((report.get("events") or [{}])[-1].get("ts", 0))
        now = time.monotonic()
        if fingerprint == self._report_fingerprint and now - self._report_sent_at < REPORT_HEARTBEAT_S:
            return
        try:
            env = self._seal(report)
            self.fb.put(f"{self.base}/report", {"env": env, "ts": self.fb.server_timestamp()})
            self._report_fingerprint = fingerprint
            self._report_sent_at = now
        except Exception as error:  # noqa: BLE001 - retenta no próximo tique
            log.debug("relatório não subiu: %s", error)


def _number(value) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError, OverflowError):
        return 0
