"""Limites do canal up/ no ponto único de saída do PC (spec §2.4).

Janela deslizante com timestamps de parede, persistida no Storage do agente
(chave `limites`, por Session.key): reiniciar o agente não zera a conta. Puro:
o relógio (`agora`, em ms) é injetado.
"""

import time

from . import protocol

L1_INTERVALO_MS = 2 * protocol.SEGUNDO_MS
L2_POR_HORA = 30
L3_POR_SITE_MS = 60 * protocol.SEGUNDO_MS
L3_PENDENTES = 5
L4_INTERVALO_MS = 10 * protocol.SEGUNDO_MS

TEXTO_L1 = "Espere um pouquinho para mandar outra mensagem."
TEXTO_L2 = "Você mandou muitas mensagens. Espere o professor responder."
TEXTO_L3 = "Você já pediu. Aguarde o professor responder."
TEXTO_L4 = "Mão levantada ✋"


def _agora_ms() -> int:
    return int(time.time() * 1000)


class Limites:
    def __init__(self, storage, agora=_agora_ms):
        self.storage = storage
        self.agora = agora

    # ---- estado persistido ------------------------------------------------------

    def _ler(self, chave: str) -> dict:
        todos = self.storage.get("limites")
        estado = todos.get(chave) if isinstance(todos, dict) else None
        estado = estado if isinstance(estado, dict) else {}
        chats = estado.get("chat") if isinstance(estado.get("chat"), list) else []
        pedidos = estado.get("pedidos") if isinstance(estado.get("pedidos"), dict) else {}
        return {
            "chat": [t for t in chats if isinstance(t, (int, float))],
            "pedidos": {s: p for s, p in pedidos.items()
                        if isinstance(s, str) and isinstance(p, dict) and isinstance(p.get("ts"), (int, float))},
            "mao": estado.get("mao") if isinstance(estado.get("mao"), (int, float)) else 0,
        }

    def _gravar(self, chave: str, estado: dict):
        # Só a sessão atual fica: a conta compartilhada não herda contadores.
        self.storage.set("limites", {chave: estado})

    def _podar(self, estado: dict, agora: int) -> dict:
        estado["chat"] = [t for t in estado["chat"] if agora - protocol.HORA_MS < t <= agora + L1_INTERVALO_MS]
        estado["pedidos"] = {
            site: pedido for site, pedido in estado["pedidos"].items()
            if agora - max(L3_POR_SITE_MS, protocol.PEDIDO_SEM_RESPOSTA) < pedido["ts"] <= agora + L3_POR_SITE_MS
        }
        return estado

    # ---- consulta e registro -------------------------------------------------------

    def verificar(self, chave: str, tipo: str, site: str | None = None) -> str | None:
        """None = pode enviar; senão o texto fixo de §2.4 para o aluno."""
        agora = self.agora()
        estado = self._podar(self._ler(chave), agora)
        if tipo == protocol.UP_CHAT:
            if estado["chat"] and agora - max(estado["chat"]) < L1_INTERVALO_MS:
                return TEXTO_L1
            if len(estado["chat"]) >= L2_POR_HORA:
                return TEXTO_L2
            return None
        if tipo == protocol.UP_UNBLOCK:
            pedido = estado["pedidos"].get(site or "")
            if pedido and agora - pedido["ts"] < L3_POR_SITE_MS:
                return TEXTO_L3
            pendentes = [p for p in estado["pedidos"].values()
                         if p.get("pendente") and agora - p["ts"] < protocol.PEDIDO_SEM_RESPOSTA]
            if len(pendentes) >= L3_PENDENTES:
                return TEXTO_L3
            return None
        if tipo == protocol.UP_HAND:
            if estado["mao"] and 0 <= agora - estado["mao"] < L4_INTERVALO_MS:
                return TEXTO_L4
            return None
        return None

    def registrar(self, chave: str, tipo: str, site: str | None = None, mid: str | None = None):
        agora = self.agora()
        estado = self._podar(self._ler(chave), agora)
        if tipo == protocol.UP_CHAT:
            estado["chat"].append(agora)
        elif tipo == protocol.UP_UNBLOCK and site:
            estado["pedidos"][site] = {"ts": agora, "pendente": True, **({"mid": mid} if mid else {})}
        elif tipo == protocol.UP_HAND:
            estado["mao"] = agora
        else:
            return
        self._gravar(chave, estado)

    def mao_levantada_em(self, chave: str) -> int:
        return self._ler(chave)["mao"]

    def resolver_pedido(self, chave: str, site: str):
        """O professor respondeu: o pedido deixa de contar como pendente."""
        estado = self._ler(chave)
        pedido = estado["pedidos"].get(site)
        if pedido and pedido.get("pendente"):
            pedido["pendente"] = False
            self._gravar(chave, estado)

    def limpar(self):
        self.storage.set("limites", None)
