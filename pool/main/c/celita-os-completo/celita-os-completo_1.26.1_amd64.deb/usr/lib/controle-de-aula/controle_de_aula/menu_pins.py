"""Apps fixados da escola: `/home/menu` → `/etc/celita/menu-fixados`.

O arquivo é o mesmo que o Menu Iniciar lê e que o "Fixar para todos os
usuários" do menu grava: vale o último. Por isso o agente só escreve quando a
lista da escola MUDA (hash guardado no Storage), marca o arquivo com uma
primeira linha `# controle-de-aula:` e só apaga arquivo com essa marca. Erro
de rede ou HTTP não mexe em nada.
"""

import hashlib
import json
import logging
import os
import re
import time

from .firebase import FirebaseError

log = logging.getLogger("controle-de-aula.menu")

PATH = "/etc/celita/menu-fixados"
MARCA = "# controle-de-aula:"
MAX_IDS = 24
MAX_ID = 64
ID_RE = re.compile(r"^[A-Za-z0-9._-]+\.desktop$")
REFRESH_S = 60
AUTH_BACKOFF_S = 10 * 60


def ids_da_escola(node) -> list:
    """Ids válidos do nó público, na ordem; lista do RTDB pode vir como dict."""
    if not isinstance(node, dict):
        return []
    raw = node.get("ids")
    if isinstance(raw, dict):
        try:
            raw = [raw[k] for k in sorted(raw, key=int)]
        except (TypeError, ValueError):
            return []
    if not isinstance(raw, list):
        return []
    ids = []
    for value in raw:
        if isinstance(value, str) and len(value) <= MAX_ID and ID_RE.match(value) and value not in ids:
            ids.append(value)
        if len(ids) >= MAX_IDS:
            break
    return ids


def texto_do_arquivo(ids: list, rev) -> str:
    rev = int(rev) if isinstance(rev, (int, float)) and not isinstance(rev, bool) else 0
    return f"{MARCA} lista da escola (rev {rev})\n" + "".join(f"{value}\n" for value in ids)


def tem_marca(path: str) -> bool:
    try:
        with open(path, encoding="utf-8", errors="replace") as handle:
            return handle.readline().startswith(MARCA)
    except OSError:
        return False


class MenuPins:
    def __init__(self, storage, path: str = PATH, monotonic=time.monotonic):
        self.storage = storage
        self.path = path
        self.monotonic = monotonic
        self._next_at = None
        self._blocked_until = None

    def refresh_soon(self):
        self._next_at = None

    def apply(self, node) -> bool:
        """Aplica o nó lido; devolve se mexeu no disco."""
        ids = ids_da_escola(node)
        digest = hashlib.sha256(json.dumps(ids).encode()).hexdigest()
        if digest == self.storage.get("menuEscola"):
            return False
        changed = False
        if ids:
            directory = os.path.dirname(self.path)
            os.makedirs(directory, mode=0o755, exist_ok=True)
            temporary = self.path + ".tmp"
            with open(temporary, "w", encoding="utf-8") as handle:
                handle.write(texto_do_arquivo(ids, node.get("rev") if isinstance(node, dict) else 0))
            os.chmod(temporary, 0o644)
            os.replace(temporary, self.path)
            log.info("apps fixados da escola: %d", len(ids))
            changed = True
        elif tem_marca(self.path):
            # Só some o que o agente escreveu; a lista do administrador fica.
            os.unlink(self.path)
            log.info("apps fixados da escola: lista removida")
            changed = True
        self.storage.set("menuEscola", digest)
        return changed

    def tick(self, fb):
        """Mesmo ritmo da página inicial: ao conectar, a cada sessão nova e a cada 60 s."""
        now = self.monotonic()
        if fb is None or not fb.id_token:
            return
        if self._next_at is not None and now < self._next_at:
            return
        if self._blocked_until is not None and now < self._blocked_until:
            return
        self._next_at = now + REFRESH_S
        try:
            node = fb.side_get("/home/menu")
        except FirebaseError as error:
            if error.status in (401, 403):
                self._blocked_until = now + AUTH_BACKOFF_S
                log.warning("apps fixados negados (%s); nova tentativa em 10 min", error.status)
            return
        try:
            self.apply(node)
        except OSError as error:
            log.warning("apps fixados não foram gravados: %s", error)


def purge(path: str = PATH):
    """postrm purge: apaga só o arquivo com a marca do agente."""
    if tem_marca(path):
        os.unlink(path)
