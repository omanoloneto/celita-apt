"""Grade ao vivo: miniatura da tela a cada 10 s enquanto o professor olha.

`state/monitor` = set_monitor {rev, ate}. O prazo é contado pelo relógio
monotônico do PC (`ate − env.ts`, teto de 45 s), então um relógio errado não
estica a captura. Cada miniatura vai cifrada para `/thumbs/{deviceId}` pelo
caminho lateral; ao vencer o prazo o PC apaga o nó uma vez. Thread própria,
nunca no laço lateral do arquivo.
"""

import base64
import logging
import threading
import time

from . import protocol
from . import session as sess
from .firebase import FirebaseError

log = logging.getLogger("controle-de-aula.miniaturas")

INTERVALO_S = protocol.THUMB_INTERVALO / 1000


class Miniaturas:
    def __init__(self, sessions, get_client, capture=None, monotonic=time.monotonic):
        self.sessions = sessions
        self.get_client = get_client
        self.capture = capture or sess.capture_thumb
        self.monotonic = monotonic
        self.wake = threading.Event()
        self._lock = threading.Lock()
        self._prazo = 0.0
        self._rev = 0
        self._bloqueado_rev = None
        self._proxima = 0.0
        self._marcador = None
        self._escreveu = False
        self._thread = None

    # ---- comandos (thread do CloudClient) ------------------------------------------

    def aplicar(self, payload, env_ts) -> dict:
        monitor = protocol.clean_monitor(payload)
        if monitor is None:
            return {"ok": False, "error": "payload_invalido"}
        duracao_s = protocol.prazo_relativo(monitor["ate"], env_ts, protocol.MONITOR_TETO) / 1000
        with self._lock:
            agora = self.monotonic()
            ligando = self._prazo <= agora
            self._prazo = agora + duracao_s
            self._rev = monitor["rev"]
            if self._bloqueado_rev is not None and self._bloqueado_rev != self._rev:
                self._bloqueado_rev = None
            if ligando:
                self._proxima = agora
        self.wake.set()
        return {"ok": True}

    def parar(self):
        with self._lock:
            self._prazo = 0.0
        self.wake.set()

    def ativo(self) -> bool:
        with self._lock:
            return self.monotonic() < self._prazo and self._bloqueado_rev is None

    # ---- laço -----------------------------------------------------------------------

    def start(self):
        if self._thread is None:
            self._thread = threading.Thread(target=self._loop, name="miniaturas", daemon=True)
            self._thread.start()

    def _loop(self):
        while True:
            espera = None
            try:
                espera = self.passo()
            except Exception as error:  # noqa: BLE001 - o laço nunca morre
                log.warning("miniatura: %s", error)
                espera = INTERVALO_S
            self.wake.wait(espera)
            self.wake.clear()

    def passo(self):
        """Um tique; devolve quanto esperar (None = até o próximo aviso)."""
        with self._lock:
            agora = self.monotonic()
            vigente = agora < self._prazo and self._bloqueado_rev is None
            proxima = self._proxima
            prazo = self._prazo
        if not vigente:
            self._apagar_uma_vez()
            # Apagar falhou (sem rede): tenta de novo no próximo intervalo.
            return INTERVALO_S if self._escreveu else None
        if agora >= proxima:
            self._capturar()
            with self._lock:
                self._proxima = agora + INTERVALO_S
                proxima = self._proxima
        return max(0.05, min(proxima, prazo) - self.monotonic())

    def _capturar(self):
        client = self.get_client()
        if client is None:
            return
        session = self.sessions.active()
        if session is None:
            self._enviar(client, None, "sem_sessao")
            return
        result = self.capture(session) or {}
        if not result.get("ok"):
            self._enviar(client, None, "falhou")
            return
        self._enviar(client, result, None)

    def _enviar(self, client, imagem, motivo):
        # Marcador (sem imagem) só na mudança: o professor distingue
        # "carregando" de "indisponível" sem uma escrita a cada 10 s.
        if imagem is None and motivo == self._marcador and self._escreveu:
            return
        snapshot = {"v": protocol.PROTOCOL_VERSION, "type": protocol.THUMB_SNAPSHOT,
                    "jpegB64": None, "w": protocol.THUMB_LARGURA, "h": 0}
        if imagem is not None:
            snapshot.update(jpegB64=base64.b64encode(imagem["jpeg"]).decode("ascii"),
                            w=imagem.get("w") or protocol.THUMB_LARGURA, h=imagem.get("h") or 0)
        else:
            snapshot["motivo"] = motivo
        try:
            client.put_thumb(client.seal_thumb(snapshot))
        except FirebaseError as error:
            if error.status in (401, 403):
                # Rules atrasadas: para até o professor mandar um rev novo.
                with self._lock:
                    self._bloqueado_rev = self._rev
                log.warning("miniatura negada pelas rules; parada até o próximo pedido")
            return
        except Exception as error:  # noqa: BLE001 - próximo tique tenta de novo
            log.info("miniatura não subiu: %s", error)
            return
        self._marcador = motivo
        self._escreveu = True

    def _apagar_uma_vez(self):
        if not self._escreveu:
            return
        client = self.get_client()
        if client is None:
            return
        try:
            client.delete_thumb()
        except FirebaseError as error:
            log.info("miniatura não foi apagada: %s", error)
            if error.status not in (401, 403):
                return
        except Exception as error:  # noqa: BLE001
            log.info("miniatura não foi apagada: %s", error)
            return
        self._escreveu = False
        self._marcador = None
