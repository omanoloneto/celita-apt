"""Mensagens do protocolo v4 e seus limites, espelho de protocol.js e rules.js."""

import math
from urllib.parse import urlsplit

PROTOCOL_VERSION = 1

OPEN_URL = "open_url"
ACK = "ack"
TAB_REPORT = "tab_report"
CLOSE_TABS = "close_tabs"
CLOSE_ALL_TABS = "close_all_tabs"
SET_RULES = "set_rules"
SET_WALLPAPER = "set_wallpaper"
SHOW_MESSAGE = "show_message"
SET_CLASS_VIEW = "set_class_view"
SET_UNIT = "set_unit"
CAPTURE_CAMERA = "capture_camera"
CAMERA_SNAPSHOT = "camera_snapshot"
CAPTURE_SCREEN = "capture_screen"
SCREEN_SNAPSHOT = "screen_snapshot"
LIBERAR_IAS = "liberar_ias"
ATUALIZAR = "atualizar"
# Recursos de turma (app ≥ 0.20.0, extensão ≥ 0.7.0, Celita ≥ 0.13.0).
CHAT_MESSAGE = "chat_message"
UNBLOCK_RESULT = "unblock_result"
SET_LOCK = "set_lock"
SET_EXAM = "set_exam"
SET_MONITOR = "set_monitor"
THUMB_SNAPSHOT = "thumb_snapshot"
# Tipos do canal up/ (aluno → professor).
UP_CHAT = "chat"
UP_UNBLOCK = "unblock_request"
UP_HAND = "raise_hand"
UP_TYPES = (UP_CHAT, UP_UNBLOCK, UP_HAND)

MAX_REPORT_TABS = 30
MAX_REPORT_EVENTS = 20
MAX_REPORT_URL = 300
MAX_REPORT_TITLE = 120
MAX_REPORT_APPS = 30
MAX_REPORT_APP_NAME = 40
MAX_REPORT_USER = 32
MAX_REPORT_BLOQUEIO = 20

MAX_CANAIS = 200
MAX_CANAL = 100
# Espelho de FILTROS_PADRAO (extensão, src/lib/filtros.js): pedido do usuário,
# tudo chega ligado até o professor desligar.
FILTROS_PADRAO = {"shorts": True, "reels": True, "tiktok": True, "ias": True, "canais": []}

MAX_RULES = 1000
MAX_RULE_PATTERN = 200

MAX_CLASSVIEW_PCS = 60
MAX_CLASSVIEW_NOME = 40
MAX_CLASSVIEW_ALUNO = 60
MAX_CLASSVIEW_TURMA = 60
MAX_CLASSVIEW_TITULO = 120
MAX_CLASSVIEW_DOMINIO = 100

MAX_MESSAGE_TITLE = 100
MAX_MESSAGE_BODY = 500
MAX_MESSAGE_FROM = 60

# Constantes de turma (nomes iguais nos quatro códigos; spec §1.6). Caps de
# texto contam code points, que é o que o fatiamento de str do Python conta.
SEGUNDO_MS = 1000
MINUTO_MS = 60 * SEGUNDO_MS
HORA_MS = 60 * MINUTO_MS
UP_MAX_ENVELOPE = 4096
MAX_CHAT_TEXTO = 500
MAX_CHAT_DE = 60
MAX_PEDIDO_SITE = 100
MAX_PEDIDO_URL = 500
MAX_PEDIDO_MOTIVO = 200
MAX_TRAVA_TEXTO = 200
MAX_PROVA_INICIO = 2048
UP_MAX_ENTRADAS = 20
UP_IDADE_MAX_PC = 2 * HORA_MS
UP_IDADE_MAX_PROFESSOR = 12 * HORA_MS
UP_JANELA_PASSADO = 12 * HORA_MS
UP_JANELA_FUTURO = 120 * SEGUNDO_MS
TRAVA_ATE = 20 * MINUTO_MS
TRAVA_TETO = 2 * HORA_MS
PROVA_ATE = 2 * HORA_MS
PROVA_TETO = 4 * HORA_MS
RENOVACAO = 5 * MINUTO_MS
MONITOR_RENOVA = 10 * SEGUNDO_MS
MONITOR_ATE = 30 * SEGUNDO_MS
MONITOR_TETO = 45 * SEGUNDO_MS
MONITOR_JANELA_TS = 120 * SEGUNDO_MS
THUMB_INTERVALO = 10 * SEGUNDO_MS
THUMB_LARGURA = 480
THUMB_QUALIDADE = 60
THUMB_MAX_BYTES = 256 * 1024
ENTREGA_TIMEOUT = 25 * SEGUNDO_MS
CHAT_HISTORICO_PC = 100
CHAT_HISTORICO_THREAD = 200
MAO_VISIVEL = 10 * MINUTO_MS
PEDIDO_SEM_RESPOSTA = 10 * MINUTO_MS
RECARGA_ESPERA = 10 * SEGUNDO_MS
MAX_APLICADO_ACKS = 20
MAX_APLICADO_ID = 32
MAX_APLICADO_ERRO = 40
TRAVA_TEXTO_PADRAO = "Olhos no professor"


def _cut(value, limit: int) -> str:
    return "" if value is None else str(value)[:limit]


def is_safe_http_url(url) -> bool:
    if not isinstance(url, str):
        return False
    try:
        parts = urlsplit(url)
    except ValueError:
        return False
    return parts.scheme in ("http", "https") and bool(parts.netloc)


def make_qr_payload(device_id: str, pub: str, token: str, label: str) -> dict:
    return {"v": 4, "id": device_id, "pub": pub, "tok": token, "label": label or ""}


def make_tab_report(tabs, events, apps=None, user=None, ias_liberadas=False, aplicado=None) -> dict:
    tabs = [t for t in (tabs or []) if isinstance(t, dict) and is_safe_http_url(t.get("url"))]
    events = [e for e in (events or []) if isinstance(e, dict) and is_safe_http_url(e.get("url"))]
    report = {
        "v": PROTOCOL_VERSION,
        "type": TAB_REPORT,
        "tabs": [
            {
                "url": _cut(t.get("url"), MAX_REPORT_URL),
                "title": _cut(t.get("title"), MAX_REPORT_TITLE),
                "active": t.get("active") is True,
            }
            for t in tabs[:MAX_REPORT_TABS]
        ],
        "events": [
            {
                "url": _cut(e.get("url"), MAX_REPORT_URL),
                "title": _cut(e.get("title"), MAX_REPORT_TITLE),
                "ts": e.get("ts") if isinstance(e.get("ts"), (int, float)) else 0,
                **({"bloqueio": _cut(e["bloqueio"], MAX_REPORT_BLOQUEIO)}
                   if isinstance(e.get("bloqueio"), str) and e["bloqueio"] else {}),
            }
            for e in events[-MAX_REPORT_EVENTS:]
        ],
    }
    # Campos além do que a extensão manda: o app ignora chaves desconhecidas.
    if apps is not None:
        report["apps"] = [
            {
                "name": _cut(a.get("name"), MAX_REPORT_APP_NAME),
                "title": _cut(a.get("title"), MAX_REPORT_TITLE),
            }
            for a in apps[:MAX_REPORT_APPS]
            if isinstance(a, dict)
        ]
    if user:
        report["user"] = _cut(user, MAX_REPORT_USER)
    if ias_liberadas:
        report["iasLiberadas"] = True
    if isinstance(aplicado, dict):
        report["aplicado"] = clean_aplicado(aplicado)
    return report


def _clean_aplicado_estado(raw):
    if not isinstance(raw, dict):
        return None
    item = {"rev": raw["rev"] if _finite_number(raw.get("rev")) else 0, "on": raw.get("on") is True}
    if isinstance(raw.get("erro"), str) and raw["erro"]:
        item["erro"] = raw["erro"][:MAX_APLICADO_ERRO]
    return item


def clean_aplicado(aplicado: dict) -> dict:
    """Confirmação positiva do tab_report: trava, prova e os últimos 20 acks."""
    result = {}
    for key in ("trava", "prova"):
        item = _clean_aplicado_estado(aplicado.get(key))
        if item is not None:
            result[key] = item
    acks = []
    for ack in aplicado.get("acks") if isinstance(aplicado.get("acks"), list) else []:
        if not isinstance(ack, dict) or not isinstance(ack.get("id"), str) or not ack["id"]:
            continue
        item = {"id": ack["id"][:MAX_APLICADO_ID], "ok": ack.get("ok") is True}
        if isinstance(ack.get("error"), str) and ack["error"]:
            item["error"] = ack["error"][:MAX_APLICADO_ERRO]
        acks.append(item)
    result["acks"] = acks[-MAX_APLICADO_ACKS:]
    return result


def clean_filtros(raw) -> dict:
    """Chave ausente = padrão; a extensão ainda normaliza os canais."""
    raw = raw if isinstance(raw, dict) else {}
    filtros = {k: raw[k] if isinstance(raw.get(k), bool) else v
               for k, v in FILTROS_PADRAO.items() if k != "canais"}
    canais = raw.get("canais") if isinstance(raw.get("canais"), list) else []
    filtros["canais"] = [c for c in canais if isinstance(c, str) and 0 < len(c) <= MAX_CANAL][:MAX_CANAIS]
    return filtros


def normalize_pattern(pattern) -> str:
    text = ("" if pattern is None else str(pattern)).strip().lower()
    if text.startswith("http://"):
        text = text[7:]
    elif text.startswith("https://"):
        text = text[8:]
    slash = text.find("/")
    host = text if slash == -1 else text[:slash]
    rest = "" if slash == -1 else text[slash:]
    colon = host.find(":")
    if colon != -1:
        host = host[:colon]
    return (host + rest).rstrip("/")[:MAX_RULE_PATTERN]


def host_matches(host: str, pattern: str) -> bool:
    return host == pattern or host.endswith("." + pattern)


def rule_matches(pattern, url) -> bool:
    if not pattern or not is_safe_http_url(url):
        return False
    parts = urlsplit(url)
    host = (parts.hostname or "").lower()
    slash = pattern.find("/")
    if slash == -1:
        return host_matches(host, pattern)
    return host_matches(host, pattern[:slash]) and (parts.path or "/").lower().startswith(
        pattern[slash:]
    )


def clean_rules(rules) -> list:
    cleaned = []
    for rule in rules if isinstance(rules, list) else []:
        pattern = rule.get("pattern") if isinstance(rule, dict) else None
        if isinstance(pattern, str) and pattern:
            cleaned.append({"pattern": pattern[:MAX_RULE_PATTERN]})
        if len(cleaned) >= MAX_RULES:
            break
    return cleaned


def _finite_number(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _positive_number(value) -> bool:
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value)
        and value > 0
    )


def parse_class_view(payload):
    if not isinstance(payload, dict):
        return None
    rev = payload.get("rev")
    if not _positive_number(rev) or not isinstance(payload.get("pcs"), list):
        return None
    aula_raw = payload.get("aula") if isinstance(payload.get("aula"), dict) else {}
    aula = {"ativa": aula_raw.get("ativa") is True}
    if aula["ativa"] and isinstance(aula_raw.get("turma"), str):
        aula["turma"] = _cut(aula_raw["turma"], MAX_CLASSVIEW_TURMA)
    pcs = []
    for pc in payload["pcs"]:
        if not isinstance(pc, dict) or not isinstance(pc.get("nome"), str):
            continue
        item = {"nome": _cut(pc["nome"], MAX_CLASSVIEW_NOME), "online": pc.get("online") is True}
        if isinstance(pc.get("aluno"), str):
            item["aluno"] = _cut(pc["aluno"], MAX_CLASSVIEW_ALUNO)
        aba = pc.get("aba")
        if isinstance(aba, dict) and isinstance(aba.get("dominio"), str):
            item["aba"] = {
                "titulo": _cut(aba.get("titulo"), MAX_CLASSVIEW_TITULO),
                "dominio": _cut(aba["dominio"], MAX_CLASSVIEW_DOMINIO),
            }
        if isinstance(pc.get("alerta"), str):
            item["alerta"] = _cut(pc["alerta"], MAX_CLASSVIEW_DOMINIO)
        pcs.append(item)
        if len(pcs) >= MAX_CLASSVIEW_PCS:
            break
    return {"rev": rev, "aula": aula, "pcs": pcs}


# ---- Estados de turma (state/lock, state/exam, state/monitor) -------------------


def clean_lock(payload):
    """set_lock {rev, on, texto, mute, ate}; None = payload inválido (não muda nada)."""
    if not isinstance(payload, dict):
        return None
    rev, ate = payload.get("rev"), payload.get("ate")
    if not _positive_number(rev) or not isinstance(payload.get("on"), bool):
        return None
    on = payload["on"]
    if on and not _positive_number(ate):
        return None
    texto = payload.get("texto")
    texto = " ".join(texto.split())[:MAX_TRAVA_TEXTO] if isinstance(texto, str) else ""
    return {
        "rev": int(rev),
        "on": on,
        "texto": texto or TRAVA_TEXTO_PADRAO,
        "mute": payload.get("mute") is True,
        "ate": int(ate) if _positive_number(ate) else 0,
    }


def clean_allow(allow) -> list:
    """Lista da prova com a mesma normalização das regras, sem repetidos."""
    cleaned, seen = [], set()
    for rule in allow if isinstance(allow, list) else []:
        pattern = rule.get("pattern") if isinstance(rule, dict) else None
        pattern = normalize_pattern(pattern) if isinstance(pattern, str) else ""
        if pattern and pattern not in seen:
            seen.add(pattern)
            cleaned.append({"pattern": pattern})
        if len(cleaned) >= MAX_RULES:
            break
    return cleaned


def clean_exam(payload):
    """set_exam {rev, on, allow, inicio?, ate}; None = payload inválido."""
    if not isinstance(payload, dict):
        return None
    rev, ate = payload.get("rev"), payload.get("ate")
    if not _positive_number(rev) or not isinstance(payload.get("on"), bool):
        return None
    on = payload["on"]
    if on and not _positive_number(ate):
        return None
    exam = {
        "rev": int(rev),
        "on": on,
        "allow": clean_allow(payload.get("allow")),
        "ate": int(ate) if _positive_number(ate) else 0,
    }
    inicio = payload.get("inicio")
    if isinstance(inicio, str) and len(inicio) <= MAX_PROVA_INICIO and is_safe_http_url(inicio.strip()):
        exam["inicio"] = inicio.strip()
    return exam


def clean_monitor(payload):
    """set_monitor {rev, ate}; None = payload inválido."""
    if not isinstance(payload, dict):
        return None
    rev, ate = payload.get("rev"), payload.get("ate")
    if not _positive_number(rev) or not _positive_number(ate):
        return None
    return {"rev": int(rev), "ate": int(ate)}


def prazo_relativo(ate, env_ts, teto_ms: int) -> int:
    """Quanto falta, pelo relógio do remetente: clamp(ate − env.ts, 0, teto).
    Os dois valores vêm do mesmo relógio (o do professor); o PC só soma ao seu."""
    if not _finite_number(ate) or not _finite_number(env_ts):
        return 0
    return int(max(0, min(teto_ms, ate - env_ts)))
