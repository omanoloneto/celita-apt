"""Sessão gráfica: quem está logado e como agir dentro dela.

Conta controlada é conta do grupo nopasswdlogin. O agente roda como root e
executa dentro da sessão por runuser, com DISPLAY, XAUTHORITY e o barramento
lidos do processo líder da sessão.
"""

import base64
import grp
import logging
import os
import pwd
import re
import shutil
import stat
import struct
import subprocess
import tempfile
import threading
import time

log = logging.getLogger("controle-de-aula.session")

CONTROLLED_GROUP = "nopasswdlogin"
SESSION_CACHE_S = 5
COMMAND_TIMEOUT_S = 20
CAMERA_DEVICE = "/dev/video0"
# Quadros descartados antes da foto (a câmera ajusta a exposição). Medir no aparelho.
CAMERA_SKIP_FRAMES = 3
CAMERA_REUSE_S = 5
WALLPAPER_PATH = "/var/lib/controle-de-aula/wallpaper.jpg"
LOGIND_SESSIONS_DIR = "/run/systemd/sessions"
BOOT_ID_PATH = "/proc/sys/kernel/random/boot_id"
MIN_HUMAN_UID = 1000
# Capturas da tela: diretório do root, atravessável pelo aluno mas não listável
# nem gravável por ele; os arquivos-alvo nascem do root (spec §5.3).
CAPTURE_DIR = "/run/controle-de-aula/cap"
SCREEN_MAX_BYTES = 8 * 1024 * 1024
THUMB_MAX_BYTES = 256 * 1024
THUMB_WIDTH = 480
THUMB_QUALITY = 60


class Session:
    def __init__(self, session_id: str, user: str, uid: int, display: str, leader: int,
                 controlled: bool = True, realtime_ms: int | None = None, boot_id: str = ""):
        self.id = session_id
        self.user = user
        self.uid = uid
        self.display = display
        self.leader = leader
        self.controlled = controlled
        self.realtime_ms = realtime_ms
        self.key = f"{boot_id}:{session_id}"
        self.env = self._read_env()

    def _read_env(self) -> dict:
        env = {
            "DISPLAY": self.display or ":0",
            "XAUTHORITY": os.path.join(pwd.getpwnam(self.user).pw_dir, ".Xauthority"),
            "DBUS_SESSION_BUS_ADDRESS": f"unix:path=/run/user/{self.uid}/bus",
            # Sem ele o pactl via runuser não acha o socket do pulse/pipewire
            # e falha calado.
            "XDG_RUNTIME_DIR": f"/run/user/{self.uid}",
        }
        try:
            with open(f"/proc/{self.leader}/environ", "rb") as handle:
                for item in handle.read().split(b"\0"):
                    key, sep, value = item.partition(b"=")
                    if sep and key.decode() in env and value:
                        env[key.decode()] = value.decode("utf-8", "replace")
        except OSError:
            pass
        return env

    def run(self, argv: list, timeout: float = COMMAND_TIMEOUT_S, capture: bool = True):
        command = ["runuser", "-u", self.user, "--", "env"]
        command += [f"{k}={v}" for k, v in self.env.items()]
        command += argv
        return subprocess.run(
            command,
            capture_output=capture,
            timeout=timeout,
            check=False,
            stdin=subprocess.DEVNULL,
        )

    def spawn(self, argv: list):
        command = ["runuser", "-u", self.user, "--", "env"]
        command += [f"{k}={v}" for k, v in self.env.items()]
        command += argv
        subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )

    def unit_command(self, name: str, argv: list, restart: bool) -> list:
        """systemd-run de um serviço transitório como o aluno, fora do cgroup do
        agente: apt upgrade, crash ou restart do agente não o derrubam."""
        try:
            gid = pwd.getpwnam(self.user).pw_gid
        except KeyError:
            gid = self.uid
        command = ["systemd-run", "--quiet", f"--unit={name}", "--collect",
                   f"--uid={self.uid}", f"--gid={gid}"]
        if restart:
            command += ["-p", "Restart=always", "-p", "RestartSec=1", "-p", "StartLimitIntervalSec=0"]
        for key in ("DISPLAY", "XAUTHORITY", "DBUS_SESSION_BUS_ADDRESS", "XDG_RUNTIME_DIR"):
            if self.env.get(key):
                command.append(f"--setenv={key}={self.env[key]}")
        command.append("--setenv=NO_AT_BRIDGE=1")
        return command + list(argv)


def _controlled_users() -> set:
    try:
        group = grp.getgrnam(CONTROLLED_GROUP)
    except KeyError:
        return set()
    members = set(group.gr_mem)
    for entry in pwd.getpwall():
        if entry.pw_gid == group.gr_gid:
            members.add(entry.pw_name)
    return members


def _loginctl(*args) -> str:
    try:
        return subprocess.run(
            ["loginctl", *args],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        ).stdout
    except (OSError, subprocess.TimeoutExpired):
        return ""


def _read_key_values(path: str) -> dict:
    with open(path, encoding="utf-8", errors="replace") as handle:
        return dict(line.rstrip("\n").split("=", 1) for line in handle if "=" in line and not line.startswith("#"))


def _boot_id() -> str:
    try:
        with open(BOOT_ID_PATH, encoding="ascii") as handle:
            return handle.read().strip()
    except OSError:
        return ""


def _logind_files(directory: str) -> list | None:
    """Sessões lidas dos arquivos do logind (root, sem fork); None = indisponível."""
    try:
        names = sorted(os.listdir(directory))
    except OSError:
        return None
    sessions = []
    for name in names:
        if "." in name:
            continue
        try:
            values = _read_key_values(os.path.join(directory, name))
        except OSError:
            continue
        sessions.append({
            "id": name,
            "class": values.get("CLASS"),
            "state": values.get("STATE"),
            "type": values.get("TYPE"),
            "user": values.get("USER", ""),
            "uid": values.get("UID", ""),
            "display": values.get("DISPLAY", ""),
            "leader": values.get("LEADER", ""),
            "realtime": values.get("REALTIME", ""),
        })
    return sessions


def _logind_loginctl() -> list:
    sessions = []
    for line in _loginctl("list-sessions", "--no-legend").splitlines():
        fields = line.split()
        if not fields:
            continue
        props = _loginctl(
            "show-session", fields[0],
            "-p", "Class", "-p", "State", "-p", "Type", "-p", "Name",
            "-p", "User", "-p", "Display", "-p", "Leader",
        )
        values = dict(item.split("=", 1) for item in props.splitlines() if "=" in item)
        sessions.append({
            "id": fields[0],
            "class": values.get("Class"),
            "state": values.get("State"),
            "type": values.get("Type"),
            "user": values.get("Name", ""),
            "uid": values.get("User", ""),
            "display": values.get("Display", ""),
            "leader": values.get("Leader", ""),
            "realtime": "",
        })
    return sessions


class SessionTracker:
    """Uma varredura em cache curto serve a sessão controlada ativa e a sessão
    gráfica ativa de qualquer conta humana."""

    def __init__(self, sessions_dir: str = LOGIND_SESSIONS_DIR):
        self.sessions_dir = sessions_dir
        self._cached = []
        self._cached_at = None
        self._lock = threading.Lock()

    def _scan_cached(self) -> list:
        with self._lock:
            now = time.monotonic()
            if self._cached_at is None or now - self._cached_at >= SESSION_CACHE_S:
                self._cached = self._scan()
                self._cached_at = now
            return self._cached

    def active(self) -> Session | None:
        for session in self._scan_cached():
            if session.controlled:
                return session
        return None

    def active_any(self) -> Session | None:
        sessions = self._scan_cached()
        return sessions[0] if sessions else None

    def _scan(self) -> list:
        raw = _logind_files(self.sessions_dir)
        if raw is None:
            raw = _logind_loginctl()
        controlled = _controlled_users()
        boot_id = _boot_id()
        found = []
        for values in raw:
            if values.get("class") != "user" or values.get("state") != "active":
                continue
            if values.get("type") not in ("x11", "wayland"):
                continue
            try:
                uid = int(values.get("uid", ""))
                leader = int(values.get("leader", ""))
            except ValueError:
                continue
            user = values.get("user", "")
            if uid < MIN_HUMAN_UID or not user:
                continue
            try:
                realtime_ms = int(values.get("realtime") or "") // 1000 or None
            except ValueError:
                realtime_ms = None
            try:
                found.append(Session(values["id"], user, uid, values.get("display", ""), leader,
                                     controlled=user in controlled, realtime_ms=realtime_ms, boot_id=boot_id))
            except KeyError:
                continue  # conta sumiu do passwd entre a varredura e o Session
        found.sort(key=lambda session: not session.controlled)
        return found


# ---- Unidades transitórias do systemd -------------------------------------------


def _systemctl(*args, timeout: float = 10):
    return subprocess.run(["systemctl", *args], capture_output=True, text=True,
                          timeout=timeout, check=False, stdin=subprocess.DEVNULL)


def spawn_unit(session: Session, name: str, argv: list, restart: bool = False) -> dict:
    """Sobe `argv` como serviço transitório com o uid do aluno (spec §7.2/§3.3)."""
    try:
        result = subprocess.run(session.unit_command(name, argv, restart), capture_output=True, text=True,
                                timeout=COMMAND_TIMEOUT_S, check=False, stdin=subprocess.DEVNULL)
    except (OSError, subprocess.TimeoutExpired) as error:
        log.warning("systemd-run %s falhou: %s", name, error)
        return {"ok": False, "error": "unidade_falhou"}
    if result.returncode != 0:
        log.warning("systemd-run %s: %s", name, (result.stderr or "").strip()[:200])
        return {"ok": False, "error": "unidade_falhou"}
    return {"ok": True}


def unit_active(name: str) -> bool:
    try:
        return _systemctl("is-active", "--quiet", name).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def unit_user(name: str) -> str | None:
    """User= da unidade (o aluno para quem ela foi criada), ou None."""
    try:
        result = _systemctl("show", "-p", "User", "--value", name)
    except (OSError, subprocess.TimeoutExpired):
        return None
    value = (result.stdout or "").strip()
    return value or None


def stop_unit(name: str):
    try:
        _systemctl("stop", name, timeout=15)
    except (OSError, subprocess.TimeoutExpired) as error:
        log.warning("systemctl stop %s: %s", name, error)


def restart_unit(name: str):
    try:
        _systemctl("restart", name, timeout=15)
    except (OSError, subprocess.TimeoutExpired) as error:
        log.warning("systemctl restart %s: %s", name, error)


# ---- Ações dentro da sessão --------------------------------------------------


def _read_and_remove(path: str) -> bytes | None:
    try:
        with open(path, "rb") as handle:
            return handle.read()
    except OSError:
        return None
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def _capture_dir(uid: int) -> str | None:
    """Diretório do root, 0711, recriado a cada captura: o aluno atravessa,
    mas não lista, não cria e não troca arquivo por link."""
    base = CAPTURE_DIR
    directory = os.path.join(base, str(int(uid)))
    try:
        os.makedirs(base, mode=0o711, exist_ok=True)
        info = os.lstat(base)
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid():
            return None
        os.chmod(base, 0o711)
        shutil.rmtree(directory, ignore_errors=True)
        os.mkdir(directory, 0o711)
        os.chmod(directory, 0o711)
    except OSError as error:
        log.warning("diretório de captura: %s", error)
        return None
    return directory


def _precreate(path: str, uid: int, gid: int) -> bool:
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    except OSError:
        return False
    try:
        os.fchown(fd, uid, gid)
    except OSError:
        return False
    finally:
        os.close(fd)
    return True


def _read_capture(path: str, uid: int, cap: int) -> bytes | None:
    """Arquivo regular do aluno certo, sem seguir link e sem travar em FIFO,
    com no máximo `cap` bytes; maior que isso é recusado, não cortado."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    except OSError:
        return None
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != uid or info.st_size > cap:
            return None
        chunks, total = [], 0
        while total <= cap:
            chunk = os.read(fd, min(65536, cap + 1 - total))
            if not chunk:
                break
            chunks.append(chunk)
            total += len(chunk)
        if total > cap:
            return None
        return b"".join(chunks)
    except OSError:
        return None
    finally:
        os.close(fd)


def _unlink_all(*paths):
    for path in paths:
        try:
            os.unlink(path)
        except OSError:
            pass


def _scrot(session: Session, uid: int, quality: int, cap: int, thumb: bool):
    """(dados, None) ou (None, código). O scrot roda como o aluno e sobrescreve
    no lugar arquivos que o root criou para ele."""
    directory = _capture_dir(uid)
    if directory is None:
        return None, "tela_vazia"
    full = os.path.join(directory, "tela.jpg")
    small = os.path.join(directory, "tela-thumb.jpg")
    try:
        gid = pwd.getpwnam(session.user).pw_gid
    except KeyError:
        gid = uid
    targets = (full, small) if thumb else (full,)
    if not all(_precreate(path, uid, gid) for path in targets):
        _unlink_all(*targets)
        return None, "tela_vazia"
    argv = ["scrot", "-o", "-q", str(quality)]
    if thumb:
        argv += ["-t", f"{THUMB_WIDTH}x0"]
    try:
        result = session.run(argv + [full])
    except (OSError, subprocess.TimeoutExpired) as error:
        _unlink_all(*targets)
        return None, f"tela_{type(error).__name__}"
    if result.returncode != 0:
        _unlink_all(*targets)
        log.warning("scrot: %s", (result.stderr or b"").decode("utf-8", "replace").strip()[:200])
        return None, "tela_falhou"
    data = _read_capture(small if thumb else full, uid, cap)
    _unlink_all(*targets)
    return (data, None) if data else (None, "tela_vazia")


def capture_screen(session: Session) -> dict:
    data, error = _scrot(session, session.uid, 45, SCREEN_MAX_BYTES, thumb=False)
    if not data:
        return {"ok": False, "error": error}
    return {"ok": True, "jpegB64": base64.b64encode(data).decode("ascii")}


def jpeg_size(data: bytes) -> tuple[int, int] | None:
    """(largura, altura) do marcador SOF de um JPEG, sem decodificar."""
    if not data or data[:2] != b"\xff\xd8":
        return None
    offset = 2
    while offset + 4 <= len(data):
        if data[offset] != 0xFF:
            return None
        marker = data[offset + 1]
        if marker in (0xD8, 0x01) or 0xD0 <= marker <= 0xD7:
            offset += 2
            continue
        (length,) = struct.unpack(">H", data[offset + 2: offset + 4])
        if 0xC0 <= marker <= 0xCF and marker not in (0xC4, 0xC8, 0xCC):
            if offset + 9 > len(data):
                return None
            height, width = struct.unpack(">HH", data[offset + 5: offset + 9])
            return width, height
        offset += 2 + length
    return None


def capture_thumb(session: Session) -> dict:
    """Miniatura da tela inteira (≤ 480 px, q 60) para a grade ao vivo."""
    data, error = _scrot(session, session.uid, THUMB_QUALITY, THUMB_MAX_BYTES, thumb=True)
    if not data:
        return {"ok": False, "error": error}
    size = jpeg_size(data) or (THUMB_WIDTH, 0)
    return {"ok": True, "jpeg": data, "w": size[0], "h": size[1]}


# Uma câmera só: o comando do professor e as fotos do arquivo se revezam, e a
# foto recente serve aos dois.
_camera_lock = threading.Lock()
_camera_last = {"at": None, "jpeg": None}


def _run_fswebcam() -> tuple[bytes | None, str | None]:
    if not os.path.exists(CAMERA_DEVICE):
        return None, "camera_ausente"
    fd, path = tempfile.mkstemp(prefix="controle-de-aula-", suffix=".jpg")
    os.close(fd)
    try:
        result = subprocess.run(
            ["fswebcam", "-q", "-d", CAMERA_DEVICE, "-r", "640x480", "--no-banner",
             "--jpeg", "60", "-S", str(CAMERA_SKIP_FRAMES), path],
            capture_output=True,
            timeout=COMMAND_TIMEOUT_S,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        _read_and_remove(path)
        return None, f"camera_{type(error).__name__}"
    data = _read_and_remove(path)
    if result.returncode != 0 or not data:
        return None, "camera_falhou"
    return data, None


def capture_camera_jpeg() -> tuple[bytes | None, str | None]:
    """(jpeg, None) ou (None, erro)."""
    with _camera_lock:
        at = _camera_last["at"]
        if at is not None and time.monotonic() - at < CAMERA_REUSE_S:
            return _camera_last["jpeg"], None
        jpeg, error = _run_fswebcam()
        if jpeg:
            _camera_last["at"], _camera_last["jpeg"] = time.monotonic(), jpeg
        return jpeg, error


def capture_camera() -> dict:
    jpeg, error = capture_camera_jpeg()
    if not jpeg:
        return {"ok": False, "error": error}
    return {"ok": True, "jpegB64": base64.b64encode(jpeg).decode("ascii")}


def list_apps(session: Session, browser_reported: bool = False) -> list:
    """Janelas da barra de tarefas, lidas do X no próprio processo."""
    from .xwindows import LISTER
    return LISTER.list(session, browser_reported)


def notify(session: Session, title: str, body: str) -> dict:
    try:
        result = session.run(
            ["notify-send", "-a", "Controle de Aula", "-u", "critical",
             "-i", "dialog-information", title, body],
            timeout=10,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        return {"ok": False, "error": f"aviso_{type(error).__name__}"}
    return {"ok": result.returncode == 0, "error": None if result.returncode == 0 else "aviso_falhou"}


def open_browser(session: Session, url: str) -> dict:
    try:
        session.spawn(["voges", url])
    except OSError as error:
        return {"ok": False, "error": f"voges_{type(error).__name__}"}
    return {"ok": True}


def set_wallpaper(session: Session, jpeg: bytes) -> dict:
    # O xfconf é por usuário, então o arquivo fica em lugar legível por todos e
    # cada propriedade last-image do xfce4-desktop aponta para ele.
    try:
        os.makedirs(os.path.dirname(WALLPAPER_PATH), exist_ok=True)
        with open(WALLPAPER_PATH + ".tmp", "wb") as handle:
            handle.write(jpeg)
        os.chmod(WALLPAPER_PATH + ".tmp", 0o644)
        os.replace(WALLPAPER_PATH + ".tmp", WALLPAPER_PATH)
        listing = session.run(["xfconf-query", "-c", "xfce4-desktop", "-l"], timeout=10)
    except (OSError, subprocess.TimeoutExpired) as error:
        return {"ok": False, "error": f"papel_{type(error).__name__}"}
    properties = [
        line.strip()
        for line in listing.stdout.decode("utf-8", "replace").splitlines()
        if line.strip().endswith("/last-image")
    ]
    if not properties:
        return {"ok": False, "error": "papel_sem_monitor"}
    for prop in properties:
        try:
            session.run(["xfconf-query", "-c", "xfce4-desktop", "-p", prop, "-s", WALLPAPER_PATH], timeout=10)
        except (OSError, subprocess.TimeoutExpired):
            return {"ok": False, "error": "papel_xfconf"}
    return {"ok": True}


_VERSAO_VALIDA = re.compile(r"^[0-9A-Za-z.+~-]{1,20}$")
UPDATE_UNIT = "celita-update-manual.service"


def celita_version() -> str | None:
    """Versão instalada do celita-os-completo, ou None fora do Celita."""
    try:
        result = subprocess.run(
            ["dpkg-query", "-W", "-f=${Version}", "celita-os-completo"],
            capture_output=True, text=True, timeout=10, check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    version = result.stdout.strip()
    return version if result.returncode == 0 and _VERSAO_VALIDA.match(version) else None


def start_update() -> dict:
    # A mesma verificação do "Atualizar agora" da Central. --no-block: o apt
    # reinicia este agente no meio, e o ack precisa sair antes.
    try:
        result = subprocess.run(
            ["systemctl", "start", "--no-block", UPDATE_UNIT],
            capture_output=True, timeout=10, check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        return {"ok": False, "error": f"atualizar_{type(error).__name__}"}
    if result.returncode != 0:
        return {"ok": False, "error": "atualizador_ausente"}
    return {"ok": True}
