"""Alvo dos comandos (SPEC-turma §1.5): quais PCs cada ação atinge. Puro;
porta de `broadcast_target.dart` do app (`alvoDeBroadcast`,
`alvoDeRegrasRemotas`, `alvoDeTurma`). O PC do professor (telão) nunca é alvo
de broadcast, e PC reservado por outro professor nunca é alvo meu."""


def alvo_de_broadcast(aula_ativa: bool, da_aula, todos, pc_professor_id=None, travados_por_outros=frozenset()) -> list:
    """Durante a aula, os PCs da aula; fora dela, todos os pareados, menos o
    telão e os presos na aula de outro professor."""
    base = da_aula if aula_ativa else todos
    return [i for i in base if i != pc_professor_id and i not in travados_por_outros]


def alvo_de_regras_remotas(todos, meus, travados_por_outros=frozenset()) -> list:
    """Regras mudaram em OUTRO aparelho: quem editou já mandou o snapshot aos
    PCs livres. Aqui só reenvia aos PCs em que este app tem reserva ou
    liberação própria — o snapshot daqui leva as liberações daqui."""
    return [i for i in todos if i in meus and i not in travados_por_outros]


def alvo_de_turma(aula_ativa: bool, da_aula, pc_professor_id=None, modo_escola: bool = False,
                  reservados_por_mim=frozenset(), reservados_por_outros=frozenset()) -> list:
    """Trava, prova, grade, "Mensagem para a turma" e, no desktop, "Abrir
    site" e "Fechar abas" da turma: só com aula ativa; na escola, só os PCs
    da aula que estão reservados por MIM agora."""
    if not aula_ativa:
        return []
    return [
        i for i in da_aula
        if i != pc_professor_id and i not in reservados_por_outros and (not modo_escola or i in reservados_por_mim)
    ]
