"""Reservas de aula da escola (`/school/aulas/{deviceId}`): um PC participa
de UMA aula por vez, entre professores diferentes. Porta de `aula_locks.dart`
do app (SPEC-turma §1.5, §14.B.1).

Reserva = {uid, ts, env}; env = {professor, turma} selado com a chave dos
stores da escola (o nome da turma não vaza em claro). O heartbeat renova o
ts; reserva sem heartbeat há mais de 15 min é órfã. As rules arbitram a
disputa no servidor: escrever por cima da reserva viva de outro dá 401.
Escritas pelo caminho lateral (negação não reconecta os streams).
"""

import logging
import threading

from ..crypto import open_envelope, seal
from ..firebase import FirebaseError

log = logging.getLogger("controle-de-aula.teacher.aulas")

# Espelhado nas rules: now - ts > 900000.
TRAVA_EXPIRA_MS = 15 * 60 * 1000
OUTRO_PROFESSOR = "outro professor"


def trava_expirada(ts, agora_ms: int) -> bool:
    return agora_ms - ts > TRAVA_EXPIRA_MS


class AulaLocks:
    def __init__(self, fb, meu_uid: str, key: bytes, now_server_ms):
        self.fb = fb
        self.meu_uid = meu_uid
        self.key = key
        self.now_server_ms = now_server_ms
        self.on_change = None
        # A primeira leitura de /school/aulas já chegou? Antes dela não se sabe
        # quem é de quem: o up/ dos PCs espera (nem lê, nem apaga).
        self.carregado = False
        self._travas = {}
        self._stream = None
        self._lock = threading.RLock()

    # ---- leitura ------------------------------------------------------------

    def start(self):
        self._stream = self.fb.stream("/school/aulas", self._on_event)

    def stop(self):
        if self._stream is not None:
            self._stream.close()
            self._stream = None

    def _parse(self, raw):
        if not isinstance(raw, dict):
            return None
        uid, ts = raw.get("uid"), raw.get("ts")
        if not isinstance(uid, str) or isinstance(ts, bool) or not isinstance(ts, (int, float)):
            return None
        trava = {"uid": uid, "ts": int(ts), "professor": None, "turma": None}
        env = raw.get("env")
        if isinstance(env, str):
            try:
                message = open_envelope(self.key, env)
            except Exception:  # noqa: BLE001 - chave antiga: vale sem os nomes
                message = None
            if isinstance(message, dict):
                for campo in ("professor", "turma"):
                    if isinstance(message.get(campo), str) and message[campo].strip():
                        trava[campo] = message[campo].strip()[:60]
        trava["raw"] = dict(raw)
        return trava

    def _on_event(self, event: dict):
        path, data = event.get("path"), event.get("data")
        with self._lock:
            if event.get("type") == "patch":
                base = "" if path == "/" else (path or "").rstrip("/")
                for key, value in (data.items() if isinstance(data, dict) else ()):
                    self._apply(f"{base}/{key}", value)
            else:
                self._apply(path, data)
            if path == "/":
                self.carregado = True
        if self.on_change is not None:
            self.on_change()

    def _apply(self, path, data):
        parts = [p for p in (path or "").split("/") if p]
        if not parts:
            self._travas = {}
            for device_id, raw in (data.items() if isinstance(data, dict) else ()):
                trava = self._parse(raw)
                if trava is not None:
                    self._travas[device_id] = trava
            return
        device_id = parts[0]
        if len(parts) == 1:
            trava = self._parse(data)
        else:
            atual = dict(self._travas.get(device_id, {}).get("raw", {}))
            if data is None:
                atual.pop(parts[1], None)
            else:
                atual[parts[1]] = data
            trava = self._parse(atual)
        if trava is None:
            self._travas.pop(device_id, None)
        else:
            self._travas[device_id] = trava

    # ---- consultas ----------------------------------------------------------

    def trava_de(self, device_id: str):
        with self._lock:
            return self._travas.get(device_id)

    def trava_viva_de(self, device_id: str):
        trava = self.trava_de(device_id)
        if trava is None or trava_expirada(trava["ts"], self.now_server_ms()):
            return None
        return trava

    def travado_por_outro(self, device_id: str) -> bool:
        trava = self.trava_viva_de(device_id)
        return trava is not None and trava["uid"] != self.meu_uid

    def travado_por_mim(self, device_id: str) -> bool:
        trava = self.trava_viva_de(device_id)
        return trava is not None and trava["uid"] == self.meu_uid

    def professor_de(self, device_id: str) -> str:
        trava = self.trava_de(device_id)
        return (trava or {}).get("professor") or OUTRO_PROFESSOR

    def meus(self) -> list:
        with self._lock:
            return [d for d, t in self._travas.items() if t["uid"] == self.meu_uid]

    # ---- escrita ------------------------------------------------------------

    def travar(self, device_id: str, professor: str, turma: str) -> str | None:
        """Reserva o PC para a MINHA aula. None = reservado; senão o nome do
        professor que já está com ele. Erro de rede sobe como FirebaseError."""
        if self.travado_por_outro(device_id):
            return self.professor_de(device_id)
        env = seal(self.key, {"professor": (professor or "").strip()[:60], "turma": (turma or "").strip()[:60]})
        node = {"uid": self.meu_uid, "ts": self.now_server_ms(), "env": env}
        try:
            self.fb.side_request("PUT", f"/school/aulas/{device_id}", node)
        except FirebaseError as error:
            if error.status in (401, 403):
                # As rules recusaram: alguém reservou antes (o stream ainda
                # não tinha chegado aqui).
                return self.professor_de(device_id)
            raise
        with self._lock:
            parsed = self._parse(node)
            if parsed is not None:
                self._travas[device_id] = parsed
        return None

    def destravar(self, device_id: str):
        trava = self.trava_de(device_id)
        if trava is not None and trava["uid"] != self.meu_uid:
            return  # não é minha
        try:
            self.fb.side_request("DELETE", f"/school/aulas/{device_id}")
        except FirebaseError as error:
            log.warning("soltar a reserva de %s falhou: %s", device_id, error)
            return
        with self._lock:
            self._travas.pop(device_id, None)

    def destravar_todas(self):
        """Remove todas as MINHAS reservas (encerrar aula)."""
        for device_id in self.meus():
            self.destravar(device_id)

    def heartbeat(self):
        """Renova o ts das minhas reservas (a cada 5 min com aula ativa)."""
        agora = self.now_server_ms()
        for device_id in self.meus():
            try:
                self.fb.side_request("PUT", f"/school/aulas/{device_id}/ts", agora)
            except FirebaseError as error:
                log.warning("renovar a reserva de %s falhou: %s", device_id, error)
