"""Cliente do professor: o papel inverso do agente, com os mesmos módulos.

Um stream por PC no nó inteiro `/devices/{id}` (as regras liberam a leitura ao
professor vinculado) e um no roster. Comandos saem selados com a chave de
sessão de cada PC e o cabeçalho anti-replay no relógio do servidor, exatamente
como o celular faz — dois professores alternando no mesmo PC não se
envenenam, e um replay é rejeitado pelo guard do PC.
"""

import base64
import json
import logging
import threading
import time
import urllib.parse
from collections import OrderedDict

from .. import protocol
from ..crypto import derive_session_key, open_envelope, public_key_b64url, seal
from ..firebase import FirebaseError, FirebaseSession
from ..up import push_id_ms
from . import commands, up_router
from .sessions import SessionRegistry

log = logging.getLogger("controle-de-aula.teacher")

STATE_KINDS = {
    protocol.SET_RULES: "rules",
    protocol.SET_WALLPAPER: "wallpaper",
    protocol.SET_CLASS_VIEW: "classview",
    protocol.SET_UNIT: "unit",
    protocol.SET_LOCK: "lock",
    protocol.SET_EXAM: "exam",
    protocol.SET_MONITOR: "monitor",
}
# Nós de estado dos recursos de turma: escrita pelo caminho lateral, porque
# rules ainda não publicadas negam (401) e o caminho normal renovaria o token
# e reconectaria todos os streams (SPEC-turma §1.3).
SIDE_STATE_KINDS = {"lock", "exam", "monitor"}
# "Pertence a mim": ids de comando que ESTE processo emitiu (os 500 últimos).
MAX_EMITIDOS = 500


class IdsEmitidos:
    def __init__(self, limite: int = MAX_EMITIDOS):
        self.limite = limite
        self._ids = OrderedDict()
        self._lock = threading.Lock()

    def registrar(self, command_id):
        if not isinstance(command_id, str):
            return
        with self._lock:
            self._ids.pop(command_id, None)
            self._ids[command_id] = True
            while len(self._ids) > self.limite:
                self._ids.popitem(last=False)

    def __contains__(self, command_id) -> bool:
        with self._lock:
            return command_id in self._ids


def chave_no_caminho(key: str) -> str:
    """Chave escrita pelo PC (up/, ack/) dentro de uma URL do RTDB: as rules
    não fixam o formato, e "?", "%" ou "&" mudariam o pedido."""
    return urllib.parse.quote(str(key), safe="-_")


def _estado_trava(payload) -> dict | None:
    if not isinstance(payload, dict):
        return None
    rev, ate = payload.get("rev"), payload.get("ate")
    if not isinstance(rev, (int, float)) or not isinstance(ate, (int, float)):
        return None
    texto = payload.get("texto")
    return {"rev": int(rev), "on": payload.get("on") is True,
            "texto": texto[: protocol.MAX_TRAVA_TEXTO] if isinstance(texto, str) else "",
            "mute": payload.get("mute") is True, "ate": int(ate)}


def _estado_prova(payload) -> dict | None:
    if not isinstance(payload, dict):
        return None
    rev, ate = payload.get("rev"), payload.get("ate")
    if not isinstance(rev, (int, float)) or not isinstance(ate, (int, float)):
        return None
    allow = [a["pattern"] for a in payload.get("allow") or [] if isinstance(a, dict) and isinstance(a.get("pattern"), str)]
    inicio = payload.get("inicio")
    return {"rev": int(rev), "on": payload.get("on") is True, "allow": allow[: protocol.MAX_RULES],
            "inicio": inicio if isinstance(inicio, str) else None, "ate": int(ate)}


def parse_qr_payload(raw: str) -> dict | None:
    """QR v4 da extensão e do agente: {v, id, pub, tok, label}."""
    try:
        data = json.loads((raw or "").strip())
    except (TypeError, ValueError):
        return None
    if not isinstance(data, dict) or data.get("v") != 4:
        return None
    fields = {}
    for key, name in (("id", "device_id"), ("pub", "pub"), ("tok", "token")):
        value = data.get(key)
        if not isinstance(value, str) or not value or len(value) > 64:
            return None
        fields[name] = value
    label = data.get("label")
    fields["label"] = label if isinstance(label, str) and label else "Chromebook"
    return fields


class TeacherClient:
    def __init__(
        self,
        config: dict,
        private_key,
        teacher_name: str = "Professor",
        school_uid: str | None = None,
        load_auth=None,
        save_auth=None,
        session_factory=None,
    ):
        self.private_key = private_key
        self.teacher_name = teacher_name
        self.school_uid = school_uid
        self.registry = SessionRegistry()
        self.on_snapshot = None
        self.on_ack = None
        self.state_commands_for = None
        # Recursos de turma: `aplicado` do relatório, itens do up/, estado
        # decifrado de state/lock|exam e o destino do up/ (reserva de aula).
        self.on_aplicado = None
        self.on_up = None
        self.on_up_removido = None
        self.on_up_silenciado = None
        self.on_estado_turma = None
        self.destino_do_up = None
        self.emitidos = IdsEmitidos()
        self.up_router = up_router.UpRouter()
        # up/ de PC reservado por outro: guardado sem ler (os 20 mais novos),
        # para o caso de o PC ficar livre ou meu depois.
        self._up_ignorados = {}
        self._up_locks = {}
        # authOrigin/tokenOrigin só existem em teste, apontando para o loopback.
        origins = {k: config[c] for k, c in (("auth_origin", "authOrigin"), ("token_origin", "tokenOrigin")) if c in config}
        self._session_factory = session_factory or (
            lambda: FirebaseSession(config["apiKey"], config["databaseURL"], load_auth, save_auth, **origins)
        )
        self.fb = None
        self._roster_stream = None
        self._device_streams = {}
        self._first_report = {}
        self._server_offset_ms = 0
        self._last_sid = 0
        self._lock = threading.RLock()

    # ---- ciclo de vida ------------------------------------------------------------

    @property
    def teacher_uid(self) -> str | None:
        return self.fb.uid if self.fb else None

    @property
    def owner_uid(self) -> str:
        return self.school_uid or self.teacher_uid

    @property
    def roster_path(self) -> str:
        return "/school/devices" if self.school_uid else f"/teachers/{self.teacher_uid}/devices"

    def start(self):
        self.connect()
        self.start_streams()

    def connect(self):
        """Só autentica e calibra o relógio; os streams esperam a escola liberar."""
        self.fb = self._session_factory()
        self.fb.sign_in()
        self._calibrate_clock()

    def start_streams(self):
        self._roster_stream = self.fb.stream(self.roster_path, self._on_roster_event)

    def stop(self):
        with self._lock:
            streams = list(self._device_streams.values())
            self._device_streams.clear()
        # Um attach em andamento ainda não tem stream (None): nada a fechar.
        for stream in streams:
            if stream is not None:
                stream.close()
        if self._roster_stream is not None:
            self._roster_stream.close()
        if self.fb is not None:
            self.fb.stop()

    def now_server_ms(self) -> int:
        return int(time.time() * 1000) + self._server_offset_ms

    def _calibrate_clock(self):
        # O REST não expõe .info/serverTimeOffset. Gravar o carimbo do servidor
        # num nó próprio e ler de volta dá o mesmo desvio.
        path = f"/teachers/{self.teacher_uid}/clock"
        try:
            local = int(time.time() * 1000)
            self.fb.put(path, FirebaseSession.server_timestamp())
            server = self.fb.get(path)
            if isinstance(server, (int, float)):
                self._server_offset_ms = int(server) - local
        except Exception as error:  # noqa: BLE001
            log.warning("relógio do servidor indisponível: %s", error)

    def _next_sid(self) -> int:
        with self._lock:
            now = self.now_server_ms()
            self._last_sid = now if now > self._last_sid else self._last_sid + 1
            return self._last_sid

    # ---- roster ---------------------------------------------------------------------

    def _on_roster_event(self, event: dict):
        path, data = event.get("path"), event.get("data")
        if path == "/":
            ids = set(data.keys()) if isinstance(data, dict) else set()
            for device_id in ids:
                self._attach(device_id)
            for device_id in list(self._device_streams):
                if device_id not in ids:
                    self._detach(device_id, remove_session=True)
        elif isinstance(path, str) and path.count("/") == 1:
            device_id = path[1:]
            if data:
                self._attach(device_id)
            else:
                self._detach(device_id, remove_session=True)

    # ---- por PC ---------------------------------------------------------------------

    def _attach(self, device_id: str):
        with self._lock:
            if device_id in self._device_streams:
                return
            self._device_streams[device_id] = None
        self._first_report[device_id] = True
        if self.registry.by_id(device_id) is None:
            # App reaberto: a chave de sessão é derivada de novo do meta/pub.
            meta = self.fb.get(f"/devices/{device_id}/meta")
            pub = meta.get("pub") if isinstance(meta, dict) else None
            if not isinstance(pub, str):
                self._detach(device_id)
                return
            try:
                key = derive_session_key(self.private_key, pub)
            except (ValueError, TypeError):
                self._detach(device_id)
                return
            label = meta.get("label") if isinstance(meta.get("label"), str) else "Chromebook"
            self.registry.bind(device_id, label, key)
        stream = self.fb.stream(
            f"/devices/{device_id}",
            lambda event: self._on_device_event(device_id, event),
        )
        with self._lock:
            if device_id in self._device_streams:
                self._device_streams[device_id] = stream
            else:
                stream.close()

    def _detach(self, device_id: str, remove_session: bool = False):
        with self._lock:
            stream = self._device_streams.pop(device_id, None)
        if stream is not None:
            stream.close()
        self._first_report.pop(device_id, None)
        if remove_session:
            self.registry.remove(device_id)
            self.up_router.limpar_pc(device_id)
            self._up_ignorados.pop(device_id, None)

    def _on_device_event(self, device_id: str, event: dict):
        path, data = event.get("path"), event.get("data")
        if event.get("type") == "patch":
            # patch = put em cada filho citado (o resto não muda). O app apaga
            # itens do up/ assim (`up.update({k: null})`).
            base = "" if path == "/" else (path or "").rstrip("/")
            for key, value in (data.items() if isinstance(data, dict) else ()):
                self._on_device_event(device_id, {"type": "put", "path": f"{base}/{key}", "data": value})
            return
        if path == "/":
            node = data if isinstance(data, dict) else {}
            if "bind" in node and node.get("bind") is None:
                return self._device_unbound(device_id)
            self._route_meta(device_id, node.get("meta"))
            presence = node.get("presence")
            if isinstance(presence, dict):
                self._route_presence(device_id, presence.get("lastSeen"))
            self._route_report(device_id, node.get("report"))
            self._route_snapshot(device_id, node.get("snapshot"))
            acks = node.get("ack")
            if isinstance(acks, dict):
                for push_id, envelope in acks.items():
                    self._route_ack(device_id, push_id, envelope)
            self._route_state_node(device_id, node.get("state"), replace=True)
            # Reconexão do stream: o que sumiu nesse meio-tempo sai de Recados.
            self._route_up_node(device_id, node.get("up"), replace=True)
            return
        if path == "/bind":
            if data is None:
                self._device_unbound(device_id)
        elif path == "/presence/lastSeen":
            self._route_presence(device_id, data)
        elif path == "/presence" and isinstance(data, dict):
            self._route_presence(device_id, data.get("lastSeen"))
        elif path == "/report":
            self._route_report(device_id, data)
        elif path == "/snapshot":
            self._route_snapshot(device_id, data)
        elif isinstance(path, str) and path.startswith("/ack/"):
            self._route_ack(device_id, path[len("/ack/"):], data)
        elif path == "/ack" and isinstance(data, dict):
            for push_id, envelope in data.items():
                self._route_ack(device_id, push_id, envelope)
        elif path == "/meta":
            self._route_meta(device_id, data)
        elif path == "/meta/label" and isinstance(data, str):
            self._route_meta(device_id, {"label": data})
        elif path == "/meta/ext" and isinstance(data, str):
            self._route_meta(device_id, {"ext": data})
        elif path == "/state":
            self._route_state_node(device_id, data, replace=True)
        elif path in ("/state/lock", "/state/exam"):
            self._route_state(device_id, path[len("/state/"):], data)
        elif path == "/up":
            self._route_up_node(device_id, data, replace=True)
        elif isinstance(path, str) and path.startswith("/up/") and path.count("/") == 2:
            key = path[len("/up/"):]
            if data is None:
                self._route_up_removed(device_id, key)
            else:
                self._route_up(device_id, key, data)

    def _device_unbound(self, device_id: str):
        # Aluno desvinculou pelo próprio PC: some do roster e da lista.
        self._detach(device_id, remove_session=True)
        self._remove_from_rosters(device_id)

    def _route_meta(self, device_id: str, meta):
        session = self.registry.by_id(device_id)
        if session is None or not isinstance(meta, dict):
            return
        changed = False
        label, ext = meta.get("label"), meta.get("ext")
        if isinstance(label, str) and label and session.label != label:
            session.label, changed = label, True
        if isinstance(ext, str) and session.ext_version != ext:
            session.ext_version, changed = ext, True
        if changed and self.registry.on_change:
            self.registry.on_change()

    def _route_presence(self, device_id: str, last_seen):
        if isinstance(last_seen, (int, float)):
            self.registry.touch_server_ts(device_id, int(last_seen))

    def _open(self, session, envelope):
        try:
            return open_envelope(session.session_key, envelope)
        except Exception:  # noqa: BLE001
            return None  # ilegível: corrida de re-pareamento

    def _route_report(self, device_id: str, node):
        session = self.registry.by_id(device_id)
        if session is None or not isinstance(node, dict) or not isinstance(node.get("env"), str):
            return
        message = self._open(session, node["env"])
        if not isinstance(message, dict) or message.get("type") != protocol.TAB_REPORT:
            return
        # O primeiro relatório depois de abrir pode ser antigo e é aceito sem
        # janela de tempo; ao vivo vale a janela. sid/seq valem sempre.
        first = self._first_report.get(device_id, True)
        self._first_report[device_id] = False
        now = int(time.time() * 1000)
        ts = now if first else message.get("ts", 0)
        if not session.report_guard.accept(message.get("sid", 0), message.get("seq", 0), ts, now):
            return
        server_ts = node.get("ts")
        fresh = self.registry.apply_report(
            device_id, message, int(server_ts) if isinstance(server_ts, (int, float)) else None
        )
        aplicado = message.get("aplicado")
        if isinstance(aplicado, dict) and self.on_aplicado is not None:
            self.on_aplicado(device_id, aplicado)
        return fresh

    def _route_snapshot(self, device_id: str, node):
        session = self.registry.by_id(device_id)
        if session is None or not isinstance(node, dict) or not isinstance(node.get("env"), str):
            return
        message = self._open(session, node["env"])
        if not isinstance(message, dict):
            return
        kind = message.get("type")
        if kind not in (protocol.CAMERA_SNAPSHOT, protocol.SCREEN_SNAPSHOT):
            return
        raw = message.get("jpegB64")
        if not isinstance(raw, str) or not raw:
            return
        try:
            jpeg = base64.b64decode(raw, validate=True)
        except (ValueError, TypeError):
            return
        if self.on_snapshot is not None:
            self.on_snapshot(device_id, kind, jpeg)

    def _route_ack(self, device_id: str, push_id: str, envelope):
        session = self.registry.by_id(device_id)
        if session is None or not isinstance(envelope, str):
            return
        message = self._open(session, envelope)
        ack = commands.parse_ack(message) if isinstance(message, dict) else None
        if ack is not None:
            now = int(time.time() * 1000)
            if session.ack_guard.accept(
                message.get("sid", 0), message.get("seq", 0), message.get("ts", now), now
            ):
                if not ack["ok"]:
                    log.info("ack com erro de %s: %s (%s)", device_id, ack["error"], ack["id"])
                if self.on_ack is not None:
                    self.on_ack(device_id, ack)
        # Só o ack de um id que ESTE app emitiu é apagado: os de outro
        # professor (ou de antes de reiniciar) ficam para quem os emitiu, e o
        # PC poda o resto (≤ 20) e os repete em `aplicado.acks`.
        if ack is None or ack["id"] not in self.emitidos:
            return
        try:
            self.fb.delete(f"/devices/{device_id}/ack/{chave_no_caminho(push_id)}")
        except Exception:  # noqa: BLE001
            pass

    # ---- estado de turma (state/lock, state/exam) -----------------------------------

    def _route_state_node(self, device_id: str, node, replace: bool = False):
        node = node if isinstance(node, dict) else {}
        for kind in ("lock", "exam"):
            if kind in node or replace:
                self._route_state(device_id, kind, node.get(kind))

    def _route_state(self, device_id: str, kind: str, envelope):
        """O que o PC deve aplicar, decifrado: é assim que a tela sabe quem
        está travado ou em prova depois de reiniciar. Ilegível (chave nova)
        = não se sabe; o PC destrava pelo prazo."""
        session = self.registry.by_id(device_id)
        if session is None:
            return
        message = self._open(session, envelope) if isinstance(envelope, str) else None
        payload = message.get("payload") if isinstance(message, dict) else None
        if kind == "lock":
            valor = _estado_trava(payload) if isinstance(message, dict) and message.get("type") == protocol.SET_LOCK else None
            if valor == session.trava:
                return
            session.trava = valor
        else:
            valor = _estado_prova(payload) if isinstance(message, dict) and message.get("type") == protocol.SET_EXAM else None
            if valor == session.prova:
                return
            session.prova = valor
        if self.on_estado_turma is not None:
            self.on_estado_turma(device_id)
        if self.registry.on_change:
            self.registry.on_change()

    # ---- canal up/ (aluno -> professor) ----------------------------------------------
    # Ordem (SPEC-turma §2.7): destino pela reserva de aula (ignorar = nem
    # decifra, nem apaga) → idade/teto/silêncio → decifra + up_guard → valida
    # caps e site → dedup por (deviceId, mid) → controller.

    def _up_lock(self, device_id: str):
        with self._lock:
            return self._up_locks.setdefault(device_id, threading.RLock())

    def _destino(self, device_id: str) -> str:
        decide = self.destino_do_up
        return decide(device_id) if decide is not None else up_router.MOSTRAR_E_NOTIFICAR

    def _route_up_node(self, device_id: str, node, replace: bool = False):
        node = node if isinstance(node, dict) else {}
        if replace:
            known = set(self.up_router.chaves_presentes(device_id)) | set(self._up_ignorados.get(device_id, {}))
            for key in sorted(known - set(node)):
                self._route_up_removed(device_id, key)
        for key in sorted(node):
            self._route_up(device_id, key, node[key])

    def _route_up(self, device_id: str, key: str, envelope):
        with self._up_lock(device_id):
            destino = self._destino(device_id)
            if destino == up_router.IGNORAR:
                if isinstance(envelope, str) and len(envelope) < protocol.UP_MAX_ENVELOPE:
                    guardados = self._up_ignorados.setdefault(device_id, {})
                    guardados[key] = envelope
                    for velha in sorted(guardados)[: max(0, len(guardados) - protocol.UP_MAX_ENTRADAS)]:
                        guardados.pop(velha, None)
                return
            # O que ficou guardado enquanto o PC era de outro professor vem
            # ANTES deste item: o up_guard (sid,seq) exige a ordem de chegada.
            self._drenar_ignorados(device_id, destino)
            self._ler_up(device_id, key, envelope, destino)

    def _drenar_ignorados(self, device_id: str, destino: str):
        guardados = self._up_ignorados.pop(device_id, None) or {}
        for key in sorted(guardados):
            self._ler_up(device_id, key, guardados[key], destino)

    def _ler_up(self, device_id: str, key: str, envelope, destino: str):
        agora = self.now_server_ms()
        chegada = self.up_router.ao_chegar(device_id, key, agora)
        for velha in chegada.apagar:
            self._apagar_up_calado(device_id, velha)
        if chegada.silenciou and self.on_up_silenciado is not None:
            self.on_up_silenciado(device_id)
        if not chegada.ler or not isinstance(envelope, str) or len(envelope) >= protocol.UP_MAX_ENVELOPE:
            return
        session = self.registry.by_id(device_id)
        if session is None:
            return
        item = up_router.parse_up(self._open(session, envelope))
        if item is None:
            return  # outra chave ou fora do protocolo: o PC poda em 2 h
        if not session.up_guard.accept(item["sid"], item["seq"], item["ts"], agora):
            return
        if not self.up_router.ao_ler(device_id, key, item["mid"]):
            return  # repetido (mesmo mid)
        if self.on_up is not None:
            self.on_up(device_id, item, push_id_ms(key) or agora, destino)

    def _route_up_removed(self, device_id: str, key: str):
        with self._up_lock(device_id):
            self._up_ignorados.get(device_id, {}).pop(key, None)
            mid = self.up_router.ao_remover(device_id, key)
        if mid is not None and self.on_up_removido is not None:
            self.on_up_removido(device_id, mid)

    def reavaliar_up_ignorados(self):
        """A reserva mudou (ou venceu pelo relógio): o up/ guardado de PC que
        deixou de ser de outro professor passa pelo caminho normal."""
        for device_id in list(self._up_ignorados):
            with self._up_lock(device_id):
                destino = self._destino(device_id)
                if destino != up_router.IGNORAR:
                    self._drenar_ignorados(device_id, destino)

    def _apagar_up_calado(self, device_id: str, key: str):
        try:
            self.delete_up(device_id, key)
        except FirebaseError as error:
            log.info("apagar up/%s de %s: %s", key, device_id, error)

    def delete_up(self, device_id: str, key: str):
        """Só filhos (as rules não deixam o professor apagar o nó inteiro).
        Erro sobe (o controller mostra o texto de §1.3)."""
        self.fb.side_request("DELETE", f"/devices/{device_id}/up/{chave_no_caminho(key)}")

    def delete_up_mid(self, device_id: str, mid: str):
        """Apaga todas as chaves do item `mid` (o pedido/mão resolvido)."""
        for key in self.up_router.chaves_de(device_id, mid):
            self.delete_up(device_id, key)

    def delete_all_up(self, device_id: str):
        """"Encerrar aula": todo o up/ do PC, filho a filho."""
        keys = self.fb.side_get(f"/devices/{device_id}/up", {"shallow": "true"})
        for key in sorted(keys) if isinstance(keys, dict) else []:
            self.delete_up(device_id, key)

    # ---- miniaturas da grade (/thumbs/{id}, fora de /devices) -------------------------

    def read_thumb(self, device_id: str) -> dict | None:
        """Última miniatura do PC, decifrada: {ts, jpeg|None, w, h, motivo}.
        None = nada lá (ou ilegível). Erro de rede/rules sobe."""
        session = self.registry.by_id(device_id)
        if session is None:
            return None
        node = self.fb.side_get(f"/thumbs/{device_id}")
        if not isinstance(node, dict):
            return None
        env, ts = node.get("env"), node.get("ts")
        if not isinstance(env, str) or len(env) >= protocol.THUMB_MAX_BYTES or isinstance(ts, bool) \
                or not isinstance(ts, (int, float)):
            return None
        message = self._open(session, env)
        if not isinstance(message, dict) or message.get("type") != protocol.THUMB_SNAPSHOT:
            return None
        jpeg = None
        raw = message.get("jpegB64")
        if isinstance(raw, str) and raw:
            try:
                jpeg = base64.b64decode(raw, validate=True)
            except (ValueError, TypeError):
                return None
        motivo = message.get("motivo")
        return {
            "ts": int(ts), "jpeg": jpeg,
            "w": message.get("w") if isinstance(message.get("w"), int) else 0,
            "h": message.get("h") if isinstance(message.get("h"), int) else 0,
            "motivo": None if jpeg else (motivo[:20] if isinstance(motivo, str) and motivo else "falhou"),
        }

    def delete_thumb(self, device_id: str):
        self.fb.side_request("DELETE", f"/thumbs/{device_id}")

    # ---- pareamento -----------------------------------------------------------------

    def pair(self, qr: dict, numero: int | None = None):
        """O passo do professor no QR: grava o bind (as regras validam o token e
        o primeiro dono), o roster e o estado vigente."""
        key = derive_session_key(self.private_key, qr["pub"])
        bind = {
            "teacherUid": self.owner_uid,
            "teacherPub": public_key_b64url(self.private_key),
            "teacherName": self.teacher_name,
            "token": qr["token"],
            "ts": FirebaseSession.server_timestamp(),
        }
        if numero is not None:
            bind["numero"] = numero
        device_id = qr["device_id"]
        label = f"Unidade {numero}" if numero is not None else qr["label"]
        # A sessão entra ANTES de gravar o roster: o stream do roster dispara
        # um attach em outra thread, e sem a sessão ele iria buscar meta/pub
        # e desistir, deixando o PC sem stream.
        self.registry.bind(device_id, label, key)
        self.fb.put(f"/devices/{device_id}/bind", bind)
        self.fb.put(f"{self.roster_path}/{device_id}", True)
        if self.school_uid:
            # Roster pessoal em paralelo: um app antigo continua enxergando.
            self.fb.put(f"/teachers/{self.teacher_uid}/devices/{device_id}", True)
        self._attach(device_id)
        for command in (self.state_commands_for(device_id) if self.state_commands_for else []):
            self.set_state(device_id, command)

    def forget(self, device_id: str):
        self._detach(device_id, remove_session=True)
        self.fb.delete(f"/devices/{device_id}/bind")
        self._remove_from_rosters(device_id)

    def _remove_from_rosters(self, device_id: str):
        for path in {f"{self.roster_path}/{device_id}", f"/teachers/{self.teacher_uid}/devices/{device_id}"}:
            try:
                self.fb.delete(path)
            except Exception:  # noqa: BLE001
                pass

    # ---- saída ----------------------------------------------------------------------

    def _seal_for(self, session, command: dict) -> str:
        return seal(
            session.session_key,
            {"sid": self._next_sid(), "seq": 1, "ts": self.now_server_ms(), **command},
        )

    def send(self, device_id: str, command: dict):
        session = self.registry.by_id(device_id)
        if session is None:
            return None
        self.emitidos.registrar(command.get("id"))
        return self.fb.push(f"/devices/{device_id}/cmd", self._seal_for(session, command))

    def send_all(self, command: dict, targets):
        """Lista explícita de alvos (SPEC-turma §1.5): o PC do professor fica
        fora de todo broadcast, como no celular."""
        for device_id in targets:
            if device_id != self.registry.teacher_pc_id:
                self.send(device_id, command)

    def set_state(self, device_id: str, command: dict):
        session = self.registry.by_id(device_id)
        kind = STATE_KINDS.get(command.get("type"))
        if session is None or kind is None:
            raise ValueError(f"não é comando de estado: {command.get('type')}")
        path = f"/devices/{device_id}/state/{kind}"
        if kind in SIDE_STATE_KINDS:
            self.fb.side_request("PUT", path, self._seal_for(session, command))
        else:
            self.fb.put(path, self._seal_for(session, command))

    def set_state_all(self, command: dict, targets):
        for device_id in targets:
            if device_id != self.registry.teacher_pc_id:
                self.set_state(device_id, command)

    def clear_state(self, device_id: str, kind: str):
        if kind in SIDE_STATE_KINDS:
            self.fb.side_request("DELETE", f"/devices/{device_id}/state/{kind}")
        else:
            self.fb.delete(f"/devices/{device_id}/state/{kind}")

    def publish_wallpaper(self, jpeg: bytes) -> str:
        """Publica o blob uma vez para a turma e devolve o hash a mandar por PC."""
        if len(jpeg) > 4 * 1024 * 1024:
            raise ValueError("imagem_grande")
        import hashlib

        hash_hex = hashlib.sha256(jpeg).hexdigest()[:8]
        self.fb.put(
            f"/wallpapers/{self.owner_uid}",
            {"hash": hash_hex, "jpeg": base64.b64encode(jpeg).decode(), "ts": FirebaseSession.server_timestamp()},
        )
        return hash_hex
