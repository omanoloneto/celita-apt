"""Comandos do professor, na forma exata que o app do celular envia.

Cada builder devolve o mesmo dicionário que `command.dart` monta: o PC não tem
como saber se quem mandou foi o celular ou o Celita OS, e é assim que precisa
ser. O cabeçalho anti-replay (sid, seq, ts) é acrescentado na selagem, não aqui.
"""

from .. import protocol
from ..up import new_id
from .rules import normalize_pattern, padrao_amplo_demais


def next_command_id() -> str:
    """12 bytes aleatórios (16 caracteres base64url). O antigo 'a'+contador se
    repetia entre professores e entre reinícios do app (SPEC-turma §1.2)."""
    return new_id()


def _command(kind: str, payload: dict) -> dict:
    return {"v": protocol.PROTOCOL_VERSION, "type": kind, "id": next_command_id(), "payload": payload}


def open_url(url: str, new_tab: bool = True, focus: bool = True) -> dict:
    return _command(protocol.OPEN_URL, {"url": url, "newTab": new_tab, "focus": focus})


def close_all_tabs(close_windows: bool = False, fim_de_aula: bool = False) -> dict:
    """`fim_de_aula` (só no "Encerrar aula"): o cliente novo limpa chat,
    pedidos e contadores; o antigo ignora a chave."""
    payload = {"closeWindows": close_windows}
    if fim_de_aula:
        payload["fimDeAula"] = True
    return _command(protocol.CLOSE_ALL_TABS, payload)


def show_message(title: str, body: str, popup: bool = False, sender: str | None = None) -> dict:
    payload = {"title": title, "body": body}
    if popup:
        payload["popup"] = True
        if sender is not None:
            payload["de"] = sender
    return _command(protocol.SHOW_MESSAGE, payload)


def close_tabs(domain: str | None = None, url: str | None = None) -> dict:
    if (domain is None) == (url is None):
        raise ValueError("informe domain OU url")
    return _command(protocol.CLOSE_TABS, {"domain": domain} if domain is not None else {"url": url})


def set_rules(rules, rev: int, liberados=frozenset(), filtros=None) -> dict:
    # rules = bloqueios (a extensão bloqueia); alerts = avisos, que o PC só usa
    # para fotografar a tentativa e marcar o histórico. alerts vai sempre.
    # `liberados` = padrões de bloqueio liberados para ESTE PC (forma do app);
    # `filtros` só vai quando a escola tem filtros salvos (ausente = padrão).
    def patterns(action: str) -> list:
        return [
            {"pattern": rule["pattern"]}
            for rule in rules
            if isinstance(rule, dict) and rule.get("action", "block") == action and rule.get("pattern")
            and not (action == "block" and rule["pattern"] in liberados)
        ][: protocol.MAX_RULES]

    payload = {"rev": rev, "rules": patterns("block"), "alerts": patterns("alert")}
    if isinstance(filtros, dict):
        payload["filtros"] = filtros
    return _command(protocol.SET_RULES, payload)


def set_unit(rev: int, numero: int) -> dict:
    return _command(protocol.SET_UNIT, {"rev": rev, "numero": numero})


def set_wallpaper(hash_hex: str) -> dict:
    return _command(protocol.SET_WALLPAPER, {"hash": hash_hex})


def capture_camera() -> dict:
    return _command(protocol.CAPTURE_CAMERA, {})


def capture_screen() -> dict:
    return _command(protocol.CAPTURE_SCREEN, {})


def atualizar() -> dict:
    """O PC roda na hora a verificação do "Atualizar agora" (só Celita)."""
    return _command(protocol.ATUALIZAR, {})


# ---- Recursos de turma (SPEC-turma §3, §4, §5, §7, §8) -----------------------------


def chat_message(texto: str, de: str, mid: str) -> dict:
    """Mensagem para a janela de chat do aluno. `mid` identifica o balão; o
    `id` do comando é outro (o do ack)."""
    return _command(protocol.CHAT_MESSAGE, {
        "texto": (texto or "").strip()[: protocol.MAX_CHAT_TEXTO],
        "de": (de or "").strip()[: protocol.MAX_CHAT_DE],
        "mid": mid,
    })


def unblock_result(mid: str, site: str, approved: bool, motivo: str | None = None,
                   rules_rev: int | None = None, exam_rev: int | None = None) -> dict:
    motivo = (motivo or "").strip()[: protocol.MAX_PEDIDO_MOTIVO]
    payload = {"mid": mid, "site": site, "approved": approved}
    if not approved and motivo:
        payload["motivo"] = motivo
    if approved and rules_rev is not None:
        payload["rulesRev"] = rules_rev
    if approved and exam_rev is not None:
        payload["examRev"] = exam_rev
    return _command(protocol.UNBLOCK_RESULT, payload)


def set_lock(rev: int, on: bool, texto: str, mute: bool, ate: int) -> dict:
    """"Olhos em mim" em state/lock. `ate` no relógio do SERVIDOR; o PC o
    converte para o próprio relógio. Destravar = on:false (nunca apagar)."""
    texto = " ".join((texto or "").split())[: protocol.MAX_TRAVA_TEXTO] or protocol.TRAVA_TEXTO_PADRAO
    return _command(protocol.SET_LOCK, {"rev": rev, "on": on, "texto": texto, "mute": bool(mute), "ate": ate})


def set_exam(rev: int, on: bool, allow, ate: int, inicio: str | None = None) -> dict:
    """Modo prova em state/exam: `allow` normalizado como as regras, sem
    repetidos e sem sufixo público (≤ 1000); `inicio` = página inicial da
    escola (http/https ≤ 2048)."""
    padroes = []
    for pattern in allow or ():
        normalizado = normalize_pattern(pattern)
        if not normalizado or padrao_amplo_demais(normalizado) or normalizado in padroes:
            continue
        padroes.append(normalizado)
        if len(padroes) >= protocol.MAX_RULES:
            break
    payload = {"rev": rev, "on": on, "allow": [{"pattern": p} for p in padroes]}
    inicio = (inicio or "").strip()
    if inicio and len(inicio) <= protocol.MAX_PROVA_INICIO and protocol.is_safe_http_url(inicio):
        payload["inicio"] = inicio
    payload["ate"] = ate
    return _command(protocol.SET_EXAM, payload)


def set_monitor(rev: int, ate: int) -> dict:
    """Grade ao vivo em state/monitor, renovado a cada 10 s (ate = agora+30 s)."""
    return _command(protocol.SET_MONITOR, {"rev": rev, "ate": ate})


def parse_ack(message) -> dict | None:
    if not isinstance(message, dict) or message.get("type") != protocol.ACK:
        return None
    command_id, ok = message.get("id"), message.get("ok")
    if not isinstance(command_id, str) or not isinstance(ok, bool):
        return None
    error = message.get("error")
    return {"id": command_id, "ok": ok, "error": error if isinstance(error, str) else None}
