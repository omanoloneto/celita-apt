"""Liga os stores locais, o cliente do professor e o workspace da escola. Sem
GTK: a interface só chama métodos daqui e ouve `on_change`. Todo método que
fala com a rede bloqueia — a interface chama numa thread.

Recursos de turma (SPEC-turma): reserva de aula na escola, alvo explícito de
cada ação, "Olhos em mim", modo prova, grade de telas, conversas e Recados
(pedidos de liberação e mão levantada) e a confirmação de entrega. O alvo de
tudo que é "da turma" é `alvo_turma()`: só com aula ativa; na escola, só os PCs
da aula reservados por mim.
"""

import json
import logging
import os
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.parse import urlsplit

from .. import protocol
from ..firebase import FirebaseError
from ..up import new_id
from . import commands, home as home_rules
from . import entrega as ent
from . import up_router as upr
from .alvo import alvo_de_broadcast, alvo_de_regras_remotas, alvo_de_turma
from .aulas import AulaLocks
from .auth import GoogleLogin
from .client import TeacherClient, parse_qr_payload
from .handoff import LoginHandoff
from .rules import find_rule, padroes_que_casam
from .school import NOT_ALLOWED, SchoolKeys, SchoolSync, school_store_key
from .stores import (
    AuthStore, ClassSession, HomeStore, JsonFile, KeyStore, NameStore, PrefsStore, ProvaStore, RulesStore,
    UnitStore, WallpaperStore, forget_if_stale, profile_dir, stamp_session,
)
from .textos_erro import (
    ERRO_ENVIO_LOCAL, TEXTO_SEM_INTERNET, TEXTO_SERVIDOR_DESATUALIZADO, negado, texto_erro_de_escrita,
)
from .thumb_estado import estado_do_quadro
from .versao import suporta_turma, tem_celita

log = logging.getLogger("controle-de-aula.teacher.controller")

WEBCAM_TIMEOUT_S = 8
# Escritas/leituras da turma em paralelo (cada uma é um HTTPS próprio, ~0,5 s
# até o servidor): 30 PCs em fila passariam do prazo de 30 s da grade.
PARALELO = 8

# Textos do item 10 (SPEC-turma §10.2): o erro cru fica só no log.
SEM_INTERNET_CONECTAR = "Sem conexão com a internet. Verifique a rede e toque em Tentar de novo."
CODIGO_EXPIROU = "O código expirou. Peça um novo código na janela do computador do aluno."
PUBLICACAO_FALHOU = "Não foi possível publicar agora. Tente de novo em instantes."
GOOGLE_FALHOU = "Não foi possível entrar com o Google. Tente de novo."
CELULAR_FALHOU = "Não foi possível entrar pelo celular. Tente de novo."
ESCOLA_LER_FALHOU = "Não foi possível acessar a escola agora. Tente de novo."
ESCOLA_CRIAR_FALHOU = "Não foi possível criar a escola agora. Tente de novo."

SEM_AULA = "Comece uma aula para usar com a turma."
AINDA_CONECTANDO = "Ainda conectando — tente de novo."
TRAVA_PRESETS = ("Olhos no professor", "Atenção à explicação")
# /home/menu só aceita o fundador e os membros da escola (rules).
FIXADOS_SO_ESCOLA = "Os apps fixados valem para a escola compartilhada. Crie ou entre na escola em Ajustes."


class TeacherController:
    def __init__(self, config: dict, directory: Path | None = None, session_factory=None, login_factory=None):
        self.config = config
        self.dir = directory or profile_dir()
        # Sair da conta, reiniciar ou desligar = sair do Controle do Professor.
        self.forgot_previous_session = forget_if_stale(self.dir)
        stamp_session(self.dir)
        self.rules = RulesStore(self.dir)
        self.units = UnitStore(self.dir)
        self.names = NameStore(self.dir)
        self.home = HomeStore(self.dir)
        self.wallpaper = WallpaperStore(self.dir)
        self.prefs = PrefsStore(self.dir)
        self.keys = KeyStore(self.dir)
        self.auth = AuthStore(self.dir)
        self.aula = ClassSession(self.dir)
        self.prova_store = ProvaStore(self.dir)
        self._session_factory = session_factory
        self._login_factory = login_factory or (lambda: GoogleLogin(config["googleClientId"], config.get("googleClientSecret")))
        self.client = None
        self.sync = None
        self.aulas = None
        self.on_change = None
        # (tipo, título, corpo, deviceId) de um recado que deve tocar
        # (notify-send na UI).
        self.on_recado = None
        self.error = None
        # E-mail fora de /school/members: a escola continua salva, sem sincronizar.
        self.not_allowed = False
        self.home_error = None
        self._last_rev = 0
        self._lock = threading.RLock()
        self._turma_lock = threading.RLock()
        # Confirmação de entrega: último comando (turma ou um PC), trava e prova.
        self.entrega = None
        self.entrega_um_pc = None
        self.entrega_trava = None
        self.entrega_prova = None
        self._timers = []
        self._silenciados = {}
        self._up_inicio_ms = 0
        # Grade de telas.
        self._grade_stop = None
        self._grade_pcs = set()
        self.grade_aberta_em = None
        self.erro_grade = None
        # Apps fixados da escola (/home/menu).
        self.menu_ids = []
        self.menu_carregado = False
        self.menu_error = None
        self._renova_stop = None

    # ---- ciclo de vida ------------------------------------------------------------

    def start(self):
        with self._lock:
            key = self.keys.load_or_create()
            factory = self._session_factory
            self.client = TeacherClient(
                self.config, key, teacher_name=self.prefs.teacher_name, school_uid=self.prefs.school_uid,
                load_auth=self.auth.load, save_auth=self.auth.save,
                session_factory=(lambda: factory(self.auth.load, self.auth.save)) if factory else None,
            )
            self.client.state_commands_for = self.state_commands_for
            self.client.registry.evaluate_alert = self.evaluate_alert
            self.client.registry.on_change = self._changed
            self.client.on_ack = self._ao_ack
            self.client.on_aplicado = self._ao_aplicado
            self.client.on_up = self._ao_up
            self.client.on_up_removido = self._ao_up_removido
            self.client.on_up_silenciado = self._ao_up_silenciado
            self.client.destino_do_up = self._destino_do_up
            self.not_allowed = False
            try:
                self.client.connect()
                if self.prefs.school_uid and not SchoolKeys(self.client.fb).is_member(self.prefs.school_uid, self.email):
                    self.not_allowed = True
                    self.error = NOT_ALLOWED.format(email=self.email or "sem e-mail")
                    log.warning("escola: e-mail ainda não liberado")
                    self._changed()
                    return
                self._up_inicio_ms = self.client.now_server_ms()
                if self.prefs.school_uid:
                    # Reservas antes dos streams dos PCs: sem elas o up/ de um
                    # PC não sabe de quem é e espera.
                    self.aulas = AulaLocks(self.client.fb, self.client.teacher_uid, school_store_key(key),
                                           self.client.now_server_ms)
                    self.aulas.on_change = self._reservas_mudaram
                    self.aulas.start()
                self.client.start_streams()
                self.error = None
            except Exception as error:  # noqa: BLE001
                self.error = SEM_INTERNET_CONECTAR
                log.warning("não foi possível conectar: %s", error)
                self._changed()
                return
            if self.prefs.school_uid:
                self.sync = SchoolSync(school_store_key(key), self.client.now_server_ms, self._read_store, self._write_store)
                self.sync.on_remote = self._store_changed_remotely
                self.sync.start(self.client.fb)
            self._seed_from_cloud()
            self._start_renovacao()
        self.carregar_menu()
        self._changed()

    def _seed_from_cloud(self):
        """Depois de um login novo os arquivos locais não existem: a página
        inicial publicada e o papel de parede vigente vêm do banco, senão a
        primeira edição publicaria um padrão por cima do que a escola tinha."""
        if not self.home.file.exists():
            try:
                published = self.client.fb.get("/home/escola")
                if isinstance(published, dict) and isinstance(published.get("cfg"), str):
                    self.home.replace(json.loads(published["cfg"]))
            except (FirebaseError, ValueError) as error:
                log.warning("página inicial publicada indisponível: %s", error)
        if not self.wallpaper.file.exists():
            try:
                hash_hex = self.client.fb.get(f"/wallpapers/{self.client.owner_uid}/hash")
                if isinstance(hash_hex, str) and hash_hex:
                    self.wallpaper.set(hash_hex)
            except FirebaseError:
                pass

    def stop(self):
        stop_event = self._renova_stop
        self._renova_stop = None
        if stop_event is not None:
            stop_event.set()
        try:
            self.fechar_grade()
        except Exception as error:  # noqa: BLE001 - sair nunca trava
            log.warning("fechar a grade ao sair: %s", error)
        with self._turma_lock:
            timers, self._timers = self._timers, []
        for timer in timers:
            timer.cancel()
        with self._lock:
            if self.aulas is not None:
                self.aulas.stop()
                self.aulas = None
            if self.sync is not None:
                self.sync.stop()
                self.sync = None
            if self.client is not None:
                self.client.stop()
                self.client = None

    def restart(self):
        self.stop()
        self.start()

    def _changed(self):
        if self.on_change is not None:
            self.on_change()

    @property
    def connected(self) -> bool:
        return self.client is not None and self.client.fb is not None and self.error is None

    @property
    def signed_in(self) -> bool:
        """Trocar de conta continua possível com o e-mail ainda não liberado."""
        return self.client is not None and self.client.fb is not None and (self.error is None or self.not_allowed)

    def _read_store(self, name: str):
        return JsonFile(self.dir / name).read_text()

    def _write_store(self, name: str, text: str):
        JsonFile(self.dir / name).write_text(text)

    def _store_changed_remotely(self, kind: str):
        {"rules": self.rules, "units": self.units, "names": self.names, "prova": self.prova_store}[kind].reload()
        if kind == "rules":
            self._redistribute_remote_rules()
        elif kind == "prova":
            self._redistribuir_prova()
        self._changed()

    def now_ms(self) -> int:
        return self.client.now_server_ms() if self.client else int(time.time() * 1000)

    # ---- estado por PC ------------------------------------------------------------

    def next_rev(self) -> int:
        with self._lock:
            now = self.client.now_server_ms() if self.client else 0
            self._last_rev = now if now > self._last_rev else self._last_rev + 1
            return self._last_rev

    def _set_rules_para(self, device_id: str) -> dict:
        """Bloqueios da escola menos as liberações deste PC; avisos todos."""
        return commands.set_rules(self.rules.rules, rev=self.next_rev(),
                                  liberados=self.aula.liberacoes_de(device_id), filtros=self.rules.filtros)

    def state_commands_for(self, device_id: str) -> list:
        # set_rules sempre, mesmo vazio, para limpar regras antigas no PC.
        result = [self._set_rules_para(device_id)]
        numero = self.units.get(device_id)
        if numero is not None:
            result.append(commands.set_unit(rev=self.next_rev(), numero=numero))
        if self.wallpaper.hash:
            result.append(commands.set_wallpaper(self.wallpaper.hash))
        return result

    def evaluate_alert(self, device_id: str, tabs: list):
        liberados = self.aula.liberacoes_de(device_id)
        for tab in tabs:
            rule = find_rule(self.rules.rules, tab.get("url", ""))
            if rule is not None and rule["pattern"] not in liberados:
                return urlsplit(tab.get("url", "")).hostname or rule["pattern"]
        return None

    def _session(self, device_id: str):
        return self.client.registry.by_id(device_id) if self.client else None

    def nome_do_pc(self, device_id: str) -> str:
        session = self._session(device_id)
        return self.names.get(device_id) or (session.label if session else "Computador")

    def _online(self, session) -> bool:
        return session is not None and session.online(self.now_ms())

    def pcs(self) -> list:
        if self.client is None:
            return []
        now = self.client.now_server_ms()
        alvo = set(self.alvo_turma())
        rows = []
        for session in self.client.registry.all:
            tab = session.active_tab or {}
            device_id = session.device_id
            rows.append({
                "id": device_id,
                "name": self.names.get(device_id) or session.label,
                "unit": self.units.get(device_id),
                "online": session.online(now),
                "tab_title": tab.get("title") or "",
                "tab_url": tab.get("url") or "",
                "alert": session.alert,
                "user": session.user,
                "travada": session.trava_vigente(now),
                "travada_sem_professor": self.travada_sem_professor(device_id),
                "em_prova": session.prova_vigente(now),
                "mao": self._mao_visivel(session, now),
                "nao_lidas": session.nao_lidas,
                "na_aula": device_id in alvo,
                "outro_professor": self.professor_que_travou(device_id),
                "suporta_turma": suporta_turma(session.ext_version),
            })
        rows.sort(key=lambda row: (row["unit"] is None, row["unit"] or 0, row["name"].lower()))
        return rows

    # ---- aula e alvo (SPEC-turma §1.5) --------------------------------------------

    @property
    def modo_escola(self) -> bool:
        return self.aulas is not None

    @property
    def aula_ativa(self) -> bool:
        """No modo isolado a aula é implícita: está sempre ativa."""
        return self.aula.ativa if self.modo_escola else self.client is not None

    def _ids(self) -> list:
        return [s.device_id for s in self.client.registry.all] if self.client else []

    def _travado_por_outro(self, device_id: str) -> bool:
        return self.aulas is not None and self.aulas.travado_por_outro(device_id)

    def professor_que_travou(self, device_id: str) -> str | None:
        """Professor da aula em que o PC está preso, ou None se é livre para mim."""
        if not self._travado_por_outro(device_id):
            return None
        return self.aulas.professor_de(device_id)

    def alvo_turma(self) -> list:
        if self.client is None:
            return []
        ids = self._ids()
        if not self.modo_escola:
            return alvo_de_turma(True, ids, self.client.registry.teacher_pc_id)
        presentes = set(ids)
        return alvo_de_turma(
            self.aula.ativa, [i for i in self.aula.pcs if i in presentes], self.client.registry.teacher_pc_id,
            modo_escola=True,
            reservados_por_mim={i for i in ids if self.aulas.travado_por_mim(i)},
            reservados_por_outros={i for i in ids if self.aulas.travado_por_outro(i)},
        )

    @property
    def motivo_sem_turma(self) -> str | None:
        """Texto quando um recurso de turma não tem alvo (None = tem)."""
        if self.client is None or not self.connected:
            return AINDA_CONECTANDO
        if not self.aula_ativa:
            return SEM_AULA
        if not self.alvo_turma():
            if self.modo_escola:
                return "Nenhum computador reservado nesta aula. Inclua computadores na aula."
            return "Nenhum computador conectado ainda."
        return None

    def pcs_livres(self) -> list:
        """PCs que podem entrar na minha aula (não reservados por outro). O
        telão nunca é alvo da turma: não aparece para escolher."""
        telao = self.client.registry.teacher_pc_id if self.client else None
        return [row for row in self.pcs() if row["outro_professor"] is None and row["id"] != telao]

    def comecar_aula(self, turma: str, device_ids) -> list:
        """Modo escola: reserva cada PC escolhido e começa a aula. Devolve as
        recusas ("Unidade 3 está na aula de Ana.")."""
        if self.aulas is None:
            return []
        recusas, reservados = [], []
        for device_id in device_ids:
            erro = self._reservar(device_id, turma)
            if erro:
                recusas.append(erro)
            else:
                reservados.append(device_id)
        self.aula.iniciar(turma, reservados)
        self._changed()
        return recusas

    def _reservar(self, device_id: str, turma: str) -> str | None:
        nome = self.nome_do_pc(device_id)
        try:
            dono = self.aulas.travar(device_id, self.prefs.teacher_name, turma)
        except FirebaseError as error:
            log.warning("reservar %s: %s", device_id, error)
            return f"{nome}: não foi possível reservar agora. Verifique a internet."
        return f"{nome} está na aula de {dono}." if dono else None

    def incluir_na_aula(self, device_id: str) -> str | None:
        """PC que entra na aula depois herda a trava e a prova vigentes."""
        if self.aulas is None or not self.aula.ativa:
            return SEM_AULA
        erro = self._reservar(device_id, self.aula.turma)
        if erro:
            return erro
        self.aula.incluir(device_id)
        # Entrou na aula; se a trava/prova vigente não gravou, o professor
        # precisa saber (o PC ficaria livre achando-se travado).
        erro = self._herdar_estado(device_id)
        self._changed()
        return erro

    def tirar_da_aula(self, device_id: str) -> str | None:
        """Saiu da aula: trava e prova daquele PC são desligadas. Se o on:false
        não gravou, o PC continua na aula (dá para tentar de novo)."""
        erro = self._desligar_estado_no_pc(device_id)
        if erro:
            return erro
        if self.aulas is not None:
            self.aulas.destravar(device_id)
        self.aula.tirar(device_id)
        self._changed()
        return None

    def _reservas_mudaram(self):
        # up/ guardado de PC que ficou livre (ou meu) é lido agora.
        if self.client is not None:
            self.client.reavaliar_up_ignorados()
        self._changed()

    def _start_renovacao(self):
        stop = threading.Event()
        self._renova_stop = stop

        def loop():
            while not stop.wait(protocol.RENOVACAO / 1000):
                try:
                    self.renovar()
                except Exception as error:  # noqa: BLE001 - o laço nunca morre
                    log.warning("renovação da turma: %s", error)

        threading.Thread(target=loop, name="professor-renovacao", daemon=True).start()

    def renovar(self):
        """A cada 5 min: heartbeat das reservas, prazo de trava e prova e o up/
        guardado de PC cuja reserva venceu pelo relógio."""
        if self.aulas is not None and self.aula.ativa:
            self.aulas.heartbeat()
        self._renovar_turma()
        if self.client is not None:
            self.client.reavaliar_up_ignorados()
        self._changed()

    # ---- pareamento ---------------------------------------------------------------

    def pair_code(self, raw: str, numero: int | None = None) -> str | None:
        qr = parse_qr_payload(raw)
        if qr is None:
            return "Código inválido. Cole o código mostrado na janela Controle de Aula do computador."
        if self.client is None or not self.connected:
            return "Sem conexão com o servidor."
        if numero is not None:
            self._assign_unit(qr["device_id"], numero)
        try:
            self.client.pair(qr, numero)
        except FirebaseError as error:
            log.warning("pareamento recusado: %s", error)
            return CODIGO_EXPIROU
        if qr["device_id"] in self.alvo_turma():
            self._herdar_estado(qr["device_id"])
        self._changed()
        return None

    @staticmethod
    def capture_qr_from_webcam() -> str | None:
        """Uma foto da webcam lida pelo zbar; None quando não há QR na foto."""
        try:
            photo = subprocess.run(
                ["fswebcam", "-q", "--no-banner", "-r", "1280x720", "-"],
                capture_output=True, check=True, timeout=WEBCAM_TIMEOUT_S,
            ).stdout
            decoded = subprocess.run(
                ["zbarimg", "-q", "--raw", "-Sdisable", "-Sqrcode.enable", "-"],
                input=photo, capture_output=True, timeout=WEBCAM_TIMEOUT_S,
            ).stdout
        except (OSError, subprocess.SubprocessError):
            return None
        text = decoded.decode("utf-8", "replace").strip()
        return text or None

    def forget(self, device_id: str):
        if self.client is not None:
            self.client.forget(device_id)
        self.units.remove(device_id)
        self.names.remove(device_id)
        self.aula.tirar(device_id)
        self._push("units")
        self._push("names")
        self._changed()

    def rename(self, device_id: str, name: str):
        name = (name or "").strip()
        if name:
            self.names.set(device_id, name)
        else:
            self.names.remove(device_id)
        self._push("names")
        self._changed()

    def set_unit(self, device_id: str, numero: int):
        self._assign_unit(device_id, numero)
        if self.client is not None and self.client.registry.by_id(device_id) is not None:
            self.client.set_state(device_id, commands.set_unit(rev=self.next_rev(), numero=numero))
        self._changed()

    def _assign_unit(self, device_id: str, numero: int):
        # Número já de outro PC: troca, como no celular.
        previous = self.units.owner_of(numero)
        mine = self.units.get(device_id)
        if previous is not None and previous != device_id:
            if mine is not None:
                self.units.set(previous, mine)
            else:
                self.units.remove(previous)
        self.units.set(device_id, numero)
        self._push("units")

    # ---- comandos com confirmação de entrega (SPEC-turma §6) ----------------------

    def open_url(self, url: str, device_id: str | None = None) -> str | None:
        return self._comando(lambda _id: commands.open_url(url), device_id)

    def close_all_tabs(self, device_id: str | None = None) -> str | None:
        return self._comando(lambda _id: commands.close_all_tabs(), device_id)

    def _comando(self, montar, device_id: str | None) -> str | None:
        if self.client is None:
            return AINDA_CONECTANDO
        if device_id is None:
            # "Abrir site na turma"/"Fechar abas da turma": o alvo da turma
            # (na escola, exige aula; nunca a escola inteira).
            sem = self.motivo_sem_turma
            if sem:
                return sem
            return self._enviar_com_entrega(self.alvo_turma(), montar)
        dono = self.professor_que_travou(device_id)
        if dono:
            return f"Está na aula de {dono}."
        return self._enviar_com_entrega([device_id], montar, um_pc=True)

    def _enviar_com_entrega(self, alvos, montar, um_pc: bool = False, tipo_comando: str | None = None) -> str | None:
        """Comando one-shot para `alvos` (um id por PC), acompanhado na faixa."""
        e = ent.Entrega(ent.COMANDO, tipo_comando=tipo_comando)
        envios = {}
        for device_id in alvos:
            session = self._session(device_id)
            if session is None:
                continue
            command = montar(device_id)
            envios[device_id] = command
            e.adicionar(device_id, self._online(session), suporta_turma(session.ext_version), cmd_id=command["id"])
        if not envios:
            return None
        self._nova_entrega(e, next(iter(envios)) if um_pc and len(envios) == 1 else None)
        falhou = None
        for device_id, command in envios.items():
            try:
                self.client.send(device_id, command)
            except FirebaseError as error:
                log.warning("envio para %s falhou: %s", device_id, error)
                with self._turma_lock:
                    p = e.pc(device_id)
                    p.estado, p.codigo = ent.ERRO, ERRO_ENVIO_LOCAL
                falhou = TEXTO_SEM_INTERNET
        self._changed()
        return falhou

    def _agendar(self, delay_s: float, fn):
        timer = threading.Timer(delay_s, fn)
        timer.daemon = True
        with self._turma_lock:
            self._timers = [t for t in self._timers if t.is_alive()] + [timer]
        timer.start()

    def _timer_de_entrega(self, e):
        def vence():
            with self._turma_lock:
                mudou = e.ao_tempo()
            if mudou:
                self._changed()
        self._agendar(e.timeout_ms / 1000 + 0.2, vence)

    def _nova_entrega(self, e, um_pc: str | None = None):
        with self._turma_lock:
            self.entrega, self.entrega_um_pc = e, um_pc
        self._timer_de_entrega(e)
        self._changed()

    def _nova_entrega_estado(self, e):
        with self._turma_lock:
            if e.tipo == ent.TRAVA:
                self.entrega_trava = e
            else:
                self.entrega_prova = e
        self._timer_de_entrega(e)

    def dispensar_entrega_de_estado(self, e):
        """A faixa de um desligar (trava ou prova) já resolvido some."""
        with self._turma_lock:
            if self.entrega_trava is e:
                self.entrega_trava = None
            if self.entrega_prova is e:
                self.entrega_prova = None
        self._changed()

    def dispensar_entrega(self):
        with self._turma_lock:
            self.entrega, self.entrega_um_pc = None, None
        self._changed()

    @property
    def texto_da_entrega(self) -> str | None:
        e = self.entrega
        if e is None:
            return None
        if self.entrega_um_pc is not None:
            session = self._session(self.entrega_um_pc)
            return ent.texto_entrega_um_pc(e, self.nome_do_pc(self.entrega_um_pc),
                                           ext=session.ext_version if session else None)
        return ent.texto_entrega(e)

    @property
    def texto_da_trava(self) -> str | None:
        e = self.entrega_trava
        if e is None:
            return None
        desde = self.aula.trava.get("desde") if self.aula.trava.get("on") else None
        return ent.texto_trava(e, desde_ms=desde if e.alvo_on else None)

    @property
    def texto_da_prova(self) -> str | None:
        return ent.texto_prova(self.entrega_prova) if self.entrega_prova is not None else None

    def detalhes_da_entrega(self, e) -> list:
        """Uma linha por PC ("Unidade 3 · Ana — Recebeu ✓"), na ordem da lista."""
        linhas = []
        for p in e.pcs if e is not None else []:
            session = self._session(p.device_id)
            nome = self.nome_do_pc(p.device_id)
            numero = self.units.get(p.device_id)
            prefixo = f"Unidade {numero} · " if numero is not None and nome != f"Unidade {numero}" else ""
            texto = f"{prefixo}{nome} — {ent.texto_do_pc(e, p, ext=session.ext_version if session else None)}"
            linhas.append(((numero is None, numero or 0, nome.lower()), texto))
        return [texto for _, texto in sorted(linhas)]

    def _ao_ack(self, device_id: str, ack: dict):
        with self._turma_lock:
            mudou = bool(self.entrega and self.entrega.ao_ack(device_id, ack["id"], ack["ok"], ack["error"]))
            mudou = self._atualizar_balao(device_id, ack["id"], ack["ok"], ack["error"]) or mudou
        if mudou:
            self._changed()

    def _ao_aplicado(self, device_id: str, aplicado: dict):
        mudou = False
        with self._turma_lock:
            for e in (self.entrega, self.entrega_trava, self.entrega_prova):
                if e is not None and e.ao_aplicado(device_id, aplicado):
                    mudou = True
            for ack in aplicado.get("acks") or []:
                if isinstance(ack, dict) and isinstance(ack.get("id"), str):
                    if self._atualizar_balao(device_id, ack["id"], ack.get("ok") is True, ack.get("error")):
                        mudou = True
        if mudou:
            self._changed()

    # ---- escritas de estado novas (falha macia: SPEC-turma §1.3) ------------------

    @staticmethod
    def _em_paralelo(fazer, ids) -> dict:
        """`fazer(id)` para cada PC, até PARALELO de cada vez. {id: resultado
        ou a exceção que ele levantou}."""
        ids = list(ids)

        def um(device_id):
            try:
                return device_id, fazer(device_id)
            except Exception as error:  # noqa: BLE001 - quem chamou decide
                return device_id, error

        if len(ids) <= 1:
            return dict(map(um, ids))
        with ThreadPoolExecutor(max_workers=min(PARALELO, len(ids)), thread_name_prefix="professor-turma") as pool:
            return dict(pool.map(um, ids))

    def _gravar_estados(self, por_pc: dict) -> str | None:
        """Grava state/lock|exam|monitor pelo caminho lateral, vários PCs ao
        mesmo tempo. None = tudo gravado; senão o texto ao professor (nunca
        sucesso falso)."""
        client = self.client
        if client is None:
            return AINDA_CONECTANDO
        erro, inesperado = None, None
        for device_id, resultado in self._em_paralelo(lambda i: client.set_state(i, por_pc[i]), por_pc).items():
            if isinstance(resultado, FirebaseError):
                log.warning("estado de turma em %s recusado: %s", device_id, resultado)
                if erro != TEXTO_SERVIDOR_DESATUALIZADO:
                    erro = texto_erro_de_escrita(resultado)
            elif isinstance(resultado, Exception) and inesperado is None:
                inesperado = resultado
        if inesperado is not None:
            raise inesperado
        return erro

    # ---- "Olhos em mim" (SPEC-turma §7) -------------------------------------------

    def tela_travada(self, device_id: str) -> bool:
        session = self._session(device_id)
        return session is not None and session.trava_vigente(self.now_ms())

    def travada_sem_professor(self, device_id: str) -> bool:
        """Na escola: tela travada sem reserva viva de ninguém — qualquer
        MEMBRO pode destravar."""
        return (self.aulas is not None and self.aulas.carregado and self.tela_travada(device_id)
                and self.aulas.trava_viva_de(device_id) is None)

    @property
    def trava_ligada(self) -> bool:
        return bool(self.aula.trava.get("on")) or any(self.tela_travada(i) for i in self.alvo_turma())

    def _set_lock_ligado(self, rev: int | None = None) -> dict:
        trava = self.aula.trava
        return commands.set_lock(rev=rev or self.next_rev(), on=True, texto=trava.get("texto", ""),
                                 mute=trava.get("mute", True), ate=self.now_ms() + protocol.TRAVA_ATE)

    def _set_lock_desligado(self, device_id: str, rev: int) -> dict:
        atual = self._session(device_id).trava if self._session(device_id) else None
        return commands.set_lock(rev=rev, on=False, texto=(atual or {}).get("texto") or protocol.TRAVA_TEXTO_PADRAO,
                                 mute=False, ate=self.now_ms())

    def _entrega_de_estado(self, tipo: str, alvos, alvo_on: bool, rev: int):
        e = ent.Entrega(tipo, alvo_on=alvo_on, rev_enviado=rev)
        for device_id in alvos:
            session = self._session(device_id)
            if session is not None:
                e.adicionar(device_id, self._online(session), suporta_turma(session.ext_version), comando_novo=True)
        self._nova_entrega_estado(e)

    def travar_turma(self, texto: str, mute: bool = True, apenas=None) -> str | None:
        """Trava as telas da aula (ou só `apenas`, "Escolher computadores").
        None = gravado (a faixa confirma PC a PC pelo relatório)."""
        sem = self.motivo_sem_turma
        if sem:
            return sem
        escolhidos = set(apenas) if apenas is not None else None
        alvos = [i for i in self.alvo_turma() if escolhidos is None or i in escolhidos]
        if not alvos:
            return "Escolha pelo menos um computador."
        texto = " ".join((texto or "").split())[: protocol.MAX_TRAVA_TEXTO] or protocol.TRAVA_TEXTO_PADRAO
        rev, ate = self.next_rev(), self.now_ms() + protocol.TRAVA_ATE
        erro = self._gravar_estados({
            i: commands.set_lock(rev=rev, on=True, texto=texto, mute=mute, ate=ate) for i in alvos
        })
        if erro:
            return erro
        self._entrega_de_estado(ent.TRAVA, alvos, True, rev)
        desde = self.aula.trava.get("desde") if self.aula.trava.get("on") and self.aula.trava.get("desde") \
            else int(time.time() * 1000)
        self.aula.definir_trava(True, rev=rev, texto=texto, mute=mute, desde=desde)
        self._changed()
        return None

    def destravar_turma(self) -> str | None:
        """"Destravar": on:false a todo PC com a tela travada (menos os da aula
        de outro professor), com ou sem aula."""
        alvos = [s.device_id for s in self.client.registry.all
                 if (s.trava or {}).get("on") and not self._travado_por_outro(s.device_id)] if self.client else []
        return self._destravar(alvos)

    def destravar_pc(self, device_id: str) -> str | None:
        dono = self.professor_que_travou(device_id)
        if dono:
            return f"Está na aula de {dono}."
        return self._destravar([device_id], so_este=True)

    def _destravar(self, alvos, so_este: bool = False) -> str | None:
        if not alvos:
            if not so_este:
                self.aula.definir_trava(False)
            self._changed()
            return None
        rev = self.next_rev()
        erro = self._gravar_estados({i: self._set_lock_desligado(i, rev) for i in alvos})
        if erro:
            return erro
        self._entrega_de_estado(ent.TRAVA, alvos, False, rev)
        if not so_este or not any(i != alvos[0] and self.tela_travada(i) for i in self.alvo_turma()):
            self.aula.definir_trava(False)
        self._changed()
        return None

    # ---- Modo prova (SPEC-turma §8) -----------------------------------------------

    @property
    def sites_prova(self) -> list:
        return list(self.prova_store.padroes)

    def adicionar_site_prova(self, pattern: str) -> bool:
        ok = self.prova_store.adicionar(pattern)
        if ok:
            self._depois_de_editar_prova()
        return ok

    def adicionar_sites_prova_em_lote(self, text: str) -> int:
        added = self.prova_store.adicionar_em_lote((text or "").splitlines())
        if added:
            self._depois_de_editar_prova()
        return added

    def remover_site_prova(self, index: int):
        self.prova_store.remover(index)
        self._depois_de_editar_prova()

    def _depois_de_editar_prova(self):
        self._push("prova")
        # Editar com a prova ligada redistribui state/exam aos PCs da prova.
        self._redistribuir_prova()
        self._changed()

    def prova_no_pc(self, device_id: str) -> bool:
        session = self._session(device_id)
        return session is not None and session.prova_vigente(self.now_ms())

    @property
    def prova_ligada(self) -> bool:
        return bool(self.aula.prova.get("on")) or any(self.prova_no_pc(i) for i in self.alvo_turma())

    def pcs_sem_modo_prova(self) -> list:
        """PCs da aula que não entrariam em modo prova (versão antiga)."""
        rows = []
        for device_id in self.alvo_turma():
            session = self._session(device_id)
            if session is not None and not suporta_turma(session.ext_version):
                rows.append({"id": device_id, "name": self.nome_do_pc(device_id),
                             "celita": tem_celita(session.ext_version)})
        return rows

    def _set_exam_para(self, device_id: str, on: bool, rev: int) -> dict:
        allow = self.sites_prova + self.aula.prova_liberacoes_de(device_id)
        return commands.set_exam(rev=rev, on=on, allow=allow, inicio=self.home.config.get("url") or None,
                                 ate=self.now_ms() + protocol.PROVA_ATE)

    def ligar_prova(self) -> str | None:
        """1 toque: a aula toda. None = gravado."""
        sem = self.motivo_sem_turma
        if sem:
            return sem
        alvos = self.alvo_turma()
        rev = self.next_rev()
        erro = self._gravar_estados({i: self._set_exam_para(i, True, rev) for i in alvos})
        if erro:
            return erro
        self._entrega_de_estado(ent.PROVA, alvos, True, rev)
        self.aula.definir_prova(True, rev)
        self._changed()
        return None

    def desligar_prova(self) -> str | None:
        """Todo PC com a prova ligada, menos os da aula de outro professor."""
        alvos = [s.device_id for s in self.client.registry.all
                 if (s.prova or {}).get("on") and not self._travado_por_outro(s.device_id)] if self.client else []
        if alvos:
            rev = self.next_rev()
            erro = self._gravar_estados({i: self._set_exam_para(i, False, rev) for i in alvos})
            if erro:
                return erro
            self._entrega_de_estado(ent.PROVA, alvos, False, rev)
        self.aula.definir_prova(False)
        self._changed()
        return None

    def desligar_prova_pc(self, device_id: str) -> str | None:
        """"Sair do modo prova" de um PC só (como o "Destravar" da linha):
        serve também ao PC que ficou em prova fora de qualquer aula."""
        dono = self.professor_que_travou(device_id)
        if dono:
            return f"Está na aula de {dono}."
        if self._session(device_id) is None:
            return AINDA_CONECTANDO
        rev = self.next_rev()
        erro = self._gravar_estados({device_id: self._set_exam_para(device_id, False, rev)})
        if erro:
            return erro
        self._entrega_de_estado(ent.PROVA, [device_id], False, rev)
        if not any(i != device_id and self.prova_no_pc(i) for i in self.alvo_turma()):
            self.aula.definir_prova(False)
        self._changed()
        return None

    def atualizar_pcs(self, device_ids) -> str | None:
        """"Atualizar agora" (só Celita): o PC roda a verificação na hora."""
        celitas = [i for i in device_ids if self._session(i) and tem_celita(self._session(i).ext_version)]
        return self._enviar_com_entrega(celitas, lambda _id: commands.atualizar(), tipo_comando=protocol.ATUALIZAR)

    def _redistribuir_prova(self):
        if not self.aula.prova.get("on") or self.client is None:
            return
        alvos = [i for i in self.alvo_turma() if self.prova_no_pc(i)]
        if not alvos:
            return
        rev = self.next_rev()
        erro = self._gravar_estados({i: self._set_exam_para(i, True, rev) for i in alvos})
        if erro:
            log.warning("redistribuir a prova: %s", erro)

    # ---- renovação, herança e desligamento ----------------------------------------

    def _renovar_turma(self):
        """Renova `ate` da trava (+20 min) e da prova (+2 h) nos PCs da aula
        que ainda estão com o estado vigente: professor que some deixa a
        turma travada no máximo 20 min."""
        if self.client is None:
            return
        alvo = self.alvo_turma()
        if self.aula.trava.get("on"):
            ids = [i for i in alvo if self.tela_travada(i)]
            if not ids and (self.entrega_trava is None or self.entrega_trava.resolvida):
                self.aula.definir_trava(False)  # venceu sozinha
            elif ids:
                rev = self.next_rev()
                erro = self._gravar_estados({i: self._set_lock_ligado(rev) for i in ids})
                if erro:
                    log.warning("renovar a trava: %s", erro)
        if self.aula.prova.get("on"):
            ids = [i for i in alvo if self.prova_no_pc(i)]
            if not ids and (self.entrega_prova is None or self.entrega_prova.resolvida):
                self.aula.definir_prova(False)
            elif ids:
                rev = self.next_rev()
                erro = self._gravar_estados({i: self._set_exam_para(i, True, rev) for i in ids})
                if erro:
                    log.warning("renovar a prova: %s", erro)

    @staticmethod
    def _pior_erro(erros) -> str | None:
        erros = [e for e in erros if e]
        return TEXTO_SERVIDOR_DESATUALIZADO if TEXTO_SERVIDOR_DESATUALIZADO in erros else next(iter(erros), None)

    def _herdar_estado(self, device_id: str) -> str | None:
        """PC que entra na aula depois herda a trava e a prova vigentes."""
        if self.client is None or device_id == self.client.registry.teacher_pc_id:
            return None
        por_pc = []
        if self.aula.trava.get("on"):
            por_pc.append(self._set_lock_ligado())
        if self.aula.prova.get("on"):
            por_pc.append(self._set_exam_para(device_id, True, self.next_rev()))
        erros = []
        for command in por_pc:
            erro = self._gravar_estados({device_id: command})
            if erro:
                log.warning("herdar estado em %s: %s", device_id, erro)
                erros.append(erro)
        return self._pior_erro(erros)

    def _desligar_estado_no_pc(self, device_id: str, na_aula: bool = True) -> str | None:
        """on:false da trava/prova ligadas neste PC. O estado decifrado pode
        ainda não ter voltado pelo stream (acabou de herdar): a da aula vale."""
        session = self._session(device_id)
        if session is None or self._travado_por_outro(device_id):
            return None
        rev = self.next_rev()
        erros = []
        if (session.trava or {}).get("on") or (na_aula and self.aula.trava.get("on")):
            erros.append(self._gravar_estados({device_id: self._set_lock_desligado(device_id, rev)}))
        if (session.prova or {}).get("on") or (na_aula and self.aula.prova.get("on")):
            erros.append(self._gravar_estados({device_id: self._set_exam_para(device_id, False, rev)}))
        return self._pior_erro(erros)

    def _desligar_trava_e_prova_de_todos(self) -> str | None:
        """"Encerrar aula": on:false a todo PC com o estado ligado (inclusive
        sem aluno), menos os da aula de outro professor."""
        if self.client is None:
            return None
        rev = self.next_rev()
        da_aula = set(self.alvo_turma())
        trava_da_aula, prova_da_aula = self.aula.trava.get("on"), self.aula.prova.get("on")
        por_pc_trava, por_pc_prova = {}, {}
        for session in self.client.registry.all:
            if self._travado_por_outro(session.device_id):
                continue
            na_aula = session.device_id in da_aula
            if (session.trava or {}).get("on") or (na_aula and trava_da_aula):
                por_pc_trava[session.device_id] = self._set_lock_desligado(session.device_id, rev)
            if (session.prova or {}).get("on") or (na_aula and prova_da_aula):
                por_pc_prova[session.device_id] = self._set_exam_para(session.device_id, False, rev)
        # As duas gravações sempre: um on:false de trava que falhou não pode
        # deixar a turma inteira presa no modo prova depois da aula.
        erro = self._pior_erro([self._gravar_estados(por_pc_trava), self._gravar_estados(por_pc_prova)])
        with self._turma_lock:
            self.entrega_trava = self.entrega_prova = None
        return erro

    def encerrar_aula(self) -> str | None:
        """Nesta ordem (SPEC-turma §14.B.3): estado → grade →
        close_all_tabs{fimDeAula} → up/ → regras → reservas → Recados."""
        if self.client is None:
            return AINDA_CONECTANDO
        alvo = self.alvo_turma()
        erro = self._desligar_trava_e_prova_de_todos()
        self.fechar_grade()
        self._enviar_com_entrega(alvo, lambda _id: commands.close_all_tabs(close_windows=True, fim_de_aula=True))
        self._limpar_recados_de(alvo)
        com_excecao = list(self.aula.liberacoes)
        self.aula.encerrar(manter_ativa=not self.modo_escola)
        for device_id in com_excecao:
            if self._session(device_id) is None or self._travado_por_outro(device_id):
                continue
            try:
                self.client.set_state(device_id, self._set_rules_para(device_id))
            except FirebaseError as error:
                log.warning("regras de %s depois da aula: %s", device_id, error)
        if self.aulas is not None:
            self.aulas.destravar_todas()
        self._changed()
        return erro

    # ---- regras -------------------------------------------------------------------

    def add_rule(self, pattern: str, action: str) -> bool:
        if not self.rules.add(pattern, action):
            return False
        self._rules_changed()
        return True

    def add_rules_bulk(self, text: str, action: str) -> int:
        added = self.rules.add_many((text or "").splitlines(), action)
        if added:
            self._rules_changed()
        return added

    def update_rule(self, index: int, pattern: str, action: str) -> bool:
        if not self.rules.update(index, pattern, action):
            return False
        self._rules_changed()
        return True

    def remove_rule(self, index: int):
        self.rules.remove(index)
        self._rules_changed()

    def _rules_changed(self):
        self._distribute_rules()
        self._push("rules")
        self._changed()

    def _distribute_rules(self, targets=None):
        """Snapshot por PC (as liberações variam por PC). PCs presos na aula de
        OUTRO professor ficam de fora: o dono redistribui os dele."""
        if self.client is None or not self.connected:
            return
        if targets is None:
            targets = [i for i in self._ids() if not self._travado_por_outro(i)]
        for device_id in targets:
            if device_id == self.client.registry.teacher_pc_id:
                continue
            try:
                self.client.set_state(device_id, self._set_rules_para(device_id))
            except FirebaseError as error:
                log.warning("regras não chegaram a %s: %s", device_id, error)

    def _redistribute_remote_rules(self):
        """Mudança vinda de outro aparelho: reenviar a todos derrubaria as
        liberações dos outros professores. Só os PCs meus."""
        if self.client is None:
            return
        ids = self._ids()
        meus = {i for i in ids if (self.aulas is not None and self.aulas.travado_por_mim(i))
                or self.aula.liberacoes_de(i)}
        outros = {i for i in ids if self._travado_por_outro(i)}
        self._distribute_rules(alvo_de_regras_remotas(ids, meus, outros))

    def _push(self, kind: str):
        if self.sync is not None:
            self.sync.schedule_push(kind)

    # ---- liberação por PC ---------------------------------------------------------

    def liberacoes_de(self, device_id: str) -> set:
        return self.aula.liberacoes_de(device_id)

    def liberar_para(self, device_id: str, pattern: str) -> str | None:
        dono = self.professor_que_travou(device_id)
        if dono:
            return f"Está na aula de {dono}."
        self.aula.liberar(device_id, pattern)
        try:
            self.client.set_state(device_id, self._set_rules_para(device_id))
        except FirebaseError as error:
            log.warning("liberar %s em %s: %s", pattern, device_id, error)
            return TEXTO_SEM_INTERNET
        self._changed()
        return None

    # ---- papel de parede ----------------------------------------------------------

    def set_wallpaper(self, jpeg: bytes):
        if self.client is None or not self.connected:
            raise FirebaseError("sem_conexao")
        hash_hex = self.client.publish_wallpaper(jpeg)
        self.wallpaper.set(hash_hex)
        # Toda a escola, menos o telão e os PCs presos na aula de outro
        # professor (SPEC-turma §1.5: PC reservado por outro nunca é alvo meu).
        ids = self._ids()
        self.client.set_state_all(commands.set_wallpaper(hash_hex), alvo_de_broadcast(
            False, [], ids, self.client.registry.teacher_pc_id, {i for i in ids if self._travado_por_outro(i)}))
        self._changed()

    # ---- página inicial e apps fixados --------------------------------------------

    def publish_home(self) -> str | None:
        if self.client is None or not self.connected:
            self.home_error = "Sem conexão: a página inicial será publicada quando o app conectar."
        elif not self.email:
            self.home_error = "Entre com a conta Google (em Ajustes) para publicar a página inicial."
        else:
            try:
                # PATCH: preserva as outras chaves de /home/escola (SPEC-turma §9.4).
                self.client.fb.patch("/home/escola", home_rules.publish_payload(self.home.config, self.client.now_server_ms()))
                self.home_error = None
            except FirebaseError as error:
                log.warning("publicação da página inicial recusada: %s", error)
                self.home_error = PUBLICACAO_FALHOU
        self._changed()
        return self.home_error

    def carregar_menu(self):
        """Lê /home/menu. Sem a leitura, o editor fica bloqueado: editar uma
        lista vazia apagaria a da escola."""
        if self.client is None or not self.connected:
            return
        try:
            self.menu_ids = home_rules.ids_publicados(self.client.fb.side_get("/home/menu"))
            self.menu_carregado = True
            self.menu_error = None
        except FirebaseError as error:
            log.warning("apps fixados indisponíveis: %s", error)
            self.menu_error = ("Não foi possível ler os apps fixados agora." if not negado(error)
                               else TEXTO_SERVIDOR_DESATUALIZADO)
        self._changed()

    def definir_menu(self, ids) -> str | None:
        """Publica a lista de apps fixados no menu dos alunos (≤ 24)."""
        ids = list(ids)
        if len(ids) > home_rules.MAX_FIXADOS:
            return home_rules.LIMITE_FIXADOS
        if not self.school_active:
            return FIXADOS_SO_ESCOLA
        if self.client is None or not self.connected:
            return TEXTO_SEM_INTERNET
        if not self.menu_carregado:
            # Sem a lista da escola, publicar apagaria o que já está lá.
            return self.menu_error or "Aguarde a lista da escola carregar e tente de novo."
        try:
            payload = home_rules.menu_payload(ids, self.client.now_server_ms())
        except ValueError:
            return "Este app não pode ser fixado."
        try:
            self.client.fb.side_request("PUT", "/home/menu", payload)
        except FirebaseError as error:
            log.warning("apps fixados recusados: %s", error)
            return texto_erro_de_escrita(error)
        self.menu_ids = ids
        self._changed()
        return None

    # ---- conversas (SPEC-turma §3.6) ----------------------------------------------

    def conversa_de(self, device_id: str) -> list:
        session = self._session(device_id)
        with self._turma_lock:
            return list(session.chat) if session else []

    def nao_lidas_de(self, device_id: str) -> int:
        session = self._session(device_id)
        return session.nao_lidas if session else 0

    def abrir_conversa(self, device_id: str):
        """Abrir zera as não lidas e baixa a mão (apaga o up/)."""
        session = self._session(device_id)
        if session is None:
            return
        session.nao_lidas = 0
        self._changed()
        if session.mao_mids or session.mao_em is not None:
            self.baixar_mao(device_id)

    def marcar_conversa_lida(self, device_id: str):
        session = self._session(device_id)
        if session is not None and session.nao_lidas:
            session.nao_lidas = 0
            self._changed()

    @staticmethod
    def _validar_texto_chat(texto: str) -> str | None:
        texto = (texto or "").strip()
        if not texto:
            return "Escreva a mensagem."
        if len(texto) > protocol.MAX_CHAT_TEXTO:
            return f"Mensagem muito longa (máx. {protocol.MAX_CHAT_TEXTO} letras)."
        return None

    def enviar_chat(self, device_id: str, texto: str) -> str | None:
        """"Conversar": manda ao aluno do PC. PC antigo recebe como aviso
        (show_message) e o balão diz que ele não consegue responder."""
        erro = self._validar_texto_chat(texto)
        if erro:
            return erro
        dono = self.professor_que_travou(device_id)
        if dono:
            return f"Está na aula de {dono}."
        return self._enviar_chat_para(device_id, texto.strip(), para_turma=False)

    def enviar_mensagem_para_turma(self, texto: str) -> str | None:
        """Um chat_message para cada PC da aula: cada aluno responde na própria
        conversa. A faixa acompanha a entrega."""
        erro = self._validar_texto_chat(texto)
        if erro:
            return erro
        sem = self.motivo_sem_turma
        if sem:
            return sem
        e = ent.Entrega(ent.COMANDO, tipo_comando=protocol.CHAT_MESSAGE)
        envios = [p for p in (self._preparar_chat(i, texto.strip(), True, e) for i in self.alvo_turma()) if p]
        if not envios:
            return AINDA_CONECTANDO
        # A faixa nasce com todos os PCs: publicada vazia, ela "resolveria"
        # com 0 e sumiria no meio da entrega.
        self._nova_entrega(e)
        # Em sequência: o push vai pelo caminho principal, onde um 401 renova
        # o token e reconecta os streams; em paralelo seriam vários de uma vez.
        falhou = None
        for envio in envios:
            falhou = self._mandar_chat(*envio, entrega=e) or falhou
        self._changed()
        return falhou

    def _enviar_chat_para(self, device_id: str, texto: str, para_turma: bool) -> str | None:
        preparado = self._preparar_chat(device_id, texto, para_turma)
        if preparado is None:
            return AINDA_CONECTANDO
        return self._mandar_chat(*preparado)

    def _preparar_chat(self, device_id: str, texto: str, para_turma: bool, entrega=None):
        """O balão entra na conversa (e o PC na faixa) antes de ir à rede.
        None = PC sem sessão."""
        session = self._session(device_id)
        if session is None or self.client is None:
            return None
        antigo = not suporta_turma(session.ext_version)
        mid = new_id()
        command = (commands.show_message("Mensagem do professor", texto, popup=True, sender=self.prefs.teacher_name)
                   if antigo else commands.chat_message(texto, self.prefs.teacher_name, mid))
        online = self._online(session)
        item = upr.ChatItem(mid, upr.PROFESSOR, texto, self.now_ms(), cmd_id=command["id"],
                            estado=upr.B_ENVIANDO if online else upr.B_AGUARDANDO,
                            para_turma=para_turma, versao_antiga=antigo)
        with self._turma_lock:
            self._anexar_chat(session, item)
            # O aviso para PC antigo é comando que ele entende: conta normal.
            if entrega is not None:
                entrega.adicionar(device_id, online, True, cmd_id=command["id"])
        return device_id, item, command

    def _mandar_chat(self, device_id: str, item, command: dict, entrega=None) -> str | None:
        if item.estado == upr.B_ENVIANDO:
            def sem_resposta():
                with self._turma_lock:
                    mudou = item.estado == upr.B_ENVIANDO
                    if mudou:
                        item.estado = upr.B_SEM_RESPOSTA
                if mudou:
                    self._changed()
            self._agendar(protocol.ENTREGA_TIMEOUT / 1000, sem_resposta)
        self._changed()
        client = self.client
        try:
            if client is None:
                raise FirebaseError("sem_conexao")
            client.send(device_id, command)
        except FirebaseError as error:
            log.warning("chat para %s falhou: %s", device_id, error)
            with self._turma_lock:
                item.estado, item.codigo_erro = upr.B_ERRO, ERRO_ENVIO_LOCAL
                if entrega is not None and entrega.pc(device_id):
                    entrega.pc(device_id).estado, entrega.pc(device_id).codigo = ent.ERRO, ERRO_ENVIO_LOCAL
            self._changed()
            return TEXTO_SEM_INTERNET
        return None

    def _atualizar_balao(self, device_id: str, cmd_id: str, ok: bool, error) -> bool:
        session = self._session(device_id)
        if session is None:
            return False
        for item in reversed(session.chat):
            if item.cmd_id != cmd_id:
                continue
            if ok:
                novo, codigo = upr.B_ENTREGUE, None
            elif error == "sem_sessao":
                novo, codigo = upr.B_NINGUEM, None
            else:
                novo, codigo = upr.B_ERRO, error or "executor_falhou"
            if item.estado == novo and item.codigo_erro == codigo:
                return False
            item.estado, item.codigo_erro = novo, codigo
            return True
        return False

    @staticmethod
    def _anexar_chat(session, item):
        if item.autor == upr.ALUNO and any(c.autor == upr.ALUNO and c.mid == item.mid for c in session.chat):
            return
        index = len(session.chat)
        while index > 0 and session.chat[index - 1].ts > item.ts:
            index -= 1
        session.chat.insert(index, item)
        del session.chat[: -protocol.CHAT_HISTORICO_THREAD]

    # ---- up/ e Recados (SPEC-turma §2.6, §4.4) ------------------------------------

    def _destino_do_up(self, device_id: str) -> str:
        if self.prefs.school_uid and (self.aulas is None or not self.aulas.carregado):
            return upr.IGNORAR  # ainda não se sabe de quem é: espera
        return upr.destino_do_up(
            self.aulas is not None,
            self.aulas is not None and self.aulas.travado_por_outro(device_id),
            self.aulas is not None and self.aulas.travado_por_mim(device_id),
        )

    def _mao_visivel(self, session, agora_ms: int) -> bool:
        return session.mao_em is not None and agora_ms - session.mao_em < protocol.MAO_VISIVEL

    def _ao_up(self, device_id: str, item: dict, ms: int, destino: str):
        session = self._session(device_id)
        if session is None:
            return
        nome = self.nome_do_pc(device_id)
        # Só toca para o que chegou ao vivo, e só para quem é dono.
        notificar = destino == upr.MOSTRAR_E_NOTIFICAR and ms >= self._up_inicio_ms
        aviso = None
        with self._turma_lock:
            if item["type"] == protocol.UP_CHAT:
                if any(c.autor == upr.ALUNO and c.mid == item["mid"] for c in session.chat):
                    return
                self._anexar_chat(session, upr.ChatItem(item["mid"], upr.ALUNO, item["texto"], ms))
                session.nao_lidas += 1
                aviso = ("chat", nome, item["texto"])
            elif item["type"] == protocol.UP_UNBLOCK:
                existente = next((p for p in session.pedidos if p.site == item["site"]), None)
                if existente is not None:
                    existente.juntar(item["mid"], item["url"], item["motivo"], item["bloqueio"], ms)
                else:
                    session.pedidos.append(upr.Pedido(device_id, item["mid"], item["site"], item["url"],
                                                      item["motivo"], item["bloqueio"], ms))
                aviso = ("pedido", "Pedido de liberação", f"{nome}: {item['site']}")
            else:
                agora = self.now_ms()
                ja = self._mao_visivel(session, agora)
                session.mao_mids.add(item["mid"])
                if session.mao_em is None or ms > session.mao_em:
                    session.mao_em = ms
                # A mão notifica só na transição para levantada.
                aviso = ("mao", "Mão levantada", nome) if not ja and self._mao_visivel(session, agora) else None
        if notificar and aviso and self.on_recado is not None:
            self.on_recado(*aviso, device_id)
        self._changed()

    def _ao_up_removido(self, device_id: str, mid: str):
        session = self._session(device_id)
        if session is None:
            return
        # Outro aparelho resolveu (ou o PC podou): sai de Recados. O chat fica.
        with self._turma_lock:
            for pedido in list(session.pedidos):
                pedido.mids.discard(mid)
                if not pedido.mids:
                    session.pedidos.remove(pedido)
            if mid in session.mao_mids:
                session.mao_mids.discard(mid)
                if not session.mao_mids:
                    session.mao_em = None
        self._changed()

    def _ao_up_silenciado(self, device_id: str):
        self._silenciados[device_id] = self.now_ms() + upr.DURACAO_SILENCIO_MS
        self._changed()

    def _pcs_dos_recados(self) -> list:
        """Todos, menos os da aula de outro professor."""
        if self.client is None:
            return []
        return [s for s in self.client.registry.all if not self._travado_por_outro(s.device_id)]

    def pedidos_pendentes(self) -> list:
        with self._turma_lock:
            pedidos = [p for s in self._pcs_dos_recados() for p in s.pedidos]
        return sorted(pedidos, key=lambda p: p.ts)

    def maos_levantadas(self) -> list:
        """PCs com a mão levantada há menos de 10 min (some sozinha)."""
        agora = self.now_ms()
        sessions = [s for s in self._pcs_dos_recados() if self._mao_visivel(s, agora)]
        return [{"id": s.device_id, "name": self.nome_do_pc(s.device_id), "ts": s.mao_em}
                for s in sorted(sessions, key=lambda s: s.mao_em)]

    def conversas(self) -> list:
        """PCs com conversa, a mais recente primeiro."""
        rows = []
        with self._turma_lock:
            for s in self._pcs_dos_recados():
                if s.chat:
                    ultima = s.chat[-1]
                    previa = ("Você: " if ultima.autor == upr.PROFESSOR else "") + ultima.texto
                    rows.append({"id": s.device_id, "name": self.nome_do_pc(s.device_id), "previa": previa,
                                 "ts": ultima.ts, "nao_lidas": s.nao_lidas})
        return sorted(rows, key=lambda r: r["ts"], reverse=True)

    def pcs_silenciados(self) -> list:
        agora = self.now_ms()
        return [{"id": i, "name": self.nome_do_pc(i)} for i, ate in list(self._silenciados.items())
                if ate > agora and not self._travado_por_outro(i)]

    @property
    def recados_count(self) -> int:
        """Pedidos + mãos + conversas com não lidas."""
        return len(self.pedidos_pendentes()) + len(self.maos_levantadas()) + \
            sum(1 for c in self.conversas() if c["nao_lidas"])

    def padroes_para_liberar(self, pedido) -> list:
        """Regras que "Liberar" tiraria deste PC (fora da prova). Mais de uma =
        confirmar "Liberar para {nome}: {p1}, {p2}?"."""
        ja = self.aula.liberacoes_de(pedido.device_id)
        return [p for p in padroes_que_casam(self.rules.rules, upr.url_para_casar(pedido.url, pedido.site))
                if p not in ja]

    def liberar_pedido(self, pedido, padroes=None) -> str | None:
        """Fora da prova tira as regras que casam a URL pedida (liberação deste
        PC); em prova acrescenta o site ao `allow` deste PC. Depois responde ao
        aluno e apaga o pedido. None = ok."""
        device_id = pedido.device_id
        dono = self.professor_que_travou(device_id)
        if dono:
            return f"Está na aula de {dono}."
        if self.client is None:
            return AINDA_CONECTANDO
        rules_rev = exam_rev = None
        if self.prova_no_pc(device_id):
            novo = self.aula.liberar_na_prova(device_id, pedido.site)
            rev = self.next_rev()
            erro = self._gravar_estados({device_id: self._set_exam_para(device_id, True, rev)})
            if erro:
                # O site não pode ser liberado depois, calado, pela renovação.
                if novo:
                    self.aula.revogar_na_prova(device_id, pedido.site)
                return erro
            exam_rev = rev
        else:
            lista = self.padroes_para_liberar(pedido) if padroes is None else list(padroes)
            if lista:
                novos = [p for p in lista if p not in self.aula.liberacoes_de(device_id)]
                for pattern in lista:
                    self.aula.liberar(device_id, pattern)
                command = self._set_rules_para(device_id)
                try:
                    self.client.set_state(device_id, command)
                except FirebaseError as error:
                    log.warning("liberar pedido: %s", error)
                    # Como na prova: não fica liberado escondido para a
                    # próxima redistribuição das regras.
                    for pattern in novos:
                        self.aula.revogar(device_id, pattern)
                    return TEXTO_SEM_INTERNET
                rules_rev = command["payload"]["rev"]
        erro = self._responder_pedido(device_id, commands.unblock_result(
            pedido.mid, pedido.site, True, rules_rev=rules_rev, exam_rev=exam_rev))
        if erro:
            return erro
        self._resolver_pedido(pedido)
        return None

    def recusar_pedido(self, pedido, motivo: str | None = None) -> str | None:
        dono = self.professor_que_travou(pedido.device_id)
        if dono:
            return f"Está na aula de {dono}."
        erro = self._responder_pedido(pedido.device_id, commands.unblock_result(
            pedido.mid, pedido.site, False, motivo=motivo))
        if erro:
            return erro
        self._resolver_pedido(pedido)
        return None

    def _responder_pedido(self, device_id: str, command: dict) -> str | None:
        """O pedido só sai de Recados se a resposta foi gravada."""
        if self.client is None:
            return AINDA_CONECTANDO
        try:
            self.client.send(device_id, command)
        except FirebaseError as error:
            log.warning("resposta do pedido: %s", error)
            return texto_erro_de_escrita(error)
        return None

    def _resolver_pedido(self, pedido):
        session = self._session(pedido.device_id)
        with self._turma_lock:
            if session is not None and pedido in session.pedidos:
                session.pedidos.remove(pedido)
        self._changed()
        for mid in list(pedido.mids):
            try:
                self.client.delete_up_mid(pedido.device_id, mid)
            except FirebaseError as error:
                log.warning("apagar pedido: %s", error)

    def baixar_mao(self, device_id: str):
        """"Baixar" (ou abrir a conversa): apaga o raise_hand do up/."""
        session = self._session(device_id)
        # PC na aula de outro professor: o up/ dele não é meu para apagar.
        if session is None or self._travado_por_outro(device_id):
            return
        with self._turma_lock:
            mids = list(session.mao_mids)
            session.mao_mids.clear()
            session.mao_em = None
        self._changed()
        for mid in mids:
            try:
                self.client.delete_up_mid(device_id, mid)
            except FirebaseError as error:
                log.warning("baixar mão: %s", error)

    def _limpar_recados_de(self, alvo):
        """Fim de aula: esquece conversa e recados do alvo e apaga o up/ dele
        (sem rede, o PC poda sozinho em 2 h)."""
        for device_id in alvo:
            session = self._session(device_id)
            if session is not None:
                with self._turma_lock:
                    session.chat.clear()
                    session.nao_lidas = 0
                    session.pedidos.clear()
                    session.mao_mids.clear()
                    session.mao_em = None
            self._silenciados.pop(device_id, None)
        self._changed()
        for device_id in alvo:
            try:
                self.client.delete_all_up(device_id)
            except FirebaseError as error:
                log.warning("apagar o up/ de %s: %s", device_id, error)

    # ---- grade de telas (SPEC-turma §5) -------------------------------------------

    @property
    def grade_aberta(self) -> bool:
        return self._grade_stop is not None

    def abrir_grade(self) -> str | None:
        """Renova state/monitor a cada 10 s (ate = agora + 30 s) nos PCs da
        aula e lê /thumbs de cada um enquanto a grade está visível."""
        sem = self.motivo_sem_turma
        if sem:
            return sem
        if self._grade_stop is not None:
            return None
        stop = threading.Event()
        self._grade_stop = stop
        self.grade_aberta_em = self.now_ms()
        self.erro_grade = None

        def loop():
            while not stop.is_set():
                inicio = time.monotonic()
                try:
                    self._renovar_grade(stop)
                except Exception as error:  # noqa: BLE001 - o laço nunca morre
                    log.warning("grade: %s", error)
                # 10 s de início a início: o tempo da rede não se soma à
                # espera (o PC para 30 s depois da última renovação).
                stop.wait(max(0.5, protocol.MONITOR_RENOVA / 1000 - (time.monotonic() - inicio)))

        threading.Thread(target=loop, name="professor-grade", daemon=True).start()
        self._changed()
        return None

    def _renovar_grade(self, stop):
        alvos = self.alvo_turma()
        for device_id in self._grade_pcs - set(alvos):
            self._parar_monitor_em(device_id)  # saiu da aula ou é de outro
        if stop.is_set():
            return
        self._grade_pcs |= set(alvos)
        rev, ate = self.next_rev(), self.now_ms() + protocol.MONITOR_ATE
        erro = self._gravar_estados({i: commands.set_monitor(rev, ate) for i in alvos})
        if stop.is_set():
            # A grade fechou enquanto gravava: o monitor recém-gravado não
            # pode ficar valendo (o PC capturaria por mais 30 s). Se ela já
            # reabriu, a renovação nova é que vale.
            if self._grade_stop is None:
                self._parar_monitores(alvos)
            return
        if erro != self.erro_grade:
            self.erro_grade = erro
            self._changed()
        # A primeira captura do PC leva um instante: lê logo depois.
        if stop.wait(3):
            return
        client = self.client
        if client is None:
            return
        lidas = self._em_paralelo(client.read_thumb, [i for i in alvos if self._session(i) is not None])
        if stop.is_set():
            return
        mudou = False
        for device_id, thumb in lidas.items():
            session = self._session(device_id)
            if session is None:
                continue
            if isinstance(thumb, Exception):
                log.info("miniatura de %s: %s", device_id, thumb)
                continue
            if thumb != session.thumb:
                session.thumb = thumb
                mudou = True
        if mudou or alvos:
            self._changed()

    def _parar_monitor_em(self, device_id: str):
        self._grade_pcs.discard(device_id)
        session = self._session(device_id)
        if session is not None:
            session.thumb = None
        # PC que passou para a aula de outro professor: o nosso state/monitor
        # vence sozinho em ≤ 30 s.
        if self.client is None or self._travado_por_outro(device_id):
            return
        for apagar in (lambda: self.client.clear_state(device_id, "monitor"),
                       lambda: self.client.delete_thumb(device_id)):
            try:
                apagar()
            except FirebaseError as error:
                log.info("fechar a grade em %s: %s", device_id, error)

    def _parar_monitores(self, ids):
        for device_id, resultado in self._em_paralelo(self._parar_monitor_em, ids).items():
            if isinstance(resultado, Exception):
                log.warning("fechar a grade em %s: %s", device_id, resultado)

    def fechar_grade(self):
        """Ao esconder a grade: para a renovação e apaga state/monitor e as
        miniaturas — o PC para de capturar."""
        stop, self._grade_stop = self._grade_stop, None
        tinha = stop is not None or bool(self._grade_pcs)
        if stop is not None:
            stop.set()
        self.grade_aberta_em = None
        self.erro_grade = None
        self._parar_monitores(list(self._grade_pcs))
        if tinha:
            self._changed()

    def quadros(self) -> list:
        """Um quadro por PC da aula: nome, ponto online, estado e a imagem."""
        agora = self.now_ms()
        rows = []
        for device_id in self.alvo_turma():
            session = self._session(device_id)
            if session is None:
                continue
            online = self._online(session)
            estado = estado_do_quadro(online, suporta_turma(session.ext_version), session.thumb,
                                      self.grade_aberta_em, agora)
            rows.append({"id": device_id, "name": self.nome_do_pc(device_id), "unit": self.units.get(device_id),
                         "online": online, "estado": estado,
                         "jpeg": (session.thumb or {}).get("jpeg") if estado.tem_imagem else None,
                         "sem_prova": self.aula.prova.get("on") and not suporta_turma(session.ext_version)})
        rows.sort(key=lambda r: (r["unit"] is None, r["unit"] or 0, r["name"].lower()))
        return rows

    # ---- conta Google e escola -----------------------------------------------------

    @property
    def google_available(self) -> bool:
        return bool(self.config.get("googleClientId"))

    @property
    def email(self) -> str | None:
        saved = self.auth.load() or {}
        value = saved.get("email")
        return value if isinstance(value, str) and value else None

    def login_google(self) -> str | None:
        if not self.google_available:
            return "Conta Google não configurada neste pacote."
        if not self.signed_in:
            return "Sem conexão com o servidor."
        try:
            id_token = self._login_factory().run()
            result = self.client.fb.sign_in_with_idp("google.com", id_token)
        except TimeoutError:
            return "Login cancelado."
        except (OSError, ValueError, FirebaseError) as error:
            log.warning("login Google falhou: %s", error)
            return GOOGLE_FALHOU
        self.auth.save({"email": result.get("email") or ""})
        if result.get("switched") or self.not_allowed:
            # A conta Google já era de outro aparelho: o app agora é aquele
            # professor, e o roster é o dele.
            self.restart()
        else:
            self._changed()
        return None

    # ---- login entregue pelo celular ----------------------------------------------

    def begin_phone_login(self, on_done) -> str | None:
        """Abre um canal e devolve o texto do QR; `on_done(error)` é chamado de
        outra thread quando o celular responder (None = entrou)."""
        if not self.signed_in:
            return None
        self.cancel_phone_login()
        handoff = LoginHandoff()
        self._handoff = handoff
        self._handoff_stream = self.client.fb.stream(handoff.path, lambda event: self._on_handoff(handoff, event, on_done))
        return handoff.qr_payload()

    def cancel_phone_login(self):
        stream, self._handoff_stream = getattr(self, "_handoff_stream", None), None
        self._handoff = None
        if stream is not None:
            stream.close()

    def _on_handoff(self, handoff, event: dict, on_done):
        if event.get("path") != "/" or getattr(self, "_handoff", None) is not handoff:
            return
        delivered = handoff.open(event.get("data"))
        if delivered is None:
            return
        self.cancel_phone_login()
        on_done(self._finish_phone_login(handoff, delivered))

    def _finish_phone_login(self, handoff, delivered: dict) -> str | None:
        try:
            result = self.client.fb.sign_in_with_idp("google.com", delivered["idToken"], link=False)
        except FirebaseError as error:
            log.warning("login pelo celular recusado: %s", error)
            return CELULAR_FALHOU
        try:
            self.client.fb.delete(handoff.path)
        except FirebaseError:
            pass
        self.auth.save({"email": result.get("email") or ""})
        try:
            self.keys.adopt(delivered["keys"])
        except (ValueError, TypeError):
            return "A chave recebida do celular é inválida."
        if delivered["teacherName"]:
            self.prefs.set_teacher_name(delivered["teacherName"])
        self.prefs.set_school_uid(delivered["schoolUid"])
        self.restart()
        return None

    @property
    def school_active(self) -> bool:
        return bool(self.prefs.school_uid)

    def join_school(self) -> str | None:
        if self.client is None or not self.connected:
            return "Sem conexão com o servidor."
        if not self.email:
            return "Entre com a conta Google primeiro."
        school_keys = SchoolKeys(self.client.fb)
        try:
            school_uid = school_keys.school_uid()
            if school_uid is None:
                return "A escola ainda não foi criada — peça ao professor fundador."
            if not school_keys.is_member(school_uid, self.email):
                return NOT_ALLOWED.format(email=self.email)
            school = school_keys.download()
        except FirebaseError as error:
            log.warning("ler a escola falhou: %s", error)
            return ESCOLA_LER_FALHOU
        if school is None:
            return "A escola ainda não foi criada — peça ao professor fundador."
        if self.keys.raw() != school["keys"]:
            self.keys.adopt(school["keys"])
        self.prefs.set_school_uid(school["schoolUid"])
        self.restart()
        return None

    def create_school(self) -> str | None:
        if self.client is None or not self.connected:
            return "Sem conexão com o servidor."
        if not self.email:
            return "Entre com a conta Google primeiro."
        uid = self.client.teacher_uid
        try:
            error = SchoolKeys(self.client.fb).publish(uid, self.keys.raw())
            if error:
                return error
            roster = self.client.fb.get(f"/teachers/{uid}/devices")
            if isinstance(roster, dict) and roster:
                self.client.fb.patch("/school/devices", {k: True for k in roster})
        except FirebaseError as error:
            log.warning("criar a escola falhou: %s", error)
            return ESCOLA_CRIAR_FALHOU
        self.prefs.set_school_uid(uid)
        self.restart()
        if self.sync is not None:
            self.sync.push_all()
        return None

    def set_teacher_name(self, name: str):
        self.prefs.set_teacher_name(name)
        if self.client is not None:
            self.client.teacher_name = self.prefs.teacher_name
        self._changed()

    @staticmethod
    def load_config(path: str | None = None) -> dict:
        path = path or os.environ.get("CONTROLE_DE_AULA_CONFIG") or "/usr/share/controle-de-aula/firebase.json"
        with open(path, encoding="utf-8") as handle:
            return json.load(handle)
