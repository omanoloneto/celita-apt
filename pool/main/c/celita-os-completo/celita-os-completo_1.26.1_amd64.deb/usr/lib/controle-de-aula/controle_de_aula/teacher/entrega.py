"""Confirmação de entrega (item 26): agrega, por PC, o que aconteceu com um
comando de turma ou com uma mudança de estado (trava, prova) e monta os
textos da faixa. Puro; espelho de `lib/src/cloud/entrega.dart` (SPEC-turma §6).

Regra de ouro: o professor nunca vê "recebeu ✓" por suposição. A fonte é o
ack do id emitido ou o `aplicado` do relatório do PC.
"""

import time

from .. import protocol
from .textos_erro import TEXTO_TIMEOUT, texto_erro

ENVIANDO = "enviando"
RECEBEU = "recebeu"
ERRO = "erro"
DESLIGADO = "desligado"
SEM_RESPOSTA = "semResposta"
VERSAO_ANTIGA = "versaoAntiga"

COMANDO = "comando"
TRAVA = "trava"
PROVA = "prova"


class EntregaPc:
    def __init__(self, device_id: str, estado: str, cmd_id: str | None = None):
        self.device_id = device_id
        self.estado = estado
        # Id do comando emitido para este PC (comando one-shot); None em estado.
        self.cmd_id = cmd_id
        # Código do erro (ack ou `aplicado.*.erro`) quando o estado é erro.
        self.codigo = None


class Entrega:
    def __init__(self, tipo: str = COMANDO, enviado_em_ms: int | None = None, tipo_comando: str | None = None,
                 alvo_on: bool = True, rev_enviado: int = 0, timeout_ms: int = protocol.ENTREGA_TIMEOUT):
        self.tipo = tipo
        self.enviado_em_ms = int(time.time() * 1000) if enviado_em_ms is None else enviado_em_ms
        # `type` do comando (só para o texto de `tipo_desconhecido`).
        self.tipo_comando = tipo_comando
        # Trava/prova: o estado pedido e o `rev` da escrita que mudou on/off
        # (renovações não reiniciam a contagem).
        self.alvo_on = alvo_on
        self.rev_enviado = rev_enviado
        self.timeout_ms = timeout_ms
        self._pcs = {}

    @property
    def pcs(self) -> list:
        return list(self._pcs.values())

    def pc(self, device_id: str):
        return self._pcs.get(device_id)

    def adicionar(self, device_id: str, online: bool, suporta_turma: bool, cmd_id: str | None = None,
                  comando_novo: bool = False):
        """Offline no envio começa "desligado"; PC que não entende recurso novo
        começa "versão antiga"."""
        if comando_novo and not suporta_turma:
            estado = VERSAO_ANTIGA
        elif not online:
            estado = DESLIGADO
        else:
            estado = ENVIANDO
        self._pcs[device_id] = EntregaPc(device_id, estado, cmd_id)

    def ao_ack(self, device_id: str, command_id: str, ok: bool, error: str | None = None) -> bool:
        """Ack tardio SEMPRE corrige (depois do timeout, de "desligado", de
        "versão antiga"). True = mudou algo."""
        p = self._pcs.get(device_id)
        if p is None or p.cmd_id != command_id:
            return False
        return self._marcar(p, RECEBEU if ok else ERRO, None if ok else (error or "executor_falhou"))

    def ao_aplicado(self, device_id: str, aplicado: dict) -> bool:
        """`aplicado` do relatório: acks repetidos contam como ack; trava e
        prova confirmam pelo estado realmente aplicado."""
        p = self._pcs.get(device_id)
        if p is None or not isinstance(aplicado, dict):
            return False
        if self.tipo == COMANDO:
            for ack in aplicado.get("acks") or []:
                if isinstance(ack, dict) and ack.get("id") == p.cmd_id:
                    ok = ack.get("ok") is True
                    return self._marcar(p, RECEBEU if ok else ERRO, None if ok else (ack.get("error") or "executor_falhou"))
            return False
        estado = aplicado.get("trava" if self.tipo == TRAVA else "prova")
        if not isinstance(estado, dict):
            return False
        rev = estado.get("rev")
        if not isinstance(rev, (int, float)) or rev < self.rev_enviado:
            return False
        if isinstance(estado.get("erro"), str) and estado["erro"]:
            return self._marcar(p, ERRO, estado["erro"])
        if (estado.get("on") is True) != self.alvo_on:
            return False  # outro professor já mudou depois
        return self._marcar(p, RECEBEU, None)

    def ao_tempo(self, agora_ms: int | None = None) -> bool:
        """Passou o timeout sem confirmação: "enviando" vira "sem resposta"."""
        agora_ms = int(time.time() * 1000) if agora_ms is None else agora_ms
        if agora_ms - self.enviado_em_ms < self.timeout_ms:
            return False
        mudou = False
        for p in self._pcs.values():
            if p.estado == ENVIANDO:
                p.estado = SEM_RESPOSTA
                mudou = True
        return mudou

    @staticmethod
    def _marcar(p: EntregaPc, estado: str, codigo) -> bool:
        if p.estado == estado and p.codigo == codigo:
            return False
        p.estado, p.codigo = estado, codigo
        return True

    @property
    def resolvida(self) -> bool:
        return not any(p.estado == ENVIANDO for p in self._pcs.values())

    @property
    def total(self) -> int:
        return len(self._pcs)

    def contar(self, estado: str) -> int:
        return sum(1 for p in self._pcs.values() if p.estado == estado)

    def contar_erro(self, codigo: str) -> int:
        return sum(1 for p in self._pcs.values() if p.estado == ERRO and p.codigo == codigo)


# ---- Textos (SPEC-turma §6.3, §7.4, §8.4) ----------------------------------------


def _plural(n: int, um: str, varios: str) -> str:
    return um if n == 1 else varios


def hhmm(ms) -> str:
    try:
        return time.strftime("%H:%M", time.localtime(float(ms) / 1000))
    except (TypeError, ValueError, OverflowError, OSError):
        return ""


def texto_entrega(e: Entrega) -> str:
    """"Enviando… 3 de 20" e, no fim, "✓ Todos receberam (20)" ou "✓ 18 de
    20 receberam · 2 desligados (recebem quando ligarem)"."""
    m, r = e.total, e.contar(RECEBEU)
    if not e.resolvida:
        return f"Enviando… {r} de {m}"
    if r == m:
        return f"✓ Todos receberam ({m})"
    d, s, er, v = e.contar(DESLIGADO), e.contar(SEM_RESPOSTA), e.contar(ERRO), e.contar(VERSAO_ANTIGA)
    texto = f"✓ {r} de {m} receberam"
    if d:
        texto += f" · {d} {_plural(d, 'desligado', 'desligados')} (recebem quando ligarem)"
    if s:
        texto += f" · {s} sem resposta"
    if er:
        texto += f" · {er} com erro"
    if v:
        texto += f" · {v} com versão antiga"
    return texto


def texto_entrega_um_pc(e: Entrega, nome: str, ext: str | None = None) -> str:
    p = e.pcs[0] if e.pcs else None
    if p is None:
        return nome
    if p.estado == ENVIANDO:
        return f"Enviando para {nome}…"
    if p.estado == RECEBEU:
        return f"{nome} recebeu ✓"
    if p.estado == DESLIGADO:
        return f"{nome} está desligado — recebe quando ligar"
    if p.estado == SEM_RESPOSTA:
        return f"{nome} não respondeu a tempo"
    if p.estado == VERSAO_ANTIGA:
        return f"{nome}: {texto_erro('tipo_desconhecido', ext=ext)}"
    return f"{nome}: {texto_erro(p.codigo, tipo_comando=e.tipo_comando, ext=ext)}"


def texto_do_pc(e: Entrega, p: EntregaPc, ext: str | None = None) -> str:
    """Uma linha por PC do detalhe ("Unidade 3 · Ana — {isto}")."""
    if p.estado == ENVIANDO:
        return "Enviando…"
    if p.estado == RECEBEU:
        if e.tipo == TRAVA:
            return "Tela travada ✓" if e.alvo_on else "Tela destravada ✓"
        if e.tipo == PROVA:
            return "Em modo prova ✓" if e.alvo_on else "Saiu do modo prova ✓"
        return "Recebeu ✓"
    if p.estado == DESLIGADO:
        return "Desligado — recebe quando ligar"
    if p.estado == SEM_RESPOSTA:
        if e.tipo != COMANDO and e.alvo_on:
            return "Não travou" if e.tipo == TRAVA else "Não entrou no modo prova"
        return TEXTO_TIMEOUT
    if p.estado == VERSAO_ANTIGA:
        return "Versão antiga — atualize este computador"
    if p.codigo == "navegador_antigo":
        return "Navegador desatualizado"
    return texto_erro(p.codigo, tipo_comando=e.tipo_comando, ext=ext)


def _com_partes(base: str, e: Entrega, nao_aplicou) -> str:
    d, v = e.contar(DESLIGADO), e.contar(VERSAO_ANTIGA)
    z, b = e.contar_erro("sem_sessao"), e.contar_erro("navegador_antigo")
    outros = e.contar(ERRO) - z - b
    n = e.contar(SEM_RESPOSTA)
    texto = base
    if d:
        texto += f" · {d} {_plural(d, 'desligado', 'desligados')}"
    if v:
        texto += f" · {v} com versão antiga"
    if z:
        texto += f" · {z} sem ninguém logado"
    if b:
        texto += f" · {b} com o navegador desatualizado"
    if outros:
        texto += f" · {outros} com erro"
    if n:
        texto += f" · {nao_aplicou(n)}"
    return texto


def texto_trava(e: Entrega, desde_ms: int | None = None) -> str:
    """"Telas travadas: 18 de 20 · 1 desligado · … · desde 10:42"; durante a
    confirmação, "Travando… 3 de 20"."""
    m, r = e.total, e.contar(RECEBEU)
    if not e.alvo_on:
        if not e.resolvida:
            return f"Destravando… {r} de {m}"
        return _com_partes(f"Telas destravadas: {r} de {m}", e,
                           lambda n: f"{n} {_plural(n, 'não destravou', 'não destravaram')}")
    if not e.resolvida:
        return f"Travando… {r} de {m}"
    base = _com_partes(f"Telas travadas: {r} de {m}", e,
                       lambda n: f"{n} {_plural(n, 'não travou', 'não travaram')}")
    return f"{base} · desde {hhmm(desde_ms)}" if desde_ms else base


def texto_prova(e: Entrega) -> str:
    """"Modo prova: 18 de 20 · 1 desligado · 1 com o navegador desatualizado"."""
    m, r = e.total, e.contar(RECEBEU)
    if not e.alvo_on:
        if not e.resolvida:
            return f"Desligando o modo prova… {r} de {m}"
        return _com_partes(f"Modo prova desligado: {r} de {m}", e, lambda n: f"{n} sem resposta")
    if not e.resolvida:
        return f"Ligando o modo prova… {r} de {m}"
    return _com_partes(f"Modo prova: {r} de {m}", e,
                       lambda n: f"{n} {_plural(n, 'não entrou', 'não entraram')}")
