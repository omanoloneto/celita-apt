"""Visual do Controle do Professor: tokens do design system (DESIGN.md) e o
CSS das partes de turma (linha de aula, faixas, chips, Recados, grade e
janela de conversa), nos temas claro e escuro.

O CSS fica todo debaixo da classe `professor` das janelas deste app: nada
vaza para outros programas. Claro/escuro como manda o DESIGN.md: a fonte de
verdade é ~/.config/celita/theme, com fallback para `gtk-theme-name`
contendo "dark", e o provider é recarregado em `notify::gtk-theme-name`.
"""

import os
from pathlib import Path

# BEGIN CELITA DESIGN TOKENS
# Gerado por design/sync-tokens; nao editar a mao.
CELITA_LIGHT = {
    "text": "#151d26",
    "text_muted": "rgba(21,29,38,0.62)",
    "text_faint": "rgba(21,29,38,0.50)",
    "accent": "#0b6cbf",
    "accent_fill": "#0b6cbf",
    "accent_wash": "rgba(11,108,191,0.10)",
    "on_accent": "#ffffff",
    "on_accent_muted": "rgba(255,255,255,0.90)",
    "bg_window": "#f4f5f7",
    "bg_aside": "#f9fafc",
    "bg_sunken": "#eef0f3",
    "bg_card": "#ffffff",
    "bg_entry": "#ffffff",
    "bg_popup": "rgba(249,250,252,0.98)",
    "bg_panel": "rgba(244,245,247,0.98)",
    "hover": "rgba(21,29,38,0.06)",
    "pressed": "rgba(21,29,38,0.10)",
    "selected": "rgba(21,29,38,0.09)",
    "border": "rgba(21,29,38,0.12)",
    "border_strong": "rgba(21,29,38,0.24)",
    "border_control": "rgba(21,29,38,0.48)",
    "scrollbar": "rgba(21,29,38,0.48)",
    "shadow_popup": "0 8px 28px rgba(0,0,0,0.22)",
    "shadow_panel": "0 -2px 8px rgba(0,0,0,0.18)",
}
CELITA_DARK = {
    "text": "#f2f4f7",
    "text_muted": "rgba(255,255,255,0.62)",
    "text_faint": "rgba(255,255,255,0.48)",
    "accent": "#54b6ef",
    "accent_fill": "#0b6cbf",
    "accent_wash": "rgba(84,182,239,0.18)",
    "on_accent": "#ffffff",
    "on_accent_muted": "rgba(255,255,255,0.90)",
    "bg_window": "#1f232b",
    "bg_aside": "#191d24",
    "bg_sunken": "#191d24",
    "bg_card": "rgba(255,255,255,0.06)",
    "bg_entry": "rgba(255,255,255,0.07)",
    "bg_popup": "rgba(31,35,43,0.98)",
    "bg_panel": "rgba(25,29,36,0.98)",
    "hover": "rgba(255,255,255,0.08)",
    "pressed": "rgba(255,255,255,0.13)",
    "selected": "rgba(255,255,255,0.10)",
    "border": "rgba(255,255,255,0.12)",
    "border_strong": "rgba(255,255,255,0.24)",
    "border_control": "rgba(255,255,255,0.44)",
    "scrollbar": "rgba(255,255,255,0.44)",
    "shadow_popup": "0 8px 28px rgba(0,0,0,0.45)",
    "shadow_panel": "0 -2px 8px rgba(0,0,0,0.28)",
}
CELITA_RADIUS_CONTROL = "4px"
CELITA_RADIUS_SURFACE = "8px"
CELITA_RADIUS_FULL = "9999px"
CELITA_RADIUS_SCROLLBAR = "3px"
CELITA_TRANSITION_HOVER = "background-color 120ms ease-out"
CELITA_WINDOW_SIDE = "0.90"
CELITA_FONT = {
    "display": "font-size: 42px; font-weight: 300",
    "title": "font-size: 24px; font-weight: 600",
    "heading": "font-size: 17px; font-weight: 600",
    "subheading": "font-size: 14px; font-weight: 600",
    "body": "font-size: 13px",
    "body_strong": "font-size: 13px; font-weight: 600",
    "compact": "font-size: 12px",
    "caption": "font-size: 11px",
}
# END CELITA DESIGN TOKENS

CLASSE = "professor"


def arquivo_do_tema() -> Path:
    return Path(os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")) / "celita" / "theme"


def tema_escuro(nome_do_tema_gtk: str | None) -> bool:
    try:
        salvo = arquivo_do_tema().read_text(encoding="utf-8").strip().lower()
        if salvo in ("light", "dark"):
            return salvo == "dark"
    except OSError:
        pass
    return "dark" in (nome_do_tema_gtk or "").lower()


def tokens(escuro: bool) -> dict:
    return CELITA_DARK if escuro else CELITA_LIGHT


def css(escuro: bool) -> str:
    t = tokens(escuro)
    f = CELITA_FONT
    rc, rs, rf = CELITA_RADIUS_CONTROL, CELITA_RADIUS_SURFACE, CELITA_RADIUS_FULL
    hover = f"linear-gradient(to bottom, {t['hover']}, {t['hover']})"
    pressed = f"linear-gradient(to bottom, {t['pressed']}, {t['pressed']})"
    return f"""
    window.{CLASSE}, window.{CLASSE} .fundo {{ background-color: {t["bg_window"]}; color: {t["text"]}; }}
    .{CLASSE} .card {{
        background-color: {t["bg_card"]};
        border: 1px solid {t["border"]};
        border-radius: {rs};
    }}
    .{CLASSE} .titulo {{ {f["heading"]}; }}
    .{CLASSE} .subtitulo {{ {f["subheading"]}; }}
    .{CLASSE} .forte {{ {f["body_strong"]}; }}
    .{CLASSE} .fraco {{ color: {t["text_muted"]}; }}
    .{CLASSE} .legenda {{ color: {t["text_faint"]}; {f["caption"]}; }}
    .{CLASSE} .compacto {{ {f["compact"]}; }}
    .{CLASSE} .secao {{ color: {t["accent"]}; {f["body_strong"]}; }}

    /* Botões do app: tonal (ações da turma), primário e link. */
    .{CLASSE} button.tonal {{
        background-color: {t["accent_wash"]}; background-image: none;
        color: {t["accent"]};
        border: 0; box-shadow: none; text-shadow: none;
        border-radius: {rc};
        padding: 8px 12px;
    }}
    .{CLASSE} button.tonal label, .{CLASSE} button.tonal image {{ color: {t["accent"]}; }}
    .{CLASSE} button.tonal:hover {{ background-image: {hover}; }}
    .{CLASSE} button.tonal:active, .{CLASSE} button.tonal:checked {{
        background-color: {t["accent_fill"]}; background-image: none;
    }}
    .{CLASSE} button.tonal:checked label, .{CLASSE} button.tonal:checked image {{ color: {t["on_accent"]}; }}
    .{CLASSE} button.tonal.ligado {{ background-color: {t["accent_fill"]}; }}
    .{CLASSE} button.tonal.ligado label, .{CLASSE} button.tonal.ligado image {{ color: {t["on_accent"]}; }}
    .{CLASSE} button.tonal.ligado:hover {{ background-image: {pressed}; }}
    .{CLASSE} button.tonal:disabled {{ background-color: {t["bg_sunken"]}; }}
    .{CLASSE} button.tonal:disabled label, .{CLASSE} button.tonal:disabled image {{ color: {t["text_faint"]}; }}
    .{CLASSE} button.acao-turma {{ min-height: 56px; padding: 8px 12px; }}
    .{CLASSE} button.acao-turma label {{ {f["body_strong"]}; }}
    /* Lista | Telas: segmentos; o escolhido em tonal, o outro afundado. */
    .{CLASSE} button.segmento {{
        background-color: {t["bg_sunken"]}; background-image: none;
        border: 1px solid {t["border"]}; box-shadow: none; text-shadow: none;
        min-height: 56px; padding: 8px 12px;
    }}
    .{CLASSE} button.segmento label, .{CLASSE} button.segmento image {{ color: {t["text_muted"]}; }}
    .{CLASSE} button.segmento label {{ {f["body_strong"]}; }}
    .{CLASSE} button.segmento:hover {{ background-image: {hover}; }}
    .{CLASSE} button.segmento:checked {{ background-color: {t["accent_wash"]}; border-color: {t["accent_wash"]}; }}
    .{CLASSE} button.segmento:checked label, .{CLASSE} button.segmento:checked image {{ color: {t["accent"]}; }}
    .{CLASSE} button.segmento:disabled label, .{CLASSE} button.segmento:disabled image {{ color: {t["text_faint"]}; }}
    .{CLASSE} .segmentos button.segmento:first-child {{ border-radius: {rc} 0 0 {rc}; }}
    .{CLASSE} .segmentos button.segmento:last-child {{ border-radius: 0 {rc} {rc} 0; }}
    .{CLASSE} button.primario {{
        background-color: {t["accent_fill"]}; background-image: none;
        color: {t["on_accent"]};
        border: 0; box-shadow: none; text-shadow: none;
        border-radius: {rc};
        padding: 6px 14px;
    }}
    .{CLASSE} button.primario label, .{CLASSE} button.primario image {{ color: {t["on_accent"]}; }}
    .{CLASSE} button.primario:hover {{ background-image: {pressed}; }}
    .{CLASSE} button.primario:disabled {{ background-color: {t["bg_sunken"]}; }}
    .{CLASSE} button.primario:disabled label {{ color: {t["text_faint"]}; }}
    .{CLASSE} button.link-acao {{
        background: none; border: 0; box-shadow: none; text-shadow: none;
        color: {t["accent"]};
        padding: 4px 8px; min-height: 0;
        border-radius: {rc};
    }}
    .{CLASSE} button.link-acao label {{ color: {t["accent"]}; {f["body_strong"]}; }}
    .{CLASSE} button.link-acao:hover {{ background-color: {t["hover"]}; }}
    .{CLASSE} button.link-acao:disabled label {{ color: {t["text_faint"]}; }}
    .{CLASSE} button.icone {{
        background: none; border: 0; box-shadow: none; text-shadow: none;
        border-radius: {rc}; padding: 6px; min-height: 0; min-width: 0;
    }}
    .{CLASSE} button.icone:hover {{ background-color: {t["hover"]}; }}
    .{CLASSE} button.icone:active {{ background-color: {t["pressed"]}; }}

    /* Linha da aula e faixas. */
    .{CLASSE} .linha-aula {{ padding: 12px 16px; }}
    .{CLASSE} .faixa {{
        background-color: {t["bg_card"]};
        border: 1px solid {t["border"]};
        border-radius: {rs};
        padding: 6px 8px 6px 14px;
    }}
    .{CLASSE} .faixa.estado {{ background-color: {t["accent_fill"]}; border-color: {t["accent_fill"]}; }}
    .{CLASSE} .faixa.estado label, .{CLASSE} .faixa.estado image {{ color: {t["on_accent"]}; }}
    .{CLASSE} .faixa.estado button.link-acao label {{ color: {t["on_accent"]}; }}
    .{CLASSE} .faixa.estado button.link-acao:hover {{ background-color: alpha({t["on_accent"]}, 0.16); }}
    .{CLASSE} .faixa .texto-faixa {{ {f["body_strong"]}; }}
    .{CLASSE} .aviso-flutuante {{
        background-color: {t["bg_popup"]};
        border: 1px solid {t["border_strong"]};
        border-radius: {rs};
        box-shadow: {t["shadow_popup"]};
        padding: 8px 8px 8px 16px;
        margin: 16px;
    }}

    /* Lista de PCs. */
    .{CLASSE} list.lista, .{CLASSE} list.lista row {{ background-color: transparent; }}
    .{CLASSE} list.lista row {{ border-bottom: 1px solid {t["border"]}; }}
    .{CLASSE} list.lista row:last-child {{ border-bottom: 0; }}
    .{CLASSE} list.lista row:hover {{ background-color: {t["hover"]}; }}
    .{CLASSE} .avatar {{
        background-color: {t["accent_wash"]}; color: {t["accent"]};
        border-radius: {rf};
        min-width: 40px; min-height: 40px;
        {f["body_strong"]};
    }}
    .{CLASSE} .avatar.pequeno {{ min-width: 32px; min-height: 32px; {f["compact"]}; font-weight: 600; }}
    .{CLASSE} .avatar.desligado {{ background-color: {t["bg_sunken"]}; color: {t["text_faint"]}; }}
    .{CLASSE} .chip {{
        background-color: {t["accent_wash"]}; color: {t["accent"]};
        border-radius: {rf};
        padding: 2px 10px;
        {f["caption"]}; font-weight: 600;
    }}
    .{CLASSE} .chip.neutro {{ background-color: {t["bg_sunken"]}; color: {t["text_muted"]}; }}
    .{CLASSE} .chip.forte {{ background-color: {t["accent_fill"]}; color: {t["on_accent"]}; }}
    .{CLASSE} .contador {{
        background-color: {t["accent_fill"]}; color: {t["on_accent"]};
        border-radius: {rf};
        min-width: 18px; min-height: 18px; padding: 0 5px;
        {f["caption"]}; font-weight: 600;
    }}

    /* Recados (popover). */
    .{CLASSE} .recados {{ padding: 8px 4px; }}
    .{CLASSE} .pedido {{
        background-color: {t["bg_card"]};
        border: 1px solid {t["border"]};
        border-radius: {rs};
        padding: 12px;
    }}
    .{CLASSE} .motivo {{ font-style: italic; }}
    .{CLASSE} button.item-conversa {{
        background: none; border: 0; box-shadow: none; text-shadow: none;
        border-radius: {rc}; padding: 6px 8px;
    }}
    .{CLASSE} button.item-conversa:hover {{ background-color: {t["hover"]}; }}

    /* Grade de telas. */
    .{CLASSE} flowbox.grade, .{CLASSE} flowbox.grade flowboxchild {{ background-color: transparent; padding: 0; }}
    .{CLASSE} button.quadro {{
        background-color: {t["bg_card"]}; background-image: none;
        border: 1px solid {t["border"]};
        border-radius: {rs};
        box-shadow: none; text-shadow: none;
        padding: 0;
    }}
    .{CLASSE} button.quadro:hover {{ border-color: {t["border_strong"]}; }}
    .{CLASSE} .quadro-rodape {{ padding: 8px 12px; }}
    .{CLASSE} .ponto {{ min-width: 8px; min-height: 8px; border-radius: {rf}; background-color: {t["text_faint"]}; }}
    .{CLASSE} .ponto.online {{ background-color: {t["accent"]}; }}

    /* Conversa (janela por PC). */
    window.{CLASSE}.conversa {{ background-color: {t["bg_window"]}; }}
    .{CLASSE} .conversa-topo {{
        background-color: {t["bg_card"]};
        border-bottom: 1px solid {t["border"]};
        padding: 10px 12px;
    }}
    .{CLASSE} .mao-linha {{
        background-color: {t["accent_wash"]};
        border-bottom: 1px solid {t["border"]};
        padding: 4px 4px 4px 12px;
    }}
    .{CLASSE} .bolha {{ border-radius: {rs}; padding: 6px 10px; }}
    .{CLASSE} .bolha.minha {{ background-color: {t["accent_wash"]}; color: {t["text"]}; }}
    .{CLASSE} .bolha.dele {{ background-color: {t["bg_card"]}; border: 1px solid {t["border"]}; color: {t["text"]}; }}
    .{CLASSE} .bolha .texto {{ {f["body"]}; }}
    .{CLASSE} .sistema {{ color: {t["text_muted"]}; {f["caption"]}; }}
    .{CLASSE} .rodape {{ border-top: 1px solid {t["border"]}; background-color: {t["bg_card"]}; padding: 10px 12px; }}
    .{CLASSE} entry.campo, .{CLASSE} textview.campo text {{
        background-color: {t["bg_entry"]}; background-image: none;
        color: {t["text"]};
    }}
    .{CLASSE} entry.campo {{
        border: 1px solid {t["border_control"]};
        border-radius: {rc};
        box-shadow: none;
        min-height: 32px; padding: 0 8px;
    }}
    .{CLASSE} entry.campo:focus {{ border-color: {t["accent"]}; }}
    .{CLASSE} button.enviar {{
        background-color: {t["accent_fill"]}; background-image: none;
        border: 0; box-shadow: none; text-shadow: none;
        min-width: 34px; min-height: 34px; padding: 0;
        border-radius: {rc};
    }}
    .{CLASSE} button.enviar image {{ color: {t["on_accent"]}; }}
    .{CLASSE} button.enviar:disabled {{ background-color: {t["border"]}; }}
    .{CLASSE} button.enviar:disabled image {{ color: {t["text_faint"]}; }}
    /* Opaco e sem sombra: sem compositor, a sombra vira um retângulo e o
       fundo translúcido deixa ver os botões de baixo. */
    .{CLASSE} popover.background {{
        background-color: {t["bg_window"]}; border: 1px solid {t["border_strong"]};
        border-radius: {rs}; box-shadow: none;
    }}
    .{CLASSE} switch:checked {{
        background-color: {t["accent_fill"]}; background-image: none; border-color: {t["accent_fill"]};
    }}
    .{CLASSE} scrollbar slider {{ background-color: {t["scrollbar"]}; border-radius: {CELITA_RADIUS_SCROLLBAR}; }}
    """
