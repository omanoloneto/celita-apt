"""Estado local do professor em `~/.config/controle-de-aula/`: os mesmos
arquivos JSON do celular (nomes e formas iguais), com permissão 0600. A chave
do professor vive aqui, não no agente: administrador da máquina não vira
professor de todos os PCs."""

import json
import os
import shutil
import time
from pathlib import Path

from ..crypto import (
    generate_private_key, private_key_from_b64url, private_key_to_b64url, public_key_b64url,
)
from . import home as home_rules
from .rules import MAX_RULES, normalize_pattern, padrao_amplo_demais, sanitize_rule

FILE_RULES = "domain_rules.json"
FILE_UNITS = "unit_numbers.json"
FILE_NAMES = "device_names.json"
FILE_HOME = "home.json"
FILE_WALLPAPER = "wallpaper.json"
FILE_PREFS = "app_prefs.json"
FILE_KEY = "teacher_key.txt"
FILE_AUTH = "auth.json"
FILE_SESSION = "session.json"
# A aula em andamento. O nome da spec ("session.json") já é o carimbo da
# sessão gráfica acima; vale o do celular.
FILE_AULA = "aula.json"
FILE_PROVA = "sites_prova.json"
BOOT_ID_PATH = "/proc/sys/kernel/random/boot_id"


def profile_dir() -> Path:
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    return Path(base) / "controle-de-aula"


def current_session_stamp() -> dict:
    """Identidade da sessão gráfica: boot + sessão do logind. Muda ao sair da
    conta, reiniciar ou desligar."""
    try:
        boot = pathlib_read(BOOT_ID_PATH)
    except OSError:
        boot = ""
    return {"boot": boot, "session": os.environ.get("XDG_SESSION_ID", "")}


def pathlib_read(path: str) -> str:
    with open(path, encoding="utf-8") as handle:
        return handle.read().strip()


def forget_if_stale(directory: Path) -> bool:
    """O login do professor vale só para a sessão em que foi feito: outra
    sessão (logout, reinício, desligamento) apaga chave, conta e stores."""
    stamp_file = JsonFile(directory / FILE_SESSION)
    if not directory.exists():
        return False
    if stamp_file.read(None) == current_session_stamp():
        return False
    for entry in directory.iterdir():
        try:
            if entry.is_dir():
                shutil.rmtree(entry)
            else:
                entry.unlink()
        except OSError:
            pass
    return True


def stamp_session(directory: Path):
    JsonFile(directory / FILE_SESSION).write(current_session_stamp())


class JsonFile:
    def __init__(self, path: Path):
        self.path = path

    def read(self, default):
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return default

    def read_text(self) -> str | None:
        try:
            return self.path.read_text(encoding="utf-8")
        except OSError:
            return None

    def write(self, value):
        self.write_text(json.dumps(value, ensure_ascii=False))

    def write_text(self, text: str):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        os.chmod(self.path.parent, 0o700)
        temporary = self.path.with_name(self.path.name + ".tmp")
        with open(os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w", encoding="utf-8") as handle:
            handle.write(text)
        os.replace(temporary, self.path)

    def exists(self) -> bool:
        return self.path.exists()


class RulesStore:
    def __init__(self, directory: Path):
        self.file = JsonFile(directory / FILE_RULES)
        self.rules = []
        self.rev = 0
        self.reload()

    def reload(self):
        data = self.file.read({})
        raw = data.get("rules") if isinstance(data, dict) else None
        self.rules = [r for r in map(sanitize_rule, raw) if r] if isinstance(raw, list) else []
        rev = data.get("rev") if isinstance(data, dict) else None
        self.rev = int(rev) if isinstance(rev, (int, float)) else 0
        # Os filtros (Shorts, Reels, IAs…) viajam no mesmo arquivo, editados
        # no celular: regravar sem eles os apagaria da escola inteira.
        filtros = data.get("filtros") if isinstance(data, dict) else None
        self.filtros = filtros if isinstance(filtros, dict) else None

    def add(self, pattern: str, action: str) -> bool:
        normalized = normalize_pattern(pattern)
        if not normalized or len(self.rules) >= MAX_RULES:
            return False
        self.rules = [r for r in self.rules if r["pattern"] != normalized]
        self.rules.append(sanitize_rule({"pattern": normalized, "action": action}))
        self._save()
        return True

    def add_many(self, patterns: list, action: str) -> int:
        """Um site por linha; devolve quantos entraram. Repetidos e vazios
        são ignorados; o último de cada padrão vence."""
        added = 0
        for pattern in patterns:
            normalized = normalize_pattern(pattern)
            if not normalized or len(self.rules) >= MAX_RULES:
                continue
            self.rules = [r for r in self.rules if r["pattern"] != normalized]
            self.rules.append(sanitize_rule({"pattern": normalized, "action": action}))
            added += 1
        if added:
            self._save()
        return added

    def update(self, index: int, pattern: str, action: str) -> bool:
        normalized = normalize_pattern(pattern)
        if not normalized or not 0 <= index < len(self.rules):
            return False
        self.rules[index] = sanitize_rule({"pattern": normalized, "action": action})
        self._save()
        return True

    def remove(self, index: int):
        if 0 <= index < len(self.rules):
            del self.rules[index]
            self._save()

    def _save(self):
        self.rev = int(time.time() * 1000)
        data = {"rev": self.rev, "rules": self.rules}
        if self.filtros is not None:
            data["filtros"] = self.filtros
        self.file.write(data)


class MapStore:
    """`{deviceId: valor}`, forma dos números de unidade e dos nomes."""

    def __init__(self, path: Path, value_type):
        self.file = JsonFile(path)
        self.value_type = value_type
        self.values = {}
        self.reload()

    def reload(self):
        data = self.file.read({})
        self.values = {k: v for k, v in data.items() if isinstance(k, str) and isinstance(v, self.value_type)} \
            if isinstance(data, dict) else {}

    def get(self, device_id: str):
        return self.values.get(device_id)

    def set(self, device_id: str, value):
        if self.values.get(device_id) == value:
            return
        self.values[device_id] = value
        self.file.write(self.values)

    def remove(self, device_id: str):
        if self.values.pop(device_id, None) is not None:
            self.file.write(self.values)

    def owner_of(self, value):
        return next((k for k, v in self.values.items() if v == value), None)


class UnitStore(MapStore):
    def __init__(self, directory: Path):
        super().__init__(directory / FILE_UNITS, int)


class NameStore(MapStore):
    def __init__(self, directory: Path):
        super().__init__(directory / FILE_NAMES, str)


class HomeStore:
    def __init__(self, directory: Path):
        self.file = JsonFile(directory / FILE_HOME)
        self.config = home_rules.sanitize_home(self.file.read(None))

    def set_title(self, title: str):
        self.config["titulo"] = home_rules.sanitize_home({**self.config, "titulo": title})["titulo"]
        self._save()

    def set_search(self, enabled: bool, engine: str | None = None):
        self.config["busca"] = bool(enabled)
        if engine is not None:
            self.config["buscador"] = engine
        self.config = home_rules.sanitize_home(self.config)
        self._save()

    def set_url(self, url: str) -> bool:
        """Site no lugar da página do Celita. Vazio volta para a página."""
        url = (url or "").strip()
        if url and not home_rules.shortcut_url_valid(url):
            return False
        self.config = home_rules.sanitize_home({**self.config, "url": url})
        self._save()
        return True

    def add_shortcut(self, name: str, url: str) -> bool:
        shortcut = home_rules.shortcut_from_input(name, url)
        if shortcut is None or len(self.config["atalhos"]) >= home_rules.MAX_SHORTCUTS:
            return False
        self.config["atalhos"].append(shortcut)
        self._save()
        return True

    def update_shortcut(self, index: int, name: str, url: str) -> bool:
        shortcut = home_rules.shortcut_from_input(name, url)
        if shortcut is None or not 0 <= index < len(self.config["atalhos"]):
            return False
        self.config["atalhos"][index] = shortcut
        self._save()
        return True

    def remove_shortcut(self, index: int):
        if 0 <= index < len(self.config["atalhos"]):
            del self.config["atalhos"][index]
            self._save()

    def replace(self, raw):
        self.config = home_rules.sanitize_home(raw)
        self._save()

    def _save(self):
        self.file.write(self.config)


class WallpaperStore:
    def __init__(self, directory: Path):
        self.file = JsonFile(directory / FILE_WALLPAPER)
        data = self.file.read({})
        value = data.get("hash") if isinstance(data, dict) else None
        self.hash = value if isinstance(value, str) and value else None

    def set(self, hash_hex: str):
        self.hash = hash_hex
        self.file.write({"hash": hash_hex})


class PrefsStore:
    def __init__(self, directory: Path):
        self.file = JsonFile(directory / FILE_PREFS)
        data = self.file.read({})
        self.data = data if isinstance(data, dict) else {}

    @property
    def teacher_name(self) -> str:
        name = self.data.get("teacherName")
        return name.strip() if isinstance(name, str) and name.strip() else "Professor"

    def set_teacher_name(self, name: str):
        self.data["teacherName"] = (name or "").strip() or "Professor"
        self.file.write(self.data)

    @property
    def school_uid(self) -> str | None:
        value = self.data.get("schoolUid")
        return value if isinstance(value, str) and value else None

    def set_school_uid(self, uid: str | None):
        if uid:
            self.data["schoolUid"] = uid
        else:
            self.data.pop("schoolUid", None)
        self.file.write(self.data)


class KeyStore:
    """Par X25519 do professor em `priv:pub` b64url, formato do celular."""

    def __init__(self, directory: Path):
        self.file = JsonFile(directory / FILE_KEY)

    def raw(self) -> str | None:
        text = self.file.read_text()
        return text.strip() if text else None

    def load_or_create(self):
        raw = self.raw()
        if raw:
            try:
                return private_key_from_b64url(raw.split(":", 1)[0])
            except (ValueError, TypeError):
                pass
        key = generate_private_key()
        self.save(key)
        return key

    def save(self, key):
        self.file.write_text(f"{private_key_to_b64url(key)}:{public_key_b64url(key)}")

    def adopt(self, raw: str):
        """Adota a chave da escola: a partir daqui este professor é a escola."""
        key = private_key_from_b64url(raw.split(":", 1)[0])
        self.file.write_text(raw.strip())
        return key


class AuthStore:
    def __init__(self, directory: Path):
        self.file = JsonFile(directory / FILE_AUTH)

    def load(self):
        data = self.file.read(None)
        return data if isinstance(data, dict) else None

    def save(self, data: dict):
        current = self.load() or {}
        current.update(data)
        self.file.write(current)


def _lista_por_pc(raw) -> dict:
    saida = {}
    for device_id, valores in (raw.items() if isinstance(raw, dict) else ()):
        if isinstance(device_id, str) and isinstance(valores, list):
            limpos = [v for v in valores if isinstance(v, str) and v]
            if limpos:
                saida[device_id] = list(dict.fromkeys(limpos))
    return saida


class ClassSession:
    """A aula em andamento, persistida a cada mudança (o app pode fechar no
    meio da aula): `{ativa, inicio, turma, pcs, liberacoes, provaLiberacoes,
    prova:{on, rev}, trava:{on, rev, texto, mute, desde}}`. Só local; nada
    disso vai ao Firebase."""

    TRAVA_DESLIGADA = {"on": False}
    PROVA_DESLIGADA = {"on": False}

    def __init__(self, directory: Path):
        self.file = JsonFile(directory / FILE_AULA)
        self.reload()

    def reload(self):
        data = self.file.read({})
        data = data if isinstance(data, dict) else {}
        self.ativa = data.get("ativa") is True
        turma = data.get("turma")
        self.turma = turma if isinstance(turma, str) else ""
        inicio = data.get("inicio")
        self.inicio = int(inicio) if isinstance(inicio, (int, float)) else 0
        pcs = data.get("pcs")
        self.pcs = list(dict.fromkeys(p for p in pcs if isinstance(p, str))) if isinstance(pcs, list) else []
        # Padrões de bloqueio liberados por PC (com ou sem aula; só o
        # "Encerrar aula" os derruba).
        self.liberacoes = _lista_por_pc(data.get("liberacoes"))
        # Hosts liberados na prova por PC (somam à lista da escola).
        self.prova_liberacoes = _lista_por_pc(data.get("provaLiberacoes"))
        self.trava = self._trava(data.get("trava"))
        self.prova = self._prova(data.get("prova"))

    @staticmethod
    def _trava(raw) -> dict:
        if not isinstance(raw, dict) or raw.get("on") is not True:
            return dict(ClassSession.TRAVA_DESLIGADA)
        numero = lambda k: int(raw[k]) if isinstance(raw.get(k), (int, float)) else 0  # noqa: E731
        texto = raw.get("texto")
        return {"on": True, "rev": numero("rev"), "texto": texto if isinstance(texto, str) else "",
                "mute": raw.get("mute") is not False, "desde": numero("desde")}

    @staticmethod
    def _prova(raw) -> dict:
        if not isinstance(raw, dict) or raw.get("on") is not True:
            return dict(ClassSession.PROVA_DESLIGADA)
        rev = raw.get("rev")
        return {"on": True, "rev": int(rev) if isinstance(rev, (int, float)) else 0}

    def _save(self):
        self.file.write({
            "ativa": self.ativa, "inicio": self.inicio, "turma": self.turma, "pcs": self.pcs,
            "liberacoes": self.liberacoes, "provaLiberacoes": self.prova_liberacoes,
            "prova": self.prova, "trava": self.trava,
        })

    def iniciar(self, turma: str, pcs):
        self.ativa = True
        self.turma = (turma or "").strip()[:60]
        self.inicio = int(time.time() * 1000)
        self.pcs = list(dict.fromkeys(pcs))
        self._save()

    def incluir(self, device_id: str):
        if device_id not in self.pcs:
            self.pcs.append(device_id)
            self._save()

    def tirar(self, device_id: str):
        if device_id in self.pcs:
            self.pcs.remove(device_id)
            self._save()

    def liberacoes_de(self, device_id: str) -> set:
        return set(self.liberacoes.get(device_id, ()))

    def liberar(self, device_id: str, pattern: str):
        atuais = self.liberacoes.setdefault(device_id, [])
        if pattern not in atuais:
            atuais.append(pattern)
            self._save()

    def revogar(self, device_id: str, pattern: str):
        atuais = self.liberacoes.get(device_id)
        if atuais and pattern in atuais:
            atuais.remove(pattern)
            if not atuais:
                del self.liberacoes[device_id]
            self._save()

    def prova_liberacoes_de(self, device_id: str) -> list:
        return list(self.prova_liberacoes.get(device_id, ()))

    def liberar_na_prova(self, device_id: str, host: str) -> bool:
        """True = o host entrou agora (não estava liberado)."""
        atuais = self.prova_liberacoes.setdefault(device_id, [])
        if host in atuais:
            return False
        atuais.append(host)
        self._save()
        return True

    def revogar_na_prova(self, device_id: str, host: str):
        """Desfaz `liberar_na_prova` quando a gravação do state/exam falhou: a
        liberação não pode entrar escondida na próxima renovação."""
        atuais = self.prova_liberacoes.get(device_id)
        if atuais and host in atuais:
            atuais.remove(host)
            if not atuais:
                del self.prova_liberacoes[device_id]
            self._save()

    def definir_trava(self, on: bool, rev: int = 0, texto: str = "", mute: bool = True, desde: int = 0):
        self.trava = {"on": True, "rev": rev, "texto": texto, "mute": mute, "desde": desde} if on \
            else dict(self.TRAVA_DESLIGADA)
        self._save()

    def definir_prova(self, on: bool, rev: int = 0):
        self.prova = {"on": True, "rev": rev} if on else dict(self.PROVA_DESLIGADA)
        self._save()

    def encerrar(self, manter_ativa: bool = False):
        """Fim de aula. No modo isolado a aula é implícita e continua ativa."""
        self.ativa = manter_ativa
        self.turma = ""
        self.inicio = int(time.time() * 1000) if manter_ativa else 0
        self.pcs = []
        self.liberacoes = {}
        self.prova_liberacoes = {}
        self.trava = dict(self.TRAVA_DESLIGADA)
        self.prova = dict(self.PROVA_DESLIGADA)
        self._save()


class ProvaStore:
    """Sites permitidos no modo prova (lista da escola), `sites_prova.json` =
    {rev, allow:[{pattern}]}, sincronizado em school/stores/prova. Clientes
    antigos não conhecem o store e não o apagam ao regravar as regras."""

    def __init__(self, directory: Path):
        self.file = JsonFile(directory / FILE_PROVA)
        self.reload()

    def reload(self):
        data = self.file.read({})
        data = data if isinstance(data, dict) else {}
        rev = data.get("rev")
        self.rev = int(rev) if isinstance(rev, (int, float)) else 0
        self.padroes = []
        for item in data.get("allow") if isinstance(data.get("allow"), list) else []:
            pattern = normalize_pattern(item.get("pattern") if isinstance(item, dict) else "")
            if pattern and pattern not in self.padroes:
                self.padroes.append(pattern)
            if len(self.padroes) >= MAX_RULES:
                break

    def _aceita(self, pattern: str) -> bool:
        return bool(pattern) and not padrao_amplo_demais(pattern) and pattern not in self.padroes \
            and len(self.padroes) < MAX_RULES

    def adicionar(self, pattern: str) -> bool:
        """False = vazio, largo demais (sufixo público), repetido ou cheio."""
        normalized = normalize_pattern(pattern)
        if not self._aceita(normalized):
            return False
        self.padroes.append(normalized)
        self._save()
        return True

    def adicionar_em_lote(self, linhas) -> int:
        added = 0
        for linha in linhas:
            for parte in (linha or "").replace(",", " ").replace(";", " ").split():
                normalized = normalize_pattern(parte)
                if self._aceita(normalized):
                    self.padroes.append(normalized)
                    added += 1
        if added:
            self._save()
        return added

    def remover(self, index: int):
        if 0 <= index < len(self.padroes):
            del self.padroes[index]
            self._save()

    def _save(self):
        self.rev = int(time.time() * 1000)
        self.file.write({"rev": self.rev, "allow": [{"pattern": p} for p in self.padroes]})
