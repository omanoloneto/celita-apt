"""Tabela única de erros em português (SPEC-turma §6.2), a mesma do app
(`lib/src/ui/textos_erro.dart`). O código cru do ack nunca aparece para o
professor: só o texto daqui. Puro."""

from .versao import COMANDOS_SO_CELITA, tem_celita

# Escrita nova negada pelas rules (console ainda com as rules antigas).
TEXTO_SERVIDOR_DESATUALIZADO = ("O servidor da escola ainda não foi atualizado para este recurso. "
                                "Avise quem cuida do sistema.")
# Escrita que falhou por falta de rede.
TEXTO_SEM_INTERNET = "Sem conexão com a internet. Tente de novo."
# PC desligado ou sem internet no envio.
TEXTO_OFFLINE = "Desligado ou sem internet."
# Nada voltou do PC em 25 s.
TEXTO_TIMEOUT = "Não respondeu a tempo."

_GENERICO = "Não foi possível concluir neste computador."
# Código só daqui (nunca vem do PC): a escrita do comando falhou NESTE app.
ERRO_ENVIO_LOCAL = "envio_local"

_EXATOS = {
    "sem_sessao": "Ninguém está logado neste computador agora.",
    "url_invalida": "O endereço do site não é válido.",
    "payload_invalido": "O pedido chegou incompleto. Tente de novo.",
    "so_chromeos": "Isso só funciona em Chromebook.",
    "blob_invalido": "A imagem enviada está corrompida.",
    "imagem_grande": "A imagem é grande demais.",
    "ponte_caiu": "O navegador do aluno se desconectou — peça para reabrir.",
    "ponte_sem_resposta": "O navegador do aluno não respondeu a tempo.",
    "sem_resposta": "O navegador do aluno não respondeu a tempo.",
    "resposta_invalida": "O computador respondeu de forma inesperada.",
    "cmd_desconhecido": "O computador respondeu de forma inesperada.",
    "atualizador_ausente": "Este computador não tem o atualizador do Celita.",
    "aba_falhou": "Não foi possível abrir o site no computador.",
    "fechar_falhou": "Não foi possível fechar as abas no computador.",
    "sem_notifications": "Não foi possível mostrar a mensagem na tela do aluno.",
    "classview_falhou": "Não foi possível atualizar a visão da turma no telão.",
    "snapshot_upload": "Não foi possível enviar a imagem do computador.",
    "numero_invalido": "Número de unidade inválido (use de 1 a 9999).",
}

_PREFIXOS = (
    ("voges_", "Não foi possível abrir o site no computador."),
    ("tela_", "Não foi possível capturar a tela deste computador."),
    ("camera_", "Não foi possível usar a câmera deste computador."),
    ("papel_", "Não foi possível trocar o papel de parede."),
    ("aviso_", "Não foi possível mostrar a mensagem na tela do aluno."),
    ("chat_", "Não foi possível entregar a mensagem."),
)


def texto_erro(codigo, tipo_comando: str | None = None, ext: str | None = None) -> str:
    """Texto ao professor para o código de erro de um ack (ou de `aplicado`).
    `tipo_comando` e `ext` (meta/ext do PC) separam o `tipo_desconhecido` de
    um comando só do Celita num Chromebook do de um PC desatualizado."""
    c = codigo.strip() if isinstance(codigo, str) else ""
    if c == ERRO_ENVIO_LOCAL:
        return TEXTO_SEM_INTERNET
    if c == "tipo_desconhecido":
        if tipo_comando in COMANDOS_SO_CELITA and not tem_celita(ext):
            return "Isso só funciona nos computadores com Celita OS."
        return "Este computador tem uma versão antiga — atualize-o."
    if c in _EXATOS:
        return _EXATOS[c]
    for prefixo, texto in _PREFIXOS:
        if c.startswith(prefixo):
            return texto
    return _GENERICO  # executor_falhou e qualquer outro


def negado(error) -> bool:
    """A escrita foi negada pelas rules (401/403)?"""
    return getattr(error, "status", None) in (401, 403)


def texto_erro_de_escrita(error) -> str:
    """Erro de uma ESCRITA nova (state/lock|exam|monitor, apagar up/thumbs,
    /home/menu, /school/aulas, stores): negada pelas rules vira o aviso de
    servidor desatualizado; o resto, falta de internet. O professor nunca vê
    sucesso quando a escrita foi negada (SPEC-turma §1.3)."""
    return TEXTO_SERVIDOR_DESATUALIZADO if negado(error) else TEXTO_SEM_INTERNET
