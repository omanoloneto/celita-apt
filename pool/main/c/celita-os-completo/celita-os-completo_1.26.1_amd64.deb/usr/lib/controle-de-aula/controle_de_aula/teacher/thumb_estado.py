"""Grade de telas ao vivo (item 23): o que um quadro mostra — a miniatura com
a idade dela, ou o texto no lugar da imagem. Puro; espelho de
`thumb_estado.dart` do app (SPEC-turma §5.4)."""

CARREGANDO = "carregando"
DESLIGADO = "desligado"
VERSAO_ANTIGA = "versaoAntiga"
NINGUEM_LOGADO = "ninguemLogado"
NAO_PERMITIDA = "naoPermitida"
INDISPONIVEL = "indisponivel"
IMAGEM = "imagem"

THUMB_FRESCA_MS = 30_000
THUMB_AGORA_MS = 5_000

TILE_MINIMO = 220
COLUNAS_MIN, COLUNAS_MAX = 3, 5


class EstadoQuadro:
    def __init__(self, tipo: str, texto: str, esmaecida: bool = False):
        self.tipo = tipo
        # Sem imagem: o texto no lugar dela. Com imagem: a idade.
        self.texto = texto
        # Imagem velha (mais de 30 s): opacidade 0,5.
        self.esmaecida = esmaecida

    @property
    def tem_imagem(self) -> bool:
        return self.tipo == IMAGEM

    def __eq__(self, other):
        return isinstance(other, EstadoQuadro) and (self.tipo, self.texto, self.esmaecida) == (
            other.tipo, other.texto, other.esmaecida)

    def __repr__(self):
        return f"EstadoQuadro({self.tipo}, {self.texto}{', esmaecida' if self.esmaecida else ''})"


def estado_do_quadro(online: bool, suporta_turma: bool, thumb, grade_aberta_em, agora_ms: int) -> EstadoQuadro:
    """`thumb` = última miniatura lida ({ts, jpeg|None, motivo}) ou None;
    `grade_aberta_em` e `agora_ms` no relógio do servidor (o do `ts`)."""
    if not online:
        return EstadoQuadro(DESLIGADO, "Desligado")
    if not suporta_turma:
        return EstadoQuadro(VERSAO_ANTIGA, "Versão antiga — atualize para ver a tela")
    if thumb is None:
        return EstadoQuadro(CARREGANDO, "Carregando…")
    ts = thumb.get("ts") or 0
    if grade_aberta_em is not None and ts < grade_aberta_em:
        return EstadoQuadro(CARREGANDO, "Carregando…")
    if not thumb.get("jpeg"):
        motivo = thumb.get("motivo")
        if motivo == "sem_sessao":
            return EstadoQuadro(NINGUEM_LOGADO, "Ninguém logado")
        if motivo == "sem_permissao":
            return EstadoQuadro(NAO_PERMITIDA, "Miniatura não permitida neste Chromebook")
        return EstadoQuadro(INDISPONIVEL, "Tela indisponível agora")
    idade = max(0, agora_ms - ts)
    if idade <= THUMB_FRESCA_MS:
        if idade < THUMB_AGORA_MS:
            return EstadoQuadro(IMAGEM, "agora")
        return EstadoQuadro(IMAGEM, f"há {idade // 1000} s")
    minutos = max(1, round(idade / 60_000))
    return EstadoQuadro(IMAGEM, f"há {minutos} min", esmaecida=True)


# A miniatura tem ≤ 480 px de largura. Um JPEG pequeno pode declarar 65535 px
# de lado (gigabytes ao decodificar): acima disto, nem decodifica.
MAX_LADO_JPEG = 4096


def dimensoes_jpeg(dados) -> tuple | None:
    """(largura, altura) declaradas no quadro SOF do JPEG, sem decodificar;
    None = não é JPEG ou o cabeçalho está quebrado."""
    if not isinstance(dados, (bytes, bytearray)) or dados[:2] != b"\xff\xd8":
        return None
    i = 2
    while i + 4 <= len(dados):
        if dados[i] != 0xFF:
            return None
        marcador = dados[i + 1]
        if marcador == 0xFF:  # preenchimento entre segmentos
            i += 1
            continue
        if marcador == 0x01 or 0xD0 <= marcador <= 0xD7:  # sem tamanho
            i += 2
            continue
        tamanho = int.from_bytes(dados[i + 2:i + 4], "big")
        if 0xC0 <= marcador <= 0xCF and marcador not in (0xC4, 0xC8, 0xCC):
            if i + 9 > len(dados):
                return None
            return int.from_bytes(dados[i + 7:i + 9], "big"), int.from_bytes(dados[i + 5:i + 7], "big")
        if marcador in (0xD9, 0xDA) or tamanho < 2:  # dados da imagem sem SOF antes
            return None
        i += 2 + tamanho
    return None


def jpeg_aceitavel(dados) -> bool:
    dimensoes = dimensoes_jpeg(dados)
    return dimensoes is not None and 0 < dimensoes[0] <= MAX_LADO_JPEG and 0 < dimensoes[1] <= MAX_LADO_JPEG


def colunas_da_grade(largura: int, espaco: int = 12) -> int:
    """Colunas pela largura disponível, com quadro mínimo de 220 px, de 3 a 5."""
    cabem = (max(0, largura) + espaco) // (TILE_MINIMO + espaco)
    return max(COLUNAS_MIN, min(COLUNAS_MAX, cabem))
