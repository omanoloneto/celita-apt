"""Peças de turma da janela do professor (SPEC-turma §3.6, §4.4, §5.4, §6.3,
§7.4, §8.4–8.5): faixas de entrega e de estado, linha de ações da aula,
popover "Olhos em mim", Recados, janela de conversa e grade de telas.

Importado só de dentro de `app.main()` (o GTK é carregado lá). Todo texto
que vem da rede (nome do PC, mensagem, motivo, site) entra por `set_text`,
nunca como markup. Rede sempre fora da thread da interface.
"""

import logging
import subprocess
import threading
import time

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gdk, GdkPixbuf, GLib, Gtk, Pango  # noqa: E402

from .. import protocol  # noqa: E402
from ..up import monograma  # noqa: E402
from . import estilo  # noqa: E402
from . import up_router as upr  # noqa: E402
from .controller import TRAVA_PRESETS  # noqa: E402
from .thumb_estado import TILE_MINIMO, colunas_da_grade, jpeg_aceitavel  # noqa: E402

log = logging.getLogger("controle-de-aula.teacher.ui")

ERRO_GENERICO = "Não deu certo. Tente de novo."
AVISO_S = 6
FAIXA_RESOLVIDA_S = 12
MAX_CHAT = protocol.MAX_CHAT_TEXTO
ESPACO_GRADE = 12
PROPORCAO = 1.6  # quadro 16:10
MAX_LADO_EXIBIDO = 960  # o "Ampliar" mostra no máximo isto


# ---- utilidades ----------------------------------------------------------------------


def run_async(work, done):
    """`work` numa thread; `done(resultado ou exceção)` no laço do GTK."""
    def runner():
        try:
            result = work()
        except Exception as error:  # noqa: BLE001
            log.warning("ação falhou: %s", error)
            result = error
        GLib.idle_add(done, result)
    threading.Thread(target=runner, daemon=True).start()


def texto_do_resultado(result) -> str | None:
    """None/""= deu certo; str = texto ao professor; exceção = genérico (o erro
    cru fica só no log)."""
    if isinstance(result, Exception):
        return ERRO_GENERICO
    return result or None


def rotulo(texto="", *classes, xalign=0.0, wrap=True, ellipsize=False, max_chars=None):
    widget = Gtk.Label(xalign=xalign)
    widget.set_text(texto or "")
    if ellipsize:
        widget.set_ellipsize(Pango.EllipsizeMode.END)
        widget.set_single_line_mode(True)
    elif wrap:
        widget.set_line_wrap(True)
        widget.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
    if max_chars:
        widget.set_max_width_chars(max_chars)
    for classe in classes:
        widget.get_style_context().add_class(classe)
    return widget


def com_classes(widget, *classes):
    context = widget.get_style_context()
    for classe in classes:
        context.add_class(classe)
    return widget


def botao(texto, *classes, icone=None, ao_clicar=None, tooltip=None):
    button = Gtk.Button()
    if icone:
        box = Gtk.Box(spacing=8)
        box.pack_start(Gtk.Image.new_from_icon_name(icone, Gtk.IconSize.BUTTON), False, False, 0)
        box.pack_start(rotulo(texto, wrap=False), False, False, 0)
        box.set_halign(Gtk.Align.CENTER)
        button.add(box)
    else:
        button.set_label(texto)
    com_classes(button, *classes)
    if tooltip:
        button.set_tooltip_text(tooltip)
    if ao_clicar is not None:
        button.connect("clicked", lambda *_: ao_clicar())
    return button


def botao_icone(icone, tooltip, ao_clicar=None):
    button = Gtk.Button.new_from_icon_name(icone, Gtk.IconSize.BUTTON)
    com_classes(button, "icone")
    button.set_tooltip_text(tooltip)
    if ao_clicar is not None:
        button.connect("clicked", lambda *_: ao_clicar())
    return button


def limpar(container):
    for child in container.get_children():
        container.remove(child)
        child.destroy()


def vestir(janela):
    """Toda janela deste app leva a classe do CSS do professor."""
    com_classes(janela, estilo.CLASSE)
    return janela


def avatar(nome, online=True, pequeno=False):
    widget = rotulo(monograma(nome) or "?", "avatar", xalign=0.5, wrap=False)
    if pequeno:
        com_classes(widget, "pequeno")
    if not online:
        com_classes(widget, "desligado")
    widget.set_valign(Gtk.Align.CENTER)
    return widget


def chip(texto, *classes):
    widget = rotulo(texto, "chip", *classes, wrap=False)
    widget.set_valign(Gtk.Align.CENTER)
    return widget


def hora(ms) -> str:
    return upr.hora_minuto(ms)


def plural(n, um, varios):
    return um if n == 1 else varios


# ---- estilo (claro/escuro, recarregado na troca de tema) ------------------------------


class Estilo:
    def __init__(self):
        self.provider = Gtk.CssProvider()
        self.settings = Gtk.Settings.get_default()
        screen = Gdk.Screen.get_default()
        if screen is not None:
            Gtk.StyleContext.add_provider_for_screen(screen, self.provider,
                                                     Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        self.carregar()
        if self.settings is not None:
            self.settings.connect("notify::gtk-theme-name", lambda *_: self.carregar())
            self.settings.connect("notify::gtk-application-prefer-dark-theme", lambda *_: self.carregar())

    def carregar(self):
        # Lido uma vez por troca de tema (cor() é chamada a cada desenho).
        nome = self.settings.get_property("gtk-theme-name") if self.settings else ""
        self.escuro = estilo.tema_escuro(nome)
        try:
            self.provider.load_from_data(estilo.css(self.escuro).encode("utf-8"))
        except GLib.Error as error:
            log.warning("CSS do professor: %s", error)

    def cor(self, nome) -> Gdk.RGBA:
        rgba = Gdk.RGBA()
        rgba.parse(estilo.tokens(self.escuro)[nome])
        return rgba


# ---- diálogos -------------------------------------------------------------------------


def _dialogo(parent, titulo, aceitar=None, cancelar="Cancelar"):
    dialog = vestir(Gtk.Dialog(title=titulo, transient_for=parent, modal=True))
    if cancelar:
        dialog.add_button(cancelar, Gtk.ResponseType.CANCEL)
    if aceitar:
        ok = dialog.add_button(aceitar, Gtk.ResponseType.ACCEPT)
        com_classes(ok, "primario")
        dialog.set_default_response(Gtk.ResponseType.ACCEPT)
    return dialog


def ask(parent, title, fields, accept="Salvar", max_length=0):
    """Diálogo com entradas; devolve lista de textos ou None."""
    dialog = _dialogo(parent, title, accept)
    grid = Gtk.Grid(row_spacing=12, column_spacing=12, border_width=24)
    entries = []
    for row, (caption, initial) in enumerate(fields):
        grid.attach(rotulo(caption), 0, row, 1, 1)
        widget = Gtk.Entry(text=initial or "")
        widget.set_width_chars(36)
        widget.set_activates_default(True)
        if max_length:
            widget.set_max_length(max_length)
        grid.attach(widget, 1, row, 1, 1)
        entries.append(widget)
    dialog.get_content_area().add(grid)
    dialog.show_all()
    response = dialog.run()
    values = [widget.get_text() for widget in entries]
    dialog.destroy()
    return values if response == Gtk.ResponseType.ACCEPT else None


def confirm(parent, title, body, accept):
    dialog = vestir(Gtk.MessageDialog(transient_for=parent, modal=True, message_type=Gtk.MessageType.QUESTION,
                                      buttons=Gtk.ButtonsType.NONE, text=title))
    if body:
        dialog.format_secondary_text(body)
    dialog.add_button("Cancelar", Gtk.ResponseType.CANCEL)
    com_classes(dialog.add_button(accept, Gtk.ResponseType.ACCEPT), "primario")
    response = dialog.run()
    dialog.destroy()
    return response == Gtk.ResponseType.ACCEPT


def notice(parent, text, error=False, secondary=None):
    dialog = vestir(Gtk.MessageDialog(transient_for=parent, modal=True,
                                      message_type=Gtk.MessageType.ERROR if error else Gtk.MessageType.INFO,
                                      buttons=Gtk.ButtonsType.OK, text=text))
    if secondary:
        dialog.format_secondary_text(secondary)
    dialog.run()
    dialog.destroy()


def dialogo_texto(parent, titulo, explicacao, aceitar, placeholder="", limite=MAX_CHAT, obrigatorio=True):
    """Texto de várias linhas com contador. None = cancelou."""
    dialog = _dialogo(parent, titulo, aceitar)
    dialog.set_default_size(460, -1)
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, border_width=20)
    if explicacao:
        box.pack_start(rotulo(explicacao, "fraco"), False, False, 0)
    view = Gtk.TextView()
    view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
    view.set_accepts_tab(False)
    view.set_left_margin(8)
    view.set_right_margin(8)
    view.set_top_margin(6)
    view.set_bottom_margin(6)
    com_classes(view, "campo")
    scroller = Gtk.ScrolledWindow()
    scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    scroller.set_shadow_type(Gtk.ShadowType.IN)
    scroller.set_size_request(-1, 96)
    scroller.add(view)
    box.pack_start(scroller, True, True, 0)
    contador = rotulo(f"0/{limite}", "legenda", xalign=1)
    box.pack_start(contador, False, False, 0)
    buffer = view.get_buffer()
    if placeholder:
        view.set_tooltip_text(placeholder)
    ok = dialog.get_widget_for_response(Gtk.ResponseType.ACCEPT)

    def mudou(*_):
        texto = buffer.get_text(buffer.get_start_iter(), buffer.get_end_iter(), True)
        if len(texto) > limite:
            buffer.set_text(texto[:limite])
            return
        contador.set_text(f"{len(texto)}/{limite}")
        if ok is not None and obrigatorio:
            ok.set_sensitive(bool(texto.strip()))
    buffer.connect("changed", mudou)
    mudou()
    dialog.get_content_area().add(box)
    dialog.show_all()
    view.grab_focus()
    response = dialog.run()
    texto = buffer.get_text(buffer.get_start_iter(), buffer.get_end_iter(), True).strip()
    dialog.destroy()
    return texto if response == Gtk.ResponseType.ACCEPT else None


def dialogo_recusar(parent):
    """"Recusar o pedido?" com "Motivo (opcional)". None = cancelou."""
    dialog = _dialogo(parent, "Recusar o pedido?", "Recusar")
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, border_width=20)
    box.pack_start(rotulo("Recusar o pedido?", "subtitulo"), False, False, 0)
    box.pack_start(rotulo("Motivo (opcional)", "fraco"), False, False, 0)
    entry = Gtk.Entry()
    entry.set_max_length(protocol.MAX_PEDIDO_MOTIVO)
    entry.set_width_chars(40)
    entry.set_placeholder_text("Por exemplo: depois da prova")
    entry.set_activates_default(True)
    box.pack_start(entry, False, False, 0)
    dialog.get_content_area().add(box)
    dialog.show_all()
    response = dialog.run()
    motivo = entry.get_text().strip()
    dialog.destroy()
    return motivo if response == Gtk.ResponseType.ACCEPT else None


def notificar(titulo, corpo):
    """notify-send na sessão do professor. O xfce4-notifyd interpreta markup no
    corpo: passa por GLib.markup_escape_text (SPEC-turma §3.6)."""
    corpo = GLib.markup_escape_text(corpo or "")

    def enviar():
        try:
            # "--": o título é o nome do PC (vem da rede) e não pode virar opção.
            subprocess.run(["notify-send", "-a", "Controle do Professor", "-i", "computer", "--", titulo or "", corpo],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10, check=False)
        except (OSError, subprocess.SubprocessError):
            pass
    threading.Thread(target=enviar, daemon=True).start()


# ---- faixas e aviso flutuante -----------------------------------------------------------


class Faixa(Gtk.Revealer):
    """Faixa do topo da aula: ícone, texto, "Ver detalhes" (popover com uma
    linha por PC) e, na de entrega, o fechar."""

    def __init__(self, estado=False, fechar=None):
        super().__init__()
        self.set_transition_type(Gtk.RevealerTransitionType.NONE)
        self.box = com_classes(Gtk.Box(spacing=10), "faixa")
        if estado:
            com_classes(self.box, "estado")
        self.spinner = Gtk.Spinner()
        self.icone = Gtk.Image()
        self.box.pack_start(self.spinner, False, False, 0)
        self.box.pack_start(self.icone, False, False, 0)
        self.texto = rotulo("", "texto-faixa")
        self.box.pack_start(self.texto, True, True, 0)
        self.detalhes = botao("Ver detalhes", "link-acao")
        self.detalhes.set_valign(Gtk.Align.CENTER)
        self.detalhes.connect("clicked", self._abrir_detalhes)
        self.box.pack_start(self.detalhes, False, False, 0)
        self.fechar = None
        if fechar is not None:
            self.fechar = botao_icone("window-close-symbolic", "Fechar", fechar)
            self.box.pack_start(self.fechar, False, False, 0)
        self.add(self.box)
        self.linhas = lambda: []
        self._assinatura = None
        # Escondida de verdade (não só recolhida): recolhida, o espaçamento
        # da caixa de cima ainda contaria. show_all() da janela não a mostra.
        self.set_reveal_child(True)
        self.box.show_all()
        self.set_no_show_all(True)
        self.hide()

    def mostrar(self, texto, icone=None, ocupado=False, linhas=None):
        if icone and not ocupado and texto.startswith("✓ "):
            texto = texto[2:]  # o ícone já é o ✓
        assinatura = (texto, icone, ocupado)
        if assinatura != self._assinatura:
            self._assinatura = assinatura
            self.texto.set_text(texto)
            self.spinner.set_visible(ocupado)
            if ocupado:
                self.spinner.start()
            else:
                self.spinner.stop()
            self.icone.set_visible(bool(icone) and not ocupado)
            if icone:
                self.icone.set_from_icon_name(icone, Gtk.IconSize.BUTTON)
        self.linhas = linhas or (lambda: [])
        self.detalhes.set_visible(linhas is not None)
        self.show()

    def esconder(self):
        self.hide()
        self._assinatura = None

    def _abrir_detalhes(self, button):
        popover = Gtk.Popover.new(button)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, border_width=12)
        linhas = self.linhas() or ["Nenhum computador nesta entrega."]
        for linha in linhas:
            box.pack_start(rotulo(linha, max_chars=60), False, False, 0)
        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroller.set_propagate_natural_height(True)
        scroller.set_max_content_height(360)
        scroller.add(box)
        popover.add(scroller)
        popover.show_all()
        popover.popup()


class AvisoFlutuante(Gtk.Revealer):
    """Aviso curto no rodapé da página (o "snackbar"), com uma ação."""

    def __init__(self):
        super().__init__()
        self.set_transition_type(Gtk.RevealerTransitionType.NONE)
        self.set_halign(Gtk.Align.CENTER)
        self.set_valign(Gtk.Align.END)
        box = com_classes(Gtk.Box(spacing=12), "aviso-flutuante")
        self.texto = rotulo("", wrap=False)
        box.pack_start(self.texto, True, True, 0)
        self.acao = botao("", "link-acao")
        self.acao.connect("clicked", self._clicou)
        box.pack_start(self.acao, False, False, 0)
        box.pack_start(botao_icone("window-close-symbolic", "Fechar", self.esconder), False, False, 0)
        self.add(box)
        self._fazer = None
        self._timer = None
        # Escondido de verdade: recolhido, o GTK ainda aloca a caixa com 1 px.
        self.set_reveal_child(True)
        box.show_all()
        self.set_no_show_all(True)
        self.hide()

    def mostrar(self, texto, acao=None, fazer=None):
        self.texto.set_text(texto)
        self._fazer = fazer
        if acao:
            self.acao.set_label(acao)
        self.acao.set_visible(bool(acao))
        self.show()
        if self._timer is not None:
            GLib.source_remove(self._timer)
        self._timer = GLib.timeout_add_seconds(AVISO_S, self._venceu)

    def _venceu(self):
        self._timer = None
        self.hide()
        return False

    def esconder(self):
        if self._timer is not None:
            GLib.source_remove(self._timer)
            self._timer = None
        self.hide()

    def _clicou(self, *_):
        fazer, self._fazer = self._fazer, None
        self.esconder()
        if fazer is not None:
            fazer()


# ---- "Olhos em mim" ---------------------------------------------------------------------


class TravaPopover(Gtk.Popover):
    """Título, presets (tocar já trava a aula toda), texto personalizado,
    "Silenciar o som" ligado por padrão e "Escolher computadores"."""

    def __init__(self, relative, controller, travar):
        super().__init__()
        self.set_relative_to(relative)
        self.controller = controller
        self.travar = travar  # travar(texto, mute, apenas)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, border_width=16)
        box.set_size_request(340, -1)
        box.pack_start(rotulo("Travar as telas da turma", "subtitulo"), False, False, 0)
        box.pack_start(rotulo("Os alunos veem o aviso em tela cheia até você destravar.", "fraco", "compacto"),
                       False, False, 4)
        self.presets = []
        for texto in TRAVA_PRESETS:
            preset = botao(texto, "tonal", icone="view-reveal-symbolic",
                           ao_clicar=lambda texto=texto: self._travar(texto))
            preset.get_child().set_halign(Gtk.Align.START)
            box.pack_start(preset, False, False, 0)
            self.presets.append(preset)
        self.personalizado = botao("Texto personalizado…", "link-acao", ao_clicar=self._abrir_personalizado)
        self.personalizado.set_halign(Gtk.Align.START)
        box.pack_start(self.personalizado, False, False, 0)
        self.campo_revealer = Gtk.Revealer()
        linha = Gtk.Box(spacing=8)
        self.campo = com_classes(Gtk.Entry(), "campo")
        self.campo.set_max_length(protocol.MAX_TRAVA_TEXTO)
        self.campo.set_placeholder_text("Escreva o aviso…")
        self.campo.connect("activate", lambda *_: self._travar_personalizado())
        linha.pack_start(self.campo, True, True, 0)
        linha.pack_start(botao("Travar", "primario", ao_clicar=self._travar_personalizado), False, False, 0)
        self.campo_revealer.add(linha)
        box.pack_start(self.campo_revealer, False, False, 0)
        box.pack_start(Gtk.Separator(), False, False, 4)
        som = Gtk.Box(spacing=12)
        som.pack_start(rotulo("Silenciar o som"), True, True, 0)
        self.mute = Gtk.Switch(active=True)
        self.mute.set_valign(Gtk.Align.CENTER)
        som.pack_start(self.mute, False, False, 0)
        box.pack_start(som, False, False, 0)
        self.escolher = botao("Escolher computadores", "link-acao", ao_clicar=self._abrir_escolha)
        self.escolher.set_halign(Gtk.Align.START)
        box.pack_start(self.escolher, False, False, 0)
        self.escolha_revealer = Gtk.Revealer()
        escolha = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.lista = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroller.set_propagate_natural_height(True)
        scroller.set_max_content_height(220)
        scroller.add(self.lista)
        escolha.pack_start(scroller, False, False, 0)
        self.travar_escolhidos = botao("Travar 0 computadores", "primario", ao_clicar=self._travar_escolhidos)
        escolha.pack_start(self.travar_escolhidos, False, False, 0)
        self.escolha_revealer.add(escolha)
        box.pack_start(self.escolha_revealer, False, False, 0)
        self.add(box)
        box.show_all()
        self.checks = {}

    def abrir(self):
        self.campo_revealer.set_reveal_child(False)
        self.escolha_revealer.set_reveal_child(False)
        self.campo.set_text("")
        self.mute.set_active(True)
        self.popup()

    def _abrir_personalizado(self):
        self.campo_revealer.set_reveal_child(True)
        self.campo.grab_focus()

    def _abrir_escolha(self):
        limpar(self.lista)
        self.checks = {}
        for device_id in self.controller.alvo_turma():
            check = Gtk.CheckButton(active=True)
            check.add(rotulo(self.controller.nome_do_pc(device_id), wrap=False))
            check.connect("toggled", lambda *_: self._contar())
            self.lista.pack_start(check, False, False, 0)
            self.checks[device_id] = check
        self.lista.show_all()
        self._contar()
        self.escolha_revealer.set_reveal_child(True)

    def _contar(self):
        n = sum(1 for check in self.checks.values() if check.get_active())
        self.travar_escolhidos.set_label(f"Travar {n} {plural(n, 'computador', 'computadores')}")
        self.travar_escolhidos.set_sensitive(n > 0)

    def _texto(self):
        return self.campo.get_text().strip() or TRAVA_PRESETS[0]

    def _travar(self, texto, apenas=None):
        self.popdown()
        self.travar(texto, self.mute.get_active(), apenas)

    def _travar_personalizado(self):
        if self.campo.get_text().strip():
            self._travar(self.campo.get_text().strip())
        else:
            self.campo.grab_focus()

    def _travar_escolhidos(self):
        escolhidos = [d for d, check in self.checks.items() if check.get_active()]
        if escolhidos:
            self._travar(self._texto(), escolhidos)


# ---- Recados --------------------------------------------------------------------------


class RecadosPopover(Gtk.Popover):
    """Pedidos de liberação, mãos levantadas e conversas (SPEC-turma §4.4)."""

    def __init__(self, relative, page):
        super().__init__()
        self.set_relative_to(relative)
        self.page = page
        self.controller = page.controller
        self.scroller = Gtk.ScrolledWindow()
        self.scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.scroller.set_propagate_natural_height(True)
        self.scroller.set_max_content_height(560)
        self.scroller.set_size_request(420, -1)
        self.conteudo = com_classes(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, border_width=12),
                                    "recados")
        self.scroller.add(self.conteudo)
        self.add(self.scroller)
        self.scroller.show_all()
        self._assinatura = None
        self.connect("notify::visible", lambda *_: self.atualizar(forcar=True) if self.get_visible() else None)

    def _dados(self):
        c = self.controller
        pedidos = c.pedidos_pendentes()
        maos = c.maos_levantadas()
        conversas = c.conversas()
        silenciados = c.pcs_silenciados()
        assinatura = (
            [(p.device_id, p.site, p.motivo, p.ts, p.bloqueio, c.nome_do_pc(p.device_id)) for p in pedidos],
            [(m["id"], m["name"], m["ts"]) for m in maos],
            [(r["id"], r["name"], r["previa"], r["ts"], r["nao_lidas"]) for r in conversas],
            [(s["id"], s["name"]) for s in silenciados],
        )
        return pedidos, maos, conversas, silenciados, assinatura

    def atualizar(self, forcar=False):
        if not self.get_visible() and not forcar:
            return
        pedidos, maos, conversas, silenciados, assinatura = self._dados()
        if assinatura == self._assinatura and not forcar:
            return
        self._assinatura = assinatura
        limpar(self.conteudo)
        self.conteudo.pack_start(rotulo("Recados", "titulo"), False, False, 0)
        if not (pedidos or maos or conversas or silenciados):
            vazio = rotulo("Nenhum recado dos alunos agora.", "fraco")
            vazio.set_margin_top(8)
            vazio.set_margin_bottom(8)
            self.conteudo.pack_start(vazio, False, False, 0)
        if pedidos:
            self.conteudo.pack_start(rotulo(f"Pedidos de liberação ({len(pedidos)})", "secao"), False, False, 0)
            for pedido in pedidos:
                self.conteudo.pack_start(self._pedido(pedido), False, False, 0)
        if maos:
            self.conteudo.pack_start(rotulo(f"Mãos levantadas ({len(maos)})", "secao"), False, False, 0)
            for mao in maos:
                self.conteudo.pack_start(self._mao(mao), False, False, 0)
        if conversas or silenciados:
            self.conteudo.pack_start(rotulo(f"Conversas ({len(conversas)})", "secao"), False, False, 0)
            for conversa in conversas:
                self.conteudo.pack_start(self._conversa(conversa), False, False, 0)
            for silenciado in silenciados:
                linha = Gtk.Box(spacing=12)
                linha.pack_start(avatar(silenciado["name"], online=False, pequeno=True), False, False, 0)
                textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
                textos.pack_start(rotulo(silenciado["name"], "forte"), False, False, 0)
                textos.pack_start(rotulo(upr.TEXTO_SILENCIADO, "fraco", "compacto"), False, False, 0)
                linha.pack_start(textos, True, True, 0)
                self.conteudo.pack_start(linha, False, False, 0)
        self.conteudo.show_all()

    def _pedido(self, pedido):
        card = com_classes(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4), "pedido")
        nome = self.controller.nome_do_pc(pedido.device_id)
        topo = Gtk.Box(spacing=8)
        topo.pack_start(rotulo(f"{nome} · {hora(pedido.ts)}", "legenda"), True, True, 0)
        if pedido.bloqueio == "prova":
            topo.pack_start(chip("Na prova", "neutro"), False, False, 0)
        card.pack_start(topo, False, False, 0)
        card.pack_start(rotulo(pedido.site, "subtitulo"), False, False, 0)
        if pedido.motivo:
            card.pack_start(rotulo(f"“{pedido.motivo}”", "motivo", "fraco"), False, False, 0)
        acoes = Gtk.Box(spacing=8)
        acoes.set_halign(Gtk.Align.END)
        acoes.set_margin_top(4)
        acoes.pack_start(botao("Recusar", "link-acao", ao_clicar=lambda: self.page.recusar_pedido(pedido)),
                         False, False, 0)
        acoes.pack_start(botao("Liberar", "tonal", icone="changes-allow-symbolic",
                               ao_clicar=lambda: self.page.liberar_pedido(pedido)), False, False, 0)
        card.pack_start(acoes, False, False, 0)
        return card

    def _mao(self, mao):
        linha = Gtk.Box(spacing=12)
        linha.pack_start(rotulo("✋", "avatar", "pequeno", xalign=0.5, wrap=False), False, False, 0)
        linha.pack_start(rotulo(f"{mao['name']} levantou a mão · {hora(mao['ts'])}"), True, True, 0)
        baixar = botao("Baixar", "link-acao", ao_clicar=lambda: self.page.baixar_mao(mao["id"]))
        baixar.set_valign(Gtk.Align.CENTER)
        linha.pack_start(baixar, False, False, 0)
        return linha

    def _conversa(self, conversa):
        button = com_classes(Gtk.Button(), "item-conversa")
        linha = Gtk.Box(spacing=12)
        linha.pack_start(avatar(conversa["name"], pequeno=True), False, False, 0)
        textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        textos.pack_start(rotulo(conversa["name"], "forte", wrap=False, ellipsize=True), False, False, 0)
        textos.pack_start(rotulo(conversa["previa"], "fraco", "compacto", ellipsize=True, max_chars=40),
                          False, False, 0)
        linha.pack_start(textos, True, True, 0)
        lado = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        lado.pack_start(rotulo(hora(conversa["ts"]), "legenda", xalign=1, wrap=False), False, False, 0)
        if conversa["nao_lidas"]:
            badge = rotulo(str(conversa["nao_lidas"]), "contador", xalign=0.5, wrap=False)
            badge.set_halign(Gtk.Align.END)
            lado.pack_start(badge, False, False, 0)
        linha.pack_start(lado, False, False, 0)
        button.add(linha)
        button.connect("clicked", lambda *_: (self.popdown(), self.page.abrir_conversa(conversa["id"])))
        return button


# ---- janela de conversa ---------------------------------------------------------------


class ConversaJanela(Gtk.Window):
    """"Conversa — {nome}": não modal, 360×480, uma por PC (SPEC-turma §3.6)."""

    LARGURA, ALTURA, MARGEM = 360, 480, 16

    def __init__(self, parent, controller, device_id, ao_fechar, ordem=0):
        super().__init__(title="Conversa")
        vestir(self)
        com_classes(self, "conversa")
        self.set_transient_for(parent)
        self.set_destroy_with_parent(True)
        self.set_default_size(self.LARGURA, self.ALTURA)
        self._encostar(parent, ordem)
        self.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self.controller = controller
        self.device_id = device_id
        self._assinatura = None
        self._enviando = False
        self.connect("destroy", lambda *_: ao_fechar(device_id))
        self.connect("notify::is-active", self._ativa)

        raiz = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        topo = com_classes(Gtk.Box(spacing=12), "conversa-topo")
        self.avatar_box = Gtk.Box()
        topo.pack_start(self.avatar_box, False, False, 0)
        textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        textos.set_valign(Gtk.Align.CENTER)
        self.nome = rotulo("", "subtitulo", wrap=False, ellipsize=True)
        self.situacao = rotulo("", "legenda", wrap=False, ellipsize=True)
        textos.pack_start(self.nome, False, False, 0)
        textos.pack_start(self.situacao, False, False, 0)
        topo.pack_start(textos, True, True, 0)
        raiz.pack_start(topo, False, False, 0)

        self.mao_revealer = Gtk.Revealer()
        mao = com_classes(Gtk.Box(spacing=8), "mao-linha")
        self.mao_texto = rotulo("", "compacto")
        mao.pack_start(self.mao_texto, True, True, 0)
        mao.pack_start(botao("Baixar", "link-acao", ao_clicar=self._baixar_mao), False, False, 0)
        self.mao_revealer.add(mao)
        raiz.pack_start(self.mao_revealer, False, False, 0)

        self.scroller = Gtk.ScrolledWindow()
        self.scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.bolhas = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, border_width=12)
        self.bolhas.set_valign(Gtk.Align.END)
        self.scroller.add(self.bolhas)
        self.scroller.get_vadjustment().connect("changed", self._rolar_se_no_fim)
        self._no_fim = True
        self.scroller.get_vadjustment().connect("value-changed", self._guardar_posicao)
        raiz.pack_start(self.scroller, True, True, 0)

        rodape = com_classes(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6), "rodape")
        linha = Gtk.Box(spacing=8)
        self.campo = com_classes(Gtk.Entry(), "campo")
        self.campo.set_max_length(MAX_CHAT)
        self.campo.set_placeholder_text("Escreva uma mensagem…")
        self.campo.connect("activate", lambda *_: self._enviar())
        self.campo.connect("changed", lambda *_: self._botao_enviar())
        linha.pack_start(self.campo, True, True, 0)
        self.enviar = Gtk.Button.new_from_icon_name("mail-send-symbolic", Gtk.IconSize.BUTTON)
        com_classes(self.enviar, "enviar")
        self.enviar.set_tooltip_text("Enviar")
        self.enviar.connect("clicked", lambda *_: self._enviar())
        linha.pack_start(self.enviar, False, False, 0)
        rodape.pack_start(linha, False, False, 0)
        self.erro = rotulo("", "legenda")
        rodape.pack_start(self.erro, False, False, 0)
        raiz.pack_start(rodape, False, False, 0)
        self.add(raiz)
        self.show_all()
        self.erro.hide()
        self._botao_enviar()
        self.atualizar()
        self.campo.grab_focus()

    def _encostar(self, parent, ordem):
        """Como um chat flutuante: no canto inferior direito da janela do
        professor; a segunda conversa abre à esquerda da primeira."""
        if parent is None or not parent.get_visible():
            return
        px, py = parent.get_position()
        pw, ph = parent.get_size()
        x = px + pw - (self.LARGURA + self.MARGEM) * (ordem + 1)
        y = py + ph - self.ALTURA - self.MARGEM
        self.move(max(0, x), max(0, y))

    def _guardar_posicao(self, adj):
        self._no_fim = adj.get_value() >= adj.get_upper() - adj.get_page_size() - 24

    def _rolar_se_no_fim(self, adj):
        if self._no_fim:
            adj.set_value(adj.get_upper() - adj.get_page_size())

    def _ativa(self, *_):
        if self.is_active():
            self.controller.marcar_conversa_lida(self.device_id)

    def _botao_enviar(self):
        self.enviar.set_sensitive(bool(self.campo.get_text().strip()) and not self._enviando)

    def _enviar(self):
        texto = self.campo.get_text().strip()
        if not texto or self._enviando:
            return
        self._enviando = True
        self._no_fim = True
        self.campo.set_text("")
        self._botao_enviar()

        def feito(resultado):
            self._enviando = False
            self._botao_enviar()
            erro = texto_do_resultado(resultado)
            self.erro.set_visible(bool(erro))
            self.erro.set_text(erro or "")
            self.atualizar()
            return False
        run_async(lambda: self.controller.enviar_chat(self.device_id, texto), feito)

    def _baixar_mao(self):
        run_async(lambda: self.controller.baixar_mao(self.device_id), lambda *_: False)

    def atualizar(self):
        c = self.controller
        # Mensagem que chega com a conversa em foco já foi vista.
        if self.is_active() and c.nao_lidas_de(self.device_id):
            c.marcar_conversa_lida(self.device_id)
        nome = c.nome_do_pc(self.device_id)
        row = next((r for r in c.pcs() if r["id"] == self.device_id), None)
        online = bool(row and row["online"])
        itens = c.conversa_de(self.device_id)
        maos = [m for m in c.maos_levantadas() if m["id"] == self.device_id]
        session = c._session(self.device_id)
        ext = session.ext_version if session else None
        assinatura = (nome, online, row and row["unit"], [(i.mid, i.estado, i.codigo_erro, i.texto) for i in itens],
                      [m["ts"] for m in maos])
        if assinatura == self._assinatura:
            return
        self._assinatura = assinatura
        self.set_title(f"Conversa — {nome}")
        limpar(self.avatar_box)
        self.avatar_box.pack_start(avatar(nome, online=online), False, False, 0)
        self.avatar_box.show_all()
        self.nome.set_text(nome)
        partes = [f"Unidade {row['unit']}"] if row and row["unit"] is not None and nome != f"Unidade {row['unit']}" else []
        partes.append("online" if online else "desligado")
        self.situacao.set_text(" · ".join(partes))
        if maos:
            self.mao_texto.set_text(f"✋ {nome} levantou a mão às {hora(maos[0]['ts'])}")
            self.mao_revealer.set_reveal_child(True)
        else:
            self.mao_revealer.set_reveal_child(False)
        limpar(self.bolhas)
        if not itens:
            vazio = rotulo("Nenhuma mensagem ainda. Escreva abaixo para falar com o aluno.", "fraco", xalign=0.5)
            vazio.set_margin_top(24)
            self.bolhas.pack_start(vazio, False, False, 0)
        for item in itens:
            self.bolhas.pack_start(self._bolha(item, ext), False, False, 0)
        self.bolhas.show_all()

    @staticmethod
    def _bolha(item, ext):
        if item.autor == upr.SISTEMA:
            return rotulo(item.texto, "sistema", xalign=0.5)
        minha = item.autor == upr.PROFESSOR
        linha = Gtk.Box()
        bolha = com_classes(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2), "bolha",
                            "minha" if minha else "dele")
        texto = rotulo(item.texto, "texto", max_chars=34)
        texto.set_selectable(True)
        bolha.pack_start(texto, False, False, 0)
        rodape = hora(item.ts)
        legenda = upr.legenda_do_balao(item, ext=ext) if minha else ""
        if legenda:
            rodape = f"{rodape} · {legenda}"
        bolha.pack_start(rotulo(rodape, "legenda", xalign=1 if minha else 0, max_chars=40), False, False, 0)
        if minha:
            linha.pack_end(bolha, False, False, 0)
            bolha.set_margin_start(40)
        else:
            linha.pack_start(bolha, False, False, 0)
            bolha.set_margin_end(40)
        return linha


# ---- grade de telas ---------------------------------------------------------------------


class Quadro(Gtk.Button):
    """Um PC na grade: imagem 16:10 `contain` sobre bg_sunken (ou o texto no
    lugar dela) e o rodapé com nome, ponto online e idade."""

    def __init__(self, estilo_app, ao_ampliar):
        super().__init__()
        com_classes(self, "quadro")
        self.estilo = estilo_app
        self.pixbuf = None
        self._chave_imagem = None
        self._escala = None
        self.esmaecida = False
        self.dados = None
        caixa = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        overlay = Gtk.Overlay()
        # 16:10 de borda a borda: a Grade ajusta a altura pela largura do
        # quadro (o AspectFrame deixaria faixas dos lados).
        self.area = Gtk.DrawingArea()
        self.area.set_size_request(TILE_MINIMO - 2, int((TILE_MINIMO - 2) / PROPORCAO))
        self.area.connect("draw", self._desenhar)
        overlay.add(self.area)
        self.placeholder = rotulo("", "fraco", "compacto", xalign=0.5, max_chars=24)
        self.placeholder.set_halign(Gtk.Align.CENTER)
        self.placeholder.set_valign(Gtk.Align.CENTER)
        self.placeholder.set_justify(Gtk.Justification.CENTER)
        overlay.add_overlay(self.placeholder)
        caixa.pack_start(overlay, True, True, 0)
        rodape = com_classes(Gtk.Box(spacing=8), "quadro-rodape")
        self.ponto = com_classes(Gtk.Box(), "ponto")
        self.ponto.set_valign(Gtk.Align.CENTER)
        rodape.pack_start(self.ponto, False, False, 0)
        self.nome = rotulo("", "forte", wrap=False, ellipsize=True)
        rodape.pack_start(self.nome, True, True, 0)
        self.idade = rotulo("", "legenda", wrap=False)
        rodape.pack_end(self.idade, False, False, 0)
        caixa.pack_start(rodape, False, False, 0)
        self.add(caixa)
        self.connect("clicked", lambda *_: ao_ampliar(self) if self.pixbuf is not None else None)

    def mostrar(self, dados, pixbuf):
        self.dados = dados
        estado = dados["estado"]
        self.nome.set_text(dados["name"] if dados["unit"] is None or dados["name"] == f"Unidade {dados['unit']}"
                           else f"{dados['name']} · Unidade {dados['unit']}")
        context = self.ponto.get_style_context()
        (context.add_class if dados["online"] else context.remove_class)("online")
        self.ponto.set_tooltip_text("online" if dados["online"] else "desligado")
        texto = estado.texto
        if dados.get("sem_prova") and estado.tem_imagem:
            self.idade.set_text(f"{estado.texto} · sem modo prova — versão antiga")
        else:
            self.idade.set_text(estado.texto if estado.tem_imagem else "")
        if dados.get("sem_prova") and not estado.tem_imagem:
            texto = f"{texto}\nsem modo prova — versão antiga"
        self.placeholder.set_text("" if estado.tem_imagem else texto)
        self.placeholder.set_visible(not estado.tem_imagem)
        self.set_tooltip_text("Ampliar" if pixbuf is not None else None)
        mudou = pixbuf is not self.pixbuf or estado.esmaecida != self.esmaecida
        self.pixbuf, self.esmaecida = pixbuf, estado.esmaecida
        if mudou:
            self._escala = None
            self.area.queue_draw()

    def _desenhar(self, area, cr):
        largura, altura = area.get_allocated_width(), area.get_allocated_height()
        Gdk.cairo_set_source_rgba(cr, self.estilo.cor("bg_sunken"))
        raio = 7  # o do quadro (8) menos a borda
        cr.new_sub_path()
        cr.arc(largura - raio, raio, raio, -1.5708, 0)
        cr.line_to(largura, altura)
        cr.line_to(0, altura)
        cr.arc(raio, raio, raio, 3.14159, 4.71239)
        cr.close_path()
        cr.fill()
        if self.pixbuf is None or largura < 2 or altura < 2:
            return False
        pw, ph = self.pixbuf.get_width(), self.pixbuf.get_height()
        escala = min(largura / pw, altura / ph)
        w, h = max(1, int(pw * escala)), max(1, int(ph * escala))
        if self._escala is None or self._escala.get_width() != w or self._escala.get_height() != h:
            self._escala = self.pixbuf.scale_simple(w, h, GdkPixbuf.InterpType.BILINEAR)
        Gdk.cairo_set_source_pixbuf(cr, self._escala, (largura - w) // 2, (altura - h) // 2)
        cr.paint_with_alpha(0.5 if self.esmaecida else 1.0)
        return False


def pixbuf_de_jpeg(jpeg: bytes):
    """Miniatura só em memória (nunca em disco). Cabeçalho que declara uma
    imagem enorme nem é decodificado; o resto é reduzido ao ler (≤ 960 px)."""
    if not jpeg_aceitavel(jpeg):
        return None
    try:
        loader = GdkPixbuf.PixbufLoader.new_with_type("jpeg")

        def limitar(loader, largura, altura):
            maior = max(largura, altura)
            if maior > MAX_LADO_EXIBIDO:
                escala = MAX_LADO_EXIBIDO / maior
                loader.set_size(max(1, int(largura * escala)), max(1, int(altura * escala)))
        loader.connect("size-prepared", limitar)
        loader.write(jpeg)
        loader.close()
        return loader.get_pixbuf()
    except GLib.Error:
        return None


class Grade(Gtk.ScrolledWindow):
    def __init__(self, parent, estilo_app):
        super().__init__()
        self.parent_window = parent
        self.estilo = estilo_app
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.flow = com_classes(Gtk.FlowBox(), "grade")
        self.flow.set_selection_mode(Gtk.SelectionMode.NONE)
        self.flow.set_homogeneous(True)
        self.flow.set_column_spacing(ESPACO_GRADE)
        self.flow.set_row_spacing(ESPACO_GRADE)
        self.flow.set_valign(Gtk.Align.START)
        self.flow.set_min_children_per_line(3)
        self.flow.set_max_children_per_line(3)
        caixa = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        caixa.pack_start(self.flow, False, False, 0)
        self.vazio = rotulo("", "fraco", xalign=0.5)
        self.vazio.set_margin_top(32)
        caixa.pack_start(self.vazio, False, False, 0)
        self.add(caixa)
        self.quadros = {}
        self.pixbufs = {}
        self.colunas = 3
        self.altura = int((TILE_MINIMO - 2) / PROPORCAO)
        self.connect("size-allocate", self._alocou)

    def _alocou(self, _widget, allocation):
        colunas = colunas_da_grade(allocation.width)
        largura = (allocation.width - ESPACO_GRADE * (colunas - 1)) // colunas - 2
        altura = max(1, int(largura / PROPORCAO))
        if colunas != self.colunas or altura != self.altura:
            self.colunas, self.altura = colunas, altura
            GLib.idle_add(self._aplicar_colunas)

    def _aplicar_colunas(self):
        self.flow.set_min_children_per_line(self.colunas)
        self.flow.set_max_children_per_line(self.colunas)
        for quadro in self.quadros.values():
            quadro.area.set_size_request(-1, self.altura)
        return False

    def mostrar(self, quadros, motivo=None):
        ids = [q["id"] for q in quadros]
        for device_id in list(self.quadros):
            if device_id not in ids:
                quadro = self.quadros.pop(device_id)
                self.flow.remove(quadro.get_parent())
                self.pixbufs.pop(device_id, None)
        ordem = [q["id"] for q in quadros]
        if ordem != list(self.quadros):
            for quadro in self.quadros.values():
                self.flow.remove(quadro.get_parent())
            novos = {}
            for device_id in ordem:
                novos[device_id] = self.quadros.get(device_id) or Quadro(self.estilo, self._ampliar)
                novos[device_id].area.set_size_request(-1, self.altura)
                self.flow.add(novos[device_id])
            self.quadros = novos
        for dados in quadros:
            jpeg = dados["jpeg"]
            chave = (len(jpeg), hash(jpeg)) if jpeg else None
            atual = self.pixbufs.get(dados["id"])
            if chave is None:
                pixbuf = None
            elif atual is not None and atual[0] == chave:
                pixbuf = atual[1]
            else:
                pixbuf = pixbuf_de_jpeg(jpeg)
                self.pixbufs[dados["id"]] = (chave, pixbuf)
            self.quadros[dados["id"]].mostrar(dados, pixbuf)
        self.vazio.set_text(motivo or ("" if quadros else "Nenhum computador na aula."))
        self.vazio.set_visible(bool(motivo) or not quadros)
        self.flow.show_all()

    def esquecer_imagens(self):
        """Grade fechada: nenhuma tela de aluno fica na memória do app."""
        self.pixbufs.clear()
        for quadro in self.quadros.values():
            quadro.pixbuf, quadro._escala = None, None

    def _ampliar(self, quadro):
        dados = quadro.dados or {}
        janela = vestir(Gtk.Window(title=dados.get("name") or "Tela"))
        janela.set_transient_for(self.parent_window)
        janela.set_modal(True)
        janela.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        largura = max(480, int(self.parent_window.get_allocated_width() * 0.8))
        altura = max(300, int(self.parent_window.get_allocated_height() * 0.8))
        pw, ph = quadro.pixbuf.get_width(), quadro.pixbuf.get_height()
        escala = min(largura / pw, altura / ph, 3.0)
        imagem = Gtk.Image.new_from_pixbuf(quadro.pixbuf.scale_simple(max(1, int(pw * escala)), max(1, int(ph * escala)),
                                                                        GdkPixbuf.InterpType.BILINEAR))
        caixa = com_classes(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, border_width=16), "fundo")
        caixa.pack_start(imagem, True, True, 0)
        caixa.pack_start(rotulo(f"{dados.get('name', '')} · {dados['estado'].texto if dados else ''}", "legenda",
                                xalign=0.5), False, False, 0)
        evento = Gtk.EventBox()
        evento.add(caixa)
        evento.connect("button-press-event", lambda *_: janela.destroy())
        janela.connect("key-press-event", lambda _w, e: janela.destroy() if e.keyval == Gdk.KEY_Escape else None)
        janela.add(evento)
        janela.show_all()


def agora_ms() -> int:
    return int(time.time() * 1000)
