"""Canal up/ (aluno → professor) no app do professor: quem lê, quem apaga, o
que aparece em Recados e as legendas das conversas. Puro; espelho de
`up_router.dart` e `conversa.dart` do app (SPEC-turma §2.4–§2.7, §3.6, §4.4)."""

import re
import time
from urllib.parse import urlsplit

from .. import protocol
from ..up import limpar_texto, push_id_ms, site_valido
from .textos_erro import ERRO_ENVIO_LOCAL, texto_erro

IGNORAR = "ignorar"
MOSTRAR = "mostrar"
MOSTRAR_E_NOTIFICAR = "mostrarENotificar"

LIMITE_SILENCIO = 20
JANELA_SILENCIO_MS = 10 * protocol.MINUTO_MS
DURACAO_SILENCIO_MS = 10 * protocol.MINUTO_MS
TEXTO_SILENCIADO = "Muitas mensagens deste computador — silenciado por 10 min"

_MID_RE = re.compile(r"^[A-Za-z0-9_-]{1,32}$")


def destino_do_up(modo_escola: bool, reservado_por_outro: bool, reservado_por_mim: bool) -> str:
    """Sem escola: mostra e notifica. Na escola, PC reservado por outro é
    ignorado (nem decifra, nem apaga); reservado por mim mostra e notifica;
    PC livre aparece a todo MEMBRO, sem notificação."""
    if not modo_escola:
        return MOSTRAR_E_NOTIFICAR
    if reservado_por_outro:
        return IGNORAR
    if reservado_por_mim:
        return MOSTRAR_E_NOTIFICAR
    return MOSTRAR


def url_do_site(url: str, site: str) -> bool:
    """A URL do pedido é mesmo do site (igual ou subdomínio)? Sem isto um PC
    adulterado mostraria um site ao professor e liberaria outro."""
    if not url:
        return True
    try:
        parts = urlsplit(url)
    except ValueError:
        return False
    if parts.scheme not in ("http", "https"):
        return False
    host = (parts.hostname or "").lower()
    return host == site or host.endswith("." + site)


def url_para_casar(url: str, site: str) -> str:
    return url if url else f"https://{site}/"


def _numero(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return int(value)


def parse_up(message) -> dict | None:
    """Item do up/ já decifrado → {type, mid, sid, seq, ts, texto|site,url,
    motivo,bloqueio}; None = fora do protocolo (descartado calado)."""
    if not isinstance(message, dict):
        return None
    kind, mid = message.get("type"), message.get("mid")
    if kind not in protocol.UP_TYPES or not isinstance(mid, str) or not _MID_RE.match(mid):
        return None
    sid, seq, ts = _numero(message.get("sid")), _numero(message.get("seq")), _numero(message.get("ts"))
    if sid is None or seq is None or ts is None:
        return None
    payload = message.get("payload") if isinstance(message.get("payload"), dict) else {}
    item = {"type": kind, "mid": mid, "sid": sid, "seq": seq, "ts": ts}
    if kind == protocol.UP_CHAT:
        texto = limpar_texto(payload.get("texto"), protocol.MAX_CHAT_TEXTO)
        if not texto:
            return None
        item["texto"] = texto
    elif kind == protocol.UP_UNBLOCK:
        site = payload.get("site")
        if not site_valido(site):
            return None
        url = payload.get("url").strip() if isinstance(payload.get("url"), str) else ""
        if len(url) > protocol.MAX_PEDIDO_URL or not url_do_site(url, site):
            return None
        item.update({
            "site": site,
            "url": url,
            "motivo": limpar_texto(payload.get("motivo"), protocol.MAX_PEDIDO_MOTIVO),
            "bloqueio": "prova" if payload.get("bloqueio") == "prova" else "regra",
        })
    return item


class Chegada:
    def __init__(self, ler: bool, apagar=(), silenciou: bool = False):
        self.ler = ler
        self.apagar = list(apagar)
        # O PC acabou de passar do limite e ficou silenciado por 10 min.
        self.silenciou = silenciou


class UpRouter:
    """Teto de pendentes, silêncio por excesso, apagar o que passou de 12 h e
    deduplicar por (deviceId, mid)."""

    def __init__(self, max_pendentes: int = protocol.UP_MAX_ENTRADAS, limite_silencio: int = LIMITE_SILENCIO,
                 janela_silencio_ms: int = JANELA_SILENCIO_MS, duracao_silencio_ms: int = DURACAO_SILENCIO_MS,
                 idade_max_ms: int = protocol.UP_IDADE_MAX_PROFESSOR):
        self.max_pendentes = max_pendentes
        self.limite_silencio = limite_silencio
        self.janela_silencio_ms = janela_silencio_ms
        self.duracao_silencio_ms = duracao_silencio_ms
        self.idade_max_ms = idade_max_ms
        self._chaves = {}       # deviceId -> set de chaves presentes (ordem = push id)
        self._por_mid = {}      # deviceId -> mid -> {chaves}
        self._mid_da_chave = {}  # deviceId -> chave -> mid
        self._chegadas = {}     # deviceId -> [ms]
        self._silenciado_ate = {}

    def silenciado_ate(self, device_id: str, agora_ms: int):
        ate = self._silenciado_ate.get(device_id)
        return ate if ate is not None and agora_ms < ate else None

    def ao_chegar(self, device_id: str, key: str, agora_ms: int) -> Chegada:
        """Uma chave nova apareceu em up/ (antes de decifrar). Só para PCs cujo
        destino não é IGNORAR."""
        ms = push_id_ms(key)
        if ms is None:
            return Chegada(False)
        if ms < agora_ms - self.idade_max_ms:
            return Chegada(False, [key])  # PC morto: qualquer um apaga
        chaves = self._chaves.setdefault(device_id, set())
        # A mesma chave volta a cada reconexão do stream (put na raiz): não
        # conta de novo para o silêncio.
        nova = key not in chaves
        chaves.add(key)
        apagar = []
        while len(chaves) > self.max_pendentes:
            velha = min(chaves)
            chaves.discard(velha)
            # O mid fica ligado à chave até a remoção dela chegar: é ela que
            # tira de Recados o pedido/mão que já tinha sido lido.
            apagar.append(velha)
        ler = key in chaves
        silenciou = False
        corte = agora_ms - self.janela_silencio_ms
        if nova and ms >= corte:
            lista = [t for t in self._chegadas.get(device_id, []) if t >= corte] + [ms]
            self._chegadas[device_id] = lista
            if len(lista) > self.limite_silencio and self.silenciado_ate(device_id, agora_ms) is None:
                self._silenciado_ate[device_id] = agora_ms + self.duracao_silencio_ms
                silenciou = True
        if self.silenciado_ate(device_id, agora_ms) is not None:
            return Chegada(False, apagar, silenciou)
        return Chegada(ler, apagar)

    def ao_ler(self, device_id: str, key: str, mid: str) -> bool:
        """Item decifrado e validado. False = repetido (mesmo mid deste PC):
        não mostra de novo, mas a chave fica ligada ao mid para sair junto."""
        por_mid = self._por_mid.setdefault(device_id, {})
        ja = mid in por_mid
        por_mid.setdefault(mid, set()).add(key)
        self._mid_da_chave.setdefault(device_id, {})[key] = mid
        return not ja

    def ao_remover(self, device_id: str, key: str):
        """A chave sumiu de up/. Devolve o mid quando foi a última dele."""
        self._chaves.get(device_id, set()).discard(key)
        mid = self._mid_da_chave.get(device_id, {}).pop(key, None)
        if mid is None:
            return None
        chaves = self._por_mid.get(device_id, {}).get(mid)
        if chaves is not None:
            chaves.discard(key)
        if not chaves:
            self._por_mid.get(device_id, {}).pop(mid, None)
            return mid
        return None

    def chaves_de(self, device_id: str, mid: str) -> list:
        return sorted(self._por_mid.get(device_id, {}).get(mid, ()))

    def chaves_presentes(self, device_id: str) -> list:
        return sorted(self._chaves.get(device_id, ()))

    def limpar_pc(self, device_id: str):
        for tabela in (self._chaves, self._por_mid, self._mid_da_chave, self._chegadas, self._silenciado_ate):
            tabela.pop(device_id, None)


# ---- Conversas e Recados (em memória por PC; nada vai ao banco) -------------------

PROFESSOR = "professor"
ALUNO = "aluno"
SISTEMA = "sistema"

# Situação do balão do professor (legenda embaixo dele).
B_ENVIANDO = "enviando"
B_ENTREGUE = "entregue"
B_AGUARDANDO = "aguardando"      # PC desligado no envio; vira "entregue" no ack
B_NINGUEM = "ninguemLogado"      # ack sem_sessao: não fica para a próxima sessão
B_ERRO = "erro"
B_SEM_RESPOSTA = "semResposta"   # 25 s sem ack com o PC ligado


class ChatItem:
    def __init__(self, mid: str, autor: str, texto: str, ts: int, cmd_id: str | None = None,
                 estado: str | None = None, para_turma: bool = False, versao_antiga: bool = False):
        self.mid = mid
        self.autor = autor
        self.texto = texto
        self.ts = ts
        self.cmd_id = cmd_id
        self.estado = estado
        self.codigo_erro = None
        self.para_turma = para_turma
        self.versao_antiga = versao_antiga


def legenda_do_balao(item: ChatItem, ext: str | None = None) -> str:
    partes = []
    if item.estado == B_ENVIANDO:
        partes.append("Enviando…")
    elif item.estado == B_ENTREGUE:
        partes.append("✓ Entregue")
    elif item.estado == B_AGUARDANDO:
        partes.append("Aguardando (PC desligado)")
    elif item.estado == B_NINGUEM:
        partes.append("Ninguém logado — não entregue")
    elif item.estado == B_ERRO:
        partes.append(texto_erro(item.codigo_erro or ERRO_ENVIO_LOCAL, ext=ext))
    elif item.estado == B_SEM_RESPOSTA:
        partes.append("Não respondeu a tempo")
    if item.para_turma:
        partes.append("para a turma")
    if item.versao_antiga:
        partes.append("Versão antiga: o aluno não consegue responder")
    return " · ".join(partes)


class Pedido:
    """Pedido de liberação em Recados. Repetidos do mesmo PC para o mesmo site
    colapsam: hora e motivo do mais novo; todos os mids saem ao agir."""

    def __init__(self, device_id: str, mid: str, site: str, url: str, motivo: str, bloqueio: str, ts: int):
        self.device_id = device_id
        self.mid = mid
        self.site = site
        self.url = url
        self.motivo = motivo
        self.bloqueio = bloqueio
        self.ts = ts
        self.mids = {mid}

    def juntar(self, mid: str, url: str, motivo: str, bloqueio: str, ts: int):
        self.mids.add(mid)
        if ts >= self.ts:
            self.mid, self.url, self.motivo, self.bloqueio, self.ts = mid, url, motivo, bloqueio, ts


def hora_minuto(ms) -> str:
    try:
        return time.strftime("%H:%M", time.localtime(float(ms) / 1000))
    except (TypeError, ValueError, OverflowError, OSError):
        return ""
