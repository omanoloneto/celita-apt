"""Versões de um PC (meta/ext) e o portão dos recursos de turma. Puro;
espelho de `lib/src/util/versao.dart` do app (SPEC-turma §1.4)."""

import re

CELITA_PREFIXO = "celita-"
# Versões mínimas dos recursos de turma (chat, pedidos, trava, prova, grade,
# confirmação positiva) — docs/protocolo.md §8 "Recursos de turma".
TURMA_MINIMO_CELITA = "0.13.0"
TURMA_MINIMO_EXTENSAO = "0.7.0"
# Comandos que só o agente do Celita OS atende: num Chromebook o
# `tipo_desconhecido` deles não quer dizer "versão antiga".
COMANDOS_SO_CELITA = frozenset({"capture_screen", "liberar_ias", "atualizar"})


def versao_curta(ext) -> str | None:
    """"celita-0.10.0" → "0.10.0"; "0.4.11" → "0.4.11"; vazia → None."""
    texto = ext.strip() if isinstance(ext, str) else ""
    if texto.startswith(CELITA_PREFIXO):
        texto = texto[len(CELITA_PREFIXO):]
    return texto or None


def tem_celita(ext) -> bool:
    return isinstance(ext, str) and ext.strip().startswith(CELITA_PREFIXO)


def _partes(versao: str) -> list:
    return [int(p) for p in re.split(r"[^0-9]+", versao) if p]


def comparar_versoes(a: str, b: str) -> int:
    """-1, 0 ou 1; "1.9.0" < "1.10.0"; partes ausentes valem 0."""
    pa, pb = _partes(a or ""), _partes(b or "")
    for i in range(max(len(pa), len(pb))):
        x = pa[i] if i < len(pa) else 0
        y = pb[i] if i < len(pb) else 0
        if x != y:
            return -1 if x < y else 1
    return 0


def suporta_turma(ext) -> bool:
    """O PC entende os recursos de turma? Nulo/vazio = não se sabe = antigo."""
    texto = ext.strip() if isinstance(ext, str) else ""
    if not texto:
        return False
    if texto.startswith(CELITA_PREFIXO):
        pacote = texto[len(CELITA_PREFIXO):]
        return bool(pacote) and comparar_versoes(pacote, TURMA_MINIMO_CELITA) >= 0
    return comparar_versoes(texto, TURMA_MINIMO_EXTENSAO) >= 0
