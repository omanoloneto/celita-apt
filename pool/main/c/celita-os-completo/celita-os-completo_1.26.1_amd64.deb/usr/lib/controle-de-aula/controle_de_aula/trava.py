"""Olhos em mim no Celita: estado com prazo, cópia local e supervisor por nível.

O professor grava `state/lock` = set_lock {rev, on, texto, mute, ate}. O agente
guarda uma cópia (Storage `trava`) com o prazo em tempo de parede corrigido,
então um reboot sem rede volta travado e um professor que sumiu destrava
sozinho no prazo. O supervisor confere a cada 2 s, por nível, que o overlay
`trava-aluno` (serviço transitório do systemd com o uid do aluno, fora do
cgroup do agente) está de pé, com a janela mapeada, o som mudo e as teclas do
servidor desligadas; ao destravar, desfaz tudo.

`EstadoComPrazo` também serve à prova (`state/exam`, Storage `prova`).
"""

import json
import logging
import os
import subprocess
import threading
import time

from . import protocol

log = logging.getLogger("controle-de-aula.trava")

TRAVA_UNIT = "controle-de-aula-trava"
TRAVA_BIN = "/usr/lib/controle-de-aula/trava-aluno"
TRAVA_JSON = "/run/controle-de-aula/trava.json"
TRAVA_WM_CLASS = "trava-aluno"
TICK_S = 2
WINDOW_GRACE_S = 4
MUTE_CHECK_S = 5


def _numero_finito(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and value == value \
        and abs(value) != float("inf")


class EstadoComPrazo:
    """Estado vigente do professor com prazo local (trava e prova).

    `rev >= guardado` aplica; a reentrega do mesmo envelope (mesmo rev, `ate`
    e `ts`) mantém o prazo guardado, para um reboot ou reconexão não esticar
    a trava de quem sumiu. O prazo é `agora + clamp(ate − env.ts, 0, teto)`:
    os dois valores vêm do relógio do professor, então relógio errado no PC
    não muda a duração."""

    def __init__(self, storage, key: str, clock, teto_ms: int, clean):
        self.storage = storage
        self.key = key
        self.clock = clock
        self.teto_ms = teto_ms
        self.clean = clean
        self.lock = threading.RLock()

    def copia(self) -> dict:
        value = self.storage.get(self.key)
        return dict(value) if isinstance(value, dict) else {}

    def gravar(self, copia: dict | None):
        self.storage.set(self.key, copia or None)

    def aplicar(self, payload, env_ts) -> dict:
        estado = self.clean(payload)
        if estado is None:
            return {"ok": False, "error": "payload_invalido"}
        with self.lock:
            atual = self.copia()
            if atual and atual.get("rev", 0) > estado["rev"]:
                return {"ok": True}
            mesma_entrega = (atual.get("rev") == estado["rev"] and atual.get("ate") == estado["ate"]
                             and atual.get("ts") == env_ts)
            novo = {k: v for k, v in atual.items() if k in self.locais()}
            novo.update(estado)
            novo["ts"] = env_ts if isinstance(env_ts, (int, float)) else None
            if mesma_entrega and "prazoParede" in atual:
                novo["prazoParede"] = atual["prazoParede"]
            else:
                duracao = protocol.prazo_relativo(estado["ate"], env_ts, self.teto_ms) if estado["on"] else 0
                novo["prazoParede"] = self.clock.now_ms() + duracao if duracao else 0
            if estado["on"] and not self._efetivo(atual):
                novo["revLigar"] = estado["rev"]
            self.gravar(novo)
        return {"ok": True}

    def locais(self) -> tuple:
        """Chaves só do PC que sobrevivem a uma escrita nova do professor."""
        return ("revLigar",)

    def _efetivo(self, copia: dict) -> bool:
        return bool(copia.get("on")) and self.clock.now_ms() < (copia.get("prazoParede") or 0)

    def efetivo(self) -> bool:
        with self.lock:
            return self._efetivo(self.copia())

    def encerrar(self, ts=None):
        """Fim de aula: o prazo vence agora; o mesmo rev reentregue não religa.

        `ts` é o do comando (relógio de servidor do professor, como o `ts` do
        estado): um "Encerrar aula" que ficou na fila de um PC desligado não
        desliga a trava ou a prova que a aula seguinte gravou depois dele."""
        with self.lock:
            copia = self.copia()
            if _numero_finito(ts) and _numero_finito(copia.get("ts")) and copia["ts"] > ts:
                return
            if copia.get("on") and copia.get("prazoParede"):
                copia["prazoParede"] = 0
                self.gravar(copia)

    def limpar(self):
        with self.lock:
            self.gravar(None)


class Executor:
    """Efeitos de sistema do supervisor; os testes trocam por um falso."""

    def __init__(self, session_module=None, lister=None):
        if session_module is None:
            from . import session as session_module
        self.sess = session_module
        self._lister = lister

    def spawn(self, session) -> bool:
        return self.sess.spawn_unit(session, TRAVA_UNIT, [TRAVA_BIN], restart=True).get("ok") is True

    def active(self) -> bool:
        return self.sess.unit_active(TRAVA_UNIT)

    def unit_user(self):
        return self.sess.unit_user(TRAVA_UNIT)

    def stop(self):
        self.sess.stop_unit(TRAVA_UNIT)

    def restart(self):
        self.sess.restart_unit(TRAVA_UNIT)

    def window_mapped(self, session):
        lister = self._lister
        if lister is None:
            from .xwindows import LISTER as lister
        return lister.has_mapped(session, TRAVA_WM_CLASS)

    def _run(self, session, argv):
        try:
            return session.run(argv, timeout=10)
        except (OSError, subprocess.TimeoutExpired) as error:
            log.warning("%s: %s", argv[0], error)
            return None

    def get_mute(self, session):
        result = self._run(session, ["pactl", "get-sink-mute", "@DEFAULT_SINK@"])
        if result is None or result.returncode != 0:
            return None
        text = (result.stdout or b"").decode("utf-8", "replace").strip().lower()
        if text.endswith("yes") or text.endswith("sim"):
            return True
        if text.endswith("no") or text.endswith("não"):
            return False
        return None

    def set_mute(self, session, on: bool) -> bool:
        result = self._run(session, ["pactl", "set-sink-mute", "@DEFAULT_SINK@", "1" if on else "0"])
        ok = result is not None and result.returncode == 0
        if not ok:
            log.warning("pactl não mudou o som (a trava continua)")
        return ok

    def xkb_options(self, session):
        result = self._run(session, ["setxkbmap", "-query"])
        if result is None or result.returncode != 0:
            return None
        for line in (result.stdout or b"").decode("utf-8", "replace").splitlines():
            key, _, value = line.partition(":")
            if key.strip() == "options":
                return value.strip()
        return ""

    def set_srvrkeys_none(self, session) -> bool:
        result = self._run(session, ["setxkbmap", "-option", "srvrkeys:none"])
        return result is not None and result.returncode == 0

    def restore_xkb(self, session, options: str):
        argv = ["setxkbmap", "-option", ""]
        if options:
            argv += ["-option", options]
        self._run(session, argv)

    def write_text(self, texto: str):
        directory = os.path.dirname(TRAVA_JSON)
        temporary = TRAVA_JSON + ".tmp"
        try:
            os.makedirs(directory, mode=0o755, exist_ok=True)
            with open(temporary, "w", encoding="utf-8") as handle:
                json.dump({"texto": texto}, handle, ensure_ascii=False)
            os.chmod(temporary, 0o644)
            os.replace(temporary, TRAVA_JSON)
        except OSError as error:
            log.warning("texto da trava não foi gravado: %s", error)


class Trava(EstadoComPrazo):
    """Supervisor do overlay. `tick()` é idempotente e roda a cada 2 s."""

    def __init__(self, storage, clock, sessions, executor=None, on_change=None, monotonic=time.monotonic):
        super().__init__(storage, "trava", clock, protocol.TRAVA_TETO, protocol.clean_lock)
        self.sessions = sessions
        self.executor = executor or Executor()
        self.on_change = on_change
        self.monotonic = monotonic
        self._spawned_at = None
        self._window_seen_at = None
        self._mute_checked_at = None
        self._texto_escrito = None
        self._ultimo = None
        self._falhou = False
        self._sobra_conferida = False

    def locais(self) -> tuple:
        return ("revLigar", "aplicadoEm")

    # ---- consulta -----------------------------------------------------------------

    def travado(self) -> bool:
        """Tela travada agora (com alguém logado): o chat espera destravar."""
        return self.efetivo() and self.sessions.active() is not None

    def aplicado(self) -> dict:
        with self.lock:
            copia = self.copia()
            efetivo = self._efetivo(copia)
        item = {"rev": copia.get("rev") or 0, "on": False}
        if not efetivo:
            return item
        session = self.sessions.active()
        if session is None:
            item.update(on=True, erro="sem_sessao")  # armada: vale no próximo login
        else:
            aplicado = copia.get("aplicadoEm") or {}
            item["on"] = aplicado.get("sessao") == session.key and not self._falhou
        return item

    # ---- ciclo ------------------------------------------------------------------------

    def encerrar(self, ts=None):
        super().encerrar(ts)

    def limpar(self):
        """Desvincular: desfaz agora (overlay, som, teclas) e esquece a cópia."""
        with self.lock:
            copia = self.copia()
            self.gravar(None)
            if copia.get("on") or copia.get("aplicadoEm") or self._spawned_at is not None:
                self._desfazer(copia.get("aplicadoEm"), self.sessions.active())
        self._notificar(False)

    def tick(self):
        with self.lock:
            self._tick()

    def _tick(self):
        copia = self.copia()
        travar = self._efetivo(copia)
        session = self.sessions.active()
        aplicado = copia.get("aplicadoEm")
        self._restaurar_som_pendente(session, travar)

        if aplicado and (not travar or session is None or aplicado.get("sessao") != session.key):
            self._desfazer(aplicado, session)
            copia["aplicadoEm"] = None
            self.gravar(copia)
            aplicado = None

        if not travar or session is None:
            # Sem trava, nenhum fork a cada tique: só a sobra de antes de um
            # reinício do agente é conferida, uma vez.
            if self._spawned_at is not None or (not self._sobra_conferida and self.executor.active()):
                self.executor.stop()
                self._spawned_at = None
            self._sobra_conferida = True
            self._falhou = False
            self._notificar(False)
            return

        texto = copia.get("texto") or protocol.TRAVA_TEXTO_PADRAO
        if texto != self._texto_escrito:
            self.executor.write_text(texto)
            self._texto_escrito = texto

        now = self.monotonic()
        if aplicado is None:
            aplicado = self._aplicar_na_sessao(copia, session)
            copia["aplicadoEm"] = aplicado
            self.gravar(copia)
            self._iniciar(session, now)
        else:
            self._conferir(copia, aplicado, session, now)
        self._notificar(True)

    def _iniciar(self, session, now):
        self._sobra_conferida = True
        if self.executor.active():
            # Unidade de outra sessão (ou de antes de um reboot do agente). O
            # systemd-run recebe --uid=<número>, então o User= vem em número.
            if self.executor.unit_user() not in (session.user, str(session.uid)):
                self.executor.stop()
            else:
                self._spawned_at = now
                self._falhou = False
                return
        self._falhou = not self.executor.spawn(session)
        self._spawned_at = now
        self._window_seen_at = None

    def _aplicar_na_sessao(self, copia, session) -> dict:
        pendente = self.storage.get("travaSom")
        mutado_antes = None
        if copia.get("mute"):
            if isinstance(pendente, dict) and pendente.get("usuario") == session.user:
                # O som desta conta ficou mudo por nós num login anterior.
                mutado_antes = False
                self.storage.set("travaSom", None)
            else:
                mutado_antes = self.executor.get_mute(session)
            self.executor.set_mute(session, True)
        xkb = self.executor.xkb_options(session)
        if not self.executor.set_srvrkeys_none(session):
            log.warning("setxkbmap não desligou as teclas do servidor")
        self._mute_checked_at = self.monotonic()
        return {"sessao": session.key, "usuario": session.user, "mute": bool(copia.get("mute")),
                "mutadoAntes": mutado_antes, "xkbAntes": xkb}

    def _conferir(self, copia, aplicado, session, now):
        if not self.executor.active():
            log.info("overlay da trava fora do ar; subindo de novo")
            self._iniciar(session, now)
            return
        self._falhou = False
        mapped = self.executor.window_mapped(session)
        if mapped:
            self._window_seen_at = now
        elif mapped is False:
            since = max(self._window_seen_at or 0, self._spawned_at or 0)
            if now - since >= WINDOW_GRACE_S:
                log.info("janela da trava sumiu; reiniciando a unidade")
                self.executor.restart()
                self._spawned_at = now
        if bool(copia.get("mute")) != bool(aplicado.get("mute")):
            if copia.get("mute"):
                aplicado["mutadoAntes"] = self.executor.get_mute(session)
                self.executor.set_mute(session, True)
            elif aplicado.get("mutadoAntes") is False:
                self.executor.set_mute(session, False)
            aplicado["mute"] = bool(copia.get("mute"))
            copia["aplicadoEm"] = aplicado
            self.gravar(copia)
        elif copia.get("mute") and now - (self._mute_checked_at or 0) >= MUTE_CHECK_S:
            self._mute_checked_at = now
            if self.executor.get_mute(session) is False:
                self.executor.set_mute(session, True)

    def _desfazer(self, aplicado, session):
        if self._spawned_at is not None or self.executor.active():
            self.executor.stop()
        self._spawned_at = None
        if not aplicado:
            return
        mesma_sessao = session is not None and aplicado.get("sessao") == session.key
        if aplicado.get("mute") and aplicado.get("mutadoAntes") is False:
            if mesma_sessao:
                self.executor.set_mute(session, False)
            else:
                # Logout com a trava: o pulse guarda o mudo da conta; o próximo
                # login dela volta com som.
                self.storage.set("travaSom", {"usuario": aplicado.get("usuario")})
        if mesma_sessao and aplicado.get("xkbAntes") is not None:
            self.executor.restore_xkb(session, aplicado["xkbAntes"])

    def _restaurar_som_pendente(self, session, travar):
        pendente = self.storage.get("travaSom")
        if not isinstance(pendente, dict) or session is None or travar:
            return
        if pendente.get("usuario") == session.user:
            self.executor.set_mute(session, False)
            self.storage.set("travaSom", None)

    def _notificar(self, travado: bool):
        if travado != self._ultimo:
            self._ultimo = travado
            if self.on_change:
                try:
                    self.on_change(travado)
                except Exception as error:  # noqa: BLE001
                    log.warning("aviso da trava falhou: %s", error)
