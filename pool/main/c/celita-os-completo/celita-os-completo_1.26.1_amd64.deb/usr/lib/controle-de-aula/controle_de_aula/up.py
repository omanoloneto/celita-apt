"""Canal up/ (aluno → professor): ids, pushIds, sites e payloads. Puro, sem
rede; espelho de up.js (extensão) e up_router.dart (app)."""

import base64
import re
import secrets
import unicodedata
from urllib.parse import urlsplit

from . import protocol

PUSH_CHARS = "-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz"
_PUSH_INDEX = {char: index for index, char in enumerate(PUSH_CHARS)}
ID_RE = re.compile(r"^[A-Za-z0-9_-]{16}$")
SITE_RE = re.compile(r"^[a-z0-9.-]{1,100}$")
# Sufixos públicos que nunca valem como site: liberar "com.br" liberaria tudo.
SUFIXOS_PUBLICOS = frozenset({
    "com", "br", "net", "org", "edu", "gov", "com.br", "net.br", "org.br", "edu.br", "gov.br",
    "app", "dev", "io",
})
BLOQUEIOS = ("regra", "prova")
PREFIXOS_PROFESSOR = ("professora", "professor", "profa.", "profa", "prof.", "prof")


def new_id() -> str:
    """12 bytes aleatórios em base64url: 16 caracteres, opaco para quem recebe."""
    return base64.urlsafe_b64encode(secrets.token_bytes(12)).decode("ascii")


def id_valido(value) -> bool:
    return isinstance(value, str) and bool(ID_RE.match(value))


def push_id_ms(key) -> int | None:
    """Os 8 primeiros caracteres de um pushId são o ms do servidor."""
    if not isinstance(key, str) or len(key) < 8:
        return None
    value = 0
    for char in key[:8]:
        index = _PUSH_INDEX.get(char)
        if index is None:
            return None
        value = value * 64 + index
    return value


def make_push_id(ms: int, suffix: str = "AAAAAAAAAAAA") -> str:
    """O inverso de push_id_ms; útil em testes e na poda."""
    chars = []
    for _ in range(8):
        chars.append(PUSH_CHARS[ms % 64])
        ms //= 64
    return "".join(reversed(chars)) + suffix


def site_valido(site) -> bool:
    if not isinstance(site, str) or not SITE_RE.match(site):
        return False
    labels = site.split(".")
    if len(labels) < 2 or any(not label for label in labels):
        return False
    return site not in SUFIXOS_PUBLICOS


def host_da_url(url) -> str | None:
    if not protocol.is_safe_http_url(url):
        return None
    try:
        host = (urlsplit(url).hostname or "").lower()
    except ValueError:
        return None
    return host or None


# Sobrescritas e isolamentos bidirecionais: viram o texto de trás para a
# frente na tela de quem lê (o ZWJ dos emojis fica).
_BIDI = frozenset("\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069")


def _caractere_ok(c: str) -> bool:
    if c == "\n":
        return True
    # Cc: controles C0/C1; Cs: surrogate solto (não vira UTF-8 no socket).
    return unicodedata.category(c) not in ("Cc", "Cs") and c not in _BIDI


def limpar_texto(value, limite: int) -> str:
    """Corta em code points e tira controles, surrogates soltos e sobrescritas
    bidirecionais (a quebra de linha fica)."""
    if not isinstance(value, str):
        return ""
    limpo = "".join(c for c in value if _caractere_ok(c))
    return limpo.strip()[:limite]


def limpar_payload(tipo, payload):
    """Payload pronto para selar, ou None quando não vale (quem envia corta;
    o professor revalida do mesmo jeito)."""
    payload = payload if isinstance(payload, dict) else {}
    if tipo == protocol.UP_CHAT:
        texto = limpar_texto(payload.get("texto"), protocol.MAX_CHAT_TEXTO)
        return {"texto": texto} if texto else None
    if tipo == protocol.UP_UNBLOCK:
        site = payload.get("site")
        url = payload.get("url")
        if not site_valido(site) or not isinstance(url, str):
            return None
        url = url.strip()[: protocol.MAX_PEDIDO_URL]
        if not protocol.is_safe_http_url(url):
            return None
        bloqueio = payload.get("bloqueio")
        return {
            "site": site,
            "url": url,
            "motivo": limpar_texto(payload.get("motivo"), protocol.MAX_PEDIDO_MOTIVO),
            "bloqueio": bloqueio if bloqueio in BLOQUEIOS else "regra",
        }
    if tipo == protocol.UP_HAND:
        return {}
    return None


def monograma(nome) -> str:
    """Iniciais do avatar: "Prof. Manoel" → "MA"; "Ana Paula Souza" → "AS"."""
    palavras = nome.split() if isinstance(nome, str) else []
    while palavras and palavras[0].casefold() in PREFIXOS_PROFESSOR:
        palavras = palavras[1:]
    palavras = [p for p in palavras if any(c.isalnum() for c in p)]
    if not palavras:
        return "?"
    letras = [c for c in palavras[0] if c.isalnum()]
    if len(palavras) == 1:
        return "".join(letras[:2]).upper() or "?"
    ultima = [c for c in palavras[-1] if c.isalnum()]
    return (letras[0] + ultima[0]).upper()
