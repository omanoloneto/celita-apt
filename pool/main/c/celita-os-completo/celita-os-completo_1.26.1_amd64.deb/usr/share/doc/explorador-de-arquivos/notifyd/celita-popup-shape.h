/* Superfície GTK compartilhada com o notifyd. Sem bibliotecas além de GTK/Cairo. */
#ifndef CELITA_POPUP_H
#define CELITA_POPUP_H
#include <gtk/gtk.h>

typedef struct {
    gdouble radius;
    gint width, height, composited;
} CelitaPopupShape;

static void celita_popup_path(cairo_t *cr, gint width, gint height, gdouble radius)
{
    const gdouble pi = G_PI;
    radius = MIN(radius, MIN(width / 2.0, height / 2.0));
    cairo_new_sub_path(cr);
    cairo_arc(cr, width - radius, radius, radius, -pi / 2, 0);
    cairo_arc(cr, width - radius, height - radius, radius, 0, pi / 2);
    cairo_arc(cr, radius, height - radius, radius, pi / 2, pi);
    cairo_arc(cr, radius, radius, radius, pi, 3 * pi / 2);
    cairo_close_path(cr);
}

static void celita_popup_shape_update_full(GtkWidget *widget, gboolean force)
{
    GdkWindow *native = gtk_widget_get_window(widget);
    if (!native)
        return;
    CelitaPopupShape *shape = g_object_get_data(G_OBJECT(widget), "celita-popup-shape");
    gint width = gtk_widget_get_allocated_width(widget), height = gtk_widget_get_allocated_height(widget);
    gboolean composited = gdk_screen_is_composited(gtk_widget_get_screen(widget));
    gboolean changed = shape->width != width || shape->height != height || shape->composited != composited;
    if (!changed && !force)
        return;
    shape->width = width; shape->height = height; shape->composited = composited;
    gdouble radius = MIN(shape->radius, MIN(width / 2.0, height / 2.0));
    cairo_rectangle_int_t full = {0, 0, width, height};
    cairo_region_t *region = cairo_region_create_rectangle(&full);
    for (gint y = 0; y < radius; y++) {
        gint inset = 0;
        while ((inset + .5 - radius) * (inset + .5 - radius) +
               (y + .5 - radius) * (y + .5 - radius) > radius * radius)
            inset++;
        if (!inset)
            continue;
        cairo_rectangle_int_t corners[] = {{0, y, inset, 1}, {width - inset, y, inset, 1},
            {0, height - y - 1, inset, 1}, {width - inset, height - y - 1, inset, 1}};
        for (guint i = 0; i < G_N_ELEMENTS(corners); i++)
            cairo_region_subtract_rectangle(region, &corners[i]);
    }
    gdk_window_input_shape_combine_region(native, region, 0, 0);
    gdk_window_shape_combine_region(native, composited ? NULL : region, 0, 0);
    cairo_region_destroy(region);
    if (changed)
        gtk_widget_queue_draw(widget);
}

static void celita_popup_shape_update(GtkWidget *widget)
{
    celita_popup_shape_update_full(widget, FALSE);
}

static void celita_popup_shape_size(GtkWidget *widget, GtkAllocation *allocation, gpointer data)
{
    (void)allocation; (void)data;
    celita_popup_shape_update(widget);
}

static void celita_popup_shape_screen(GdkScreen *screen, GtkWidget *widget)
{
    (void)screen;
    celita_popup_shape_update(widget);
}

static gboolean celita_popup_clear(GtkWidget *widget, cairo_t *cr, gpointer data)
{
    (void)widget; (void)data;
    cairo_save(cr);
    cairo_set_operator(cr, CAIRO_OPERATOR_CLEAR);
    cairo_paint(cr);
    cairo_restore(cr);
    return FALSE;
}

static gboolean celita_popup_corners(GtkWidget *widget, cairo_t *cr, gpointer data)
{
    (void)data;
    CelitaPopupShape *shape = g_object_get_data(G_OBJECT(widget), "celita-popup-shape");
    gint width = gtk_widget_get_allocated_width(widget), height = gtk_widget_get_allocated_height(widget);
    cairo_save(cr);
    cairo_set_operator(cr, CAIRO_OPERATOR_CLEAR);
    cairo_set_fill_rule(cr, CAIRO_FILL_RULE_EVEN_ODD);
    cairo_rectangle(cr, 0, 0, width, height);
    celita_popup_path(cr, width, height, shape->radius);
    cairo_fill(cr);
    cairo_restore(cr);
    /* GtkWindow atualiza a região de entrada durante o próprio desenho. */
    celita_popup_shape_update_full(widget, TRUE);
    return FALSE;
}

static inline void celita_popup_configure(GtkWidget *widget, gdouble radius)
{
    if (g_object_get_data(G_OBJECT(widget), "celita-popup-shape"))
        return;
    CelitaPopupShape *shape = g_new0(CelitaPopupShape, 1);
    shape->radius = radius;
    shape->composited = -1;
    g_object_set_data_full(G_OBJECT(widget), "celita-popup-shape", shape, g_free);
    GdkScreen *screen = gtk_widget_get_screen(widget);
    GdkVisual *visual = gdk_screen_get_rgba_visual(screen);
    if (visual)
        gtk_widget_set_visual(widget, visual);
    g_signal_connect(widget, "realize", G_CALLBACK(celita_popup_shape_update), NULL);
    g_signal_connect(widget, "size-allocate", G_CALLBACK(celita_popup_shape_size), NULL);
    g_signal_connect(widget, "draw", G_CALLBACK(celita_popup_clear), NULL);
    g_signal_connect_after(widget, "draw", G_CALLBACK(celita_popup_corners), NULL);
    g_signal_connect_object(screen, "composited-changed", G_CALLBACK(celita_popup_shape_screen), widget, 0);
}

/* Fecha o popup quando o clique cai fora dele. O focus-out sozinho não basta:
 * a barra de tarefas e a área de trabalho não pegam foco, então clicar nelas
 * deixava o popup aberto. Enquanto o popup está na tela ele segura o ponteiro
 * (owner_events: cliques nas próprias janelas seguem normais). Sem timers com o
 * grab de pé; se não conseguir, tenta de novo por alguns segundos e desiste,
 * ficando só o focus-out de antes. Mesmo comportamento de celita_popup.py. */
#define CELITA_OUTSIDE_RETRY_MS 200
#define CELITA_OUTSIDE_RETRY_LIMIT 25

typedef struct {
    GtkWidget *window;
    gboolean (*can_close)(gpointer data);
    gpointer data;
    gboolean held, close_requested;
    guint retry_source, retries;
} CelitaOutsideClick;

static inline gboolean celita_outside_can_close(CelitaOutsideClick *outside)
{
    return !outside->can_close || outside->can_close(outside->data);
}

static inline void celita_outside_release(CelitaOutsideClick *outside)
{
    if (outside->retry_source) {
        g_source_remove(outside->retry_source);
        outside->retry_source = 0;
    }
    if (outside->held) {
        outside->held = FALSE;
        gdk_seat_ungrab(gdk_display_get_default_seat(gtk_widget_get_display(outside->window)));
    }
}

static inline gboolean celita_outside_attempt(gpointer user_data)
{
    CelitaOutsideClick *outside = user_data;
    if (!gtk_widget_get_mapped(outside->window)) {
        outside->retry_source = 0;
        return G_SOURCE_REMOVE;
    }
    if (celita_outside_can_close(outside)) {
        if (outside->close_requested) {
            outside->retry_source = 0;
            gtk_widget_destroy(outside->window);
            return G_SOURCE_REMOVE;
        }
        GdkDisplay *display = gtk_widget_get_display(outside->window);
        GdkSeat *seat = gdk_display_get_default_seat(display);
        GdkWindow *native = gtk_widget_get_window(outside->window);
        /* Um menu do próprio app segurando o ponteiro: esperar ele soltar. */
        if (native && !gdk_display_device_is_grabbed(display, gdk_seat_get_pointer(seat)))
            outside->held = gdk_seat_grab(seat, native, GDK_SEAT_CAPABILITY_ALL_POINTING, TRUE,
                                          NULL, NULL, NULL, NULL) == GDK_GRAB_SUCCESS;
    }
    if (outside->held || outside->retries >= CELITA_OUTSIDE_RETRY_LIMIT) {
        outside->retry_source = 0;
        return G_SOURCE_REMOVE;
    }
    outside->retries++;
    if (!outside->retry_source)
        outside->retry_source = g_timeout_add(CELITA_OUTSIDE_RETRY_MS, celita_outside_attempt, outside);
    return G_SOURCE_CONTINUE;
}

static inline void celita_outside_sync(CelitaOutsideClick *outside)
{
    if (!gtk_widget_get_mapped(outside->window) || !celita_outside_can_close(outside)) {
        celita_outside_release(outside);
        return;
    }
    if (!outside->held && !outside->retry_source) {
        outside->retries = 0;
        celita_outside_attempt(outside);
    }
}

static inline gboolean celita_outside_mapped(GtkWidget *widget, GdkEvent *event, gpointer user_data)
{
    (void)widget; (void)event;
    CelitaOutsideClick *outside = user_data;
    outside->close_requested = FALSE;
    celita_outside_sync(outside);
    return FALSE;
}

static inline gboolean celita_outside_unmapped(GtkWidget *widget, GdkEvent *event, gpointer user_data)
{
    (void)widget; (void)event;
    celita_outside_release(user_data);
    return FALSE;
}

static inline void celita_outside_destroyed(GtkWidget *widget, gpointer user_data)
{
    (void)widget;
    celita_outside_release(user_data);
}

static inline gboolean celita_outside_broken(GtkWidget *widget, GdkEvent *event, gpointer user_data)
{
    (void)widget; (void)event;
    CelitaOutsideClick *outside = user_data;
    outside->held = FALSE;
    celita_outside_sync(outside);
    return FALSE;
}

static inline gboolean celita_outside_pressed(GtkWidget *widget, GdkEvent *event, gpointer user_data)
{
    CelitaOutsideClick *outside = user_data;
    if (event->type != GDK_BUTTON_PRESS && event->type != GDK_TOUCH_BEGIN)
        return FALSE;
    GdkWindow *native = gtk_widget_get_window(widget);
    gdouble x_root = 0, y_root = 0;
    if (!native || !gdk_event_get_root_coords(event, &x_root, &y_root))
        return FALSE;
    gint left = 0, top = 0;
    gdk_window_get_origin(native, &left, &top);
    gdouble x = x_root - left, y = y_root - top;
    if (x >= 0 && y >= 0 && x < gdk_window_get_width(native) && y < gdk_window_get_height(native))
        return FALSE;
    celita_outside_release(outside);
    if (celita_outside_can_close(outside)) {
        gtk_widget_destroy(widget);
    } else {
        /* Operação em andamento: fecha assim que ela terminar. */
        outside->close_requested = TRUE;
        outside->retries = 0;
        celita_outside_attempt(outside);
    }
    return TRUE;
}

/* Chamar uma vez por popup, antes de mostrá-lo. Fechar é gtk_widget_destroy;
 * can_close (opcional) adia o fechamento enquanto devolver FALSE. */
static inline CelitaOutsideClick *celita_popup_close_on_outside_click(GtkWidget *window,
    gboolean (*can_close)(gpointer data), gpointer data)
{
    CelitaOutsideClick *outside = g_new0(CelitaOutsideClick, 1);
    outside->window = window;
    outside->can_close = can_close;
    outside->data = data;
    g_object_set_data_full(G_OBJECT(window), "celita-outside-click", outside, g_free);
    gtk_widget_add_events(window, GDK_BUTTON_PRESS_MASK | GDK_TOUCH_MASK);
    g_signal_connect(window, "map-event", G_CALLBACK(celita_outside_mapped), outside);
    g_signal_connect(window, "unmap-event", G_CALLBACK(celita_outside_unmapped), outside);
    g_signal_connect(window, "destroy", G_CALLBACK(celita_outside_destroyed), outside);
    g_signal_connect(window, "grab-broken-event", G_CALLBACK(celita_outside_broken), outside);
    g_signal_connect(window, "button-press-event", G_CALLBACK(celita_outside_pressed), outside);
    g_signal_connect(window, "touch-event", G_CALLBACK(celita_outside_pressed), outside);
    return outside;
}
#endif
