"""Janela do professor: Aula (PCs, linha de aula, Recados, grade de telas),
Sites (regras, sites da prova, página inicial e apps fixados) e Ajustes
(papel de parede, conta Google, escola). Widgets do GTK com os tokens do
DESIGN.md (estilo.py) nas partes de turma, e toda rede fora da thread da
interface."""

import logging
import threading

from ..desktop import default_window_size
from .controller import TeacherController
from .home import LIMITE_FIXADOS, MAX_FIXADOS, SEARCH_DUCKDUCKGO, SEARCH_GOOGLE, fixado_valido
from .rules import ALERT, BLOCK

log = logging.getLogger("controle-de-aula.teacher.app")

WALLPAPER_MAX_SIDE = 1920
WALLPAPER_QUALITY = "85"
WEBCAM_SCAN_ATTEMPTS = 12
TIQUE_S = 30
IMAGEM_FALHOU = "Não foi possível enviar a imagem. Tente de novo."
AJUDA_PROVA = "Vale para o navegador. Apps Android do Chromebook e páginas dentro de outras páginas não são bloqueados."
PROVA_VAZIA = ("A lista de sites permitidos está vazia. Com o modo prova ligado, só a página inicial da escola "
               "abre.")
PROVA_LIGADA = "Modo prova ligado: só os sites permitidos abrem."
PROVA_DESLIGADA = "Modo prova desligado."


def main():
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gtk, Pango

    from . import turma_ui as ui
    from .turma_ui import ask, confirm, notice, run_async

    def label(text, size=13, bold=False, dim=False, xalign=0):
        widget = Gtk.Label(xalign=xalign)
        widget.set_text(text)
        widget.set_line_wrap(True)
        widget.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        attributes = Pango.AttrList()
        attributes.insert(Pango.attr_size_new_absolute(size * Pango.SCALE))
        if bold:
            attributes.insert(Pango.attr_weight_new(Pango.Weight.SEMIBOLD))
        widget.set_attributes(attributes)
        if dim:
            widget.get_style_context().add_class("dim-label")
        return widget

    def section(title):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.pack_start(ui.rotulo(title, "titulo"), False, False, 0)
        return box

    def frame(child):
        holder = ui.com_classes(Gtk.Box(orientation=Gtk.Orientation.VERTICAL), "card")
        holder.pack_start(child, True, True, 0)
        return holder

    def entry(placeholder, width=24):
        widget = Gtk.Entry()
        widget.set_placeholder_text(placeholder)
        widget.set_width_chars(width)
        return widget

    def image_to_jpeg(path: str) -> bytes:
        pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, WALLPAPER_MAX_SIDE, WALLPAPER_MAX_SIDE, True)
        ok, data = pixbuf.save_to_bufferv("jpeg", ["quality"], [WALLPAPER_QUALITY])
        if not ok:
            raise ValueError("imagem_invalida")
        return bytes(data)

    def empty_row(text):
        row = Gtk.ListBoxRow()
        row.set_activatable(False)
        box = Gtk.Box(border_width=12)
        box.pack_start(ui.rotulo(text, "fraco"), True, True, 0)
        row.add(box)
        return row

    def lista():
        widget = ui.com_classes(Gtk.ListBox(), "lista")
        widget.set_selection_mode(Gtk.SelectionMode.NONE)
        return widget

    class PairDialog(Gtk.Dialog):
        def __init__(self, parent, controller):
            super().__init__(title="Conectar computador", transient_for=parent, modal=True)
            ui.vestir(self)
            self.controller = controller
            self.scanning = False
            self.add_button("Cancelar", Gtk.ResponseType.CANCEL)
            ui.com_classes(self.add_button("Conectar", Gtk.ResponseType.ACCEPT), "primario")
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16, border_width=24)
            box.pack_start(label("Abra o Controle de Aula no computador do aluno. Aponte a webcam para o código, ou copie o código e cole aqui."), False, False, 0)
            self.code = Gtk.Entry()
            self.code.set_placeholder_text("Código do computador")
            self.code.set_activates_default(True)
            box.pack_start(self.code, False, False, 0)
            row = Gtk.Box(spacing=12)
            self.scan = Gtk.Button.new_with_label("Ler pela webcam")
            self.scan.connect("clicked", self.scan_clicked)
            row.pack_start(self.scan, False, False, 0)
            self.spinner = Gtk.Spinner()
            row.pack_start(self.spinner, False, False, 0)
            self.status = label("", dim=True)
            row.pack_start(self.status, True, True, 0)
            box.pack_start(row, False, False, 0)
            unit_row = Gtk.Box(spacing=12)
            unit_row.pack_start(label("Número da unidade (opcional)"), False, False, 0)
            self.unit = Gtk.SpinButton.new_with_range(0, 999, 1)
            unit_row.pack_start(self.unit, False, False, 0)
            box.pack_start(unit_row, False, False, 0)
            self.get_content_area().add(box)
            self.set_default_response(Gtk.ResponseType.ACCEPT)
            self.connect("destroy", lambda *_: setattr(self, "scanning", False))
            self.show_all()
            self.spinner.hide()

        def scan_clicked(self, _button):
            if self.scanning:
                return
            self.scanning = True
            self.scan.set_sensitive(False)
            self.spinner.show()
            self.spinner.start()
            self.status.set_text("Aponte a webcam para o código…")
            run_async(self._scan_loop, self._scan_done)

        def _scan_loop(self):
            for _ in range(WEBCAM_SCAN_ATTEMPTS):
                if not self.scanning:
                    return None
                text = self.controller.capture_qr_from_webcam()
                if text:
                    return text
            return None

        def _scan_done(self, result):
            self.scanning = False
            self.spinner.stop()
            self.spinner.hide()
            self.scan.set_sensitive(True)
            if isinstance(result, str):
                self.code.set_text(result)
                self.status.set_text("Código lido. Confirme em Conectar.")
            else:
                self.status.set_text("Nenhum código encontrado. Tente de novo ou cole o código.")
            return False

        def values(self):
            unit = int(self.unit.get_value())
            return self.code.get_text().strip(), (unit if unit > 0 else None)

    class PhoneLoginDialog(Gtk.Dialog):
        """QR para o celular ler: o app entra na conta do professor por aqui."""

        def __init__(self, parent, controller):
            super().__init__(title="Entrar pelo celular", transient_for=parent, modal=True)
            ui.vestir(self)
            self.controller = controller
            self.add_button("Cancelar", Gtk.ResponseType.CANCEL)
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16, border_width=24)
            box.pack_start(label("No celular, abra o Controle de Aula, toque em conectar computador e aponte a câmera para este código. O celular precisa estar com a conta Google."), False, False, 0)
            self.image = Gtk.Image()
            box.pack_start(self.image, False, False, 0)
            self.status = label("", dim=True, xalign=0.5)
            box.pack_start(self.status, False, False, 0)
            self.get_content_area().add(box)
            self.show_all()
            payload = controller.begin_phone_login(lambda error: GLib.idle_add(self.finished, error))
            if payload is None:
                self.status.set_text("Sem conexão com o servidor. Feche e tente de novo.")
                return
            pixbuf = qr_pixbuf(payload)
            if pixbuf is None:
                self.status.set_text("Não foi possível gerar o código.")
                return
            self.image.set_from_pixbuf(pixbuf)
            self.status.set_text("Aguardando o celular…")

        def finished(self, error):
            if error:
                self.status.set_text(error)
            else:
                self.response(Gtk.ResponseType.ACCEPT)
            return False

    def qr_pixbuf(payload: str):
        import subprocess
        try:
            data = subprocess.run(["qrencode", "-t", "PNG", "-s", "6", "-m", "4", "-o", "-"],
                                  input=payload.encode(), capture_output=True, check=True, timeout=5).stdout
            loader = GdkPixbuf.PixbufLoader.new_with_type("png")
            loader.write(data)
            loader.close()
            return loader.get_pixbuf()
        except (OSError, subprocess.SubprocessError, GLib.Error):
            return None

    # ---- aba Aula ---------------------------------------------------------------------

    class AulaPage(Gtk.Overlay):
        def __init__(self, window, controller):
            super().__init__()
            self.window = window
            self.controller = controller
            self.conversas = {}
            self.signature = None
            self._cabecalho = None
            self._popover_aberto = False
            self._entrega_vista = None
            self._entrega_fim = None
            # Faixas de "destravadas"/"prova desligada" já resolvidas que
            # estão para sumir sozinhas.
            self._estados_vencendo = set()

            corpo = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
            self.add(corpo)
            self.aviso = ui.AvisoFlutuante()
            self.add_overlay(self.aviso)

            # Linha da aula: turma, Recados (N), Começar/Encerrar aula.
            linha = ui.com_classes(Gtk.Box(spacing=12), "card", "linha-aula")
            icone = Gtk.Image.new_from_icon_name("system-users-symbolic", Gtk.IconSize.LARGE_TOOLBAR)
            linha.pack_start(icone, False, False, 0)
            textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            textos.set_valign(Gtk.Align.CENTER)
            self.aula_titulo = ui.rotulo("", "subtitulo")
            self.aula_sub = ui.rotulo("", "fraco", "compacto")
            textos.pack_start(self.aula_titulo, False, False, 0)
            textos.pack_start(self.aula_sub, False, False, 0)
            linha.pack_start(textos, True, True, 0)
            self.recados = Gtk.Button(label="Recados")
            ui.com_classes(self.recados, "tonal")
            self.recados.set_valign(Gtk.Align.CENTER)
            self.recados_popover = ui.RecadosPopover(self.recados, self)
            self.recados.connect("clicked", lambda *_: self.recados_popover.popup())
            linha.pack_start(self.recados, False, False, 0)
            self.comecar = ui.botao("Começar aula…", "primario", ao_clicar=self.comecar_aula)
            self.comecar.set_valign(Gtk.Align.CENTER)
            linha.pack_start(self.comecar, False, False, 0)
            self.encerrar = ui.botao("Encerrar aula", "link-acao", icone="media-playback-stop-symbolic",
                                     ao_clicar=self.encerrar_aula)
            self.encerrar.set_valign(Gtk.Align.CENTER)
            linha.pack_start(self.encerrar, False, False, 0)
            corpo.pack_start(linha, False, False, 0)

            # Linha de ações da turma (SPEC-turma §7.4).
            acoes = Gtk.Box(spacing=8, homogeneous=True)
            self.olhos = self.acao("Olhos em mim", "view-reveal-symbolic", "Travar as telas da turma", self.olhos_clicked)
            self.prova = self.acao("Prova", "checkbox-checked-symbolic", "Modo prova: só sites permitidos",
                                   self.prova_clicked)
            self.mensagem = self.acao("Mensagem", "chat-message-new-symbolic", "Mensagem para a turma",
                                      self.mensagem_clicked)
            for button in (self.olhos, self.prova, self.mensagem):
                acoes.pack_start(button, True, True, 0)
            alternancia = ui.com_classes(Gtk.Box(homogeneous=True), "linked", "segmentos")
            self.ver_lista = self.alternar("Lista", "view-list-symbolic", None)
            self.ver_telas = self.alternar("Telas", "view-grid-symbolic", self.ver_lista)
            self.ver_telas.set_tooltip_text("Ver as telas ao vivo")
            alternancia.pack_start(self.ver_lista, True, True, 0)
            alternancia.pack_start(self.ver_telas, True, True, 0)
            self.ver_telas.connect("toggled", self.telas_toggled)
            acoes.pack_start(alternancia, True, True, 0)
            corpo.pack_start(acoes, False, False, 0)
            self.trava_popover = ui.TravaPopover(self.olhos, controller, self.travar)

            # Faixas: estado (trava, prova) e entrega (SPEC-turma §6.3).
            self.faixa_trava = ui.Faixa(estado=True)
            self.faixa_prova = ui.Faixa(estado=True)
            self.faixa_entrega = ui.Faixa(fechar=self.dispensar_entrega)
            for faixa in (self.faixa_trava, self.faixa_prova, self.faixa_entrega):
                corpo.pack_start(faixa, False, False, 0)

            # Segunda linha: as ações de antes (sem "Mensagem para a turma").
            secundaria = Gtk.Box(spacing=8)
            self.conectar = Gtk.Button.new_with_label("Conectar computador")
            self.conectar.connect("clicked", self.pair_clicked)
            self.abrir_turma = Gtk.Button.new_with_label("Abrir site na turma")
            self.abrir_turma.connect("clicked", lambda *_: self.open_url(None))
            self.fechar_turma = Gtk.Button.new_with_label("Fechar abas da turma")
            self.fechar_turma.connect("clicked", self.close_all_clicked)
            for button in (self.conectar, self.abrir_turma, self.fechar_turma):
                secundaria.pack_start(button, False, False, 0)
            corpo.pack_start(secundaria, False, False, 0)

            # Lista | Telas.
            self.stack = Gtk.Stack()
            self.stack.set_transition_type(Gtk.StackTransitionType.NONE)
            vista_lista = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            self.empty = ui.rotulo("Nenhum computador conectado ainda. Use \"Conectar computador\".", "fraco")
            vista_lista.pack_start(self.empty, False, False, 0)
            self.list = lista()
            scroller = Gtk.ScrolledWindow()
            scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            scroller.add(self.list)
            self.list_card = frame(scroller)
            vista_lista.pack_start(self.list_card, True, True, 0)
            self.stack.add_named(vista_lista, "lista")
            self.grade = ui.Grade(window, window.estilo)
            self.stack.add_named(self.grade, "telas")
            corpo.pack_start(self.stack, True, True, 0)

        def acao(self, texto, icone, tooltip, handler):
            button = ui.com_classes(Gtk.Button(), "tonal", "acao-turma")
            button.add(self._conteudo_acao(texto, icone))
            button.set_tooltip_text(tooltip)
            button.tooltip_padrao = tooltip
            button.connect("clicked", lambda *_: handler())
            return button

        @staticmethod
        def _conteudo_acao(texto, icone):
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            image = Gtk.Image.new_from_icon_name(icone, Gtk.IconSize.LARGE_TOOLBAR)
            image.set_pixel_size(20)
            box.pack_start(image, False, False, 0)
            box.pack_start(ui.rotulo(texto, xalign=0.5, wrap=False), False, False, 0)
            box.set_valign(Gtk.Align.CENTER)
            return box

        def mudar_acao(self, button, texto, icone, ligado):
            box = button.get_child()
            image, rotulo = box.get_children()
            image.set_from_icon_name(icone, Gtk.IconSize.LARGE_TOOLBAR)
            rotulo.set_text(texto)
            context = button.get_style_context()
            (context.add_class if ligado else context.remove_class)("ligado")

        def alternar(self, texto, icone, grupo):
            button = Gtk.RadioButton.new_from_widget(grupo)
            button.set_mode(False)
            ui.com_classes(button, "segmento")
            button.add(self._conteudo_acao(texto, icone))
            return button

        # -- estado da tela ------------------------------------------------------------

        def refresh(self):
            c = self.controller
            self._refresh_cabecalho()
            self._refresh_faixas()
            self.recados_popover.atualizar()
            for janela in list(self.conversas.values()):
                janela.atualizar()
            if self.stack.get_visible_child_name() == "telas":
                if not c.aula_ativa and c.modo_escola:
                    self.ver_lista.set_active(True)
                else:
                    self.grade.mostrar(c.quadros(), c.erro_grade)
            if self._popover_aberto:
                return
            rows = c.pcs()
            signature = repr(rows) + repr(c.modo_escola) + repr(c.aula_ativa)
            if signature == self.signature:
                return
            self.signature = signature
            ui.limpar(self.list)
            self.empty.set_visible(not rows)
            self.list_card.set_visible(bool(rows))
            for pc in rows:
                self.list.add(self.row_for(pc))
            self.list.show_all()

        def _refresh_cabecalho(self):
            c = self.controller
            motivo = c.motivo_sem_turma
            n_recados = c.recados_count
            alvo = c.alvo_turma()
            online = sum(1 for r in c.pcs() if r["na_aula"] and r["online"])
            estado = (c.connected, c.modo_escola, c.aula_ativa, c.aula.turma, len(alvo), online, n_recados,
                      c.trava_ligada, c.prova_ligada, motivo)
            if estado == self._cabecalho:
                return
            self._cabecalho = estado
            if c.modo_escola and not c.aula_ativa:
                self.aula_titulo.set_text("Nenhuma aula em andamento")
                self.aula_sub.set_text("Comece uma aula para travar as telas, ligar a prova e ver as telas ao vivo.")
            else:
                turma = c.aula.turma if c.modo_escola else ""
                self.aula_titulo.set_text(f"Aula: {turma}" if turma else "Aula em andamento")
                self.aula_sub.set_text(
                    f"{len(alvo)} {ui.plural(len(alvo), 'computador', 'computadores')} na aula · {online} online"
                    if alvo else (motivo or ""))
            self.comecar.set_visible(c.modo_escola and not c.aula_ativa)
            self.encerrar.set_visible(c.connected and c.aula_ativa)
            self.recados.set_label(f"Recados ({n_recados})" if n_recados else "Recados")
            context = self.recados.get_style_context()
            (context.add_class if n_recados else context.remove_class)("ligado")
            self.mudar_acao(self.olhos, "Destravar" if c.trava_ligada else "Olhos em mim",
                            "changes-allow-symbolic" if c.trava_ligada else "view-reveal-symbolic", c.trava_ligada)
            self.mudar_acao(self.prova, "Prova ligada" if c.prova_ligada else "Prova", "checkbox-checked-symbolic",
                            c.prova_ligada)
            # Destravar e sair da prova continuam valendo sem aula (PCs com o
            # estado decifrado ligado); o resto exige aula com alvo.
            for button, livre in ((self.olhos, c.trava_ligada), (self.prova, c.prova_ligada), (self.mensagem, False),
                                  (self.ver_telas, False), (self.abrir_turma, False), (self.fechar_turma, False)):
                pode = c.connected and (livre or motivo is None)
                button.set_sensitive(pode)
                padrao = getattr(button, "tooltip_padrao", None)
                button.set_tooltip_text(padrao if pode or not motivo else motivo)
            self.conectar.set_sensitive(c.connected)

        def _refresh_faixas(self):
            c = self.controller
            for e in (c.entrega_trava, c.entrega_prova):
                # Desligar já confirmado: o resultado fica um pouco e some
                # (ligado, a faixa é o estado da turma e fica).
                if e is not None and not e.alvo_on and e.resolvida and e not in self._estados_vencendo:
                    self._estados_vencendo.add(e)
                    GLib.timeout_add_seconds(ui.FAIXA_RESOLVIDA_S, self._estado_venceu, e)
            texto = c.texto_da_trava
            if texto and (c.trava_ligada or (c.entrega_trava and not c.entrega_trava.resolvida)
                          or (c.entrega_trava and not c.entrega_trava.alvo_on)):
                e = c.entrega_trava
                self.faixa_trava.mostrar(texto, "changes-prevent-symbolic", ocupado=not e.resolvida,
                                         linhas=lambda e=e: c.detalhes_da_entrega(e))
            else:
                self.faixa_trava.esconder()
            texto = c.texto_da_prova
            # Como a da trava: "Modo prova: …" só enquanto a prova vale (o
            # prazo venceu ou outro aparelho desligou = some).
            if texto and (c.prova_ligada or not c.entrega_prova.resolvida or not c.entrega_prova.alvo_on):
                e = c.entrega_prova
                self.faixa_prova.mostrar(texto, "checkbox-checked-symbolic", ocupado=not e.resolvida,
                                         linhas=lambda e=e: c.detalhes_da_entrega(e))
            else:
                self.faixa_prova.esconder()
            e = c.entrega
            texto = c.texto_da_entrega
            if e is None or not texto:
                self.faixa_entrega.esconder()
                return
            if e is not self._entrega_vista:
                self._entrega_vista, self._entrega_fim = e, None
            if e.resolvida and self._entrega_fim is None:
                # Resolvida: fica um pouco e some sozinha (outra nova substitui).
                self._entrega_fim = GLib.timeout_add_seconds(ui.FAIXA_RESOLVIDA_S, self._entrega_venceu, e)
            self.faixa_entrega.mostrar(texto, "object-select-symbolic", ocupado=not e.resolvida,
                                       linhas=lambda e=e: c.detalhes_da_entrega(e))

        def _estado_venceu(self, e):
            self._estados_vencendo.discard(e)
            self.controller.dispensar_entrega_de_estado(e)
            return False

        def _entrega_venceu(self, e):
            if self.controller.entrega is not e:
                return False
            if not e.resolvida:
                # Voltou a andar (um PC reconectou): some só quando resolver de novo.
                self._entrega_fim = None
                return False
            self.controller.dispensar_entrega()
            return False

        def dispensar_entrega(self):
            self.controller.dispensar_entrega()

        # -- linha de cada PC ----------------------------------------------------------

        def row_for(self, pc):
            row = Gtk.ListBoxRow()
            row.set_activatable(False)
            box = Gtk.Box(spacing=12, border_width=12)
            outro = pc["outro_professor"]
            box.pack_start(ui.avatar(pc["name"], online=pc["online"] and not outro), False, False, 0)
            texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            name = pc["name"] if pc["unit"] is None or pc["name"] == f"Unidade {pc['unit']}" \
                else f"{pc['name']} · Unidade {pc['unit']}"
            texts.pack_start(ui.rotulo(name, "subtitulo", wrap=False, ellipsize=True), False, False, 0)
            detail = pc["tab_title"] or pc["tab_url"] or ("Conectado" if pc["online"] else "Desligado ou sem internet")
            if pc["user"]:
                detail = f"{pc['user']} — {detail}"
            texts.pack_start(ui.rotulo(detail, "fraco", "compacto", ellipsize=True), False, False, 0)
            chips = Gtk.Box(spacing=6)
            if outro:
                chips.pack_start(ui.chip(f"Na aula de {outro}", "neutro"), False, False, 0)
            if pc["travada"] and not pc["travada_sem_professor"]:
                chips.pack_start(ui.chip("Tela travada"), False, False, 0)
            if pc["travada_sem_professor"]:
                chips.pack_start(ui.chip("Travada sem professor"), False, False, 0)
                chips.pack_start(ui.botao("Destravar", "link-acao", ao_clicar=lambda: self.destravar_pc(pc["id"])),
                                 False, False, 0)
            if pc["em_prova"]:
                chips.pack_start(ui.chip("Em prova"), False, False, 0)
            if pc["mao"]:
                chips.pack_start(ui.chip("✋ Mão levantada", "forte"), False, False, 0)
            if pc["nao_lidas"]:
                n = pc["nao_lidas"]
                chips.pack_start(ui.chip(f"{n} {ui.plural(n, 'mensagem nova', 'mensagens novas')}"), False, False, 0)
            if self.controller.modo_escola and self.controller.aula_ativa and not pc["na_aula"] and not outro:
                chips.pack_start(ui.chip("Fora da aula", "neutro"), False, False, 0)
            if pc["online"] and not pc["suporta_turma"] and not outro:
                antiga = ui.chip("Versão antiga", "neutro")
                antiga.set_tooltip_text("Atualize este computador para usar trava, prova, conversa e telas.")
                chips.pack_start(antiga, False, False, 0)
            if chips.get_children():
                texts.pack_start(chips, False, False, 2)
            if pc["alert"]:
                warning = Gtk.Box(spacing=6)
                warning.pack_start(Gtk.Image.new_from_icon_name("dialog-warning-symbolic", Gtk.IconSize.MENU),
                                   False, False, 0)
                warning.pack_start(ui.rotulo(f"Acessando {pc['alert']}", "forte"), False, False, 0)
                texts.pack_start(warning, False, False, 0)
            box.pack_start(texts, True, True, 0)
            if not outro:
                conversar = ui.botao_icone("chat-message-new-symbolic", "Conversar",
                                           lambda: self.abrir_conversa(pc["id"]))
                conversar.set_valign(Gtk.Align.CENTER)
                box.pack_start(conversar, False, False, 0)
            menu = ui.botao_icone("view-more-symbolic", "Mais ações")
            menu.set_valign(Gtk.Align.CENTER)
            menu.connect("clicked", lambda button: self.popover_for(pc, button))
            box.pack_start(menu, False, False, 0)
            row.add(box)
            return row

        def popover_for(self, pc, relative):
            popover = Gtk.Popover.new(relative)
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, border_width=8)
            device_id = pc["id"]
            c = self.controller
            itens = []
            if not pc["outro_professor"]:
                itens += [
                    ("Conversar", lambda *_: self.abrir_conversa(device_id)),
                    ("Abrir site", lambda *_: self.open_url(device_id)),
                    ("Fechar abas", lambda *_: self.rede(lambda: c.close_all_tabs(device_id))),
                ]
                if pc["travada"]:
                    itens.append(("Destravar", lambda *_: self.destravar_pc(device_id)))
                if pc["em_prova"]:
                    itens.append(("Sair do modo prova", lambda *_: self.rede(lambda: c.desligar_prova_pc(device_id))))
                if c.modo_escola and c.aula_ativa:
                    if pc["na_aula"] or device_id in c.aula.pcs:
                        itens.append(("Tirar da aula", lambda *_: self.rede(lambda: c.tirar_da_aula(device_id))))
                    else:
                        itens.append(("Incluir na aula", lambda *_: self.rede(lambda: c.incluir_na_aula(device_id))))
            itens += [
                ("Renomear", lambda *_: self.rename(pc)),
                ("Número da unidade", lambda *_: self.set_unit(pc)),
                ("Desconectar", lambda *_: self.forget(pc)),
            ]
            for caption, handler in itens:
                button = Gtk.ModelButton(text=caption)
                button.connect("clicked", handler)
                box.pack_start(button, False, False, 0)
            box.show_all()
            popover.add(box)
            self._popover_aberto = True
            popover.connect("closed", self._popover_fechou)
            popover.popup()

        def _popover_fechou(self, popover):
            self._popover_aberto = False
            GLib.idle_add(lambda: self.refresh() or False)

        # -- ações ---------------------------------------------------------------------

        def rede(self, work, sucesso=None, depois=None):
            """Ação de rede numa thread; o texto que voltar é mostrado ao professor."""
            def done(result):
                texto = ui.texto_do_resultado(result)
                if texto:
                    notice(self.window, texto, error=True)
                elif sucesso:
                    sucesso()
                if depois:
                    depois()
                self.refresh()
                return False
            run_async(work, done)

        def after_network(self, result):
            self.window.busy(False)
            texto = ui.texto_do_resultado(result)
            if texto:
                notice(self.window, texto, error=True)
            return False

        def pair_clicked(self, _button):
            dialog = PairDialog(self.window, self.controller)
            response = dialog.run()
            code, unit = dialog.values()
            dialog.destroy()
            if response != Gtk.ResponseType.ACCEPT:
                return
            self.window.busy(True)
            run_async(lambda: self.controller.pair_code(code, unit), self.after_network)

        def open_url(self, device_id=None):
            values = ask(self.window, "Abrir site", [("Endereço", "https://")], accept="Abrir")
            if values and values[0].strip():
                url = values[0].strip()
                self.rede(lambda: self.controller.open_url(url, device_id))

        def close_all_clicked(self, _button):
            if confirm(self.window, "Fechar as abas de toda a turma?",
                       "Todas as abas abertas nos computadores da aula serão fechadas.", "Fechar abas"):
                self.rede(lambda: self.controller.close_all_tabs(None))

        def olhos_clicked(self):
            if self.controller.trava_ligada:
                self.rede(self.controller.destravar_turma)
            else:
                self.trava_popover.abrir()

        def travar(self, texto, mute, apenas):
            self.rede(lambda: self.controller.travar_turma(texto, mute=mute, apenas=apenas))

        def destravar_pc(self, device_id):
            self.rede(lambda: self.controller.destravar_pc(device_id))

        def prova_clicked(self):
            c = self.controller
            if c.prova_ligada:
                self.rede(c.desligar_prova, sucesso=lambda: self.aviso.mostrar(
                    PROVA_DESLIGADA, "Desfazer", lambda: self.rede(c.ligar_prova)))
                return
            if not c.sites_prova and not self.dialogo_prova_vazia():
                return
            antigos = c.pcs_sem_modo_prova()
            if antigos and not self.dialogo_prova_versao(antigos):
                return
            self.rede(c.ligar_prova, sucesso=lambda: self.aviso.mostrar(PROVA_LIGADA, "Editar sites", self.editar_sites))

        def editar_sites(self):
            self.window.mostrar_sites_da_prova()

        def dialogo_prova_vazia(self) -> bool:
            dialog = ui.vestir(Gtk.MessageDialog(transient_for=self.window, modal=True,
                                                 message_type=Gtk.MessageType.QUESTION,
                                                 buttons=Gtk.ButtonsType.NONE, text="Lista de sites vazia"))
            dialog.format_secondary_text(PROVA_VAZIA)
            dialog.add_button("Editar lista", 1)
            ui.com_classes(dialog.add_button("Ligar mesmo assim", Gtk.ResponseType.ACCEPT), "primario")
            response = dialog.run()
            dialog.destroy()
            if response == 1:
                self.editar_sites()
            return response == Gtk.ResponseType.ACCEPT

        def dialogo_prova_versao(self, antigos) -> bool:
            dialog = ui.vestir(Gtk.MessageDialog(transient_for=self.window, modal=True,
                                                 message_type=Gtk.MessageType.WARNING, buttons=Gtk.ButtonsType.NONE,
                                                 text="Alguns computadores não vão entrar em modo prova"))
            nomes = ", ".join(a["name"] for a in antigos)
            corpo = f"Estes computadores têm uma versão antiga e continuariam com todos os sites liberados: {nomes}."
            if any(not a["celita"] for a in antigos):
                corpo += "\n\nOs Chromebooks se atualizam sozinhos em algumas horas."
            dialog.format_secondary_text(corpo)
            celitas = [a["id"] for a in antigos if a["celita"]]
            if celitas:
                dialog.add_button("Atualizar agora", 2)
            dialog.add_button("Cancelar", Gtk.ResponseType.CANCEL)
            ui.com_classes(dialog.add_button("Ligar mesmo assim", Gtk.ResponseType.ACCEPT), "primario")
            while True:
                response = dialog.run()
                if response != 2:
                    break
                self.rede(lambda: self.controller.atualizar_pcs(celitas))
                dialog.set_response_sensitive(2, False)
            dialog.destroy()
            return response == Gtk.ResponseType.ACCEPT

        def mensagem_clicked(self):
            texto = ui.dialogo_texto(self.window, "Mensagem para a turma",
                                     "Cada aluno recebe na janela de chat e pode responder.", "Enviar",
                                     placeholder="Escreva uma mensagem…")
            if texto:
                self.rede(lambda: self.controller.enviar_mensagem_para_turma(texto))

        def telas_toggled(self, button):
            if button.get_active():
                motivo = self.controller.motivo_sem_turma
                if motivo:
                    self.ver_lista.set_active(True)
                    self.aviso.mostrar(motivo)
                    return
                self.stack.set_visible_child_name("telas")
                self.controller.abrir_grade()
                self.grade.mostrar(self.controller.quadros())
            else:
                self.stack.set_visible_child_name("lista")
                self.fechar_grade()

        def fechar_grade(self):
            self.grade.esquecer_imagens()
            if self.controller.grade_aberta:
                threading.Thread(target=self.controller.fechar_grade, daemon=True).start()

        def pagina_escondida(self):
            if self.ver_telas.get_active():
                self.ver_lista.set_active(True)

        # -- aula ---------------------------------------------------------------------

        def comecar_aula(self):
            c = self.controller
            dialog = ui._dialogo(self.window, "Começar aula", "Começar aula")
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, border_width=20)
            box.set_size_request(420, -1)
            box.pack_start(ui.rotulo("Turma (opcional)"), False, False, 0)
            turma = Gtk.Entry()
            turma.set_max_length(60)
            turma.set_placeholder_text("Por exemplo: 7º ano A")
            box.pack_start(turma, False, False, 0)
            livres = c.pcs_livres()
            box.pack_start(ui.rotulo("Computadores da aula", "forte"), False, False, 4)
            checks = {}
            todos = Gtk.CheckButton(label="Selecionar todos os livres")
            box.pack_start(todos, False, False, 0)
            caixa = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            for pc in livres:
                check = Gtk.CheckButton()
                nome = pc["name"] if pc["unit"] is None or pc["name"] == f"Unidade {pc['unit']}" \
                    else f"{pc['name']} · Unidade {pc['unit']}"
                check.add(ui.rotulo(nome, wrap=False))
                caixa.pack_start(check, False, False, 0)
                checks[pc["id"]] = check
            if not livres:
                caixa.pack_start(ui.rotulo("Nenhum computador livre agora.", "fraco"), False, False, 0)
            todos.connect("toggled", lambda w: [check.set_active(w.get_active()) for check in checks.values()])
            scroller = Gtk.ScrolledWindow()
            scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            scroller.set_propagate_natural_height(True)
            scroller.set_max_content_height(320)
            scroller.add(caixa)
            box.pack_start(scroller, True, True, 0)
            outros = [r for r in c.pcs() if r["outro_professor"]]
            if outros:
                box.pack_start(ui.rotulo(f"{len(outros)} {ui.plural(len(outros), 'computador está', 'computadores estão')}"
                                         " na aula de outro professor.", "legenda"), False, False, 0)
            dialog.get_content_area().add(box)
            dialog.show_all()
            response = dialog.run()
            nome_turma = turma.get_text().strip()
            escolhidos = [d for d, check in checks.items() if check.get_active()]
            dialog.destroy()
            if response != Gtk.ResponseType.ACCEPT:
                return

            def done(result):
                if isinstance(result, Exception):
                    notice(self.window, ui.ERRO_GENERICO, error=True)
                elif result:
                    notice(self.window, "Alguns computadores ficaram de fora", error=True,
                           secondary="\n".join(result))
                self.refresh()
                return False
            run_async(lambda: c.comecar_aula(nome_turma, escolhidos), done)

        def encerrar_aula(self):
            if not confirm(self.window, "Encerrar a aula?",
                           "As telas são destravadas, o modo prova é desligado, as abas dos alunos são fechadas e "
                           "os recados somem.", "Encerrar aula"):
                return
            self.pagina_escondida()
            for janela in list(self.conversas.values()):
                janela.destroy()
            self.rede(self.controller.encerrar_aula)

        # -- Recados e conversa -------------------------------------------------------

        def abrir_conversa(self, device_id):
            janela = self.conversas.get(device_id)
            if janela is None:
                janela = ui.ConversaJanela(self.window, self.controller, device_id, self._conversa_fechou,
                                           ordem=len(self.conversas) % 3)
                self.conversas[device_id] = janela
            janela.present()
            run_async(lambda: self.controller.abrir_conversa(device_id), lambda *_: False)

        def _conversa_fechou(self, device_id):
            self.conversas.pop(device_id, None)

        def conversa_ativa(self, device_id) -> bool:
            janela = self.conversas.get(device_id)
            return janela is not None and janela.is_active()

        def liberar_pedido(self, pedido):
            c = self.controller
            padroes = None
            if not c.prova_no_pc(pedido.device_id):
                padroes = c.padroes_para_liberar(pedido)
                if len(padroes) > 1:
                    self.recados_popover.popdown()
                    if not confirm(self.window, f"Liberar para {c.nome_do_pc(pedido.device_id)}: {', '.join(padroes)}?",
                                   None, "Liberar"):
                        return
            self.rede(lambda: c.liberar_pedido(pedido, padroes))

        def recusar_pedido(self, pedido):
            self.recados_popover.popdown()
            motivo = ui.dialogo_recusar(self.window)
            if motivo is not None:
                self.rede(lambda: self.controller.recusar_pedido(pedido, motivo or None))

        def baixar_mao(self, device_id):
            self.rede(lambda: self.controller.baixar_mao(device_id))

        def rename(self, pc):
            values = ask(self.window, "Renomear computador", [("Nome", pc["name"])])
            if values is not None:
                self.controller.rename(pc["id"], values[0])

        def set_unit(self, pc):
            values = ask(self.window, "Número da unidade", [("Número", str(pc["unit"] or ""))])
            if values is None:
                return
            try:
                numero = int(values[0].strip())
            except ValueError:
                notice(self.window, "Digite um número.", error=True)
                return
            self.window.busy(True)
            run_async(lambda: self.controller.set_unit(pc["id"], numero), self.after_network)

        def forget(self, pc):
            if confirm(self.window, f"Desconectar {pc['name']}?", "O computador volta a mostrar o código de pareamento.", "Desconectar"):
                self.window.busy(True)
                run_async(lambda: self.controller.forget(pc["id"]), self.after_network)

    # ---- aba Sites ---------------------------------------------------------------------

    class SitesPage(Gtk.Box):
        ACTIONS = ((BLOCK, "Bloquear"), (ALERT, "Avisar"))
        ENGINES = ((SEARCH_GOOGLE, "Google"), (SEARCH_DUCKDUCKGO, "DuckDuckGo"))

        def __init__(self, window, controller):
            super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=32)
            self.window = window
            self.controller = controller
            self.signature = None
            self._apps = None
            self.build_rules()
            self.build_prova()
            self.build_home()
            self.build_fixados()

        @staticmethod
        def combo(options, current):
            widget = Gtk.ComboBoxText()
            for key, caption in options:
                widget.append(key, caption)
            widget.set_active_id(current)
            return widget

        def build_rules(self):
            box = section("Regras de sites")
            box.pack_start(ui.rotulo("Bloquear impede o acesso; Avisar deixa entrar e mostra um aviso aqui.", "fraco"),
                           False, False, 0)
            self.rules_list = lista()
            box.pack_start(frame(self.rules_list), False, False, 0)
            add = Gtk.Box(spacing=12)
            self.rule_pattern = entry("Site, por exemplo youtube.com", 32)
            self.rule_action = self.combo(self.ACTIONS, BLOCK)
            button = Gtk.Button.new_with_label("Adicionar")
            button.connect("clicked", self.add_rule_clicked)
            self.rule_pattern.connect("activate", self.add_rule_clicked)
            add.pack_start(self.rule_pattern, True, True, 0)
            add.pack_start(self.rule_action, False, False, 0)
            add.pack_start(button, False, False, 0)
            bulk = Gtk.Button.new_with_label("Adicionar em lote…")
            bulk.connect("clicked", self.bulk_clicked)
            add.pack_start(bulk, False, False, 0)
            box.pack_start(add, False, False, 0)
            self.pack_start(box, False, False, 0)

        def bulk_dialog(self, title, hint, with_action):
            dialog = ui._dialogo(self.window, title, "Adicionar")
            dialog.set_default_size(520, 420)
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, border_width=24)
            box.pack_start(ui.rotulo(hint), False, False, 0)
            view = Gtk.TextView()
            view.set_wrap_mode(Gtk.WrapMode.NONE)
            view.set_accepts_tab(False)
            scroller = Gtk.ScrolledWindow()
            scroller.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            scroller.set_shadow_type(Gtk.ShadowType.IN)
            scroller.add(view)
            box.pack_start(scroller, True, True, 0)
            action = None
            if with_action:
                row = Gtk.Box(spacing=12)
                row.pack_start(ui.rotulo("Ação para todos"), False, False, 0)
                action = self.combo(self.ACTIONS, self.rule_action.get_active_id() or BLOCK)
                row.pack_start(action, False, False, 0)
                box.pack_start(row, False, False, 0)
            dialog.get_content_area().add(box)
            dialog.show_all()
            view.grab_focus()
            response = dialog.run()
            buffer = view.get_buffer()
            text = buffer.get_text(buffer.get_start_iter(), buffer.get_end_iter(), True)
            chosen = action.get_active_id() if action is not None else None
            dialog.destroy()
            return (text, chosen) if response == Gtk.ResponseType.ACCEPT else (None, None)

        def bulk_clicked(self, _button):
            text, chosen = self.bulk_dialog("Adicionar sites em lote",
                                            "Um site por linha, por exemplo youtube.com ou reddit.com/r/games.", True)
            if text is None:
                return
            if not self.controller.add_rules_bulk(text, chosen):
                notice(self.window, "Nenhum site válido nas linhas. Use o formato youtube.com.", error=True)

        def build_prova(self):
            self.prova_box = box = section("Sites permitidos na prova")
            box.pack_start(ui.rotulo("Com o modo prova ligado, só estes sites e a página inicial da escola abrem.",
                                     "fraco"), False, False, 0)
            box.pack_start(ui.rotulo(AJUDA_PROVA, "legenda"), False, False, 0)
            self.prova_list = lista()
            box.pack_start(frame(self.prova_list), False, False, 0)
            add = Gtk.Box(spacing=12)
            self.prova_pattern = entry("Site, por exemplo khanacademy.org", 32)
            self.prova_pattern.connect("activate", self.add_prova_clicked)
            button = Gtk.Button.new_with_label("Adicionar")
            button.connect("clicked", self.add_prova_clicked)
            bulk = Gtk.Button.new_with_label("Adicionar em lote…")
            bulk.connect("clicked", self.bulk_prova_clicked)
            add.pack_start(self.prova_pattern, True, True, 0)
            add.pack_start(button, False, False, 0)
            add.pack_start(bulk, False, False, 0)
            box.pack_start(add, False, False, 0)
            self.pack_start(box, False, False, 0)

        def add_prova_clicked(self, *_):
            pattern = self.prova_pattern.get_text()
            run_async(lambda: self.controller.adicionar_site_prova(pattern), self._prova_added)

        def _prova_added(self, result):
            if result is True:
                self.prova_pattern.set_text("")
            else:
                notice(self.window, "Digite um site válido que ainda não está na lista, por exemplo khanacademy.org.",
                       error=True, secondary="Domínios inteiros, como com.br, não podem ser liberados.")
            return False

        def bulk_prova_clicked(self, _button):
            text, _ = self.bulk_dialog("Adicionar sites permitidos em lote",
                                       "Um site por linha (ou separados por vírgula), por exemplo khanacademy.org.",
                                       False)
            if text is None:
                return
            def done(added):
                if not added or isinstance(added, Exception):
                    notice(self.window, "Nenhum site válido (ou novo) nas linhas.", error=True)
                return False
            run_async(lambda: self.controller.adicionar_sites_prova_em_lote(text), done)

        def build_home(self):
            box = section("Página inicial dos alunos")
            box.pack_start(ui.rotulo("Título, busca e atalhos aparecem na nova aba; o site abaixo abre junto com o navegador.",
                                     "fraco"), False, False, 0)
            grid = Gtk.Grid(row_spacing=12, column_spacing=12)
            grid.attach(ui.rotulo("Título"), 0, 0, 1, 1)
            self.home_title = Gtk.Entry()
            self.home_title.connect("activate", self.title_changed)
            self.home_title.connect("focus-out-event", self.title_changed)
            grid.attach(self.home_title, 1, 0, 1, 1)
            grid.attach(ui.rotulo("Busca"), 0, 1, 1, 1)
            search_row = Gtk.Box(spacing=12)
            self.home_search = Gtk.Switch()
            self.home_search.set_valign(Gtk.Align.CENTER)
            self.home_search.connect("state-set", self.search_changed)
            self.home_engine = self.combo(self.ENGINES, SEARCH_GOOGLE)
            self.home_engine.connect("changed", self.engine_changed)
            search_row.pack_start(self.home_search, False, False, 0)
            search_row.pack_start(self.home_engine, False, False, 0)
            grid.attach(search_row, 1, 1, 1, 1)
            grid.attach(ui.rotulo("Site que abre com o navegador"), 0, 2, 1, 1)
            self.home_url = Gtk.Entry()
            self.home_url.set_placeholder_text("Vazio = a página do Celita")
            self.home_url.connect("activate", self.url_changed)
            self.home_url.connect("focus-out-event", self.url_changed)
            grid.attach(self.home_url, 1, 2, 1, 1)
            box.pack_start(grid, False, False, 0)
            box.pack_start(ui.rotulo("Atalhos", "subtitulo"), False, False, 0)
            self.home_list = lista()
            box.pack_start(frame(self.home_list), False, False, 0)
            add = Gtk.Box(spacing=12)
            self.shortcut_name = entry("Nome", 16)
            self.shortcut_url = entry("https://", 32)
            button = Gtk.Button.new_with_label("Adicionar")
            button.connect("clicked", self.add_shortcut_clicked)
            self.shortcut_url.connect("activate", self.add_shortcut_clicked)
            add.pack_start(self.shortcut_name, False, False, 0)
            add.pack_start(self.shortcut_url, True, True, 0)
            add.pack_start(button, False, False, 0)
            box.pack_start(add, False, False, 0)
            status_row = Gtk.Box(spacing=12)
            self.home_status = ui.rotulo("", "fraco")
            status_row.pack_start(self.home_status, True, True, 0)
            publish = Gtk.Button.new_with_label("Publicar de novo")
            publish.connect("clicked", lambda *_: self.publish())
            status_row.pack_end(publish, False, False, 0)
            box.pack_start(status_row, False, False, 0)
            self.pack_start(box, False, False, 0)
            self.loading = False

        def build_fixados(self):
            box = section("Apps fixados no menu dos alunos")
            box.pack_start(ui.rotulo("Aparecem fixados no menu Iniciar dos alunos de toda a escola, nesta ordem.", "fraco"),
                           False, False, 0)
            self.fixados_status = ui.rotulo("", "legenda")
            box.pack_start(self.fixados_status, False, False, 0)
            self.fixados_list = lista()
            self.fixados_frame = frame(self.fixados_list)
            box.pack_start(self.fixados_frame, False, False, 0)
            row = Gtk.Box(spacing=12)
            self.fixados_add = Gtk.Button.new_with_label("Adicionar app…")
            self.fixados_add.connect("clicked", self.add_app_clicked)
            row.pack_start(self.fixados_add, False, False, 0)
            self.fixados_count = ui.rotulo("", "fraco")
            row.pack_start(self.fixados_count, True, True, 0)
            box.pack_start(row, False, False, 0)
            self.pack_start(box, False, False, 0)

        def apps(self) -> dict:
            if self._apps is None:
                self._apps = {}
                for info in Gio.AppInfo.get_all():
                    app_id = info.get_id() or ""
                    if info.should_show() and fixado_valido(app_id):
                        self._apps[app_id] = info
            return self._apps

        def refresh(self):
            c = self.controller
            rules = c.rules
            home = c.home.config
            signature = (rules.rev, repr(rules.rules), repr(home), c.home_error, repr(c.sites_prova),
                         repr(c.menu_ids), c.menu_carregado, c.menu_error, c.school_active, c.connected)
            if signature == self.signature:
                return
            self.signature = signature
            self.loading = True
            ui.limpar(self.rules_list)
            for index, rule in enumerate(rules.rules):
                self.rules_list.add(self.rule_row(index, rule))
            if not rules.rules:
                self.rules_list.add(empty_row("Nenhuma regra. Todos os sites estão liberados."))
            self.rules_list.show_all()
            ui.limpar(self.prova_list)
            for index, pattern in enumerate(c.sites_prova):
                self.prova_list.add(self.prova_row(index, pattern))
            if not c.sites_prova:
                self.prova_list.add(empty_row("Nenhum site. Com a prova ligada, só a página inicial da escola abre."))
            self.prova_list.show_all()
            if self.home_title.get_text() != home["titulo"]:
                self.home_title.set_text(home["titulo"])
            if self.home_url.get_text().strip() != home["url"]:
                self.home_url.set_text(home["url"])
            self.home_search.set_active(home["busca"])
            self.home_engine.set_active_id(home["buscador"])
            self.home_engine.set_sensitive(home["busca"])
            ui.limpar(self.home_list)
            for index, shortcut in enumerate(home["atalhos"]):
                self.home_list.add(self.shortcut_row(index, shortcut))
            if not home["atalhos"]:
                self.home_list.add(empty_row("Sem atalhos. A página mostra só o título e a busca."))
            self.home_list.show_all()
            self.home_status.set_text(c.home_error or "Publicada para toda a escola.")
            self.refresh_fixados()
            self.loading = False

        def refresh_fixados(self):
            c = self.controller
            pronto = c.school_active and c.menu_carregado and c.connected
            ui.limpar(self.fixados_list)
            if not c.school_active:
                status = "Os apps fixados valem para a escola compartilhada. Crie ou entre na escola em Ajustes."
            elif c.menu_error and not c.menu_carregado:
                status = c.menu_error
            elif not c.menu_carregado:
                status = "Carregando a lista da escola…"
            else:
                status = ""
            self.fixados_status.set_text(status)
            self.fixados_status.set_visible(bool(status))
            self.fixados_frame.set_visible(pronto)
            ids = list(c.menu_ids)
            for index, app_id in enumerate(ids):
                self.fixados_list.add(self.fixado_row(index, app_id, ids))
            if pronto and not ids:
                self.fixados_list.add(empty_row("Nenhum app fixado. O menu dos alunos mostra só os apps de sempre."))
            self.fixados_list.show_all()
            self.fixados_add.set_visible(pronto)
            self.fixados_add.set_sensitive(len(ids) < MAX_FIXADOS)
            self.fixados_count.set_visible(pronto)
            self.fixados_count.set_text(LIMITE_FIXADOS if len(ids) >= MAX_FIXADOS else f"{len(ids)} de {MAX_FIXADOS}")

        def fixado_row(self, index, app_id, ids):
            row = Gtk.ListBoxRow()
            row.set_activatable(False)
            box = Gtk.Box(spacing=12, border_width=8)
            info = self.apps().get(app_id)
            icon = info.get_icon() if info else None
            image = Gtk.Image.new_from_gicon(icon, Gtk.IconSize.LARGE_TOOLBAR) if icon else \
                Gtk.Image.new_from_icon_name("application-x-executable", Gtk.IconSize.LARGE_TOOLBAR)
            image.set_pixel_size(24)
            box.pack_start(image, False, False, 0)
            texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
            texts.pack_start(ui.rotulo(info.get_display_name() if info else app_id, "forte", wrap=False), False, False, 0)
            if info is None:
                texts.pack_start(ui.rotulo("Não instalado neste computador", "legenda", wrap=False), False, False, 0)
            box.pack_start(texts, True, True, 0)
            up = ui.botao_icone("go-up-symbolic", "Subir", lambda: self.mover(ids, index, -1))
            up.set_sensitive(index > 0)
            down = ui.botao_icone("go-down-symbolic", "Descer", lambda: self.mover(ids, index, 1))
            down.set_sensitive(index < len(ids) - 1)
            remove = ui.botao_icone("edit-delete-symbolic", "Remover",
                                    lambda: self.publicar_menu(ids[:index] + ids[index + 1:]))
            for button in (up, down, remove):
                box.pack_start(button, False, False, 0)
            row.add(box)
            return row

        def mover(self, ids, index, delta):
            novo = list(ids)
            destino = index + delta
            if 0 <= destino < len(novo):
                novo[index], novo[destino] = novo[destino], novo[index]
                self.publicar_menu(novo)

        def publicar_menu(self, ids):
            self.fixados_count.set_text("Publicando…")

            def done(result):
                texto = ui.texto_do_resultado(result)
                if texto:
                    notice(self.window, texto, error=True)
                self.signature = None
                self.refresh()
                return False
            run_async(lambda: self.controller.definir_menu(ids), done)

        def add_app_clicked(self, _button):
            ids = list(self.controller.menu_ids)
            if len(ids) >= MAX_FIXADOS:
                notice(self.window, LIMITE_FIXADOS, error=True)
                return
            dialog = ui._dialogo(self.window, "Adicionar app ao menu dos alunos", None, cancelar="Fechar")
            dialog.set_default_size(420, 520)
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, border_width=16)
            busca = Gtk.SearchEntry()
            busca.set_placeholder_text("Buscar app")
            box.pack_start(busca, False, False, 0)
            apps = sorted(self.apps().items(), key=lambda item: (item[1].get_display_name() or item[0]).lower())
            listbox = lista()
            for app_id, info in apps:
                row = Gtk.ListBoxRow()
                row.app_id = app_id
                row.nome = (info.get_display_name() or app_id).lower()
                linha = Gtk.Box(spacing=12, border_width=8)
                icon = info.get_icon()
                image = Gtk.Image.new_from_gicon(icon, Gtk.IconSize.LARGE_TOOLBAR) if icon else \
                    Gtk.Image.new_from_icon_name("application-x-executable", Gtk.IconSize.LARGE_TOOLBAR)
                image.set_pixel_size(24)
                linha.pack_start(image, False, False, 0)
                linha.pack_start(ui.rotulo(info.get_display_name() or app_id, wrap=False), True, True, 0)
                if app_id in ids:
                    linha.pack_start(ui.rotulo("Fixado", "legenda", wrap=False), False, False, 0)
                    row.set_sensitive(False)
                row.add(linha)
                listbox.add(row)
            listbox.set_filter_func(lambda row: busca.get_text().strip().lower() in row.nome)
            busca.connect("search-changed", lambda *_: listbox.invalidate_filter())
            scroller = Gtk.ScrolledWindow()
            scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            scroller.add(listbox)
            box.pack_start(frame(scroller), True, True, 0)
            escolhido = []
            listbox.set_activate_on_single_click(True)
            listbox.connect("row-activated", lambda _l, row: (escolhido.append(row.app_id),
                                                               dialog.response(Gtk.ResponseType.ACCEPT)))
            dialog.get_content_area().add(box)
            dialog.show_all()
            busca.grab_focus()
            response = dialog.run()
            dialog.destroy()
            if response == Gtk.ResponseType.ACCEPT and escolhido:
                self.publicar_menu(ids + [escolhido[0]])

        @staticmethod
        def remove_button(handler):
            return ui.botao_icone("edit-delete-symbolic", "Remover", handler)

        def rule_row(self, index, rule):
            row = Gtk.ListBoxRow()
            row.set_activatable(False)
            box = Gtk.Box(spacing=12, border_width=8)
            box.pack_start(ui.rotulo(rule["pattern"]), True, True, 0)
            action = self.combo(self.ACTIONS, rule["action"])
            action.connect("changed", lambda widget: self.controller.update_rule(index, rule["pattern"], widget.get_active_id()))
            box.pack_start(action, False, False, 0)
            box.pack_start(self.remove_button(lambda: self.controller.remove_rule(index)), False, False, 0)
            row.add(box)
            return row

        def prova_row(self, index, pattern):
            row = Gtk.ListBoxRow()
            row.set_activatable(False)
            box = Gtk.Box(spacing=12, border_width=8)
            box.pack_start(ui.rotulo(pattern), True, True, 0)
            box.pack_start(self.remove_button(
                lambda: run_async(lambda: self.controller.remover_site_prova(index), lambda *_: False)), False, False, 0)
            row.add(box)
            return row

        def shortcut_row(self, index, shortcut):
            row = Gtk.ListBoxRow()
            row.set_activatable(False)
            box = Gtk.Box(spacing=12, border_width=8)
            texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            texts.pack_start(ui.rotulo(shortcut["label"], "forte"), False, False, 0)
            texts.pack_start(ui.rotulo(shortcut["url"], "fraco", "compacto"), False, False, 0)
            box.pack_start(texts, True, True, 0)
            box.pack_start(ui.botao_icone("document-edit-symbolic", "Editar", lambda: self.edit_shortcut(index, shortcut)),
                           False, False, 0)
            box.pack_start(self.remove_button(
                lambda: self.mutate_home(lambda: self.controller.home.remove_shortcut(index))), False, False, 0)
            row.add(box)
            return row

        def add_rule_clicked(self, *_):
            if self.controller.add_rule(self.rule_pattern.get_text(), self.rule_action.get_active_id()):
                self.rule_pattern.set_text("")
            else:
                notice(self.window, "Digite um site, por exemplo youtube.com.", error=True)

        def mutate_home(self, change):
            change()
            self.publish()

        def publish(self):
            self.home_status.set_text("Publicando…")
            run_async(self.controller.publish_home, lambda *_: self.refresh() or False)

        def title_changed(self, *_):
            if self.loading:
                return False
            title = self.home_title.get_text().strip()
            if title and title != self.controller.home.config["titulo"]:
                self.mutate_home(lambda: self.controller.home.set_title(title))
            return False

        def url_changed(self, *_):
            if self.loading:
                return False
            url = self.home_url.get_text().strip()
            if url == self.controller.home.config["url"]:
                return False
            if self.controller.home.set_url(url):
                self.publish()
            else:
                notice(self.window, "Endereço inválido. Use http:// ou https://, ou deixe vazio.", error=True)
            return False

        def search_changed(self, _switch, state):
            if not self.loading and state != self.controller.home.config["busca"]:
                self.mutate_home(lambda: self.controller.home.set_search(state))
            return False

        def engine_changed(self, widget):
            engine = widget.get_active_id()
            if not self.loading and engine and engine != self.controller.home.config["buscador"]:
                self.mutate_home(lambda: self.controller.home.set_search(self.controller.home.config["busca"], engine))

        def add_shortcut_clicked(self, *_):
            if self.controller.home.add_shortcut(self.shortcut_name.get_text(), self.shortcut_url.get_text()):
                self.shortcut_name.set_text("")
                self.shortcut_url.set_text("")
                self.publish()
            else:
                notice(self.window, "Endereço inválido ou limite de 12 atalhos. Use http:// ou https://.", error=True)

        def edit_shortcut(self, index, shortcut):
            values = ask(self.window, "Editar atalho", [("Nome", shortcut["label"]), ("Endereço", shortcut["url"])])
            if values is None:
                return
            if self.controller.home.update_shortcut(index, values[0], values[1]):
                self.publish()
            else:
                notice(self.window, "Endereço inválido. Use http:// ou https://.", error=True)

    # ---- aba Ajustes -------------------------------------------------------------------

    class SettingsPage(Gtk.Box):
        def __init__(self, window, controller):
            super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=32)
            self.window = window
            self.controller = controller
            self.signature = None

            name_box = section("Professor")
            row = Gtk.Box(spacing=12)
            row.pack_start(ui.rotulo("Nome mostrado aos alunos"), False, False, 0)
            self.name = Gtk.Entry(text=controller.prefs.teacher_name)
            self.name.connect("activate", self.name_changed)
            self.name.connect("focus-out-event", self.name_changed)
            row.pack_start(self.name, True, True, 0)
            name_box.pack_start(row, False, False, 0)
            self.pack_start(name_box, False, False, 0)

            wallpaper = section("Papel de parede da turma")
            wallpaper.pack_start(ui.rotulo("A imagem vai para todos os computadores conectados, inclusive os que conectarem depois.",
                                           "fraco"), False, False, 0)
            row = Gtk.Box(spacing=12)
            choose = Gtk.Button.new_with_label("Escolher imagem…")
            choose.connect("clicked", self.wallpaper_clicked)
            row.pack_start(choose, False, False, 0)
            self.wallpaper_status = ui.rotulo("", "fraco")
            row.pack_start(self.wallpaper_status, True, True, 0)
            wallpaper.pack_start(row, False, False, 0)
            self.pack_start(wallpaper, False, False, 0)

            account = section("Conta Google")
            account.pack_start(ui.rotulo("Necessária para publicar a página inicial e para a escola compartilhada. Entre pelo celular: o app lê um código e este computador vira o mesmo professor.",
                                         "fraco"), False, False, 0)
            row = Gtk.Box(spacing=12)
            self.phone_login = Gtk.Button.new_with_label("Entrar pelo celular")
            self.phone_login.connect("clicked", self.phone_login_clicked)
            row.pack_start(self.phone_login, False, False, 0)
            self.login = Gtk.Button.new_with_label("Entrar com Google")
            self.login.connect("clicked", self.login_clicked)
            row.pack_start(self.login, False, False, 0)
            self.account_status = ui.rotulo("", "fraco")
            row.pack_start(self.account_status, True, True, 0)
            account.pack_start(row, False, False, 0)
            self.pack_start(account, False, False, 0)

            school = section("Escola")
            school.pack_start(ui.rotulo("Na escola compartilhada, todos os professores veem os mesmos computadores e regras.",
                                        "fraco"), False, False, 0)
            row = Gtk.Box(spacing=12)
            self.join = Gtk.Button.new_with_label("Entrar na escola")
            self.join.connect("clicked", lambda *_: self.school_action(controller.join_school))
            self.create = Gtk.Button.new_with_label("Criar a escola")
            self.create.connect("clicked", self.create_clicked)
            row.pack_start(self.join, False, False, 0)
            row.pack_start(self.create, False, False, 0)
            self.school_status = ui.rotulo("", "fraco")
            row.pack_start(self.school_status, True, True, 0)
            school.pack_start(row, False, False, 0)
            self.pack_start(school, False, False, 0)

        def refresh(self):
            controller = self.controller
            signature = (controller.wallpaper.hash, controller.email, controller.school_active, controller.google_available,
                         controller.not_allowed)
            if signature == self.signature:
                return
            self.signature = signature
            self.wallpaper_status.set_text(
                f"Imagem definida ({controller.wallpaper.hash})." if controller.wallpaper.hash else "Nenhuma imagem definida.")
            if controller.email:
                self.account_status.set_text(f"Conectada como {controller.email}.")
                self.phone_login.set_label("Trocar pelo celular")
                self.login.set_label("Trocar de conta")
            else:
                self.account_status.set_text("Não conectada.")
            self.login.set_visible(controller.google_available)
            if controller.not_allowed:
                self.school_status.set_text("Aguardando o professor que criou a escola liberar o seu e-mail.")
            else:
                self.school_status.set_text("Escola compartilhada ativa." if controller.school_active else "Modo isolado: só este professor.")
            self.join.set_sensitive(not controller.school_active)
            self.create.set_sensitive(not controller.school_active)

        def name_changed(self, *_):
            self.controller.set_teacher_name(self.name.get_text())
            return False

        def wallpaper_clicked(self, _button):
            dialog = Gtk.FileChooserDialog(title="Escolher papel de parede", transient_for=self.window,
                                           action=Gtk.FileChooserAction.OPEN)
            dialog.add_button("Cancelar", Gtk.ResponseType.CANCEL)
            dialog.add_button("Escolher", Gtk.ResponseType.ACCEPT)
            images = Gtk.FileFilter()
            images.set_name("Imagens")
            images.add_mime_type("image/*")
            dialog.add_filter(images)
            response = dialog.run()
            path = dialog.get_filename()
            dialog.destroy()
            if response != Gtk.ResponseType.ACCEPT or not path:
                return
            self.wallpaper_status.set_text("Enviando…")
            self.window.busy(True)
            run_async(lambda: self.controller.set_wallpaper(image_to_jpeg(path)), self.wallpaper_done)

        def wallpaper_done(self, result):
            self.window.busy(False)
            if isinstance(result, Exception):
                self.signature = None
                notice(self.window, IMAGEM_FALHOU, error=True)
            self.refresh()
            return False

        def phone_login_clicked(self, _button):
            dialog = PhoneLoginDialog(self.window, self.controller)
            dialog.run()
            dialog.destroy()
            self.controller.cancel_phone_login()
            self.signature = None
            self.refresh()

        def login_clicked(self, _button):
            self.account_status.set_text("Conclua o login no navegador…")
            self.window.busy(True)
            run_async(self.controller.login_google, self.action_done)

        def create_clicked(self, _button):
            if confirm(self.window, "Criar a escola com a sua chave?",
                       "Os outros professores entram com \"Entrar na escola\" e passam a compartilhar computadores e regras. Isso só pode ser feito uma vez.", "Criar"):
                self.school_action(self.controller.create_school)

        def school_action(self, action):
            self.window.busy(True)
            run_async(action, self.action_done)

        def action_done(self, result):
            self.window.busy(False)
            self.signature = None
            self.refresh()
            texto = ui.texto_do_resultado(result)
            if texto:
                notice(self.window, texto, error=True)
            return False

    # ---- janela ------------------------------------------------------------------------

    class Window(Gtk.ApplicationWindow):
        def __init__(self, app, controller):
            super().__init__(application=app, title="Controle do Professor")
            self.estilo = ui.Estilo()
            ui.vestir(self)
            self.set_wmclass("controle-de-aula-professor", "controle-de-aula-professor")
            self.set_icon_name("computer")
            self.set_default_size(*default_window_size(Gdk, 960, 640))
            self.controller = controller
            self._refresh_pendente = False
            controller.on_change = self._agendar_refresh
            controller.on_recado = lambda *args: GLib.idle_add(self.recado, *args)

            outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
            outer.set_border_width(24)
            self.add(outer)
            top = Gtk.Box(spacing=16)
            self.stack = Gtk.Stack()
            self.stack.set_transition_type(Gtk.StackTransitionType.NONE)
            switcher = Gtk.StackSwitcher()
            switcher.set_stack(self.stack)
            top.pack_start(switcher, False, False, 0)
            self.retry = Gtk.Button.new_with_label("Tentar de novo")
            self.retry.connect("clicked", self.retry_clicked)
            self.retry.set_valign(Gtk.Align.CENTER)
            top.pack_end(self.retry, False, False, 0)
            self.status = ui.rotulo("Conectando…", "fraco", "compacto", xalign=1)
            top.pack_end(self.status, True, True, 0)
            self.spinner = Gtk.Spinner()
            top.pack_end(self.spinner, False, False, 0)
            outer.pack_start(top, False, False, 0)

            self.pages = []
            for name, title, page in (
                ("aula", "Aula", AulaPage(self, controller)),
                ("sites", "Sites", SitesPage(self, controller)),
                ("ajustes", "Ajustes", SettingsPage(self, controller)),
            ):
                if name == "aula":
                    holder = page  # a Aula rola só a lista/grade; o cabeçalho fica parado
                else:
                    holder = Gtk.ScrolledWindow()
                    holder.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
                    holder.add(page)
                self.stack.add_titled(holder, name, title)
                self.pages.append(page)
            self.stack.connect("notify::visible-child-name", self.page_changed)
            outer.pack_start(self.stack, True, True, 0)
            self.connect("destroy", lambda *_: threading.Thread(target=controller.stop, daemon=True).start())
            self.show_all()
            self.spinner.hide()
            self.retry.hide()
            self.refresh()
            self.busy(True)
            run_async(controller.start, lambda *_: self.busy(False) or False)
            # Idade das mãos (10 min) e das miniaturas sem depender da rede.
            GLib.timeout_add_seconds(TIQUE_S, lambda: self.refresh() or True)

        def page_changed(self, *_):
            if self.stack.get_visible_child_name() != "aula":
                self.pages[0].pagina_escondida()

        def mostrar_sites_da_prova(self):
            self.stack.set_visible_child_name("sites")
            sites = self.pages[1]
            sites.prova_pattern.grab_focus()

        def recado(self, kind, title, body, device_id=None):
            # Conversa aberta e em foco já mostra a mensagem: não toca.
            if kind == "chat" and device_id and self.pages[0].conversa_ativa(device_id):
                return False
            ui.notificar(title, body)
            return False

        def _agendar_refresh(self):
            if not self._refresh_pendente:
                self._refresh_pendente = True
                GLib.idle_add(self._refresh_agendado)

        def _refresh_agendado(self):
            self._refresh_pendente = False
            self.refresh()
            return False

        def retry_clicked(self, _button):
            self.retry.set_sensitive(False)
            self.busy(True)
            run_async(self.controller.restart, lambda *_: self.retry.set_sensitive(True) or self.busy(False) or False)

        def busy(self, active):
            self.spinner.set_visible(active)
            if active:
                self.spinner.start()
            else:
                self.spinner.stop()

        def refresh(self):
            controller = self.controller
            self.retry.set_visible(controller.not_allowed)
            if controller.error:
                self.status.set_text(controller.error)
            elif controller.connected:
                mode = "escola compartilhada" if controller.school_active else "modo isolado"
                self.status.set_text(f"Conectado · {mode}")
            else:
                self.status.set_text("Conectando…")
            for page in self.pages:
                page.refresh()
            return False

    controller = TeacherController(TeacherController.load_config())
    application = Gtk.Application(application_id="br.escola.celita.ControleDeAulaProfessor",
                                  flags=Gio.ApplicationFlags.FLAGS_NONE)

    def activate(app):
        window = app.get_active_window()
        if window:
            window.present()
        else:
            Window(app, controller)

    application.connect("activate", activate)
    return application.run([])

