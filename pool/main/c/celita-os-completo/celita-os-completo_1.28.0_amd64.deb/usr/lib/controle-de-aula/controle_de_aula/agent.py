"""Laço principal do agente, espelho do offscreen.js da extensão.

Identidade e pareamento vivem aqui; a extensão no Voges é só o braço para
abas. Comandos que dependem da sessão gráfica correm na sessão controlada
ativa, e sem sessão respondem sem_sessao.
"""

import base64
import grp
import json
import logging
import os
import signal
import sys
import threading
import time
import uuid

from . import VERSION, archive, protocol, session as sess, up as upmod
from .access import can_bridge, can_manage
from .archive import Archiver, Clock
from .bridge import ADMIN_SOCKET_PATH, BridgeServer
from .chat import (
    ALUNO_MAX_MESSAGE,
    ALUNO_SOCKET_PATH,
    CHAT_BIN,
    CHAT_UNIT,
    TEXTO_SEM_ENVIO,
    ChatAluno,
    texto_liberado,
    texto_recusa,
)
from .cloud import CloudClient
from .crypto import (
    derive_session_key,
    generate_private_key,
    new_token,
    private_key_from_b64url,
    private_key_to_b64url,
    public_key_b64url,
)
from .firebase import FirebaseError, FirebaseSession
from .homepage import HomePolicy
from .limites import Limites
from .menu_pins import MenuPins
from .midia import MediaLibrary
from .miniaturas import Miniaturas
from .trava import EstadoComPrazo, Trava

log = logging.getLogger("controle-de-aula")

STATE_DIR = "/var/lib/controle-de-aula"
STATE_FILE = os.path.join(STATE_DIR, "estado.json")
FIREBASE_CONFIG = "/usr/share/controle-de-aula/firebase.json"
STUCK_CONNECTING_S = 20
MAX_WALLPAPER_BYTES = 10 * 1024 * 1024
TURMA_TICK_S = 2
# A ponte (extensão empacotada) só entende `prova` a partir desta versão.
PONTE_PROVA_MINIMA = (0, 7, 0)


def versao_tupla(texto) -> tuple:
    """Versão "0.7.0" → (0, 7, 0); qualquer coisa ilegível conta como antiga."""
    partes = []
    for parte in str(texto or "").split("."):
        digitos = "".join(c for c in parte if c.isdigit()) if parte[:1].isdigit() else ""
        if not digitos:
            break
        partes.append(int(digitos))
    return tuple(partes) or (0,)


class Storage:
    """Estado persistente em um JSON só, gravado atomicamente e legível só por root."""

    def __init__(self, path: str = STATE_FILE):
        self.path = path
        self._lock = threading.Lock()
        self._data = self._load()

    def _load(self) -> dict:
        try:
            with open(self.path, encoding="utf-8") as handle:
                data = json.load(handle)
                return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def get(self, key: str):
        with self._lock:
            return self._data.get(key)

    def set(self, key: str, value):
        with self._lock:
            if value is None:
                self._data.pop(key, None)
            else:
                self._data[key] = value
            os.makedirs(os.path.dirname(self.path), mode=0o700, exist_ok=True)
            temporary = self.path + ".tmp"
            with open(temporary, "w", encoding="utf-8") as handle:
                json.dump(self._data, handle, ensure_ascii=False)
            os.chmod(temporary, 0o600)
            os.replace(temporary, self.path)


class Agent:
    def __init__(self, storage: Storage, firebase_config: dict):
        self.storage = storage
        self.firebase_config = firebase_config
        self.fb = None
        self.identity = None
        self.client = None
        self.bind_watch = None
        self.bind_result = None
        self.bind_event = threading.Event()
        self.sessions = sess.SessionTracker()
        self.state = "connecting"
        self.detail = None
        self.teacher_name = None
        self.state_changed_at = time.monotonic()
        self._restart_requested = threading.Event()
        # Guardada aqui para o laço do arquivo; None sem vínculo.
        self.session_key = None
        self.clock = Clock()
        self.home_policy = HomePolicy()
        self.archiver = Archiver(
            storage, self.clock,
            get_fb=lambda: self.fb,
            get_link=self._archive_link,
            sessions=self.sessions,
            bucket=firebase_config.get("storageBucket"),
            state_dir=os.path.dirname(storage.path),
            capture=sess.capture_camera_jpeg,
        )
        self.midia = MediaLibrary(
            storage, self.clock,
            get_fb=lambda: self.fb,
            get_link=self._archive_link,
            escola_ok=self.archiver.escola,
            bucket=firebase_config.get("storageBucket"),
        )
        # Recursos de turma: trava e prova com cópia local, grade, chat, limites.
        self.limites = Limites(storage, agora=self.clock.now_ms)
        self.trava = Trava(storage, self.clock, self.sessions, on_change=self._trava_mudou)
        self.prova = EstadoComPrazo(storage, "prova", self.clock, protocol.PROVA_TETO, protocol.clean_exam)
        self.miniaturas = Miniaturas(self.sessions, lambda: self.client)
        self.menu_pins = MenuPins(storage)
        self.chat = ChatAluno(self.sessions, self._enviar_up, self.trava.travado,
                              lambda: self.state == "connected", self._nome_professor, self._abrir_chat,
                              agora_ms=self.clock.now_ms)
        self._up_lock = threading.Lock()
        # Pedidos da página de bloqueio em voo ao mesmo tempo: uma ponte que
        # inunda {t:'up'} não vira uma thread por mensagem.
        self._pedidos_ponte = threading.BoundedSemaphore(4)
        self._turma_wake = threading.Event()
        self._prova_efetiva = None
        self._prova_fechou = None
        # Rev da prova que já foi à ponte: a liberação em prova só recarrega
        # a aba depois de a ponte ter a lista nova.
        self._prova_rev_ponte = 0
        try:
            gid = grp.getgrnam(sess.CONTROLLED_GROUP).gr_gid
        except KeyError:
            gid = None
        self.bridges = BridgeServer(self._on_bridge_message, gid, authorize=can_bridge)
        self.admins = BridgeServer(self._on_admin_message, None,
                                  socket_path=ADMIN_SOCKET_PATH, mode=0o666,
                                  authorize=can_manage, max_message_bytes=8192)
        # Janela de chat do aluno: só a sessão controlada ativa é atendida.
        self.alunos = BridgeServer(self.chat.on_message, gid, socket_path=ALUNO_SOCKET_PATH,
                                   mode=0o660, authorize=can_bridge, max_message_bytes=ALUNO_MAX_MESSAGE)
        self.chat.server = self.alunos

    # ---- Estado ---------------------------------------------------------------

    def _broadcast(self, state: str, detail=None, teacher=None):
        if detail:
            log.info("%s: %s", state, detail)
        if state != self.state:
            self.state = state
            self.state_changed_at = time.monotonic()
        self.detail = detail
        if teacher:
            self.teacher_name = teacher
        self.bridges.broadcast(self._state_message())
        self._broadcast_admin()
        self.chat.estado_conexao(self.state == "connected")

    def _admin_message(self):
        return {"t": "admin-state", "status": self._state_message(),
                "bound": bool(self.storage.get("binding")),
                "pairing": self._pairing_message()["dados"]
                if self.state == "pairing" and not self.storage.get("binding") else None}

    def _broadcast_admin(self):
        self.admins.broadcast(self._admin_message())

    def _state_message(self) -> dict:
        binding = self.storage.get("binding") or {}
        return {
            "t": "state",
            "state": self.state,
            "detail": self.detail,
            "teacher": self.teacher_name,
            "numero": binding.get("numero"),
            "label": self.identity["label"] if self.identity else None,
            "version": VERSION,
        }

    def _pairing_message(self):
        pairing = self.storage.get("pairing") or {}
        if not self.identity or not pairing.get("token"):
            return {"t": "pairing", "dados": None}
        return {
            "t": "pairing",
            "dados": {
                "deviceId": self.identity["deviceId"],
                "pub": self.identity["pub"],
                "token": pairing["token"],
                "label": self.identity["label"],
            },
        }

    # ---- Identidade e Firebase --------------------------------------------------

    def _ensure_identity(self) -> dict:
        if self.identity:
            return self.identity
        saved = self.storage.get("keypair")
        if isinstance(saved, dict) and saved.get("priv"):
            key = private_key_from_b64url(saved["priv"])
            self.identity = {
                "key": key,
                "pub": public_key_b64url(key),
                "deviceId": saved["deviceId"],
                "label": saved.get("label") or "Celita",
            }
            return self.identity
        key = generate_private_key()
        device_id = str(uuid.uuid4())
        label = "Celita-" + device_id[:4]
        self.storage.set("keypair", {
            "priv": private_key_to_b64url(key),
            "deviceId": device_id,
            "label": label,
        })
        self.identity = {"key": key, "pub": public_key_b64url(key), "deviceId": device_id, "label": label}
        return self.identity

    def _ensure_pair_token(self) -> str:
        saved = self.storage.get("pairing")
        if isinstance(saved, dict) and saved.get("token"):
            return saved["token"]
        token = new_token()
        self.storage.set("pairing", {"token": token})
        return token

    def _rotate_token(self) -> str:
        token = new_token()
        self.storage.set("pairing", {"token": token})
        try:
            self.fb.put(f"/devices/{self.identity['deviceId']}/pairing/token", token)
        except Exception as error:  # noqa: BLE001
            log.warning("token não rotacionou no servidor: %s", error)
        return token

    def _ensure_firebase(self) -> FirebaseSession:
        if self.fb and self.fb.id_token:
            return self.fb
        if self.fb:
            self.fb.stop()
        self.fb = FirebaseSession(
            api_key=self.firebase_config["apiKey"],
            database_url=self.firebase_config["databaseURL"],
            load_auth=lambda: self.storage.get("fbauth"),
            save_auth=lambda auth: self.storage.set("fbauth", auth),
        )
        self.fb.on_server_date = self.clock.observe
        self.fb.sign_in()
        return self.fb

    def _register(self, token: str):
        identity = self.identity
        meta = {
            "uid": self.fb.uid,
            "pub": identity["pub"],
            "label": identity["label"],
            "v": 4,
            "ext": f"celita-{VERSION}",
        }
        # O professor quer ver a versão do sistema, não a do agente: é ela que
        # diz se o PC está atualizado.
        os_version = sess.celita_version()
        if os_version:
            meta["os"] = os_version
        try:
            self.fb.patch(f"/devices/{identity['deviceId']}/meta", meta)
        except FirebaseError as error:
            # Rules antigas no console não conhecem meta/ext e negam o PATCH
            # inteiro; ficar sem registrar seria ficar invisível para sempre.
            if error.status != 401:
                raise
            log.warning("rules do Firebase recusam meta/ext; registrando sem a versão")
            meta.pop("ext")
            meta.pop("os", None)
            self.fb.patch(f"/devices/{identity['deviceId']}/meta", meta)
        self.fb.put(f"/devices/{identity['deviceId']}/pairing/token", token)
        self.fb.put(f"/device_uids/{self.fb.uid}", identity["deviceId"])

    def _wait_for_bind(self, token: str):
        if self._restart_requested.is_set() or self.fb is None:
            return None
        self.bind_result = None
        self.bind_event.clear()
        snapshot = {}

        def on_event(event):
            nonlocal snapshot
            if self._restart_requested.is_set() or self.bind_result is not None:
                return
            data = event.get("data")
            path = event.get("path")
            if path == "/":
                if event.get("type") == "patch" and isinstance(data, dict):
                    snapshot.update(data)
                else:
                    snapshot = dict(data) if isinstance(data, dict) else {}
            elif isinstance(path, str) and path.count("/") == 1:
                snapshot[path[1:]] = data
            else:
                return
            if not snapshot:
                self._broadcast("pairing", "aguardando o professor escanear o QR")
                return
            if snapshot.get("token") != token:
                # Vínculo velho no servidor (desvincular sem rede não apaga o
                # nó). Voltar para "pairing" mantém o QR na tela; sem isso a
                # máquina fica presa em "connecting" e não há como parear.
                self._broadcast("pairing", "aguardando o professor escanear o QR")
                return
            uid, pub = snapshot.get("teacherUid"), snapshot.get("teacherPub")
            if not isinstance(uid, str) or not uid or not isinstance(pub, str):
                return
            try:
                # Rejeita uma chave incompleta/inválida antes de persistir o
                # vínculo; o próximo evento pode completar um patch parcial.
                derive_session_key(self.identity["key"], pub)
            except (ValueError, TypeError):
                return
            name = snapshot.get("teacherName")
            name = name.strip() if isinstance(name, str) and name.strip() else "Professor"
            numero = snapshot.get("numero")
            self.bind_result = {
                "teacherUid": uid,
                "teacherPub": pub,
                "teacherName": name,
                "numero": numero if isinstance(numero, int) and not isinstance(numero, bool)
                and 1 <= numero <= 9999 else None,
            }
            # Atualiza a janela ANTES de fechar o stream/rotacionar o token:
            # essas operações de rede não devem deixar um QR já usado na tela.
            self._broadcast("configuring", "configurando o vínculo com o professor", name)
            self.bind_event.set()

        def on_bind_stream_down(reason: str):
            # Com o QR ainda na tela, a queda do stream não muda nada para o
            # professor: o código continua válido. Sair de "pairing" apagaria
            # o QR, e a renovação de token derruba o stream a cada ~55 min.
            if self.state != "pairing":
                self._broadcast("connecting", reason)

        watch = self.fb.stream(
            f"/devices/{self.identity['deviceId']}/bind", on_event,
            on_down=on_bind_stream_down,
        )
        self.bind_watch = watch
        try:
            if not self._restart_requested.is_set():
                self.bind_event.wait()
        finally:
            watch.close()
            self.bind_watch = None
        return None if self._restart_requested.is_set() else self.bind_result

    def _unbind(self):
        if self.client:
            self.client.stop()
        self.session_key = None
        self.archiver.reset()
        self.storage.set("binding", None)
        self.storage.set("replay", None)
        self.storage.set("classview", None)
        self.teacher_name = None
        # Sem professor não há trava, prova, grade nem conversa: desfaz o overlay
        # e o mudo agora e esquece as cópias locais.
        prova_ligada = self.prova.efetivo()
        self.trava.limpar()
        self.prova.limpar()
        self.limites.limpar()
        self.miniaturas.parar()
        self.chat.fim_de_aula()
        if prova_ligada:
            self.bridges.broadcast(self._rules_message())
        if not (self.fb and self.fb.id_token):
            return
        base = f"/devices/{self.identity['deviceId']}"
        for suffix in ("bind", "report", "ack", "presence", "snapshot"):
            try:
                self.fb.delete(f"{base}/{suffix}")
            except Exception:  # noqa: BLE001
                pass
        # Nós novos pelo caminho lateral: rules atrasadas não reconectam nada.
        for path in (f"{base}/up", f"/thumbs/{self.identity['deviceId']}"):
            try:
                self.fb.side_request("DELETE", path)
            except Exception:  # noqa: BLE001
                pass
        self._rotate_token()

    def _apply_unit_number(self, numero: int) -> dict:
        # Mesma validação do bind: sem ela um payload torto virava
        # "Unidade None" gravado no disco e publicado no Firebase.
        if not isinstance(numero, int) or isinstance(numero, bool) or not 1 <= numero <= 9999:
            return {"ok": False, "error": "numero_invalido"}
        binding = self.storage.get("binding")
        if isinstance(binding, dict):
            self.storage.set("binding", {**binding, "numero": numero})
        label = f"Unidade {numero}"
        keypair = self.storage.get("keypair")
        if isinstance(keypair, dict):
            self.storage.set("keypair", {**keypair, "label": label})
        self.identity["label"] = label
        try:
            self.fb.patch(f"/devices/{self.identity['deviceId']}/meta", {"label": label})
        except Exception as error:  # noqa: BLE001
            log.warning("label não subiu: %s", error)
        self.bridges.broadcast(self._state_message())
        self._broadcast_admin()
        return {"ok": True}

    def restart_connection(self, reason: str = "reinício pedido"):
        log.info("reconectando: %s", reason)
        self._restart_requested.set()
        if self.fb:
            self.fb.stop()
            self.fb = None
        self.bind_event.set()
        if self.client:
            self.client.stop()

    # ---- Ponte com o navegador --------------------------------------------------

    def _active_bridge(self):
        session = self.sessions.active()
        if not session:
            return None, None
        return session, self.bridges.client_for_uid(session.uid)

    def _on_bridge_message(self, client, message: dict):
        kind = message.get("t")
        if kind == "hello":
            client.send(self._state_message())
            client.send(self._rules_message())
            client.send({"t": "classview", "snapshot": self.storage.get("classview")})
            self._verificar_prova_ponte()
        elif kind == "get":
            if message.get("req") != "pairing":
                client.send(self._state_message())
        elif kind == "report":
            if self.client:
                self.client.request_report()
            session = self.sessions.active()
            if session and client.uid == session.uid and isinstance(client.last_report, dict):
                self.archiver.offer_report(client.uid, client.last_report.get("events"))
        elif kind == "up":
            self._up_da_ponte(client, message)
        # A ponte do aluno só executa abas e entrega relatórios. Nunca recebe
        # o token de pareamento nem administra o vínculo.

    def _on_admin_message(self, client, message: dict):
        if not can_manage(client.uid):
            client.close()
            return
        kind = message.get("t")
        if kind in ("hello", "get"):
            client.send(self._admin_message())
        elif kind == "unbind":
            threading.Thread(target=self._unbind_from_admin, daemon=True).start()
        elif kind == "reconnect":
            self.restart_connection("aplicativo do professor")
            self._broadcast("connecting", "reconectando")

    def _unbind_from_admin(self):
        self._unbind()
        self.bind_event.set()
        self._broadcast("pairing", "desvinculado; escaneie o QR para parear de novo")

    def _ias_liberadas(self) -> bool:
        session = self.sessions.active()
        return session is not None and self.storage.get("iasLiberadas") == session.key

    def _rules_message(self) -> dict:
        # alerts nunca vai à extensão: o aviso é do professor e do arquivo.
        rules = self.storage.get("rules")
        rules = rules if isinstance(rules, dict) else {}
        filtros = self.storage.get("filtros")
        filtros = dict(filtros) if isinstance(filtros, dict) else protocol.clean_filtros(None)
        # A liberação vale só para a sessão em que foi dada: acaba no logout.
        if self._ias_liberadas():
            filtros["ias"] = False
        message = {"t": "rules", "rev": rules.get("rev", 0), "rules": rules.get("rules", []), "filtros": filtros}
        # Ponte antiga ignora a chave; ponte nova sem `prova` mantém o que tinha.
        prova = self.prova.copia()
        ligada = self.prova.efetivo()
        message["prova"] = {"on": ligada, "allow": prova.get("allow", []) if ligada else []}
        if ligada and prova.get("inicio"):
            message["prova"]["inicio"] = prova["inicio"]
        return message

    # ---- Recursos de turma --------------------------------------------------------

    def _nome_professor(self):
        binding = self.storage.get("binding")
        nome = binding.get("teacherName") if isinstance(binding, dict) else None
        return upmod.limpar_texto(nome, protocol.MAX_CHAT_DE).replace("\n", " ") or None

    def _abrir_chat(self, session):
        result = sess.spawn_unit(session, CHAT_UNIT, [CHAT_BIN, "--sem-foco"], restart=False)
        if not result.get("ok"):
            log.warning("janela de chat não subiu")

    def _enviar_up(self, session, tipo, payload, mid):
        """Ponto único de saída aluno → professor, com os limites de §2.4:
        (ok, erro, aviso para o aluno)."""
        limpo = upmod.limpar_payload(tipo, payload)
        if limpo is None:
            return False, "payload_invalido", TEXTO_SEM_ENVIO
        site = limpo.get("site")
        with self._up_lock:
            aviso = self.limites.verificar(session.key, tipo, site)
            if aviso:
                return False, "limite", aviso
            client = self.client
            if client is None:
                return False, "sem_conexao", TEXTO_SEM_ENVIO
            ok, erro = client.send_up(tipo, limpo, mid)
            if ok:
                self.limites.registrar(session.key, tipo, site, mid)
        return ok, erro, None if ok else TEXTO_SEM_ENVIO

    def _up_da_ponte(self, client, message: dict):
        """Pedido de liberação da página de bloqueio (via extensão empacotada)."""
        session = self.sessions.active()
        if session is None or client.uid != session.uid:
            client.close()
            return
        request_id = str(message.get("id") or "")[:64]
        # A extensão usa o próprio mid (novoId) como id do pedido: o professor
        # e a página de bloqueio falam do mesmo item.
        if upmod.id_valido(message.get("mid")):
            mid = message["mid"]
        elif upmod.id_valido(request_id):
            mid = request_id
        else:
            mid = upmod.new_id()

        def responder(ok=False, erro="payload_invalido"):
            reply = {"t": "up-result", "id": request_id, "ok": ok, "mid": mid}
            if erro:
                reply["erro"] = erro
            client.send(reply)

        if message.get("tipo") != protocol.UP_UNBLOCK:
            responder()
            return
        if not self._pedidos_ponte.acquire(blocking=False):
            responder(erro="limite")
            return

        def enviar():
            try:
                ok, erro, _aviso = self._enviar_up(session, protocol.UP_UNBLOCK, message.get("payload"), mid)
            except Exception as error:  # noqa: BLE001 - a página sempre recebe resposta
                log.warning("pedido da ponte falhou: %s", error)
                ok, erro = False, "sem_conexao"
            try:
                responder(ok, erro)
            finally:
                self._pedidos_ponte.release()

        # A rede não pode prender a leitura da ponte (respostas de exec).
        threading.Thread(target=enviar, name="up-ponte", daemon=True).start()

    def _trava_mudou(self, travado: bool):
        self.chat.trava(travado)
        if self.client:
            self.client.request_report()

    def _prova_aplicado(self) -> dict:
        copia = self.prova.copia()
        item = {"rev": copia.get("rev") or 0, "on": False}
        if not self.prova.efetivo():
            return item
        session, bridge = self._active_bridge()
        if session is None:
            item.update(on=True, erro="sem_sessao")
        elif self._ponte_antiga(bridge):
            item["erro"] = "navegador_antigo"
        else:
            # Sem ponte (navegador fechado, ou aberto sem hello ainda) a prova
            # fica armada para quando a ponte se apresentar.
            item["on"] = True
        return item

    @staticmethod
    def _ponte_antiga(bridge) -> bool:
        # version None = ainda sem hello: não se sabe, não fecha nada. Hello
        # sem versão ("") é de extensão antiga.
        return bridge is not None and bridge.version is not None and \
            versao_tupla(bridge.version) < PONTE_PROVA_MINIMA

    def _verificar_prova_ponte(self):
        """Ponte antiga não aplica a prova: fecha o navegador uma vez por
        (rev de ligar, sessão), e ele reabre com a extensão nova."""
        if not self.prova.efetivo():
            return
        session, bridge = self._active_bridge()
        if session is None or not self._ponte_antiga(bridge):
            return
        chave = (self.prova.copia().get("revLigar"), session.key)
        if self._prova_fechou == chave:
            return
        self._prova_fechou = chave
        log.info("prova com navegador antigo (%s): fechando para reabrir", bridge.version)
        threading.Thread(target=lambda: bridge.exec(protocol.CLOSE_ALL_TABS, {"closeWindows": True}),
                         name="prova-navegador", daemon=True).start()

    def _prova_tick(self, forcar: bool = False):
        efetiva = self.prova.efetivo()
        if forcar or efetiva != self._prova_efetiva:
            self._prova_efetiva = efetiva
            rev = _numero(self.prova.copia().get("rev"))
            self.bridges.broadcast(self._rules_message())
            self._prova_rev_ponte = max(self._prova_rev_ponte, rev)
            if self.client:
                self.client.request_report()
        self._verificar_prova_ponte()

    def _turma_loop(self):
        # Por nível e sem esperar o Firebase: um boot sem rede volta travado.
        while True:
            for step in (self.trava.tick, self._prova_tick, self.chat.tick):
                try:
                    step()
                except Exception as error:  # noqa: BLE001 - o laço nunca morre
                    log.warning("turma: %s", error)
            self._turma_wake.wait(TURMA_TICK_S)
            self._turma_wake.clear()

    def _fim_de_aula(self, ts=None):
        """Encerrar aula: a conta compartilhada não leva a conversa adiante."""
        self.chat.fim_de_aula()
        self.limites.limpar()
        self.trava.encerrar(ts)
        self.prova.encerrar(ts)
        self._turma_wake.set()

    def _resultado_pedido(self, site: str, approved: bool, motivo: str, rules_rev: int, exam_rev: int):
        if approved:
            # Recarregar antes das regras novas valerem cairia no bloqueio de novo.
            deadline = time.monotonic() + protocol.RECARGA_ESPERA / 1000
            while time.monotonic() < deadline:
                rules = self.storage.get("rules")
                regras_ok = not rules_rev or (isinstance(rules, dict) and _numero(rules.get("rev")) >= rules_rev)
                # A cópia grava antes de a mensagem sair para a ponte: espera a
                # mensagem, senão a aba recarrega com a lista velha.
                prova_ok = not exam_rev or self._prova_rev_ponte >= exam_rev
                if regras_ok and prova_ok:
                    break
                time.sleep(0.1)
        session, bridge = self._active_bridge()
        if bridge:
            result = {"site": site, "approved": approved}
            if motivo:
                result["motivo"] = motivo
            if approved and rules_rev:
                # A extensão também espera as regras dela chegarem a esse rev
                # antes de recarregar (a mensagem rules pode estar a caminho).
                # O rev da prova não vai: na ponte a prova não tem rev próprio.
                result["rulesRev"] = rules_rev
            bridge.exec(protocol.UNBLOCK_RESULT, result)
        if session:
            self.limites.resolver_pedido(session.key, site)
            if approved:
                self.chat.sistema(session, texto_liberado(site))
            else:
                self.chat.sistema(session, texto_recusa(site, motivo), abrir=True)

    # ---- Execução de comandos ---------------------------------------------------

    def _report(self):
        session, bridge = self._active_bridge()
        tabs, events = [], []
        if bridge and bridge.report_is_fresh():
            tabs = bridge.last_report.get("tabs") or []
            events = bridge.last_report.get("events") or []
        apps = sess.list_apps(session, browser_reported=bool(bridge and bridge.report_is_fresh())) if session else []
        client = self.client
        aplicado = {"trava": self.trava.aplicado(), "prova": self._prova_aplicado(),
                    "acks": client.acks_recentes() if client else []}
        return protocol.make_tab_report(tabs, events, apps=apps, user=session.user if session else None,
                                        ias_liberadas=self._ias_liberadas(), aplicado=aplicado)

    def _execute(self, cmd: dict) -> dict:
        kind = cmd.get("type")
        payload = cmd.get("payload") if isinstance(cmd.get("payload"), dict) else {}
        session, bridge = self._active_bridge()

        if kind == protocol.OPEN_URL:
            url = payload.get("url")
            if not protocol.is_safe_http_url(url):
                return {"ok": False, "error": "url_invalida"}
            if bridge:
                return bridge.exec(kind, payload)
            if session:
                return sess.open_browser(session, url)
            return {"ok": False, "error": "sem_sessao"}

        if kind in (protocol.CLOSE_TABS, protocol.CLOSE_ALL_TABS):
            if kind == protocol.CLOSE_ALL_TABS and payload.get("fimDeAula") is True:
                self._fim_de_aula(cmd.get("ts"))
            if bridge:
                return bridge.exec(kind, payload)
            # Navegador fechado: não há aba para fechar, e fechar zero é ok.
            return {"ok": True}

        if kind == protocol.CHAT_MESSAGE:
            # Sem ninguém logado não fica para a próxima sessão: o professor vê
            # "Ninguém logado — não entregue".
            if not session:
                return {"ok": False, "error": "sem_sessao"}
            texto = upmod.limpar_texto(payload.get("texto"), protocol.MAX_CHAT_TEXTO)
            if not texto:
                return {"ok": False, "error": "payload_invalido"}
            de = upmod.limpar_texto(payload.get("de"), protocol.MAX_CHAT_DE).replace("\n", " ") or None
            mid = payload.get("mid") if upmod.id_valido(payload.get("mid")) else (
                cmd.get("id") if upmod.id_valido(cmd.get("id")) else upmod.new_id())
            self.chat.mensagem_professor(session, texto, de, mid, ts=cmd.get("ts"))
            return {"ok": True}

        if kind == protocol.UNBLOCK_RESULT:
            site = payload.get("site")
            if not upmod.site_valido(site) or not isinstance(payload.get("approved"), bool):
                return {"ok": False, "error": "payload_invalido"}
            motivo = upmod.limpar_texto(payload.get("motivo"), protocol.MAX_PEDIDO_MOTIVO)
            # A espera pelas regras novas não pode segurar a fila de comandos
            # (é ela que aplica o state/rules): o ack sai já, o resto segue.
            threading.Thread(
                target=self._resultado_pedido, name="pedido-resultado", daemon=True,
                args=(site, payload["approved"], motivo, _numero(payload.get("rulesRev")),
                      _numero(payload.get("examRev"))),
            ).start()
            return {"ok": True}

        if kind == protocol.SET_LOCK:
            result = self.trava.aplicar(payload, cmd.get("ts"))
            self._turma_wake.set()
            return result

        if kind == protocol.SET_EXAM:
            result = self.prova.aplicar(payload, cmd.get("ts"))
            if result.get("ok"):
                # A lista pode ter mudado com a prova ligada: sempre repassa.
                self._prova_tick(forcar=True)
            return result

        if kind == protocol.SET_MONITOR:
            if cmd.get("payload") is None:
                self.miniaturas.parar()
                return {"ok": True}
            return self.miniaturas.aplicar(payload, cmd.get("ts"))

        if kind == protocol.SET_RULES:
            rules = protocol.clean_rules(payload.get("rules"))
            rev = payload.get("rev") if isinstance(payload.get("rev"), (int, float)) else 0
            previous = self.storage.get("rules")
            # Celular com app antigo não manda alerts: vale a lista anterior.
            if "alerts" in payload:
                alerts = protocol.clean_rules(payload.get("alerts"))
            else:
                alerts = previous.get("alerts", []) if isinstance(previous, dict) else []
            self.storage.set("rules", {"rev": rev, "rules": rules, "alerts": alerts})
            # Mesma regra dos alerts: remetente antigo não apaga os filtros.
            if "filtros" in payload:
                self.storage.set("filtros", protocol.clean_filtros(payload.get("filtros")))
            self.bridges.broadcast(self._rules_message())
            return {"ok": True}

        if kind == protocol.ATUALIZAR:
            return sess.start_update()

        if kind == protocol.LIBERAR_IAS:
            session = self.sessions.active()
            if not session:
                return {"ok": False, "error": "sem_sessao"}
            self.storage.set("iasLiberadas", session.key if payload.get("liberar") is True else None)
            self.bridges.broadcast(self._rules_message())
            if self.client:
                self.client.request_report()
            return {"ok": True}

        if kind == protocol.SET_CLASS_VIEW:
            snapshot = payload.get("snapshot")
            self.storage.set("classview", {**snapshot, "recebidoEm": int(time.time() * 1000)} if snapshot else None)
            self.bridges.broadcast({"t": "classview", "snapshot": self.storage.get("classview")})
            return {"ok": True}

        if kind == protocol.SET_UNIT:
            return self._apply_unit_number(payload.get("numero"))

        if kind == protocol.SHOW_MESSAGE:
            if bridge:
                return bridge.exec(kind, payload)
            if session:
                title = str(payload.get("title") or "Controle de Aula")[: protocol.MAX_MESSAGE_TITLE]
                body = str(payload.get("body") or "")[: protocol.MAX_MESSAGE_BODY]
                if payload.get("popup") is True and payload.get("de"):
                    title = f"Mensagem de {str(payload['de'])[: protocol.MAX_MESSAGE_FROM]}"
                return sess.notify(session, title, body)
            return {"ok": False, "error": "sem_sessao"}

        if kind == protocol.SET_WALLPAPER:
            if not session:
                return {"ok": False, "error": "sem_sessao"}
            try:
                jpeg = base64.b64decode(payload.get("jpegB64") or "")
            except ValueError:
                return {"ok": False, "error": "blob_invalido"}
            if not jpeg or len(jpeg) > MAX_WALLPAPER_BYTES:
                return {"ok": False, "error": "imagem_grande" if jpeg else "blob_invalido"}
            return sess.set_wallpaper(session, jpeg)

        if kind == protocol.CAPTURE_CAMERA:
            result = sess.capture_camera()
            return {**result, "snapshotType": protocol.CAMERA_SNAPSHOT}

        if kind == protocol.ENVIAR_MIDIA:
            return self.midia.pedir_envio(payload.get("mid"))

        if kind == protocol.APAGAR_MIDIA:
            return self.midia.apagar(payload.get("mids"))

        if kind == protocol.CAPTURE_SCREEN:
            if not session:
                return {"ok": False, "error": "sem_sessao"}
            result = sess.capture_screen(session)
            return {**result, "snapshotType": protocol.SCREEN_SNAPSHOT}

        return {"ok": False, "error": "tipo_desconhecido"}

    # ---- Laço principal -----------------------------------------------------------

    def _archive_link(self):
        binding = self.storage.get("binding")
        if not isinstance(binding, dict) or not self.session_key or not self.identity:
            return None
        return {"deviceId": self.identity["deviceId"], "key": self.session_key,
                "teacherUid": binding.get("teacherUid")}

    def _side_loop(self):
        # Arquivo e página inicial: fora do CloudClient, nunca derrubam o canal.
        last_session = None
        while True:
            self.archiver.wake.wait(archive.TICK_S)
            self.archiver.wake.clear()
            try:
                current = self.sessions.active_any()
                if current is not None and current.key != last_session:
                    self.home_policy.refresh_soon()
                    self.menu_pins.refresh_soon()
                last_session = current.key if current is not None else None
            except Exception as error:  # noqa: BLE001
                log.warning("sessões: %s", error)
            for step in (self.archiver.tick, lambda: self.home_policy.tick(self.fb),
                         lambda: self.menu_pins.tick(self.fb)):
                try:
                    step()
                except Exception as error:  # noqa: BLE001 - o laço nunca morre
                    log.warning("laço lateral: %s", error)

    def run(self):
        self.bridges.start()
        self.admins.start()
        self.alunos.start()
        threading.Thread(target=self._stuck_watchdog, name="stuck-watchdog", daemon=True).start()
        threading.Thread(target=self._side_loop, name="side-loop", daemon=True).start()
        threading.Thread(target=self._turma_loop, name="turma", daemon=True).start()
        self.miniaturas.start()
        self.midia.start()
        while True:
            self._restart_requested.clear()
            try:
                self._ensure_identity()
                binding = self.storage.get("binding")
                if isinstance(binding, dict) and binding.get("teacherPub"):
                    # Sem rede o arquivo continua guardando localmente.
                    self.session_key = derive_session_key(self.identity["key"], binding["teacherPub"])
                token = self._ensure_pair_token()
                self._broadcast("connecting", "autenticando no Firebase")
                self._ensure_firebase()
                self._register(token)
                self.archiver.connected()
                self.midia.conectado()
                self.home_policy.refresh_soon()
                self.menu_pins.refresh_soon()

                binding = self.storage.get("binding")
                if not (isinstance(binding, dict) and binding.get("teacherPub")):
                    self._broadcast("pairing", "aguardando o professor escanear o QR")
                    self._broadcast_admin()
                    binding = self._wait_for_bind(token)
                    if not binding:
                        continue
                    self.storage.set("binding", binding)
                    self._broadcast("configuring", "preparando este computador para a aula", binding["teacherName"])
                    self._rotate_token()
                    self._broadcast_admin()
                    log.info("pareado com %s", binding["teacherName"])

                if isinstance(binding.get("numero"), int):
                    label = f"Unidade {binding['numero']}"
                    if self.identity["label"] != label:
                        self._apply_unit_number(binding["numero"])

                session_key = derive_session_key(self.identity["key"], binding["teacherPub"])
                self.session_key = session_key
                # Só o primeiro evento do canal de comandos confirma conexão.
                self._broadcast("connecting", "conectando ao aplicativo do professor", binding["teacherName"])
                self.client = CloudClient(
                    fb=self.fb,
                    device_id=self.identity["deviceId"],
                    session_key=session_key,
                    teacher=binding,
                    on_command=self._execute,
                    get_report=self._report,
                    on_state=lambda ok, detail: self._broadcast(
                        "connected" if ok else "connecting", detail, binding["teacherName"]
                    ),
                    load_replay=lambda: self.storage.get("replay"),
                    save_replay=lambda replay: self.storage.set("replay", replay),
                    clock=self.clock,
                )
                reason = self.client.run()
                self.client = None
                if reason == "unbound":
                    self._unbind()
                    self._broadcast("pairing", "o professor desvinculou este computador")
                elif reason == "foreign_bind":
                    self._broadcast("connecting", "vínculo divergente no servidor; desvincule pelo Controle de Aula")
                    time.sleep(5)
            except Exception as error:  # noqa: BLE001 - qualquer falha só reinicia o laço
                # O erro cru fica no log; a janela mostra texto fixo pelo estado.
                log.warning("conexão falhou: %s", error)
                self._broadcast("connecting", "sem_conexao")
                time.sleep(4)

    def _stuck_watchdog(self):
        # Preso em "connecting" por muito tempo é um socket meio-vivo: refaz do zero.
        while True:
            time.sleep(5)
            if self.state in ("connecting", "configuring") and time.monotonic() - self.state_changed_at > STUCK_CONNECTING_S:
                self.state_changed_at = time.monotonic()
                self.restart_connection("preso em connecting")


def _numero(value) -> int:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return 0
    return int(number) if number == number and abs(number) != float("inf") else 0


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(name)s: %(message)s",
        stream=sys.stderr,
    )
    if os.geteuid() != 0:
        log.error("o agente precisa rodar como root")
        return 1
    try:
        with open(FIREBASE_CONFIG, encoding="utf-8") as handle:
            firebase_config = json.load(handle)
    except (OSError, ValueError) as error:
        log.error("configuração do Firebase ilegível: %s", error)
        return 1
    agent = Agent(Storage(), firebase_config)
    from .lid import LidLogout
    LidLogout().start()
    # SIGUSR1 vem do NetworkManager quando a rede volta.
    signal.signal(signal.SIGUSR1, lambda *_: agent.restart_connection("rede mudou"))
    agent.run()
    return 0
