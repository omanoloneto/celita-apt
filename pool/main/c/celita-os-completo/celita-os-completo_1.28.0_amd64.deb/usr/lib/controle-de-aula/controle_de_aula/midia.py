"""Fotos e vídeos da Câmera do Celita para o professor: índice cifrado em
/midia/{deviceId}, envio sob pedido em partes cifradas no Storage (midia-v1)
e apagar remoto. Tudo com a chave de sessão do PC, como o arquivo.
Formatos em docs/protocolo.md ("Fotos e vídeos da Câmera").

Duas fontes: a pasta Imagens/Câmera de cada conta (o professor guarda as dele;
o aluno, até sair) e /var/lib/celita-camera/<conta>, para onde o logout do
aluno move as dele, guardadas por 15 dias."""

import base64
import hashlib
import json
import logging
import math
import os
import pwd
import re
import secrets
import stat
import subprocess
import sys
import threading
import time

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .crypto import NONCE_LEN, seal
from .firebase import FirebaseError, FirebaseSession

log = logging.getLogger(__name__)

ARQUIVO = "/var/lib/celita-camera"
PASTA = "Câmera"
DIAS = 15
DIA_MS = 24 * 60 * 60 * 1000
TIPOS = {".jpg": "foto", ".mp4": "video"}
VARRER_S = 20
# Arquivo mexido há menos que isto ainda está sendo escrito.
ESTAVEL_S = 3
PARTE = 4 * 1024 * 1024
MAX_ITENS = 1000
MAX_ENVELOPE = 64 * 1024
ENVIO_VIDA_S = 24 * 60 * 60
MINIATURA_S = 30
CONTA_RE = re.compile(r"^[a-z_][a-z0-9_-]{0,31}$")
MID_RE = re.compile(r"^[A-Za-z0-9_-]{16}$")


def media_id(conta: str, nome: str, mtime_ns: int, size: int) -> str:
    """Estável quando o logout move o arquivo: o mv preserva nome e mtime."""
    digest = hashlib.sha256(f"{conta}\0{nome}\0{mtime_ns}\0{size}".encode()).digest()
    return base64.urlsafe_b64encode(digest[:12]).decode("ascii")


def tipo_de(nome: str) -> str | None:
    if nome.startswith("."):
        return None
    return TIPOS.get(os.path.splitext(nome)[1])


def pasta_de_imagens(home: str) -> str:
    """Mesma regra do celita-reset-session: o arquivo é da conta, então só um
    caminho relativo dentro da pasta pessoal vale."""
    valor = ""
    try:
        fd = os.open(os.path.join(home, ".config", "user-dirs.dirs"), os.O_RDONLY | os.O_NOFOLLOW)
        with os.fdopen(fd, "rb") as arquivo:
            texto = arquivo.read(8192).decode("utf-8", "replace")
        for linha in texto.splitlines():
            if linha.startswith("XDG_PICTURES_DIR="):
                valor = linha.split("=", 1)[1].replace('"', "").removeprefix("$HOME/")
                break
    except OSError:
        pass
    if not valor or valor.startswith("/") or ".." in valor:
        valor = "Imagens"
    return valor


def pasta_da_camera(home: str) -> str | None:
    pasta = os.path.join(home, pasta_de_imagens(home), PASTA)
    try:
        if os.path.islink(pasta) or not os.path.isdir(pasta):
            return None
        real = os.path.realpath(pasta)
    except OSError:
        return None
    # Nenhum link criado pela conta leva o root para fora da pasta dela.
    return real if real.startswith(home.rstrip("/") + "/") else None


def contas_com_pasta() -> list:
    contas = []
    for entrada in pwd.getpwall():
        if 1000 <= entrada.pw_uid < 60000 and entrada.pw_dir.startswith("/home/") and CONTA_RE.match(entrada.pw_name):
            contas.append((entrada.pw_name, entrada.pw_dir))
    return contas


def _listar(pasta: str, conta: str, guardado: bool, agora_s: float) -> list:
    itens = []
    try:
        nomes = os.listdir(pasta)
    except OSError:
        return itens
    for nome in nomes:
        tipo = tipo_de(nome)
        if not tipo:
            continue
        caminho = os.path.join(pasta, nome)
        try:
            info = os.lstat(caminho)
        except OSError:
            continue
        if not stat.S_ISREG(info.st_mode) or agora_s - info.st_mtime < ESTAVEL_S:
            continue
        itens.append({
            "mid": media_id(conta, nome, info.st_mtime_ns, info.st_size),
            "caminho": caminho, "conta": conta, "nome": nome, "tipo": tipo,
            "ts": info.st_mtime_ns // 1_000_000, "bytes": info.st_size, "guardado": guardado,
        })
    return itens


def varrer(contas: list, arquivo: str = ARQUIVO, agora_s: float | None = None) -> list:
    """Do mais novo para o mais velho, no máximo MAX_ITENS."""
    agora_s = time.time() if agora_s is None else agora_s
    itens = []
    for conta, home in contas:
        pasta = pasta_da_camera(home)
        if pasta:
            itens += _listar(pasta, conta, False, agora_s)
    if os.path.isdir(arquivo) and not os.path.islink(arquivo):
        for conta in sorted(os.listdir(arquivo)):
            pasta = os.path.join(arquivo, conta)
            if CONTA_RE.match(conta) and not os.path.islink(pasta) and os.path.isdir(pasta):
                itens += _listar(pasta, conta, True, agora_s)
    itens.sort(key=lambda item: item["ts"], reverse=True)
    return itens[:MAX_ITENS]


def vencidos(itens: list, agora_ms: int) -> list:
    return [item for item in itens if item["guardado"] and agora_ms - item["ts"] > DIAS * DIA_MS]


def aad_da_parte(mid: str, r: str, n: int, total: int) -> bytes:
    """Prende cada parte ao envio e à posição: nada de trocar ou reordenar."""
    return f"midia-v1|{mid}|{r}|{n}|{total}".encode("ascii")


def selar_parte(key: bytes, mid: str, r: str, n: int, total: int, dados: bytes,
                nonce: bytes | None = None) -> bytes:
    nonce = nonce if nonce is not None else os.urandom(NONCE_LEN)
    return nonce + AESGCM(key).encrypt(nonce, dados, aad_da_parte(mid, r, n, total))


def objeto_do_indice(item: dict, extra: dict, fix=lambda ms: ms) -> dict:
    ts = fix(item["ts"])
    return {
        "v": 1, "type": "midia", "mid": item["mid"], "tipo": item["tipo"], "nome": item["nome"],
        "conta": item["conta"], "ts": ts, "bytes": item["bytes"], "guardado": item["guardado"],
        "expira": ts + DIAS * DIA_MS if item["guardado"] else None,
        "duracao": extra.get("duracao"), "thumb": extra.get("thumb"),
    }


def envelope_do_indice(key: bytes, objeto: dict) -> str:
    env = seal(key, objeto)
    if len(env) >= MAX_ENVELOPE:
        env = seal(key, {**objeto, "thumb": None})
    return env


def miniatura(caminho: str, tipo: str) -> dict:
    """Miniatura e duração num processo à parte, como nobody: o arquivo pode
    ter sido fabricado pelo aluno, e decodificar vídeo como root seria abrir a
    porta. O filho só recebe o descritor já aberto, sem seguir link."""
    try:
        fd = os.open(caminho, os.O_RDONLY | os.O_NOFOLLOW)
    except OSError:
        return {}
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            return {}
        raiz = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        comando = [sys.executable, "-m", "controle_de_aula.midia_miniatura", tipo, str(fd)]
        if os.geteuid() == 0:
            comando = ["setpriv", "--reuid=nobody", "--regid=nogroup", "--clear-groups",
                       "--no-new-privs", *comando]
        resultado = subprocess.run(
            comando, pass_fds=(fd,), capture_output=True, timeout=MINIATURA_S, cwd="/",
            env={"PATH": "/usr/bin:/bin", "PYTHONPATH": raiz, "HOME": "/nonexistent",
                 "GST_REGISTRY_UPDATE": "no"},
        )
        if resultado.returncode != 0:
            return {}
        dados = json.loads(resultado.stdout.decode("ascii"))
        return dados if isinstance(dados, dict) else {}
    except (OSError, ValueError, subprocess.SubprocessError):
        return {}
    finally:
        os.close(fd)


class MediaLibrary:
    """Varredura e índice numa linha; envios em outra, um por vez."""

    def __init__(self, storage, clock, get_fb, get_link, escola_ok, bucket: str | None,
                 contas=contas_com_pasta, arquivo: str = ARQUIVO, gerar_miniatura=miniatura):
        self.storage = storage
        self.clock = clock
        self.get_fb = get_fb
        # () -> {"deviceId", "key", "teacherUid"} | None
        self.get_link = get_link
        self.escola_ok = escola_ok
        self.bucket = bucket
        self.contas = contas
        self.arquivo = arquivo
        self.gerar_miniatura = gerar_miniatura
        self._lock = threading.RLock()
        self._itens = {}
        self._fila = []
        self._acordar = threading.Event()
        self._acordar_envio = threading.Event()
        self._reconciliar = True
        self._varrido_em = None

    # ---- comandos (thread do canal: só agenda) ------------------------------------

    def pedir_envio(self, mid) -> dict:
        if not isinstance(mid, str) or not MID_RE.match(mid):
            return {"ok": False, "error": "payload_invalido"}
        with self._lock:
            if mid not in self._itens:
                return {"ok": False, "error": "nao_encontrada"}
            if mid not in self._fila:
                self._fila.append(mid)
        self._acordar_envio.set()
        return {"ok": True}

    def apagar(self, mids) -> dict:
        if not isinstance(mids, list) or not mids or len(mids) > MAX_ITENS:
            return {"ok": False, "error": "payload_invalido"}
        apagados = 0
        with self._lock:
            for mid in mids:
                item = self._itens.get(mid) if isinstance(mid, str) else None
                if item is None:
                    continue
                try:
                    os.unlink(item["caminho"])
                except FileNotFoundError:
                    pass
                except OSError as error:
                    log.warning("não apaguei %s: %s", item["nome"], error)
                    continue
                apagados += 1
                if mid in self._fila:
                    self._fila.remove(mid)
            self._varrido_em = None
        self._acordar.set()
        return {"ok": True} if apagados else {"ok": False, "error": "nao_encontrada"}

    def conectado(self):
        self._reconciliar = True
        self._acordar.set()

    # ---- laços ------------------------------------------------------------------------

    def start(self):
        threading.Thread(target=self._laco_indice, name="midia-indice", daemon=True).start()
        threading.Thread(target=self._laco_envio, name="midia-envio", daemon=True).start()

    def _laco_indice(self):
        while True:
            self._acordar.wait(VARRER_S)
            self._acordar.clear()
            try:
                self.passo()
            except Exception as error:  # noqa: BLE001 - o laço nunca morre
                log.warning("mídia: %s", error)

    def _laco_envio(self):
        while True:
            self._acordar_envio.wait(60)
            self._acordar_envio.clear()
            try:
                self._limpar_envios()
                while True:
                    with self._lock:
                        mid = self._fila[0] if self._fila else None
                        item = self._itens.get(mid) if mid else None
                    if mid is None:
                        break
                    if item is not None:
                        self._enviar(item)
                    with self._lock:
                        if self._fila and self._fila[0] == mid:
                            self._fila.pop(0)
            except Exception as error:  # noqa: BLE001
                log.warning("envio de mídia: %s", error)

    def _pronto(self):
        link = self.get_link()
        fb = self.get_fb()
        if not link or fb is None or not fb.id_token or self.escola_ok(link) is not True:
            return None, None
        return link, fb

    # ---- índice -----------------------------------------------------------------------

    def passo(self):
        agora_ms = int(time.time() * 1000)
        itens = varrer(self.contas(), self.arquivo)
        velhos = vencidos(itens, agora_ms)
        for item in velhos:
            try:
                os.unlink(item["caminho"])
            except OSError:
                pass
        sumidos = {item["mid"] for item in velhos}
        atuais = {item["mid"]: item for item in itens if item["mid"] not in sumidos}
        with self._lock:
            self._itens = atuais
        link, fb = self._pronto()
        if link is None:
            return
        cache = self.storage.get("midia") or {}
        publicados = cache.get("publicados") if isinstance(cache.get("publicados"), dict) else {}
        base = f"/midia/{link['deviceId']}"
        try:
            if self._reconciliar:
                remotos = fb.side_get(base, {"shallow": "true"})
                for mid in (remotos if isinstance(remotos, dict) else {}):
                    if mid not in atuais:
                        fb.side_request("DELETE", f"{base}/{mid}")
                publicados = {mid: v for mid, v in publicados.items()
                              if isinstance(remotos, dict) and mid in remotos}
                self._reconciliar = False
            for mid in [m for m in publicados if m not in atuais]:
                fb.side_request("DELETE", f"{base}/{mid}")
                publicados.pop(mid, None)
            for mid, item in atuais.items():
                if mid in publicados:
                    continue
                extra = self.gerar_miniatura(item["caminho"], item["tipo"])
                objeto = objeto_do_indice(item, extra, self.clock.fix)
                fb.side_request("PUT", f"{base}/{mid}", {
                    "env": envelope_do_indice(link["key"], objeto),
                    "ts": FirebaseSession.server_timestamp(),
                })
                publicados[mid] = True
        except FirebaseError as error:
            log.info("índice de mídia não subiu: %s", error)
            self._reconciliar = True
        finally:
            self.storage.set("midia", {**cache, "publicados": publicados})

    # ---- envio ------------------------------------------------------------------------

    def _enviar(self, item: dict):
        link, fb = self._pronto()
        if link is None or not self.bucket:
            return
        mid = item["mid"]
        base = f"/envios/{link['deviceId']}/{mid}"
        try:
            fd = os.open(item["caminho"], os.O_RDONLY | os.O_NOFOLLOW)
        except OSError:
            return
        r = secrets.token_urlsafe(16)
        try:
            info = os.fstat(fd)
            if not stat.S_ISREG(info.st_mode):
                return
            total = max(1, math.ceil(info.st_size / PARTE))
            fb.side_request("PUT", base, {"u": fb.uid, "r": r, "partes": total, "prontas": 0,
                                          "bytes": info.st_size, "ts": FirebaseSession.server_timestamp()})
            self._registrar_envio(mid, r, total, fb.uid)
            for n in range(total):
                dados = os.pread(fd, PARTE, n * PARTE)
                blob = selar_parte(link["key"], mid, r, n, total, dados)
                fb.upload_object(self.bucket, f"midia/{fb.uid}/{mid}/{r}_{n}.bin", blob)
                fb.side_request("PATCH", base, {"prontas": n + 1})
        except (OSError, FirebaseError) as error:
            log.info("envio de %s falhou: %s", item["nome"], error)
            try:
                fb.side_request("PATCH", base, {"erro": "falhou"})
            except FirebaseError:
                pass
        finally:
            os.close(fd)

    def _registrar_envio(self, mid: str, r: str, total: int, uid: str):
        cache = self.storage.get("midia") or {}
        envios = cache.get("envios") if isinstance(cache.get("envios"), list) else []
        envios.append({"mid": mid, "r": r, "partes": total, "u": uid, "em": int(time.time())})
        self.storage.set("midia", {**cache, "envios": envios})

    def _limpar_envios(self):
        """O app apaga as partes ao baixar; isto pega o que ficou para trás."""
        cache = self.storage.get("midia") or {}
        envios = cache.get("envios") if isinstance(cache.get("envios"), list) else []
        if not envios:
            return
        link, fb = self._pronto()
        if link is None or not self.bucket:
            return
        restantes = []
        for envio in envios:
            if time.time() - envio.get("em", 0) < ENVIO_VIDA_S:
                restantes.append(envio)
                continue
            try:
                for n in range(envio["partes"]):
                    fb.delete_object(self.bucket, f"midia/{envio['u']}/{envio['mid']}/{envio['r']}_{n}.bin")
                atual = fb.side_get(f"/envios/{link['deviceId']}/{envio['mid']}")
                if isinstance(atual, dict) and atual.get("r") == envio["r"]:
                    fb.side_request("DELETE", f"/envios/{link['deviceId']}/{envio['mid']}")
            except (FirebaseError, KeyError, TypeError):
                restantes.append(envio)
        self.storage.set("midia", {**cache, "envios": restantes})
