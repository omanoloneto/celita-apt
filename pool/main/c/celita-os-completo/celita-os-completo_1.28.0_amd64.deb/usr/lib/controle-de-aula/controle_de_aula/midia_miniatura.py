"""Miniatura (JPEG de até 240 px) e duração de uma foto ou vídeo da Câmera.

Roda como nobody, chamado por midia.miniatura com o descritor já aberto:
  python3 -m controle_de_aula.midia_miniatura foto|video <fd>
Sai um JSON {"thumb": base64 | null, "duracao": segundos | null}. Lê só do
descritor herdado: reabrir por /proc/self/fd refaria a checagem de permissão."""

import base64
import json
import sys

LADO = 240
QUALIDADE = "70"


def _jpeg(pixbuf) -> str:
    ok, dados = pixbuf.save_to_bufferv("jpeg", ["quality"], [QUALIDADE])
    return base64.b64encode(dados).decode("ascii") if ok else None


def foto(fd: int) -> dict:
    import gi
    gi.require_version("GdkPixbuf", "2.0")
    gi.require_version("GioUnix", "2.0")
    from gi.repository import GdkPixbuf, GioUnix
    stream = GioUnix.InputStream.new(fd, False)
    pixbuf = GdkPixbuf.Pixbuf.new_from_stream_at_scale(stream, LADO, LADO, True, None)
    return {"thumb": _jpeg(pixbuf), "duracao": None}


def video(fd: int) -> dict:
    import gi
    gi.require_version("Gst", "1.0")
    gi.require_version("GdkPixbuf", "2.0")
    from gi.repository import GdkPixbuf, GLib, Gst
    Gst.init(None)
    pipeline = Gst.parse_launch(
        "fdsrc name=origem ! decodebin ! videoconvert ! videoscale "
        f"! video/x-raw,format=RGB,width={LADO},pixel-aspect-ratio=1/1 "
        "! appsink name=saida max-buffers=1 drop=true sync=false"
    )
    pipeline.get_by_name("origem").set_property("fd", fd)
    saida = pipeline.get_by_name("saida")
    try:
        pipeline.set_state(Gst.State.PAUSED)
        if pipeline.get_state(10 * Gst.SECOND)[0] == Gst.StateChangeReturn.FAILURE:
            return {"thumb": None, "duracao": None}
        ok, duracao_ns = pipeline.query_duration(Gst.Format.TIME)
        duracao = duracao_ns / Gst.SECOND if ok and duracao_ns > 0 else None
        # O primeiro quadro da webcam costuma sair escuro: a miniatura é do 1 s.
        if duracao and duracao > 2:
            pipeline.seek_simple(Gst.Format.TIME, Gst.SeekFlags.FLUSH | Gst.SeekFlags.KEY_UNIT, Gst.SECOND)
            pipeline.get_state(10 * Gst.SECOND)
        amostra = saida.emit("pull-preroll")
        if amostra is None:
            return {"thumb": None, "duracao": duracao}
        estrutura = amostra.get_caps().get_structure(0)
        largura = estrutura.get_value("width")
        altura = estrutura.get_value("height")
        buffer = amostra.get_buffer()
        ok, mapa = buffer.map(Gst.MapFlags.READ)
        if not ok:
            return {"thumb": None, "duracao": duracao}
        try:
            dados = bytes(mapa.data)
        finally:
            buffer.unmap(mapa)
        linha = len(dados) // altura
        pixbuf = GdkPixbuf.Pixbuf.new_from_bytes(GLib.Bytes.new(dados), GdkPixbuf.Colorspace.RGB,
                                                 False, 8, largura, altura, linha)
        return {"thumb": _jpeg(pixbuf), "duracao": duracao}
    finally:
        pipeline.set_state(Gst.State.NULL)


def main() -> int:
    if len(sys.argv) != 3 or sys.argv[1] not in ("foto", "video"):
        return 2
    fd = int(sys.argv[2])
    try:
        resultado = foto(fd) if sys.argv[1] == "foto" else video(fd)
    except Exception:  # noqa: BLE001 - arquivo ruim vira "sem miniatura"
        resultado = {"thumb": None, "duracao": None}
    sys.stdout.write(json.dumps(resultado))
    return 0


if __name__ == "__main__":
    sys.exit(main())
