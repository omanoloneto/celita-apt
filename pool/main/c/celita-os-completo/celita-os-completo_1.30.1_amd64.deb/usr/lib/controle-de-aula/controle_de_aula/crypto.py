"""Criptografia ponta a ponta, idêntica a crypto.js e keypair.js da extensão."""

import base64
import json
import os

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    NoEncryption,
    PrivateFormat,
    PublicFormat,
)

SALT = b"controle-de-aula"
INFO = b"session-key-v3"
WIFI_INFO = b"wifi-frota-v1"
NONCE_LEN = 12
TAG_LEN = 16


def b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def b64url_decode(text: str) -> bytes:
    text = text.strip()
    padding = "=" * (-len(text) % 4)
    return base64.urlsafe_b64decode(text + padding)


def generate_private_key() -> X25519PrivateKey:
    return X25519PrivateKey.generate()


def private_key_to_b64url(key: X25519PrivateKey) -> str:
    raw = key.private_bytes(Encoding.Raw, PrivateFormat.Raw, NoEncryption())
    return b64url_encode(raw)


def private_key_from_b64url(text: str) -> X25519PrivateKey:
    return X25519PrivateKey.from_private_bytes(b64url_decode(text))


def public_key_b64url(key: X25519PrivateKey) -> str:
    return b64url_encode(key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw))


def _derive(private_key: X25519PrivateKey, peer_pub_b64url: str, info: bytes) -> bytes:
    peer = X25519PublicKey.from_public_bytes(b64url_decode(peer_pub_b64url))
    shared = private_key.exchange(peer)
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=SALT, info=info).derive(shared)


def derive_session_key(private_key: X25519PrivateKey, peer_pub_b64url: str) -> bytes:
    return _derive(private_key, peer_pub_b64url, INFO)


def derive_wifi_wrap_key(private_key: X25519PrivateKey, peer_pub_b64url: str) -> bytes:
    """Chave de um par de PCs da escola, só para entregar a chave do Wi-Fi (§9)."""
    return _derive(private_key, peer_pub_b64url, WIFI_INFO)


def seal(key: bytes, obj, nonce: bytes | None = None) -> str:
    nonce = nonce if nonce is not None else os.urandom(NONCE_LEN)
    plaintext = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    ciphertext = AESGCM(key).encrypt(nonce, plaintext, None)
    return base64.b64encode(nonce + ciphertext).decode("ascii")


def open_envelope(key: bytes, envelope: str):
    data = base64.b64decode(envelope.strip())
    if len(data) < NONCE_LEN + TAG_LEN:
        raise ValueError("envelope_curto")
    plaintext = AESGCM(key).decrypt(data[:NONCE_LEN], data[NONCE_LEN:], None)
    return json.loads(plaintext.decode("utf-8"))


PHOTO_TYPE = "archived_photo"


def seal_photo(key: bytes, header: dict, jpeg: bytes, nonce: bytes | None = None) -> bytes:
    """Foto arquivada (foto-v1): nonce || AES-GCM(json compacto + \\n + jpeg), binário."""
    nonce = nonce if nonce is not None else os.urandom(NONCE_LEN)
    head = json.dumps(header, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return nonce + AESGCM(key).encrypt(nonce, head + b"\n" + jpeg, None)


def open_photo(key: bytes, data: bytes, expected_ts: int | None = None) -> tuple[dict, bytes]:
    if len(data) < NONCE_LEN + TAG_LEN:
        raise ValueError("foto_curta")
    plaintext = AESGCM(key).decrypt(data[:NONCE_LEN], data[NONCE_LEN:], None)
    head, separator, jpeg = plaintext.partition(b"\n")
    if not separator:
        raise ValueError("foto_sem_cabecalho")
    header = json.loads(head.decode("utf-8"))
    if not isinstance(header, dict) or type(header.get("v")) is not int or header["v"] != 1:
        raise ValueError("foto_versao")
    if header.get("type") != PHOTO_TYPE:
        raise ValueError("foto_tipo")
    ts = header.get("ts")
    if type(ts) is not int or (expected_ts is not None and ts != int(expected_ts)):
        raise ValueError("foto_ts")
    return header, jpeg


def new_token() -> str:
    return b64url_encode(os.urandom(16))
