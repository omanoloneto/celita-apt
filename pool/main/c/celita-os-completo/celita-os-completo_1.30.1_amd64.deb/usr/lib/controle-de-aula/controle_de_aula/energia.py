"""Desligar, reiniciar ou encerrar a sessão a pedido do professor (`energia`).

Na hora, sem aviso ao aluno (pedido de 2026-10-17). Antes de desligar ou
reiniciar, as sessões fecham pelo logind, para o PAM devolver a pasta do aluno,
e uma atualização em andamento termina primeiro: dpkg cortado no meio estraga o
sistema. Pedido velho não vale: a fila de comandos guarda até 12 h, e um
"desligar" atrasado desligaria a máquina no meio de outra aula.
"""

import fcntl
import logging
import threading
import time

from . import protocol
from .lid import terminate_sessions
from .session import _loginctl, _systemctl

log = logging.getLogger("controle-de-aula.energia")

# Tempo para o ack sair antes de a rede cair junto com a máquina.
ESPERA_ACK_S = 3
ESPERA_SESSOES_S = 30
TRAVA_ATUALIZACAO = "/run/lock/celita-update.lock"
ESPERA_ATUALIZACAO_S = 30 * 60
INTERVALO_S = 5


def sessoes_de_usuario() -> list:
    """Ids das sessões de conta (aluno ou professor); a tela de login fica."""
    encontradas = []
    for linha in _loginctl("list-sessions", "--no-legend").splitlines():
        campos = linha.split()
        if not campos:
            continue
        dados = _loginctl("show-session", campos[0], "-p", "Class")
        if "Class=user" in dados.splitlines():
            encontradas.append(campos[0])
    return encontradas


def atualizando(caminho: str = TRAVA_ATUALIZACAO) -> bool:
    """O celita-update segura a trava enquanto trabalha (a mesma do celita-tampa)."""
    try:
        with open(caminho, "rb") as arquivo:
            try:
                fcntl.flock(arquivo, fcntl.LOCK_SH | fcntl.LOCK_NB)
            except BlockingIOError:
                return True
            fcntl.flock(arquivo, fcntl.LOCK_UN)
    except OSError:
        pass
    return False


class Energia:
    def __init__(self, agora_ms, sessoes=sessoes_de_usuario, encerrar=terminate_sessions,
                 systemctl=_systemctl, atualizando=atualizando, dormir=time.sleep,
                 iniciar=lambda alvo: threading.Thread(target=alvo, name="energia", daemon=True).start()):
        self.agora_ms = agora_ms
        self.sessoes = sessoes
        self.encerrar = encerrar
        self.systemctl = systemctl
        self.atualizando = atualizando
        self.dormir = dormir
        self.iniciar = iniciar
        self._lock = threading.Lock()
        self._acao = None

    def pedir(self, payload: dict, ts) -> dict:
        acao = payload.get("acao") if isinstance(payload, dict) else None
        if acao not in protocol.ENERGIA_ACOES:
            return {"ok": False, "error": "payload_invalido"}
        if not isinstance(ts, (int, float)) or isinstance(ts, bool) or \
                self.agora_ms() - ts > protocol.ENERGIA_VALIDADE_MS:
            return {"ok": False, "error": "expirado"}
        if acao == protocol.ENERGIA_ENCERRAR and not self.sessoes():
            return {"ok": False, "error": "sem_sessao"}
        with self._lock:
            # Desligando já: o segundo pedido só confirma.
            if self._acao in (protocol.ENERGIA_DESLIGAR, protocol.ENERGIA_REINICIAR):
                return {"ok": True}
            self._acao = acao
        log.info("professor pediu: %s", acao)
        self.iniciar(lambda: self._executar(acao))
        return {"ok": True}

    def _executar(self, acao: str):
        try:
            self.dormir(ESPERA_ACK_S)
            ids = self.sessoes()
            if ids:
                self.encerrar(ids, ESPERA_SESSOES_S)
            if acao == protocol.ENERGIA_ENCERRAR:
                return
            prazo = time.monotonic() + ESPERA_ATUALIZACAO_S
            while self.atualizando() and time.monotonic() < prazo:
                self.dormir(INTERVALO_S)
            self.systemctl("poweroff" if acao == protocol.ENERGIA_DESLIGAR else "reboot")
        finally:
            with self._lock:
                if self._acao == acao:
                    self._acao = None
