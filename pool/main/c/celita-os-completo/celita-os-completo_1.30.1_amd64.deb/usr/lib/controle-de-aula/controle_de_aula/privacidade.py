"""Câmera e microfone: o que o professor liberou em Configurações → Privacidade.

Quem grava é o /usr/libexec/celita-privacidade; aqui só se lê. Sem o arquivo,
tudo liberado. A foto de entrada do agente é do sistema e não passa por aqui.
"""

from pathlib import Path

ARQUIVO = Path("/etc/celita/privacidade.conf")


def permite(recurso: str, aplicativo: str | None = None) -> bool:
    try:
        linhas = ARQUIVO.read_text(encoding="utf-8").splitlines()
    except OSError:
        return True
    valores = dict(linha.split("=", 1) for linha in linhas if "=" in linha)
    if valores.get(recurso) == "nao":
        return False
    return not (aplicativo and valores.get(f"{recurso}_{aplicativo}") == "nao")
