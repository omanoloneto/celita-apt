"""Wi-Fi da escola: toda rede que uma unidade conhece, todas conhecem (pedido de
2026-10-17, inclusive as salvas na conta de aluno).

Cada PC da escola sobe as redes salvas no NetworkManager para
`/school/wifi/redes`, cifradas com a chave da frota, e grava no próprio
NetworkManager as que os outros subiram. A chave da frota nasce no primeiro PC
que chega e passa de PC para PC selada com X25519 entre os dois
(`/school/wifi/chaves`): nem o Firebase nem o celular do professor veem senha
de rede. Formato em docs/protocolo.md §9.

Conflito: vale a versão que conectou por último (o `timestamps` do NM), para
uma senha errada digitada numa unidade nunca derrubar a rede das outras.
Esquecer uma rede só vale para todas fora da conta de aluno (Configurações, só
administrador); na conta de aluno ela volta.
"""

import hashlib
import json
import logging
import os
import re
import subprocess
import tempfile
import time
import uuid

from .crypto import b64url_decode, b64url_encode, derive_wifi_wrap_key, open_envelope, seal
from .firebase import FirebaseError

log = logging.getLogger("controle-de-aula.wifi")

CONEXOES = "/etc/NetworkManager/system-connections"
TIMESTAMPS = "/var/lib/NetworkManager/timestamps"
# A Central de Configurações avisa no "Esquecer" que a rede some das outras unidades.
MARCA = "/run/controle-de-aula/wifi-escola"
BASE = "/school/wifi"
SYNC_S = 300
DISTRIBUIR_S = 600
AUTH_BACKOFF_S = 10 * 60
MAX_REDES = 200
MAX_ENTREGAS = 50
MAX_TEXTO = 256
STORE_CHAVE = "wifiFrota"
STORE_REGISTRO = "wifiRegistro"
STORE_PUB = "wifiPub"

SEGURANCAS = ("aberta", "owe", "wpa-psk", "sae", "wpa-eap")
CLASSE = {"aberta": "aberta", "owe": "aberta", "wpa-psk": "senha", "sae": "senha", "wpa-eap": "conta"}
# Métodos que não pedem certificado do aparelho: caminho de arquivo não viaja.
EAP_SEM_CERTIFICADO = ("peap", "ttls", "pwd")
FASES2 = ("mschapv2", "pap", "chap", "mschap", "gtc", "md5")
CERTIFICADOS = ("ca-cert", "ca-path", "client-cert", "private-key", "phase2-ca-cert", "phase2-ca-path",
                "phase2-client-cert", "phase2-private-key", "pac-file")
_LISTA_DE_BYTES = re.compile(r"^([0-9]{1,3};)+$")
_HEX64 = re.compile(r"^[0-9A-Fa-f]{64}$")


def _glib():
    import gi
    gi.require_version("GLib", "2.0")
    from gi.repository import GLib
    return GLib


# ---- a rede como viaja -----------------------------------------------------------


def _texto_ok(valor, minimo=1) -> bool:
    return isinstance(valor, str) and minimo <= len(valor) <= MAX_TEXTO and "\x00" not in valor


def _ssid_bytes(dados) -> bytes | None:
    try:
        ssid = b64url_decode(dados["ssid"])
    except (KeyError, TypeError, ValueError):
        return None
    return ssid if 1 <= len(ssid) <= 32 else None


def validar(dados) -> bool:
    """Só o que esta versão sabe gravar no NetworkManager, e nada além."""
    if not isinstance(dados, dict) or dados.get("v") != 1 or _ssid_bytes(dados) is None:
        return False
    if not isinstance(dados.get("oculta"), bool) or dados.get("seguranca") not in SEGURANCAS:
        return False
    seguranca = dados["seguranca"]
    permitidas = {"v", "ssid", "oculta", "seguranca"}
    if seguranca == "wpa-psk":
        psk = dados.get("psk")
        if not (_texto_ok(psk, 8) and (len(psk) <= 63 and psk.isprintable() or _HEX64.match(psk))):
            return False
        permitidas.add("psk")
    elif seguranca == "sae":
        if not _texto_ok(dados.get("psk")):
            return False
        permitidas.add("psk")
    elif seguranca == "wpa-eap":
        eap = dados.get("eap")
        if not isinstance(eap, dict) or set(eap) - {"metodos", "identidade", "senha", "fase2", "anonima", "dominio"}:
            return False
        metodos = eap.get("metodos")
        if not isinstance(metodos, list) or not metodos or any(m not in EAP_SEM_CERTIFICADO for m in metodos):
            return False
        if not _texto_ok(eap.get("identidade")) or not _texto_ok(eap.get("senha")):
            return False
        if "fase2" in eap and eap["fase2"] not in FASES2:
            return False
        if any(k in eap and not _texto_ok(eap[k]) for k in ("anonima", "dominio")):
            return False
        permitidas.add("eap")
    return not set(dados) - permitidas


def rede_id(dados) -> str:
    """Mesmo nome e mesmo jeito de entrar: a mesma rede em todas as unidades."""
    chave = _ssid_bytes(dados) + b"\x00" + CLASSE[dados["seguranca"]].encode()
    return b64url_encode(hashlib.sha256(chave).digest())[:22]


def resumo(dados) -> str:
    return hashlib.sha256(json.dumps(dados, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:32]


# ---- o NetworkManager desta unidade ----------------------------------------------


class RedeLocal:
    def __init__(self, arquivo, uuid_, dados, ok_ms, mtime_ms):
        self.arquivo = arquivo
        self.uuid = uuid_
        self.dados = dados
        self.ok_ms = ok_ms
        self.mtime_ms = mtime_ms


def _valor(kf, grupo, chave):
    try:
        return kf.get_string(grupo, chave)
    except Exception:  # noqa: BLE001 - GLib.Error: grupo ou chave ausente
        return None


def _grupo(kf, *nomes):
    return next((nome for nome in nomes if kf.has_group(nome)), nomes[0])


def _ssid_do_arquivo(valor) -> bytes | None:
    if valor is None:
        return None
    if _LISTA_DE_BYTES.match(valor):
        numeros = [int(n) for n in valor.split(";") if n]
        if any(n > 255 for n in numeros):
            return None
        ssid = bytes(numeros)
    else:
        ssid = valor.encode("utf-8")
    return ssid if 1 <= len(ssid) <= 32 else None


def _segredo_do_sistema(kf, grupo, chave) -> bool:
    """Senha guardada pelo NM para todas as contas; a do chaveiro de uma conta não viaja."""
    valor = _valor(kf, grupo, chave)
    try:
        return valor is None or int(valor) == 0
    except ValueError:
        return False


def dados_do_perfil(kf) -> dict | None:
    if _valor(kf, "connection", "type") not in ("wifi", "802-11-wireless"):
        return None
    wifi = _grupo(kf, "wifi", "802-11-wireless")
    if (_valor(kf, wifi, "mode") or "infrastructure") != "infrastructure":
        return None
    ssid = _ssid_do_arquivo(_valor(kf, wifi, "ssid"))
    if ssid is None:
        return None
    dados = {"v": 1, "ssid": b64url_encode(ssid), "oculta": (_valor(kf, wifi, "hidden") or "").lower() == "true"}
    seguranca = _grupo(kf, "wifi-security", "802-11-wireless-security")
    gestao = _valor(kf, seguranca, "key-mgmt") if kf.has_group(seguranca) else None
    if gestao is None:
        dados["seguranca"] = "aberta"
    elif gestao == "owe":
        dados["seguranca"] = "owe"
    elif gestao in ("wpa-psk", "sae"):
        psk = _valor(kf, seguranca, "psk")
        if not psk or not _segredo_do_sistema(kf, seguranca, "psk-flags"):
            return None
        dados.update(seguranca=gestao, psk=psk)
    elif gestao == "wpa-eap":
        if not kf.has_group("802-1x") or not _segredo_do_sistema(kf, "802-1x", "password-flags"):
            return None
        if any(_valor(kf, "802-1x", chave) for chave in CERTIFICADOS):
            return None
        eap = {"metodos": [m for m in (_valor(kf, "802-1x", "eap") or "").split(";") if m],
               "identidade": _valor(kf, "802-1x", "identity"), "senha": _valor(kf, "802-1x", "password")}
        for chave, nome in (("phase2-auth", "fase2"), ("anonymous-identity", "anonima"),
                            ("domain-suffix-match", "dominio")):
            valor = _valor(kf, "802-1x", chave)
            if valor:
                eap[nome] = valor
        dados.update(seguranca="wpa-eap", eap=eap)
    else:
        # WEP ("none") e o que esta versão não conhece ficam só aqui.
        return None
    return dados if validar(dados) else None


def _tempos(caminho) -> dict:
    GLib = _glib()
    kf = GLib.KeyFile()
    try:
        kf.load_from_file(caminho, GLib.KeyFileFlags.NONE)
        chaves = kf.get_keys("timestamps")[0]
    except Exception:  # noqa: BLE001 - sem arquivo ou ilegível: ninguém conectou ainda
        return {}
    tempos = {}
    for chave in chaves:
        try:
            tempos[chave] = int(kf.get_string("timestamps", chave))
        except Exception:  # noqa: BLE001
            continue
    return tempos


def redes_locais(pasta=CONEXOES, timestamps=TIMESTAMPS) -> tuple[dict, set]:
    """As redes que podem viajar, uma por id (com perfis repetidos, o usado por
    último), e o nome das redes Wi-Fi salvas que não viajam."""
    GLib = _glib()
    tempos = _tempos(timestamps)
    redes, presentes = {}, set()
    try:
        nomes = sorted(os.listdir(pasta))
    except OSError:
        return redes, presentes
    for nome in nomes:
        if not nome.endswith(".nmconnection"):
            continue
        caminho = os.path.join(pasta, nome)
        try:
            estado = os.lstat(caminho)
        except OSError:
            continue
        if not os.path.isfile(caminho) or os.path.islink(caminho):
            continue
        kf = GLib.KeyFile()
        try:
            kf.load_from_file(caminho, GLib.KeyFileFlags.NONE)
        except Exception:  # noqa: BLE001
            continue
        dados = dados_do_perfil(kf)
        if dados is None:
            ssid = _ssid_do_arquivo(_valor(kf, _grupo(kf, "wifi", "802-11-wireless"), "ssid"))
            if ssid is not None and _valor(kf, "connection", "type") in ("wifi", "802-11-wireless"):
                presentes.add(ssid)
            continue
        uuid_ = _valor(kf, "connection", "uuid") or ""
        rede = RedeLocal(caminho, uuid_, dados, tempos.get(uuid_, 0) * 1000, int(estado.st_mtime * 1000))
        atual = redes.get(rede_id(dados))
        if atual is None or rede.ok_ms > atual.ok_ms:
            redes[rede_id(dados)] = rede
    return redes, presentes


def _nmcli(*args):
    try:
        return subprocess.run(["nmcli", *args], capture_output=True, text=True, timeout=20,
                              stdin=subprocess.DEVNULL).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def _ssid_no_arquivo(ssid: bytes) -> str:
    """Como o NM grava: texto quando dá, lista de bytes quando não."""
    try:
        texto = ssid.decode("utf-8")
    except UnicodeDecodeError:
        texto = None
    if texto is not None and texto.isprintable() and ";" not in texto and not _LISTA_DE_BYTES.match(texto):
        return texto
    return "".join(f"{byte};" for byte in ssid)


def _tirar(kf, grupo, chave=None):
    try:
        if chave is None:
            kf.remove_group(grupo)
        else:
            kf.remove_key(grupo, chave)
    except Exception:  # noqa: BLE001 - já não estava lá
        pass


def gravar_local(dados, existente=None, pasta=CONEXOES, nmcli=_nmcli) -> bool:
    """Perfil novo ou o de antes com rede e senha trocadas: o resto (IP,
    prioridade, endereço físico) fica como a unidade tinha."""
    GLib = _glib()
    kf = GLib.KeyFile()
    ssid = _ssid_bytes(dados)
    if existente is not None:
        try:
            kf.load_from_file(existente.arquivo, GLib.KeyFileFlags.KEEP_COMMENTS)
        except Exception:  # noqa: BLE001
            return False
        destino = existente.arquivo
    else:
        nome = ssid.decode("utf-8", "replace")
        kf.set_string("connection", "id", nome if nome.isprintable() else "Wi-Fi")
        kf.set_string("connection", "uuid", str(uuid.uuid4()))
        kf.set_string("connection", "type", "wifi")
        kf.set_string("ipv4", "method", "auto")
        kf.set_string("ipv6", "method", "auto")
        kf.set_string("ipv6", "addr-gen-mode", "default")
        destino = os.path.join(pasta, f"celita-{rede_id(dados)}.nmconnection")
    wifi = _grupo(kf, "wifi", "802-11-wireless")
    kf.set_string(wifi, "ssid", _ssid_no_arquivo(ssid))
    kf.set_string(wifi, "mode", "infrastructure")
    if dados["oculta"]:
        kf.set_string(wifi, "hidden", "true")
    else:
        _tirar(kf, wifi, "hidden")
    for grupo in ("wifi-security", "802-11-wireless-security", "802-1x"):
        _tirar(kf, grupo)
    seguranca = dados["seguranca"]
    if seguranca == "aberta":
        _tirar(kf, wifi, "security")
    else:
        kf.set_string("wifi-security", "key-mgmt", seguranca)
    if seguranca in ("wpa-psk", "sae"):
        kf.set_string("wifi-security", "psk", dados["psk"])
    if seguranca == "wpa-eap":
        eap = dados["eap"]
        kf.set_string("802-1x", "eap", "".join(f"{m};" for m in eap["metodos"]))
        kf.set_string("802-1x", "identity", eap["identidade"])
        kf.set_string("802-1x", "password", eap["senha"])
        for chave, nome in (("phase2-auth", "fase2"), ("anonymous-identity", "anonima"),
                            ("domain-suffix-match", "dominio")):
            if nome in eap:
                kf.set_string("802-1x", chave, eap[nome])
    try:
        descritor, temporario = tempfile.mkstemp(prefix=".celita-", dir=os.path.dirname(destino))
        with os.fdopen(descritor, "w", encoding="utf-8") as arquivo:
            arquivo.write(kf.to_data()[0])
        os.chmod(temporario, 0o600)
        os.replace(temporario, destino)
    except OSError as error:
        log.warning("rede da escola não foi gravada: %s", error)
        return False
    if not nmcli("connection", "load", destino):
        log.warning("NetworkManager não leu %s", destino)
    return True


def apagar_local(rede: RedeLocal, nmcli=_nmcli) -> bool:
    if rede.uuid and nmcli("connection", "delete", "uuid", rede.uuid):
        return True
    try:
        os.unlink(rede.arquivo)
    except OSError:
        return False
    nmcli("connection", "reload")
    return True


def assinatura(pasta=CONEXOES) -> tuple:
    """Barata a cada 5 s: nome, tamanho e hora dos perfis."""
    try:
        entradas = sorted(os.scandir(pasta), key=lambda e: e.name)
    except OSError:
        return ()
    saida = []
    for entrada in entradas:
        try:
            estado = entrada.stat(follow_symlinks=False)
        except OSError:
            continue
        saida.append((entrada.name, estado.st_size, estado.st_mtime_ns))
    return tuple(saida)


# ---- a chave da frota ------------------------------------------------------------


class ChaveDaFrota:
    """32 bytes que só PC da escola tem. O primeiro a chegar cria (meta é
    gravado uma vez só, pelas rules); os outros recebem selada de quem já tem."""

    def __init__(self, storage):
        self.storage = storage

    def local(self) -> bytes | None:
        salva = self.storage.get(STORE_CHAVE)
        if not isinstance(salva, dict) or not salva.get("confirmada"):
            return None
        try:
            chave = b64url_decode(salva["k"])
        except (KeyError, TypeError, ValueError):
            return None
        return chave if len(chave) == 32 else None

    def garantir(self, fb, identidade) -> bytes | None:
        self._publicar(fb, identidade)
        chave = self.local()
        if chave is not None:
            return chave
        eu = identidade["deviceId"]
        entrega = fb.side_get(f"{BASE}/chaves/{eu}")
        if isinstance(entrega, dict):
            chave = self._abrir(fb, identidade, entrega)
            if chave is not None:
                self.storage.set(STORE_CHAVE, {"k": b64url_encode(chave), "confirmada": True})
                log.info("chave do Wi-Fi da escola recebida de %s", entrega.get("de"))
                return chave
        meta = fb.side_get(f"{BASE}/meta")
        salva = self.storage.get(STORE_CHAVE)
        if isinstance(meta, dict):
            # Criada por mim e o PC caiu antes de marcar: vale. Por outro: espera a entrega.
            if meta.get("de") == eu and isinstance(salva, dict) and salva.get("k"):
                self.storage.set(STORE_CHAVE, {**salva, "confirmada": True})
                return self.local()
            if isinstance(salva, dict):
                self.storage.set(STORE_CHAVE, None)
            return None
        # Guardada antes de anunciar: um PC que cai no meio não perde a chave de todos.
        if not isinstance(salva, dict) or not salva.get("k"):
            salva = {"k": b64url_encode(os.urandom(32)), "confirmada": False}
            self.storage.set(STORE_CHAVE, salva)
        try:
            fb.side_request("PUT", f"{BASE}/meta", {"de": eu, "ts": {".sv": "timestamp"}})
        except FirebaseError as error:
            if error.status in (401, 403):
                # Outro PC criou primeiro (create-once nas rules).
                self.storage.set(STORE_CHAVE, None)
                return None
            raise
        self.storage.set(STORE_CHAVE, {**salva, "confirmada": True})
        log.info("chave do Wi-Fi da escola criada nesta unidade")
        return self.local()

    def _publicar(self, fb, identidade):
        if self.storage.get(STORE_PUB) == identidade["pub"]:
            return
        fb.side_request("PUT", f"{BASE}/pubs/{identidade['deviceId']}", identidade["pub"])
        self.storage.set(STORE_PUB, identidade["pub"])

    def _abrir(self, fb, identidade, entrega) -> bytes | None:
        de, envelope = entrega.get("de"), entrega.get("env")
        if not isinstance(de, str) or not isinstance(envelope, str):
            return None
        pub = fb.side_get(f"{BASE}/pubs/{de}")
        if not isinstance(pub, str):
            return None
        try:
            conteudo = open_envelope(derive_wifi_wrap_key(identidade["key"], pub), envelope)
            chave = b64url_decode(conteudo["k"]) if conteudo.get("v") == 1 else b""
        except Exception:  # noqa: BLE001 - envelope de outra chave ou torto
            return None
        return chave if len(chave) == 32 else None

    def distribuir(self, fb, identidade, chave: bytes) -> int:
        """Sela a chave para cada PC da escola que publicou a pública e ainda não a tem."""
        pubs = fb.side_get(f"{BASE}/pubs")
        entregues = fb.side_get(f"{BASE}/chaves", {"shallow": "true"})
        pubs = pubs if isinstance(pubs, dict) else {}
        entregues = entregues if isinstance(entregues, dict) else {}
        feitas = 0
        for device_id, pub in sorted(pubs.items()):
            if device_id in entregues or not isinstance(pub, str):
                continue
            try:
                envelope = seal(derive_wifi_wrap_key(identidade["key"], pub),
                                {"v": 1, "k": b64url_encode(chave)})
            except (ValueError, TypeError):
                continue
            fb.side_request("PUT", f"{BASE}/chaves/{device_id}", {"de": identidade["deviceId"], "env": envelope})
            feitas += 1
            if feitas >= MAX_ENTREGAS:
                break
        return feitas


# ---- a sincronização -------------------------------------------------------------


class WifiEscola:
    def __init__(self, storage, get_fb, get_identity, escola, sessions, agora_ms,
                 pasta=CONEXOES, timestamps=TIMESTAMPS, marca=MARCA, nmcli=_nmcli, monotonic=time.monotonic):
        self.storage = storage
        self.get_fb = get_fb
        self.get_identity = get_identity
        self.escola = escola
        self.sessions = sessions
        self.agora_ms = agora_ms
        self.pasta = pasta
        self.timestamps = timestamps
        self.marca = marca
        self.nmcli = nmcli
        self.monotonic = monotonic
        self.chave = ChaveDaFrota(storage)
        self._assinatura = None
        self._proxima = None
        self._distribuir_em = None
        self._bloqueado_ate = None
        self._marcado = None

    def tick(self):
        if not self.escola():
            self._marcar(False)
            return
        agora = self.monotonic()
        if self._bloqueado_ate is not None and agora < self._bloqueado_ate:
            return
        if assinatura(self.pasta) == self._assinatura and self._proxima is not None and agora < self._proxima:
            return
        fb = self.get_fb()
        identidade = self.get_identity()
        if fb is None or not fb.id_token or not identidade:
            return
        try:
            self.sincronizar(fb, identidade)
        except FirebaseError as error:
            if error.status in (401, 403):
                self._bloqueado_ate = agora + AUTH_BACKOFF_S
                log.warning("Wi-Fi da escola negado (%s); nova tentativa em 10 min", error.status)
            else:
                log.warning("Wi-Fi da escola: %s", error)
            self._proxima = agora + 60
            return
        self._assinatura = assinatura(self.pasta)
        self._proxima = agora + SYNC_S

    def sincronizar(self, fb, identidade):
        chave = self.chave.garantir(fb, identidade)
        self._marcar(chave is not None)
        if chave is None:
            return
        escola = self._baixar(fb, chave)
        locais, presentes = redes_locais(self.pasta, self.timestamps)
        registro = dict(self.storage.get(STORE_REGISTRO) or {})
        aluno = self._aluno_na_tela()
        # Horas do NM e dos arquivos no relógio do servidor, o mesmo do `ts` da escola.
        desvio = self.agora_ms() - int(time.time() * 1000)
        for local in locais.values():
            local.mtime_ms += desvio
            local.ok_ms = local.ok_ms + desvio if local.ok_ms else 0
        for rede in sorted(set(escola) | set(locais))[:MAX_REDES]:
            novo = self._decidir(fb, chave, rede, escola.get(rede), locais.get(rede), registro.get(rede),
                                 aluno, presentes)
            if novo is not None:
                registro[rede] = novo
        self.storage.set(STORE_REGISTRO, registro)
        agora = self.monotonic()
        if self._distribuir_em is None or agora >= self._distribuir_em:
            self.chave.distribuir(fb, identidade, chave)
            self._distribuir_em = agora + DISTRIBUIR_S

    def _decidir(self, fb, chave, rede, escola, local, registro, aluno, presentes):
        """Uma rede: sobe, aplica, apaga ou deixa como está. Devolve o registro novo."""
        agora = self.agora_ms()
        if escola is None:
            if local is None:
                return None
            self._subir(fb, chave, rede, local.dados, local.ok_ms)
            return {"h": resumo(local.dados), "ts": agora}
        if escola["apagada"]:
            if local is None:
                return {"h": None, "ts": escola["ts"]}
            if local.mtime_ms <= escola["ts"]:
                apagar_local(local, self.nmcli)
                return {"h": None, "ts": escola["ts"]}
            # Salva de novo depois de esquecida: volta para todas.
            self._subir(fb, chave, rede, local.dados, local.ok_ms)
            return {"h": resumo(local.dados), "ts": agora}
        h_escola = resumo(escola["dados"])
        if local is None:
            # Perfil da mesma rede que não viaja (certificado, WEP, senha no chaveiro
            # de uma conta): não é rede esquecida, nem pede um segundo perfil.
            if _ssid_bytes(escola["dados"]) in presentes:
                return registro
            if registro and registro.get("h") and not aluno:
                self._subir_apagada(fb, chave, rede)
                log.info("rede esquecida nesta unidade: some das outras também")
                return {"h": None, "ts": agora}
            if gravar_local(escola["dados"], None, self.pasta, self.nmcli):
                return {"h": h_escola, "ts": escola["ts"]}
            return registro
        h_local = resumo(local.dados)
        if h_local == h_escola:
            return {"h": h_escola, "ts": max(escola["ts"], (registro or {}).get("ts") or 0)}
        mudou_aqui = registro is None or registro.get("h") != h_local
        mudou_la = registro is None or registro.get("h") != h_escola
        if not mudou_aqui:
            subir = False
        elif not mudou_la:
            # Senha nova sobe só depois de conectar: senha errada fica aqui.
            subir = local.ok_ms > escola["ok"] or escola["ok"] == 0
            if not subir:
                return registro
        elif local.ok_ms != escola["ok"]:
            subir = local.ok_ms > escola["ok"]
        else:
            subir = local.mtime_ms > escola["ts"]
        if subir:
            self._subir(fb, chave, rede, local.dados, local.ok_ms)
            return {"h": h_local, "ts": agora}
        if gravar_local(escola["dados"], local, self.pasta, self.nmcli):
            return {"h": h_escola, "ts": escola["ts"]}
        return registro

    def _baixar(self, fb, chave) -> dict:
        no = fb.side_get(f"{BASE}/redes")
        redes = {}
        for rede, item in (no if isinstance(no, dict) else {}).items():
            if not isinstance(item, dict) or not isinstance(item.get("ts"), (int, float)):
                continue
            try:
                conteudo = open_envelope(chave, item.get("env"))
            except Exception:  # noqa: BLE001 - envelope torto ou de outra chave
                continue
            if not isinstance(conteudo, dict) or conteudo.get("v") != 1 or conteudo.get("id") != rede:
                continue
            if conteudo.get("apagada") is True:
                redes[rede] = {"apagada": True, "ts": int(item["ts"])}
                continue
            dados, ok = conteudo.get("dados"), conteudo.get("ok")
            if not validar(dados) or rede_id(dados) != rede or not isinstance(ok, int) or isinstance(ok, bool):
                continue
            redes[rede] = {"apagada": False, "dados": dados, "ok": ok, "ts": int(item["ts"])}
        return redes

    def _subir(self, fb, chave, rede, dados, ok_ms):
        envelope = seal(chave, {"v": 1, "id": rede, "dados": dados, "ok": int(ok_ms)})
        fb.side_request("PUT", f"{BASE}/redes/{rede}", {"env": envelope, "ts": {".sv": "timestamp"}})

    def _subir_apagada(self, fb, chave, rede):
        envelope = seal(chave, {"v": 1, "id": rede, "apagada": True})
        fb.side_request("PUT", f"{BASE}/redes/{rede}", {"env": envelope, "ts": {".sv": "timestamp"}})

    def _aluno_na_tela(self) -> bool:
        try:
            sessao = self.sessions.active_any()
        except Exception:  # noqa: BLE001 - na dúvida, aluno: nada se apaga da escola
            return True
        return bool(sessao is not None and getattr(sessao, "controlled", False))

    def _marcar(self, ligado: bool):
        if ligado == self._marcado:
            return
        try:
            if ligado:
                with open(self.marca, "w", encoding="ascii") as arquivo:
                    arquivo.write("1\n")
                os.chmod(self.marca, 0o644)
            else:
                os.unlink(self.marca)
        except FileNotFoundError:
            pass
        except OSError as error:
            log.warning("marca do Wi-Fi da escola: %s", error)
            return
        self._marcado = ligado
