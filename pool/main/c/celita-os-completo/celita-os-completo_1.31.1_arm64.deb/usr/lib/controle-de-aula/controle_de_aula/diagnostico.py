"""Diagnóstico de Wi-Fi e da tampa (pedido de 2026-10-29), ligado pelo app por
algumas horas. A cada minuto o PC registra o Wi-Fi em uso, as redes à volta, a
tampa, a bateria e o diário do NetworkManager, do celita-rede-forte, da tampa,
do logind e do kernel, e sobe para /diag/{deviceId}/{sessão}, que nenhum
cliente lê: só o console do Firebase. O prazo vale entre reinícios (o teste é
fechar a tampa ao ligar), e sem internet os registros esperam numa fila,
porque é quando o Wi-Fi falha que eles importam. Formato em docs/protocolo.md.
"""

import glob
import json
import logging
import os
import re
import subprocess
import threading
import time

from . import protocol
from .firebase import FirebaseError
from .session import celita_version

log = logging.getLogger("controle-de-aula.diagnostico")

CHAVE = "diagnostico"
INTERVALO_MS = 60 * 1000
FILA_MAX = 240
SUBIDAS_POR_VEZ = 30
MAX_LINHAS = 400
MAX_LINHA = 300
MAX_REGISTRO = 60000
MAX_REDES = 15
LINHAS_BOOT_ANTERIOR = 80
JANELA_INICIAL = "-30min"
TIMEOUT_S = 20

UNIDADES = (
    "NetworkManager.service", "wpa_supplicant.service", "celita-rede-forte.service",
    "celita-tampa.service", "systemd-logind.service", "systemd-suspend.service",
    "controle-de-aula-agent.service",
)
# Do kernel e do systemd, só o que fala de tampa, sono, desligamento e Wi-Fi;
# do agente, só o Wi-Fi da escola. Linha que fala de segredo nunca sai.
KERNEL = re.compile(r"PM: |ACPI|\blid\b|suspend|resume|wak|wlan|wlp|iwlwifi|ath\d|mt7|rtw|brcm|"
                    r"deauth|disassoc|authenticat|associat|reboot|power down|watchdog|panic|oops|"
                    r"BUG:|hung_task|cros_ec", re.I)
SISTEMA = re.compile(r"sleep|suspend|hibernat|power-?off|reboot|shutdown|shutting down|"
                     r"startup finished|reached target (graphical|multi-user)", re.I)
AGENTE = ("controle-de-aula.wifi:", "controle-de-aula.diagnostico:")
RUIDO = re.compile(r"ACPI: ([A-Z0-9]{4} 0x|Early table|RSDP)|^efi: ")
SEGREDO = re.compile(r"psk|passw|senha|secret|wep-key|private-key", re.I)
FIM_LIMPO = re.compile(r"reboot: (power down|restarting)|systemd-shutdown|shutting down\.|"
                       r"journal stopped", re.I)


def _escapado(campo: str) -> str:
    return campo.replace("\\:", ":").replace("\\\\", "\\")


def _campos(linha: str) -> list:
    return [_escapado(c) for c in re.split(r"(?<!\\):", linha)]


def _cortar(texto: str, limite: int = MAX_LINHA) -> str:
    return texto if len(texto) <= limite else texto[: limite - 1] + "…"


class Diagnostico:
    def __init__(self, storage, get_fb, get_identity, agora_ms=None, executar=subprocess.run,
                 raiz: str = "/", fila: str | None = None, versao=celita_version):
        self.storage = storage
        self._get_fb = get_fb
        self._get_identity = get_identity
        self._agora = agora_ms or (lambda: int(time.time() * 1000))
        self._executar = executar
        self._raiz = raiz
        self._fila = fila or os.path.join(os.path.dirname(storage.path), "diagnostico-fila.jsonl")
        self._versao = versao
        self._lock = threading.Lock()
        self._ultimo = 0

    # ---- comando do app -----------------------------------------------------------

    def pedir(self, payload: dict) -> dict:
        horas = payload.get("horas")
        if isinstance(horas, bool) or not isinstance(horas, (int, float)) \
                or not 0 <= horas <= protocol.DIAGNOSTICO_MAX_HORAS:
            return {"ok": False, "error": "payload_invalido"}
        with self._lock:
            agora = self._agora()
            estado = self._estado()
            if horas == 0:
                if estado:
                    self._enfileirar(estado, {"tipo": "fim", "t": agora, "motivo": "app"})
                self.storage.set(CHAVE, None)
                return {"ok": True}
            ate = agora + int(horas * 3600 * 1000)
            # Pedido com a gravação ligada só muda o prazo: a sessão continua.
            estado = {**estado, "ate": ate} if estado else \
                {"sessao": str(agora), "ate": ate, "cursor": None, "boot": None}
            self.storage.set(CHAVE, estado)
            self._ultimo = 0
        return {"ok": True}

    # ---- laço lateral -------------------------------------------------------------

    def tick(self):
        with self._lock:
            estado = self._estado()
            agora = self._agora()
            if estado and agora >= estado["ate"]:
                self._enfileirar(estado, {"tipo": "fim", "t": agora, "motivo": "prazo"})
                self.storage.set(CHAVE, None)
            elif estado and agora - self._ultimo >= INTERVALO_MS:
                self._ultimo = agora
                self._coletar(estado, agora)
        self._esvaziar()

    def _estado(self) -> dict | None:
        estado = self.storage.get(CHAVE)
        if not isinstance(estado, dict) or not str(estado.get("sessao", "")).isdigit() \
                or not isinstance(estado.get("ate"), int):
            return None
        return estado

    def _coletar(self, estado: dict, agora: int):
        boot = (self._ler("proc/sys/kernel/random/boot_id") or "").replace("-", "") or None
        if boot and estado.get("boot") != boot:
            motivo = "inicio" if estado.get("boot") is None else "boot"
            self._enfileirar(estado, self._registro_boot(agora, boot, motivo))
            estado = {**estado, "boot": boot}
        linhas, cursor = self._diario(estado.get("cursor"))
        self._enfileirar(estado, {"tipo": "minuto", "t": agora, **self._estado_do_pc(), "log": linhas})
        self.storage.set(CHAVE, {**estado, "cursor": cursor or estado.get("cursor")})

    # ---- o que se registra --------------------------------------------------------

    def _rodar(self, args: list) -> str | None:
        try:
            resultado = self._executar(args, capture_output=True, text=True, timeout=TIMEOUT_S,
                                       check=False)
        except (OSError, subprocess.TimeoutExpired):
            return None
        return resultado.stdout if resultado.returncode == 0 else None

    def _ler(self, caminho: str) -> str | None:
        try:
            with open(os.path.join(self._raiz, caminho), encoding="utf-8", errors="replace") as arquivo:
                return arquivo.read().strip()
        except OSError:
            return None

    def _estado_do_pc(self) -> dict:
        return {"wifi": self._wifi(), "redes": self._redes(), "tampa": self._tampa(),
                "energia": self._energia()}

    def _wifi(self) -> dict:
        wifi = {}
        geral = self._rodar(["nmcli", "-t", "-f", "STATE,CONNECTIVITY,WIFI", "general"])
        if geral:
            campos = _campos(geral.splitlines()[0])
            wifi.update(zip(("estado", "conectividade", "radio"), campos))
        for linha in (self._rodar(["nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION",
                                   "device", "status"]) or "").splitlines():
            campos = _campos(linha)
            if len(campos) == 4 and campos[1] == "wifi":
                wifi.update(dispositivo=campos[0], dispositivo_estado=campos[2], conexao=campos[3])
                ip = self._rodar(["nmcli", "-t", "-g", "IP4.ADDRESS,IP4.GATEWAY", "device", "show",
                                  campos[0]])
                if ip:
                    wifi["ip"] = [_cortar(v, 60) for v in ip.splitlines()[:2]]
                break
        return wifi

    def _redes(self) -> list:
        saida = self._rodar(["nmcli", "-t", "-f", "IN-USE,BSSID,SSID,CHAN,FREQ,SIGNAL,SECURITY",
                             "device", "wifi", "list", "--rescan", "no"])
        redes = []
        for linha in (saida or "").splitlines():
            campos = _campos(linha)
            if len(campos) != 7:
                continue
            usa, bssid, ssid, canal, freq, sinal, seguranca = campos
            redes.append({"ssid": _cortar(ssid, 40), "bssid": bssid, "canal": canal, "freq": freq,
                          "sinal": int(sinal) if sinal.isdigit() else None,
                          "seg": _cortar(seguranca, 30), "usa": usa.strip() == "*"})
        redes.sort(key=lambda rede: (not rede["usa"], -(rede["sinal"] or 0)))
        return redes[:MAX_REDES]

    def _tampa(self) -> str | None:
        for caminho in sorted(glob.glob(os.path.join(self._raiz, "proc/acpi/button/lid/*/state"))):
            texto = self._ler(os.path.relpath(caminho, self._raiz)) or ""
            return texto.split()[-1] if texto.split() else None
        return None

    def _energia(self) -> dict:
        energia = {}
        for pasta in sorted(glob.glob(os.path.join(self._raiz, "sys/class/power_supply/*"))):
            relativo = os.path.relpath(pasta, self._raiz)
            tipo = self._ler(os.path.join(relativo, "type"))
            if tipo == "Battery":
                carga = self._ler(os.path.join(relativo, "capacity"))
                energia["bateria"] = int(carga) if carga and carga.isdigit() else None
                energia["situacao"] = self._ler(os.path.join(relativo, "status"))
            elif tipo == "Mains":
                energia["tomada"] = self._ler(os.path.join(relativo, "online")) == "1"
        return energia

    def _registro_boot(self, agora: int, boot: str, motivo: str) -> dict:
        uptime = (self._ler("proc/uptime") or "0").split()[0]
        return {
            "tipo": "boot", "t": agora, "motivo": motivo, "boot": boot,
            "ligado_ha_s": int(float(uptime)) if re.fullmatch(r"[0-9.]+", uptime) else None,
            "versao": self._versao(),
            "bios": self._ler("sys/class/dmi/id/bios_version"),
            "modelo": self._ler("sys/class/dmi/id/product_name"),
            "tampa": self._tampa(),
            "boots": self._boots(),
            "anterior": self._boot_anterior(),
        }

    def _boots(self) -> list:
        saida = self._rodar(["journalctl", "--list-boots", "--no-pager", "-q", "-o", "json"])
        try:
            boots = json.loads(saida or "")
        except ValueError:
            return [_cortar(linha, 120) for linha in (saida or "").splitlines()[-6:]]
        if not isinstance(boots, list):
            return []
        return [{"boot": str(b.get("boot_id", ""))[:32],
                 "de": self._hora(b.get("first_entry")), "ate": self._hora(b.get("last_entry"))}
                for b in boots[-6:] if isinstance(b, dict)]

    def _boot_anterior(self) -> dict:
        # Desligamento limpo deixa o systemd-shutdown ou o "reboot:" do kernel no
        # fim; sem eles, o boot anterior acabou na marra (botão segurado).
        fim = self._entradas(["journalctl", "-b", "-1", "-n", "60", "-o", "json", "--no-pager", "-q"])
        if not fim:
            return {"fim": None, "linhas": []}
        limpo = any(FIM_LIMPO.search(self._mensagem(e)) for e in fim)
        linhas = self._linhas(self._entradas(
            ["journalctl", "-b", "-1", "-n", str(LINHAS_BOOT_ANTERIOR), "-o", "json", "--no-pager",
             "-q", *self._filtro()]))
        return {"fim": "limpo" if limpo else "abrupto", "ultima": self._hora(fim[-1].get("__REALTIME_TIMESTAMP")),
                "linhas": linhas}

    def _filtro(self) -> list:
        return [f"_SYSTEMD_UNIT={unidade}" for unidade in UNIDADES] + ["+", "_TRANSPORT=kernel", "+", "_PID=1"]

    def _diario(self, cursor: str | None) -> tuple:
        base = ["journalctl", "-o", "json", "--no-pager", "-q"]
        entradas = None
        if cursor:
            entradas = self._entradas([*base, f"--after-cursor={cursor}", *self._filtro()])
        if entradas is None:
            # Diário girado ou cursor perdido: retoma pelos últimos minutos.
            entradas = self._entradas([*base, f"--since={JANELA_INICIAL if not cursor else '-2min'}",
                                       *self._filtro()]) or []
        novo = entradas[-1].get("__CURSOR") if entradas else None
        return self._linhas(entradas), novo

    def _entradas(self, args: list) -> list | None:
        saida = self._rodar(args)
        if saida is None:
            return None
        entradas = []
        for linha in saida.splitlines():
            try:
                entrada = json.loads(linha)
            except ValueError:
                continue
            if isinstance(entrada, dict):
                entradas.append(entrada)
        return entradas

    @staticmethod
    def _mensagem(entrada: dict) -> str:
        mensagem = entrada.get("MESSAGE")
        if isinstance(mensagem, list):
            mensagem = bytes(b for b in mensagem if isinstance(b, int) and 0 <= b < 256).decode(
                "utf-8", "replace")
        return mensagem if isinstance(mensagem, str) else ""

    @staticmethod
    def _hora(micros) -> str | None:
        try:
            return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(int(micros) / 1e6))
        except (TypeError, ValueError, OverflowError, OSError):
            return None

    def _relevante(self, entrada: dict, mensagem: str) -> bool:
        if SEGREDO.search(mensagem):
            return False
        if entrada.get("_TRANSPORT") == "kernel":
            return bool(KERNEL.search(mensagem)) and not RUIDO.search(mensagem)
        if entrada.get("_PID") == "1" and not entrada.get("_SYSTEMD_UNIT", "").startswith(UNIDADES):
            return bool(SISTEMA.search(mensagem))
        if entrada.get("_SYSTEMD_UNIT") == "controle-de-aula-agent.service":
            return mensagem.startswith(AGENTE)
        return True

    def _linhas(self, entradas: list | None) -> list:
        linhas, boot = [], None
        for entrada in entradas or []:
            mensagem = self._mensagem(entrada)
            if not self._relevante(entrada, mensagem):
                continue
            if entrada.get("_BOOT_ID") != boot:
                if boot is not None:
                    linhas.append(f"-- boot {str(entrada.get('_BOOT_ID', ''))[:8]} --")
                boot = entrada.get("_BOOT_ID")
            quem = entrada.get("SYSLOG_IDENTIFIER") or entrada.get("_SYSTEMD_UNIT") or "?"
            hora = (self._hora(entrada.get("__REALTIME_TIMESTAMP")) or "")[11:]
            linhas.append(_cortar(f"{hora} {quem}: {mensagem}"))
        if len(linhas) > MAX_LINHAS:
            cabeca = MAX_LINHAS // 4
            linhas = [*linhas[:cabeca], f"-- {len(linhas) - MAX_LINHAS} linhas omitidas --",
                      *linhas[-(MAX_LINHAS - cabeca):]]
        return linhas

    # ---- fila e envio -------------------------------------------------------------

    def _enfileirar(self, estado: dict, registro: dict):
        texto = json.dumps(registro, ensure_ascii=False, separators=(",", ":"))
        while len(texto) > MAX_REGISTRO and registro.get("log"):
            registro = {**registro, "log": registro["log"][len(registro["log"]) // 2:]}
            texto = json.dumps(registro, ensure_ascii=False, separators=(",", ":"))
        if len(texto) > MAX_REGISTRO:
            return
        fila = self._ler_fila()
        fila.append({"sessao": estado["sessao"], "texto": texto})
        self._gravar_fila(fila[-FILA_MAX:])

    def _ler_fila(self) -> list:
        try:
            with open(self._fila, encoding="utf-8") as arquivo:
                itens = [json.loads(linha) for linha in arquivo if linha.strip()]
        except (OSError, ValueError):
            return []
        return [i for i in itens if isinstance(i, dict) and str(i.get("sessao", "")).isdigit()
                and isinstance(i.get("texto"), str)]

    def _gravar_fila(self, fila: list):
        temporario = self._fila + ".tmp"
        try:
            with open(os.open(temporario, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w",
                      encoding="utf-8") as arquivo:
                for item in fila:
                    arquivo.write(json.dumps(item, ensure_ascii=False) + "\n")
            os.replace(temporario, self._fila)
        except OSError as error:
            log.warning("fila do diagnóstico: %s", error)

    def _esvaziar(self):
        fb, identidade = self._get_fb(), self._get_identity()
        if fb is None or not identidade:
            return
        with self._lock:
            fila = self._ler_fila()[:SUBIDAS_POR_VEZ]
        enviados = []
        # Sem a trava durante a rede: um pedido do app não espera o envio.
        for item in fila:
            try:
                fb.side_request("POST", f"/diag/{identidade['deviceId']}/{item['sessao']}", item["texto"])
            except (FirebaseError, OSError):
                break
            enviados.append(item)
        if not enviados:
            return
        with self._lock:
            restante = self._ler_fila()
            while enviados and restante and restante[0] == enviados[0]:
                restante.pop(0)
                enviados.pop(0)
            self._gravar_fila(restante)
