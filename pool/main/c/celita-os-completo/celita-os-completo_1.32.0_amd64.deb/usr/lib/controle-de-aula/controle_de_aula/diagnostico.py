"""Diagnóstico de Wi-Fi e da tampa (pedido de 2026-10-29), ligado pelo app por
algumas horas. A cada minuto o PC registra o Wi-Fi em uso, as redes à volta, a
tampa, a bateria e o diário do NetworkManager, do celita-rede-forte, da tampa,
do logind e do kernel, e sobe para /diag/{deviceId}/{sessão}, que nenhum
cliente lê: só o console do Firebase. O prazo vale entre reinícios (o teste é
fechar a tampa ao ligar), e sem internet os registros esperam numa fila,
porque é quando o Wi-Fi falha que eles importam. Formato em docs/protocolo.md.

A internet veio depois ("o sinal é bom, só a internet é ruim"): o tempo até
sites conhecidos, o ping do roteador e de fora, a velocidade a cada 15 minutos,
o enlace do Wi-Fi, o tráfego e a carga do PC, e o tempo das páginas que o
navegador abriu, que a extensão manda pela ponte enquanto a gravação vale.
"""

import glob
import json
import logging
import os
import re
import subprocess
import threading
import time

from . import protocol
from .firebase import FirebaseError
from .session import celita_version

log = logging.getLogger("controle-de-aula.diagnostico")

CHAVE = "diagnostico"
INTERVALO_MS = 60 * 1000
FILA_MAX = 240
SUBIDAS_POR_VEZ = 30
MAX_LINHAS = 400
MAX_LINHA = 300
MAX_REGISTRO = 60000
MAX_REDES = 15
LINHAS_BOOT_ANTERIOR = 80
JANELA_INICIAL = "-30min"
TIMEOUT_S = 20
VELOCIDADE_MS = 15 * 60 * 1000
MAX_NAV = 200
MAX_NAV_MS = 600000

SONDAS = (
    ("portal", "http://connectivitycheck.gstatic.com/generate_204"),
    ("google", "https://www.google.com/"),
    ("youtube", "https://www.youtube.com/"),
    ("docs", "https://docs.google.com/"),
)
CURL = ["curl", "-s", "--connect-timeout", "5", "--max-time", "8"]
BAIXAR = "https://speed.cloudflare.com/__down?bytes=5000000"
SUBIR = "https://speed.cloudflare.com/__up"
SUBIR_BYTES = 1_000_000
INTERNET = "1.1.1.1"
ENLACE = {"signal": "sinal", "signal avg": "sinal_medio", "beacon signal avg": "sinal_beacon",
          "tx bitrate": "tx", "rx bitrate": "rx", "tx retries": "tx_repetidos", "tx failed": "tx_falhos",
          "beacon loss": "beacons_perdidos", "expected throughput": "vazao_esperada",
          "connected time": "conectado"}
IPV4 = re.compile(r"\d{1,3}(\.\d{1,3}){3}")
DISPOSITIVO = re.compile(r"[A-Za-z0-9_-][A-Za-z0-9_.-]{0,14}")
HOST = re.compile(r"[a-z0-9._-]{1,253}|\[[0-9a-f:.]{2,45}\]")
ERRO_NAV = re.compile(r"net::ERR_[A-Z0-9_]{1,60}")
PERDA = re.compile(r"([\d.]+)% packet loss")
RTT = re.compile(r"= ([\d.]+)/([\d.]+)/([\d.]+)/")
PRESSAO = re.compile(r"^some avg10=[\d.]+ avg60=([\d.]+)", re.M)

UNIDADES = (
    "NetworkManager.service", "wpa_supplicant.service", "celita-rede-forte.service",
    "celita-tampa.service", "systemd-logind.service", "systemd-suspend.service",
    "controle-de-aula-agent.service",
)
# Do kernel e do systemd, só o que fala de tampa, sono, desligamento e Wi-Fi;
# do agente, só o Wi-Fi da escola. Linha que fala de segredo nunca sai.
KERNEL = re.compile(r"PM: |ACPI|\blid\b|suspend|resume|wak|wlan|wlp|iwlwifi|ath\d|mt7|rtw|brcm|"
                    r"deauth|disassoc|authenticat|associat|reboot|power down|watchdog|panic|oops|"
                    r"BUG:|hung_task|cros_ec", re.I)
SISTEMA = re.compile(r"sleep|suspend|hibernat|power-?off|reboot|shutdown|shutting down|"
                     r"startup finished|reached target (graphical|multi-user)", re.I)
AGENTE = ("controle-de-aula.wifi:", "controle-de-aula.diagnostico:")
RUIDO = re.compile(r"ACPI: ([A-Z0-9]{4} 0x|Early table|RSDP)|^efi: ")
SEGREDO = re.compile(r"psk|passw|senha|secret|wep-key|private-key", re.I)
FIM_LIMPO = re.compile(r"reboot: (power down|restarting)|systemd-shutdown|shutting down\.|"
                       r"journal stopped", re.I)


def _escapado(campo: str) -> str:
    return campo.replace("\\:", ":").replace("\\\\", "\\")


def _campos(linha: str) -> list:
    return [_escapado(c) for c in re.split(r"(?<!\\):", linha)]


def _cortar(texto: str, limite: int = MAX_LINHA) -> str:
    return texto if len(texto) <= limite else texto[: limite - 1] + "…"


def _numero(valor) -> float:
    return float(valor) if isinstance(valor, (int, float)) and not isinstance(valor, bool) else 0.0


def _ms(valor) -> bool:
    return isinstance(valor, int) and not isinstance(valor, bool) and 0 <= valor <= MAX_NAV_MS


def _navegacao(item) -> dict | None:
    if not isinstance(item, dict) or not isinstance(item.get("host"), str) \
            or not HOST.fullmatch(item["host"]) or not _ms(item.get("ms")):
        return None
    valida = {"host": item["host"], "ms": item["ms"]}
    if _ms(item.get("resp")):
        valida["resp"] = item["resp"]
    if isinstance(item.get("erro"), str) and ERRO_NAV.fullmatch(item["erro"]):
        valida["erro"] = item["erro"]
    return valida


def _em_thread(alvo):
    def rodar():
        try:
            alvo()
        except Exception as error:  # noqa: BLE001 - o minuto seguinte tenta de novo
            log.warning("diagnóstico: %s", error)
    threading.Thread(target=rodar, name="diagnostico", daemon=True).start()


class Diagnostico:
    def __init__(self, storage, get_fb, get_identity, agora_ms=None, executar=subprocess.run,
                 raiz: str = "/", fila: str | None = None, versao=celita_version, ao_mudar=None,
                 disparar=_em_thread):
        self.storage = storage
        self._get_fb = get_fb
        self._get_identity = get_identity
        self._agora = agora_ms or (lambda: int(time.time() * 1000))
        self._executar = executar
        self._raiz = raiz
        self._fila = fila or os.path.join(os.path.dirname(storage.path), "diagnostico-fila.jsonl")
        self._versao = versao
        self._ao_mudar = ao_mudar or (lambda _ativo: None)
        self._disparar = disparar
        self._lock = threading.Lock()
        self._ultimo = 0
        self._coletando = False
        self._velocidade_em = 0
        self._nav = []
        self._amostras = {}

    # ---- comando do app -----------------------------------------------------------

    def pedir(self, payload: dict) -> dict:
        horas = payload.get("horas")
        if isinstance(horas, bool) or not isinstance(horas, (int, float)) \
                or not 0 <= horas <= protocol.DIAGNOSTICO_MAX_HORAS:
            return {"ok": False, "error": "payload_invalido"}
        with self._lock:
            agora = self._agora()
            estado = self._estado()
            if horas == 0:
                if estado:
                    self._enfileirar(estado, {"tipo": "fim", "t": agora, "motivo": "app"})
                self.storage.set(CHAVE, None)
                self._nav = []
            else:
                ate = agora + int(horas * 3600 * 1000)
                # Pedido com a gravação ligada só muda o prazo: a sessão continua.
                estado = {**estado, "ate": ate} if estado else \
                    {"sessao": str(agora), "ate": ate, "cursor": None, "boot": None}
                self.storage.set(CHAVE, estado)
                self._ultimo = 0
        self._ao_mudar(horas > 0)
        return {"ok": True}

    def ativo(self) -> bool:
        with self._lock:
            estado = self._estado()
            return estado is not None and self._agora() < estado["ate"]

    def navegacao(self, itens):
        """Páginas que a extensão mediu ({t:'nav'}), para o próximo minuto."""
        if not isinstance(itens, list):
            return
        agora = self._agora()
        validas = [{**item, "t": agora} for item in map(_navegacao, itens[:MAX_NAV]) if item]
        with self._lock:
            estado = self._estado()
            if estado is not None and agora < estado["ate"]:
                self._nav = [*self._nav, *validas][-MAX_NAV:]

    # ---- laço lateral -------------------------------------------------------------

    def tick(self):
        coletar, acabou = None, False
        with self._lock:
            estado = self._estado()
            agora = self._agora()
            if estado and agora >= estado["ate"]:
                self._enfileirar(estado, {"tipo": "fim", "t": agora, "motivo": "prazo"})
                self.storage.set(CHAVE, None)
                self._nav = []
                acabou = True
            elif estado and not self._coletando and agora - self._ultimo >= INTERVALO_MS:
                self._ultimo = agora
                self._coletando = True
                coletar = estado
        if acabou:
            self._ao_mudar(False)
        if coletar:
            # Fora do laço lateral: ping, sondas e velocidade levam segundos.
            self._disparar(lambda: self._coletar(coletar, agora))
        self._esvaziar()

    def _estado(self) -> dict | None:
        estado = self.storage.get(CHAVE)
        if not isinstance(estado, dict) or not str(estado.get("sessao", "")).isdigit() \
                or not isinstance(estado.get("ate"), int):
            return None
        return estado

    def _coletar(self, estado: dict, agora: int):
        try:
            boot = (self._ler("proc/sys/kernel/random/boot_id") or "").replace("-", "") or None
            registros = []
            if boot and estado.get("boot") != boot:
                motivo = "inicio" if estado.get("boot") is None else "boot"
                registros.append(self._registro_boot(agora, boot, motivo))
            linhas, cursor = self._diario(estado.get("cursor"))
            minuto = {"tipo": "minuto", "t": agora, **self._estado_do_pc(agora)}
            with self._lock:
                atual = self._estado()
                # Parada pelo app durante a coleta: o fim já está na fila.
                if atual is None or atual["sessao"] != estado["sessao"]:
                    return
                nav, self._nav = self._nav, []
                for registro in (*registros, {**minuto, "nav": nav, "log": linhas}):
                    self._enfileirar(atual, registro)
                self.storage.set(CHAVE, {**atual, "boot": boot or atual.get("boot"),
                                         "cursor": cursor or atual.get("cursor")})
        finally:
            with self._lock:
                self._coletando = False

    # ---- o que se registra --------------------------------------------------------

    def _rodar(self, args: list, qualquer_saida: bool = False, entrada: str | None = None) -> str | None:
        try:
            resultado = self._executar(args, capture_output=True, text=True, timeout=TIMEOUT_S,
                                       check=False, input=entrada)
        except (OSError, subprocess.TimeoutExpired):
            return None
        return resultado.stdout if resultado.returncode == 0 or qualquer_saida else None

    def _ler(self, caminho: str) -> str | None:
        try:
            with open(os.path.join(self._raiz, caminho), encoding="utf-8", errors="replace") as arquivo:
                return arquivo.read().strip()
        except OSError:
            return None

    def _estado_do_pc(self, agora: int) -> dict:
        wifi = self._wifi()
        dispositivo, ip = wifi.get("dispositivo"), wifi.get("ip") or []
        estado = {"wifi": wifi, "redes": self._redes(), "tampa": self._tampa(), "energia": self._energia(),
                  "enlace": self._enlace(dispositivo), "ping": self._pings(ip[1] if len(ip) > 1 else None),
                  "sondas": self._sondas()}
        if agora - self._velocidade_em >= VELOCIDADE_MS:
            self._velocidade_em = agora
            estado["velocidade"] = self._velocidade()
        # Depois da velocidade: o tráfego do minuto que a mediu conta o teste.
        estado.update(trafego=self._trafego(dispositivo, agora), sistema=self._sistema())
        return estado

    def _wifi(self) -> dict:
        wifi = {}
        geral = self._rodar(["nmcli", "-t", "-f", "STATE,CONNECTIVITY,WIFI", "general"])
        if geral:
            campos = _campos(geral.splitlines()[0])
            wifi.update(zip(("estado", "conectividade", "radio"), campos))
        for linha in (self._rodar(["nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION",
                                   "device", "status"]) or "").splitlines():
            campos = _campos(linha)
            if len(campos) == 4 and campos[1] == "wifi":
                wifi.update(dispositivo=campos[0], dispositivo_estado=campos[2], conexao=campos[3])
                ip = self._rodar(["nmcli", "-t", "-g", "IP4.ADDRESS,IP4.GATEWAY,IP4.DNS", "device",
                                  "show", campos[0]])
                if ip:
                    linhas = ip.splitlines()
                    wifi["ip"] = [_cortar(v, 60) for v in linhas[:2]]
                    if len(linhas) > 2 and linhas[2]:
                        wifi["dns"] = _cortar(linhas[2], 100)
                break
        return wifi

    def _redes(self) -> list:
        saida = self._rodar(["nmcli", "-t", "-f", "IN-USE,BSSID,SSID,CHAN,FREQ,SIGNAL,SECURITY",
                             "device", "wifi", "list", "--rescan", "no"])
        redes = []
        for linha in (saida or "").splitlines():
            campos = _campos(linha)
            if len(campos) != 7:
                continue
            usa, bssid, ssid, canal, freq, sinal, seguranca = campos
            redes.append({"ssid": _cortar(ssid, 40), "bssid": bssid, "canal": canal, "freq": freq,
                          "sinal": int(sinal) if sinal.isdigit() else None,
                          "seg": _cortar(seguranca, 30), "usa": usa.strip() == "*"})
        redes.sort(key=lambda rede: (not rede["usa"], -(rede["sinal"] or 0)))
        return redes[:MAX_REDES]

    def _tampa(self) -> str | None:
        for caminho in sorted(glob.glob(os.path.join(self._raiz, "proc/acpi/button/lid/*/state"))):
            texto = self._ler(os.path.relpath(caminho, self._raiz)) or ""
            return texto.split()[-1] if texto.split() else None
        return None

    def _energia(self) -> dict:
        energia = {}
        for pasta in sorted(glob.glob(os.path.join(self._raiz, "sys/class/power_supply/*"))):
            relativo = os.path.relpath(pasta, self._raiz)
            tipo = self._ler(os.path.join(relativo, "type"))
            if tipo == "Battery":
                carga = self._ler(os.path.join(relativo, "capacity"))
                energia["bateria"] = int(carga) if carga and carga.isdigit() else None
                energia["situacao"] = self._ler(os.path.join(relativo, "status"))
            elif tipo == "Mains":
                energia["tomada"] = self._ler(os.path.join(relativo, "online")) == "1"
        return energia

    # ---- internet e carga do PC ---------------------------------------------------

    def _sondas(self) -> list:
        # HEAD sem seguir redirecionamento: mede DNS, conexão, TLS e primeiro
        # byte, sem baixar a página.
        alvos = list(SONDAS)
        url = getattr(self._get_fb(), "database_url", None)
        if isinstance(url, str) and url.startswith("https://"):
            alvos.append(("firebase", url + "/.json"))
        args = [*CURL, "-I", "--parallel", "--parallel-immediate", "-w", "%{json}\\n"]
        for _nome, endereco in alvos:
            args += ["-o", "/dev/null", endereco]
        respostas = {d["urlnum"]: d for d in self._jsons(self._rodar(args, qualquer_saida=True))
                     if isinstance(d.get("urlnum"), int)}
        return [{"alvo": nome, **self._tempos(respostas.get(i))} for i, (nome, _e) in enumerate(alvos)]

    @staticmethod
    def _tempos(dados) -> dict:
        if not isinstance(dados, dict):
            return {"erro": "sem resposta"}
        tempos = {"http": dados.get("http_code")}
        for campo, chave in (("dns", "time_namelookup"), ("tcp", "time_connect"), ("tls", "time_appconnect"),
                             ("ttfb", "time_starttransfer"), ("total", "time_total")):
            if _numero(dados.get(chave)) > 0:
                tempos[campo] = round(_numero(dados[chave]) * 1000)
        if isinstance(dados.get("remote_ip"), str) and dados["remote_ip"]:
            tempos["ip"] = dados["remote_ip"][:45]
        if dados.get("exitcode"):
            tempos["erro"] = _cortar(str(dados.get("errormsg") or f"curl {dados['exitcode']}"), 100)
        return tempos

    def _velocidade(self) -> dict:
        saida = [*CURL, "-o", "/dev/null", "-w", "%{json}"]
        baixa = self._jsons(self._rodar([*saida, BAIXAR], qualquer_saida=True))
        sobe = self._jsons(self._rodar([*saida, "--data-binary", "@-", SUBIR], qualquer_saida=True,
                                       entrada="0" * SUBIR_BYTES))
        return {"baixa": self._vazao(baixa, "download"), "sobe": self._vazao(sobe, "upload")}

    @staticmethod
    def _vazao(dados: list, sentido: str) -> dict:
        if not dados:
            return {"erro": "sem resposta"}
        vazao = {"kbps": round(_numero(dados[0].get(f"speed_{sentido}")) * 8 / 1000),
                 "kb": round(_numero(dados[0].get(f"size_{sentido}")) / 1000),
                 "s": round(_numero(dados[0].get("time_total")), 1)}
        if dados[0].get("exitcode"):
            vazao["erro"] = _cortar(str(dados[0].get("errormsg") or f"curl {dados[0]['exitcode']}"), 100)
        return vazao

    def _pings(self, roteador) -> dict:
        alvos = {"internet": INTERNET}
        if isinstance(roteador, str) and IPV4.fullmatch(roteador):
            alvos = {"roteador": roteador, **alvos}
        return {nome: self._ping(ip) for nome, ip in alvos.items()}

    def _ping(self, ip: str) -> dict:
        saida = self._rodar(["ping", "-n", "-q", "-c", "5", "-i", "0.2", "-W", "1", "-w", "3", ip],
                            qualquer_saida=True) or ""
        perda, rtt = PERDA.search(saida), RTT.search(saida)
        if not perda:
            return {"erro": "sem resposta"}
        ping = {"perda": round(float(perda.group(1)))}
        if rtt:
            ping.update(min=float(rtt.group(1)), media=float(rtt.group(2)), max=float(rtt.group(3)))
        return ping

    def _enlace(self, dispositivo) -> dict | None:
        if not isinstance(dispositivo, str) or not DISPOSITIVO.fullmatch(dispositivo):
            return None
        enlace = {}
        for linha in (self._rodar(["iw", "dev", dispositivo, "station", "dump"]) or "").splitlines():
            if linha.startswith("Station "):
                if enlace:
                    break
                enlace["bssid"] = linha.split()[1]
                continue
            chave, _, valor = linha.strip().partition(":")
            if chave in ENLACE:
                enlace[ENLACE[chave]] = _cortar(valor.strip(), 80)
        return enlace or None

    def _trafego(self, dispositivo, agora: int) -> dict | None:
        if not isinstance(dispositivo, str) or not DISPOSITIVO.fullmatch(dispositivo):
            return None
        contadores = [self._ler(f"sys/class/net/{dispositivo}/statistics/{nome}_bytes") for nome in ("rx", "tx")]
        if not all(c and c.isdigit() for c in contadores):
            return None
        rx, tx = (int(c) for c in contadores)
        anterior, self._amostras["trafego"] = self._amostras.get("trafego"), (dispositivo, agora, rx, tx)
        if not anterior or anterior[0] != dispositivo or rx < anterior[2] or tx < anterior[3]:
            return None
        return {"rx_kb": (rx - anterior[2]) // 1000, "tx_kb": (tx - anterior[3]) // 1000,
                "s": round((agora - anterior[1]) / 1000)}

    def _sistema(self) -> dict:
        sistema = {}
        carga = (self._ler("proc/loadavg") or "").split()[:3]
        if len(carga) == 3 and all(re.fullmatch(r"[\d.]+", c) for c in carga):
            sistema["carga"] = [float(c) for c in carga]
        memoria = self._memoria()
        valores = {"cpu": self._cpu(), "livre_mb": memoria.get("MemAvailable"),
                   "swap_mb": memoria["SwapTotal"] - memoria["SwapFree"]
                   if {"SwapTotal", "SwapFree"} <= memoria.keys() else None,
                   "pressao": self._pressao(), "temp": self._temperatura(), "processos": self._processos()}
        sistema.update({chave: valor for chave, valor in valores.items() if valor not in (None, {})})
        return sistema

    def _cpu(self) -> int | None:
        linha = ((self._ler("proc/stat") or "").splitlines() or [""])[0]
        valores = linha.split()[1:] if linha.startswith("cpu ") else []
        if len(valores) < 5 or not all(v.isdigit() for v in valores):
            return None
        numeros = [int(v) for v in valores]
        total, ocioso = sum(numeros[:8]), numeros[3] + numeros[4]
        anterior, self._amostras["cpu"] = self._amostras.get("cpu"), (total, ocioso)
        if not anterior or total <= anterior[0]:
            return None
        return round(100 * (1 - (ocioso - anterior[1]) / (total - anterior[0])))

    def _memoria(self) -> dict:
        memoria = {}
        for linha in (self._ler("proc/meminfo") or "").splitlines():
            nome, _, valor = linha.partition(":")
            if valor.split() and valor.split()[0].isdigit():
                memoria[nome] = int(valor.split()[0]) // 1024
        return memoria

    def _pressao(self) -> dict:
        pressao = {}
        for nome in ("cpu", "memory", "io"):
            achado = PRESSAO.search(self._ler(f"proc/pressure/{nome}") or "")
            if achado:
                pressao[nome] = float(achado.group(1))
        return pressao

    def _temperatura(self) -> int | None:
        graus = []
        for caminho in glob.glob(os.path.join(self._raiz, "sys/class/thermal/thermal_zone*/temp")):
            texto = self._ler(os.path.relpath(caminho, self._raiz)) or ""
            if texto.lstrip("-").isdigit():
                graus.append(int(texto) // 1000)
        return max(graus) if graus else None

    def _processos(self) -> dict:
        memoria = {}
        for linha in (self._rodar(["ps", "-e", "-o", "comm=,rss="]) or "").splitlines():
            nome, _, rss = linha.strip().rpartition(" ")
            if nome.strip() and rss.isdigit():
                memoria[nome.strip()] = memoria.get(nome.strip(), 0) + int(rss)
        maiores = sorted(memoria.items(), key=lambda item: -item[1])[:5]
        return {nome[:30]: rss // 1024 for nome, rss in maiores}

    def _registro_boot(self, agora: int, boot: str, motivo: str) -> dict:
        uptime = (self._ler("proc/uptime") or "0").split()[0]
        return {
            "tipo": "boot", "t": agora, "motivo": motivo, "boot": boot,
            "ligado_ha_s": int(float(uptime)) if re.fullmatch(r"[0-9.]+", uptime) else None,
            "versao": self._versao(),
            "bios": self._ler("sys/class/dmi/id/bios_version"),
            "modelo": self._ler("sys/class/dmi/id/product_name"),
            "tampa": self._tampa(),
            "boots": self._boots(),
            "anterior": self._boot_anterior(),
        }

    def _boots(self) -> list:
        saida = self._rodar(["journalctl", "--list-boots", "--no-pager", "-q", "-o", "json"])
        try:
            boots = json.loads(saida or "")
        except ValueError:
            return [_cortar(linha, 120) for linha in (saida or "").splitlines()[-6:]]
        if not isinstance(boots, list):
            return []
        return [{"boot": str(b.get("boot_id", ""))[:32],
                 "de": self._hora(b.get("first_entry")), "ate": self._hora(b.get("last_entry"))}
                for b in boots[-6:] if isinstance(b, dict)]

    def _boot_anterior(self) -> dict:
        # Desligamento limpo deixa o systemd-shutdown ou o "reboot:" do kernel no
        # fim; sem eles, o boot anterior acabou na marra (botão segurado).
        fim = self._entradas(["journalctl", "-b", "-1", "-n", "60", "-o", "json", "--no-pager", "-q"])
        if not fim:
            return {"fim": None, "linhas": []}
        limpo = any(FIM_LIMPO.search(self._mensagem(e)) for e in fim)
        linhas = self._linhas(self._entradas(
            ["journalctl", "-b", "-1", "-n", str(LINHAS_BOOT_ANTERIOR), "-o", "json", "--no-pager",
             "-q", *self._filtro()]))
        return {"fim": "limpo" if limpo else "abrupto", "ultima": self._hora(fim[-1].get("__REALTIME_TIMESTAMP")),
                "linhas": linhas}

    def _filtro(self) -> list:
        return [f"_SYSTEMD_UNIT={unidade}" for unidade in UNIDADES] + ["+", "_TRANSPORT=kernel", "+", "_PID=1"]

    def _diario(self, cursor: str | None) -> tuple:
        base = ["journalctl", "-o", "json", "--no-pager", "-q"]
        entradas = None
        if cursor:
            entradas = self._entradas([*base, f"--after-cursor={cursor}", *self._filtro()])
        if entradas is None:
            # Diário girado ou cursor perdido: retoma pelos últimos minutos.
            entradas = self._entradas([*base, f"--since={JANELA_INICIAL if not cursor else '-2min'}",
                                       *self._filtro()]) or []
        novo = entradas[-1].get("__CURSOR") if entradas else None
        return self._linhas(entradas), novo

    def _entradas(self, args: list) -> list | None:
        saida = self._rodar(args)
        return None if saida is None else self._jsons(saida)

    @staticmethod
    def _jsons(saida: str | None) -> list:
        objetos = []
        for linha in (saida or "").splitlines():
            try:
                objeto = json.loads(linha)
            except ValueError:
                continue
            if isinstance(objeto, dict):
                objetos.append(objeto)
        return objetos

    @staticmethod
    def _mensagem(entrada: dict) -> str:
        mensagem = entrada.get("MESSAGE")
        if isinstance(mensagem, list):
            mensagem = bytes(b for b in mensagem if isinstance(b, int) and 0 <= b < 256).decode(
                "utf-8", "replace")
        return mensagem if isinstance(mensagem, str) else ""

    @staticmethod
    def _hora(micros) -> str | None:
        try:
            return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(int(micros) / 1e6))
        except (TypeError, ValueError, OverflowError, OSError):
            return None

    def _relevante(self, entrada: dict, mensagem: str) -> bool:
        if SEGREDO.search(mensagem):
            return False
        if entrada.get("_TRANSPORT") == "kernel":
            return bool(KERNEL.search(mensagem)) and not RUIDO.search(mensagem)
        if entrada.get("_PID") == "1" and not entrada.get("_SYSTEMD_UNIT", "").startswith(UNIDADES):
            return bool(SISTEMA.search(mensagem))
        if entrada.get("_SYSTEMD_UNIT") == "controle-de-aula-agent.service":
            return mensagem.startswith(AGENTE)
        return True

    def _linhas(self, entradas: list | None) -> list:
        linhas, boot = [], None
        for entrada in entradas or []:
            mensagem = self._mensagem(entrada)
            if not self._relevante(entrada, mensagem):
                continue
            if entrada.get("_BOOT_ID") != boot:
                if boot is not None:
                    linhas.append(f"-- boot {str(entrada.get('_BOOT_ID', ''))[:8]} --")
                boot = entrada.get("_BOOT_ID")
            quem = entrada.get("SYSLOG_IDENTIFIER") or entrada.get("_SYSTEMD_UNIT") or "?"
            hora = (self._hora(entrada.get("__REALTIME_TIMESTAMP")) or "")[11:]
            linhas.append(_cortar(f"{hora} {quem}: {mensagem}"))
        if len(linhas) > MAX_LINHAS:
            cabeca = MAX_LINHAS // 4
            linhas = [*linhas[:cabeca], f"-- {len(linhas) - MAX_LINHAS} linhas omitidas --",
                      *linhas[-(MAX_LINHAS - cabeca):]]
        return linhas

    # ---- fila e envio -------------------------------------------------------------

    def _enfileirar(self, estado: dict, registro: dict):
        texto = json.dumps(registro, ensure_ascii=False, separators=(",", ":"))
        while len(texto) > MAX_REGISTRO and registro.get("log"):
            registro = {**registro, "log": registro["log"][len(registro["log"]) // 2:]}
            texto = json.dumps(registro, ensure_ascii=False, separators=(",", ":"))
        if len(texto) > MAX_REGISTRO:
            return
        fila = self._ler_fila()
        fila.append({"sessao": estado["sessao"], "texto": texto})
        self._gravar_fila(fila[-FILA_MAX:])

    def _ler_fila(self) -> list:
        try:
            with open(self._fila, encoding="utf-8") as arquivo:
                itens = [json.loads(linha) for linha in arquivo if linha.strip()]
        except (OSError, ValueError):
            return []
        return [i for i in itens if isinstance(i, dict) and str(i.get("sessao", "")).isdigit()
                and isinstance(i.get("texto"), str)]

    def _gravar_fila(self, fila: list):
        temporario = self._fila + ".tmp"
        try:
            with open(os.open(temporario, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w",
                      encoding="utf-8") as arquivo:
                for item in fila:
                    arquivo.write(json.dumps(item, ensure_ascii=False) + "\n")
            os.replace(temporario, self._fila)
        except OSError as error:
            log.warning("fila do diagnóstico: %s", error)

    def _esvaziar(self):
        fb, identidade = self._get_fb(), self._get_identity()
        if fb is None or not identidade:
            return
        with self._lock:
            fila = self._ler_fila()[:SUBIDAS_POR_VEZ]
        enviados = []
        # Sem a trava durante a rede: um pedido do app não espera o envio.
        for item in fila:
            try:
                fb.side_request("POST", f"/diag/{identidade['deviceId']}/{item['sessao']}", item["texto"])
            except (FirebaseError, OSError):
                break
            enviados.append(item)
        if not enviados:
            return
        with self._lock:
            restante = self._ler_fila()
            while enviados and restante and restante[0] == enviados[0]:
                restante.pop(0)
                enviados.pop(0)
            self._gravar_fila(restante)
