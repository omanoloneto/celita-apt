"""Wi-Fi da escola: toda rede que uma unidade conhece, todas conhecem (pedido de
2026-10-17, inclusive as salvas na conta de aluno).

Cada PC da escola sobe as redes salvas no NetworkManager para
`/school/wifi/redes`, cifradas com a chave da frota, e grava no próprio
NetworkManager as que os outros subiram. A chave da frota nasce no primeiro PC
que chega, com o kcv que diz qual ela é, e chega aos outros selada com X25519:
de outro PC (`/school/wifi/chaves`) ou do celular de um professor
(`/school/wifi/entregas`), que vê a chave mas não lê `redes`. O Firebase não
vê nem uma nem outra. Formato em docs/protocolo.md §9.

Conflito: vale a versão que conectou por último (o `timestamps` do NM, que só
conta depois da última gravação do perfil), para uma senha errada digitada numa
unidade nunca derrubar a rede das outras; rede nova sobe depois de conectar.
Esquecer uma rede só vale para todas pelo "Esquecer" da Central de
Configurações, que avisa o agente antes de apagar o perfil (`pedir_esquecer`);
perfil que some de outro jeito (login que falhou, nmcli, conta de aluno) volta.

A chave "Preferida" da Central (pedido de 2026-10-29: na sala, a rede de sinal
forte não navegava e a boa era outra) também vale para todas (`pedir_preferir`):
a lista vai num registro de `redes` com id reservado, que as versões antigas não
leem e deixam como está, e vira a prioridade do perfil no NetworkManager.
"""

import hashlib
import json
import logging
import os
import re
import subprocess
import tempfile
import threading
import time
import uuid

from .crypto import b64url_decode, b64url_encode, derive_wifi_wrap_key, open_envelope, seal, wifi_kcv
from .firebase import FirebaseError

log = logging.getLogger("controle-de-aula.wifi")

CONEXOES = "/etc/NetworkManager/system-connections"
TIMESTAMPS = "/var/lib/NetworkManager/timestamps"
# A Central de Configurações avisa no "Esquecer" que a rede some das outras unidades.
MARCA = "/run/controle-de-aula/wifi-escola"
BASE = "/school/wifi"
SYNC_S = 300
# Sem a chave, pergunta de minuto em minuto: o celular entrega em segundos.
SEM_CHAVE_S = 60
# Senha trocada aqui que não conectou volta à da escola depois disso.
ESPERA_CONECTAR_MS = 30 * 60 * 1000
# "Esquecer" cujo perfil continua aqui (senha do sistema cancelada) deixa de valer.
ESPERA_ESQUECER_MS = 10 * 60 * 1000
# "Esquecer" que não chegou à escola em uma semana (sem internet, sem a chave) não vale mais.
PRAZO_ESQUECER_MS = 7 * 24 * 60 * 60 * 1000
AUTH_BACKOFF_S = 10 * 60
MAX_REDES = 200
MAX_ENTREGAS = 50
MAX_TEXTO = 256
STORE_CHAVE = "wifiFrota"
STORE_REGISTRO = "wifiRegistro"
STORE_ESQUECER = "wifiEsquecer"
STORE_PREFERIDAS = "wifiPreferidas"
STORE_PREFERIR = "wifiPreferir"
# A mesma da Central de Configurações (celita-settings-rede.c).
PRIORIDADE_PREFERIDA = 10

SEGURANCAS = ("aberta", "owe", "wpa-psk", "sae", "wpa-eap")
CLASSE = {"aberta": "aberta", "owe": "aberta", "wpa-psk": "senha", "sae": "senha", "wpa-eap": "conta"}
# Métodos que não pedem certificado do aparelho: caminho de arquivo não viaja.
EAP_SEM_CERTIFICADO = ("peap", "ttls", "pwd")
FASES2 = ("mschapv2", "pap", "chap", "mschap", "gtc", "md5")
CERTIFICADOS = ("ca-cert", "ca-path", "client-cert", "private-key", "phase2-ca-cert", "phase2-ca-path",
                "phase2-client-cert", "phase2-private-key", "pac-file")
_LISTA_DE_BYTES = re.compile(r"^([0-9]{1,3};)+$")
_HEX64 = re.compile(r"^[0-9A-Fa-f]{64}$")
_UUID = re.compile(r"^[0-9A-Fa-f-]{36,40}$")
_ID = re.compile(r"^[A-Za-z0-9_-]{22}$")


def _glib():
    import gi
    gi.require_version("GLib", "2.0")
    from gi.repository import GLib
    return GLib


# ---- a rede como viaja -----------------------------------------------------------


def _texto_ok(valor, minimo=1) -> bool:
    return isinstance(valor, str) and minimo <= len(valor) <= MAX_TEXTO and "\x00" not in valor


def _ssid_bytes(dados) -> bytes | None:
    try:
        ssid = b64url_decode(dados["ssid"])
    except (KeyError, TypeError, ValueError):
        return None
    return ssid if 1 <= len(ssid) <= 32 else None


def validar(dados) -> bool:
    """Só o que esta versão sabe gravar no NetworkManager, e nada além."""
    if not isinstance(dados, dict) or dados.get("v") != 1 or _ssid_bytes(dados) is None:
        return False
    if not isinstance(dados.get("oculta"), bool) or dados.get("seguranca") not in SEGURANCAS:
        return False
    seguranca = dados["seguranca"]
    permitidas = {"v", "ssid", "oculta", "seguranca"}
    if seguranca == "wpa-psk":
        psk = dados.get("psk")
        if not (_texto_ok(psk, 8) and (len(psk) <= 63 and psk.isprintable() or _HEX64.match(psk))):
            return False
        permitidas.add("psk")
    elif seguranca == "sae":
        if not _texto_ok(dados.get("psk")):
            return False
        permitidas.add("psk")
    elif seguranca == "wpa-eap":
        eap = dados.get("eap")
        if not isinstance(eap, dict) or set(eap) - {"metodos", "identidade", "senha", "fase2", "anonima", "dominio"}:
            return False
        metodos = eap.get("metodos")
        if not isinstance(metodos, list) or not metodos or any(m not in EAP_SEM_CERTIFICADO for m in metodos):
            return False
        if not _texto_ok(eap.get("identidade")) or not _texto_ok(eap.get("senha")):
            return False
        if "fase2" in eap and eap["fase2"] not in FASES2:
            return False
        if any(k in eap and not _texto_ok(eap[k]) for k in ("anonima", "dominio")):
            return False
        permitidas.add("eap")
    return not set(dados) - permitidas


def _id(ssid: bytes, classe: str) -> str:
    return b64url_encode(hashlib.sha256(ssid + b"\x00" + classe.encode()).digest())[:22]


def rede_id(dados) -> str:
    """Mesmo nome e mesmo jeito de entrar: a mesma rede em todas as unidades."""
    return _id(_ssid_bytes(dados), CLASSE[dados["seguranca"]])


def resumo(dados) -> str:
    return hashlib.sha256(json.dumps(dados, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:32]


# Classe que nenhuma rede tem: o id não colide com o de rede nenhuma.
PREFERIDAS = _id(b"celita-preferidas-v1", "lista")


# ---- o NetworkManager desta unidade ----------------------------------------------


class RedeLocal:
    def __init__(self, arquivo, uuid_, dados, ok_ms, mtime_ms):
        self.arquivo = arquivo
        self.uuid = uuid_
        self.dados = dados
        self.ok_ms = ok_ms
        self.mtime_ms = mtime_ms


def _valor(kf, grupo, chave):
    try:
        return kf.get_string(grupo, chave)
    except Exception:  # noqa: BLE001 - GLib.Error: grupo ou chave ausente
        return None


def _grupo(kf, *nomes):
    return next((nome for nome in nomes if kf.has_group(nome)), nomes[0])


def _ssid_do_arquivo(valor) -> bytes | None:
    if valor is None:
        return None
    if _LISTA_DE_BYTES.match(valor):
        numeros = [int(n) for n in valor.split(";") if n]
        if any(n > 255 for n in numeros):
            return None
        ssid = bytes(numeros)
    else:
        ssid = valor.encode("utf-8")
    return ssid if 1 <= len(ssid) <= 32 else None


def _segredo_do_sistema(kf, grupo, chave) -> bool:
    """Senha guardada pelo NM para todas as contas; a do chaveiro de uma conta não viaja."""
    valor = _valor(kf, grupo, chave)
    try:
        return valor is None or int(valor) == 0
    except ValueError:
        return False


def dados_do_perfil(kf) -> dict | None:
    if _valor(kf, "connection", "type") not in ("wifi", "802-11-wireless"):
        return None
    wifi = _grupo(kf, "wifi", "802-11-wireless")
    if (_valor(kf, wifi, "mode") or "infrastructure") != "infrastructure":
        return None
    ssid = _ssid_do_arquivo(_valor(kf, wifi, "ssid"))
    if ssid is None:
        return None
    dados = {"v": 1, "ssid": b64url_encode(ssid), "oculta": (_valor(kf, wifi, "hidden") or "").lower() == "true"}
    seguranca = _grupo(kf, "wifi-security", "802-11-wireless-security")
    gestao = _valor(kf, seguranca, "key-mgmt") if kf.has_group(seguranca) else None
    if gestao is None:
        dados["seguranca"] = "aberta"
    elif gestao == "owe":
        dados["seguranca"] = "owe"
    elif gestao in ("wpa-psk", "sae"):
        psk = _valor(kf, seguranca, "psk")
        if not psk or not _segredo_do_sistema(kf, seguranca, "psk-flags"):
            return None
        dados.update(seguranca=gestao, psk=psk)
    elif gestao == "wpa-eap":
        if not kf.has_group("802-1x") or not _segredo_do_sistema(kf, "802-1x", "password-flags"):
            return None
        if any(_valor(kf, "802-1x", chave) for chave in CERTIFICADOS):
            return None
        eap = {"metodos": [m for m in (_valor(kf, "802-1x", "eap") or "").split(";") if m],
               "identidade": _valor(kf, "802-1x", "identity"), "senha": _valor(kf, "802-1x", "password")}
        for chave, nome in (("phase2-auth", "fase2"), ("anonymous-identity", "anonima"),
                            ("domain-suffix-match", "dominio")):
            valor = _valor(kf, "802-1x", chave)
            if valor:
                eap[nome] = valor
        dados.update(seguranca="wpa-eap", eap=eap)
    else:
        # WEP ("none") e o que esta versão não conhece ficam só aqui.
        return None
    return dados if validar(dados) else None


def _sem_viajar(kf) -> tuple[str | None, bool]:
    """Id de um perfil Wi-Fi que não viaja e se a versão da escola pode completá-lo."""
    if _valor(kf, "connection", "type") not in ("wifi", "802-11-wireless"):
        return None, False
    wifi = _grupo(kf, "wifi", "802-11-wireless")
    ssid = _ssid_do_arquivo(_valor(kf, wifi, "ssid"))
    if ssid is None or (_valor(kf, wifi, "mode") or "infrastructure") != "infrastructure":
        return None, False
    seguranca = _grupo(kf, "wifi-security", "802-11-wireless-security")
    gestao = _valor(kf, seguranca, "key-mgmt") if kf.has_group(seguranca) else None
    if gestao in ("wpa-psk", "sae"):
        return _id(ssid, "senha"), True
    if gestao in ("wpa-eap", "wpa-eap-suite-b-192"):
        metodos = [m for m in (_valor(kf, "802-1x", "eap") or "").split(";") if m]
        sem_certificado = not any(_valor(kf, "802-1x", chave) for chave in CERTIFICADOS)
        completavel = (gestao == "wpa-eap" and bool(metodos) and sem_certificado
                       and all(m in EAP_SEM_CERTIFICADO for m in metodos))
        return _id(ssid, "conta"), completavel
    # WEP e o que esta versão não conhece: para a escola é outra rede.
    return None, False


def _guardar(perfis, id_, rede):
    atual = perfis.get(id_)
    if atual is None or rede.ok_ms > atual.ok_ms:
        perfis[id_] = rede


def _tempos(caminho) -> dict:
    GLib = _glib()
    kf = GLib.KeyFile()
    try:
        kf.load_from_file(caminho, GLib.KeyFileFlags.NONE)
        chaves = kf.get_keys("timestamps")[0]
    except Exception:  # noqa: BLE001 - sem arquivo ou ilegível: ninguém conectou ainda
        return {}
    tempos = {}
    for chave in chaves:
        try:
            tempos[chave] = int(kf.get_string("timestamps", chave))
        except Exception:  # noqa: BLE001
            continue
    return tempos


def _perfis(pasta):
    """Os perfis da pasta já lidos: arquivo comum, nunca link."""
    GLib = _glib()
    try:
        nomes = sorted(os.listdir(pasta))
    except OSError:
        return
    for nome in nomes:
        if not nome.endswith(".nmconnection"):
            continue
        caminho = os.path.join(pasta, nome)
        try:
            estado = os.lstat(caminho)
        except OSError:
            continue
        if not os.path.isfile(caminho) or os.path.islink(caminho):
            continue
        kf = GLib.KeyFile()
        try:
            kf.load_from_file(caminho, GLib.KeyFileFlags.NONE)
        except Exception:  # noqa: BLE001
            continue
        yield caminho, estado, kf


def redes_locais(pasta=CONEXOES, timestamps=TIMESTAMPS) -> tuple[dict, set, dict, set]:
    """As redes que podem viajar, uma por id (com perfis repetidos, o usado por
    último); os ids das que não viajam por serem desta unidade (certificado); os
    perfis a que só falta a senha para todas as contas, que a escola completa; e o
    uuid de todos os perfis."""
    tempos = _tempos(timestamps)
    redes, presentes, incompletos, uuids = {}, set(), {}, set()
    for caminho, estado, kf in _perfis(pasta):
        uuid_ = _valor(kf, "connection", "uuid") or ""
        uuids.add(uuid_)
        dados = dados_do_perfil(kf)
        rede = RedeLocal(caminho, uuid_, dados, tempos.get(uuid_, 0) * 1000, int(estado.st_mtime * 1000))
        if dados is not None:
            _guardar(redes, rede_id(dados), rede)
            continue
        id_, completavel = _sem_viajar(kf)
        if id_ is not None and completavel:
            _guardar(incompletos, id_, rede)
        elif id_ is not None:
            presentes.add(id_)
    return redes, presentes, incompletos, uuids


def _rede_do_kf(kf) -> str | None:
    dados = dados_do_perfil(kf)
    return rede_id(dados) if dados is not None else _sem_viajar(kf)[0]


def rede_do_perfil(uuid_, pasta=CONEXOES) -> str | None:
    """Id da rede do perfil com esse uuid, viaje ele ou não."""
    for _caminho, _estado, kf in _perfis(pasta):
        if _valor(kf, "connection", "uuid") == uuid_:
            return _rede_do_kf(kf)
    return None


def _prioridade(kf) -> int:
    try:
        return int(_valor(kf, "connection", "autoconnect-priority") or 0)
    except ValueError:
        return 0


def _nmcli(*args):
    try:
        return subprocess.run(["nmcli", *args], capture_output=True, text=True, timeout=20,
                              stdin=subprocess.DEVNULL).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def _ssid_no_arquivo(ssid: bytes) -> str:
    """Como o NM grava: texto quando dá, lista de bytes quando não."""
    try:
        texto = ssid.decode("utf-8")
    except UnicodeDecodeError:
        texto = None
    if texto is not None and texto.isprintable() and ";" not in texto and not _LISTA_DE_BYTES.match(texto):
        return texto
    return "".join(f"{byte};" for byte in ssid)


def _tirar(kf, grupo, chave=None):
    try:
        if chave is None:
            kf.remove_group(grupo)
        else:
            kf.remove_key(grupo, chave)
    except Exception:  # noqa: BLE001 - já não estava lá
        pass


def gravar_local(dados, existente=None, pasta=CONEXOES, nmcli=_nmcli) -> bool:
    """Perfil novo ou o de antes com rede e senha trocadas: o resto (IP,
    prioridade, endereço físico) fica como a unidade tinha."""
    GLib = _glib()
    kf = GLib.KeyFile()
    ssid = _ssid_bytes(dados)
    if existente is not None:
        try:
            kf.load_from_file(existente.arquivo, GLib.KeyFileFlags.KEEP_COMMENTS)
        except Exception:  # noqa: BLE001
            return False
        destino = existente.arquivo
    else:
        nome = ssid.decode("utf-8", "replace")
        kf.set_string("connection", "id", nome if nome.isprintable() else "Wi-Fi")
        kf.set_string("connection", "uuid", str(uuid.uuid4()))
        kf.set_string("connection", "type", "wifi")
        kf.set_string("ipv4", "method", "auto")
        kf.set_string("ipv6", "method", "auto")
        kf.set_string("ipv6", "addr-gen-mode", "default")
        destino = os.path.join(pasta, f"celita-{rede_id(dados)}.nmconnection")
    wifi = _grupo(kf, "wifi", "802-11-wireless")
    kf.set_string(wifi, "ssid", _ssid_no_arquivo(ssid))
    kf.set_string(wifi, "mode", "infrastructure")
    if dados["oculta"]:
        kf.set_string(wifi, "hidden", "true")
    else:
        _tirar(kf, wifi, "hidden")
    for grupo in ("wifi-security", "802-11-wireless-security", "802-1x"):
        _tirar(kf, grupo)
    seguranca = dados["seguranca"]
    if seguranca == "aberta":
        _tirar(kf, wifi, "security")
    else:
        kf.set_string("wifi-security", "key-mgmt", seguranca)
    if seguranca in ("wpa-psk", "sae"):
        kf.set_string("wifi-security", "psk", dados["psk"])
    if seguranca == "wpa-eap":
        eap = dados["eap"]
        kf.set_string("802-1x", "eap", "".join(f"{m};" for m in eap["metodos"]))
        kf.set_string("802-1x", "identity", eap["identidade"])
        kf.set_string("802-1x", "password", eap["senha"])
        for chave, nome in (("phase2-auth", "fase2"), ("anonymous-identity", "anonima"),
                            ("domain-suffix-match", "dominio")):
            if nome in eap:
                kf.set_string("802-1x", chave, eap[nome])
    return _gravar_arquivo(kf, destino, nmcli)


def _gravar_arquivo(kf, destino, nmcli) -> bool:
    try:
        descritor, temporario = tempfile.mkstemp(prefix=".celita-", dir=os.path.dirname(destino))
        with os.fdopen(descritor, "w", encoding="utf-8") as arquivo:
            arquivo.write(kf.to_data()[0])
        os.chmod(temporario, 0o600)
        os.replace(temporario, destino)
    except OSError as error:
        log.warning("rede da escola não foi gravada: %s", error)
        return False
    if not nmcli("connection", "load", destino):
        log.warning("NetworkManager não leu %s", destino)
    return True


def apagar_local(rede: RedeLocal, nmcli=_nmcli) -> bool:
    if rede.uuid and nmcli("connection", "delete", "uuid", rede.uuid):
        return True
    try:
        os.unlink(rede.arquivo)
    except OSError:
        return False
    nmcli("connection", "reload")
    return True


def aplicar_preferidas(ids, pasta=CONEXOES, nmcli=_nmcli) -> int:
    """A prioridade de cada perfil pela lista da escola: a preferida sobe, a que
    deixou de ser volta a 0, e prioridade posta de outro jeito fica. Devolve
    quantos perfis mudaram."""
    GLib = _glib()
    mudados = 0
    for caminho, _estado, kf in _perfis(pasta):
        rede = _rede_do_kf(kf)
        if rede is None:
            continue
        atual = _prioridade(kf)
        quer = PRIORIDADE_PREFERIDA if rede in ids else (0 if atual == PRIORIDADE_PREFERIDA else atual)
        if quer == atual:
            continue
        completo = GLib.KeyFile()
        try:
            completo.load_from_file(caminho, GLib.KeyFileFlags.KEEP_COMMENTS)
        except Exception:  # noqa: BLE001
            continue
        if quer:
            completo.set_string("connection", "autoconnect-priority", str(quer))
        else:
            _tirar(completo, "connection", "autoconnect-priority")
        if _gravar_arquivo(completo, caminho, nmcli):
            mudados += 1
    return mudados


def assinatura(pasta=CONEXOES) -> tuple:
    """Barata a cada 5 s: nome, tamanho e hora dos perfis."""
    try:
        entradas = sorted(os.scandir(pasta), key=lambda e: e.name)
    except OSError:
        return ()
    saida = []
    for entrada in entradas:
        try:
            estado = entrada.stat(follow_symlinks=False)
        except OSError:
            continue
        saida.append((entrada.name, estado.st_size, estado.st_mtime_ns))
    return tuple(saida)


# ---- a chave da frota ------------------------------------------------------------


def _kcv_ok(kcv, chave: bytes) -> bool:
    return isinstance(kcv, str) and kcv == wifi_kcv(chave)


def _abrir_selada(key, pub, envelope) -> bytes | None:
    if not isinstance(pub, str) or not isinstance(envelope, str):
        return None
    try:
        conteudo = open_envelope(derive_wifi_wrap_key(key, pub), envelope)
        chave = b64url_decode(conteudo["k"]) if conteudo.get("v") == 1 else b""
    except Exception:  # noqa: BLE001 - envelope de outra chave ou torto
        return None
    return chave if len(chave) == 32 else None


class ChaveDaFrota:
    """32 bytes que só PC da escola e celular guardião têm. O primeiro PC a chegar
    cria (meta é gravado uma vez só, pelas rules, com o kcv que diz qual é a chave);
    os outros recebem selada de outro PC ou do celular de um professor."""

    def __init__(self, storage):
        self.storage = storage
        # A chave bate com o kcv da escola: o que não abre com ela não é da escola.
        self.conferida = False

    def local(self) -> bytes | None:
        salva = self.storage.get(STORE_CHAVE)
        if not isinstance(salva, dict) or not salva.get("confirmada"):
            return None
        try:
            chave = b64url_decode(salva["k"])
        except (KeyError, TypeError, ValueError):
            return None
        return chave if len(chave) == 32 else None

    def garantir(self, fb, identidade) -> bytes | None:
        self.conferida = False
        self._publicar(fb, identidade)
        eu = identidade["deviceId"]
        meta = fb.side_get(f"{BASE}/meta")
        chave = self.local()
        if chave is not None:
            return self._conferir(fb, eu, meta, chave)
        kcv = meta.get("kcv") if isinstance(meta, dict) else None
        chave = self._receber(fb, identidade, kcv)
        if chave is not None:
            self.storage.set(STORE_CHAVE, {"k": b64url_encode(chave), "confirmada": True})
            self.conferida = kcv is not None
            return chave
        salva = self.storage.get(STORE_CHAVE)
        if isinstance(meta, dict):
            # Criada por mim e o PC caiu antes de marcar: vale. Por outro: espera a entrega.
            if meta.get("de") == eu and isinstance(salva, dict) and salva.get("k"):
                self.storage.set(STORE_CHAVE, {**salva, "confirmada": True})
                chave = self.local()
                return None if chave is None else self._conferir(fb, eu, meta, chave)
            if isinstance(salva, dict):
                self.storage.set(STORE_CHAVE, None)
            return None
        # Guardada antes de anunciar: um PC que cai no meio não perde a chave de todos.
        if not isinstance(salva, dict) or not salva.get("k"):
            salva = {"k": b64url_encode(os.urandom(32)), "confirmada": False}
            self.storage.set(STORE_CHAVE, salva)
        try:
            fb.side_request("PUT", f"{BASE}/meta", {"de": eu, "ts": {".sv": "timestamp"},
                                                    "kcv": wifi_kcv(b64url_decode(salva["k"]))})
        except FirebaseError as error:
            if error.status in (401, 403):
                # Outro PC criou primeiro (create-once nas rules).
                self.storage.set(STORE_CHAVE, None)
                return None
            raise
        self.storage.set(STORE_CHAVE, {**salva, "confirmada": True})
        log.info("chave do Wi-Fi da escola criada nesta unidade")
        self.conferida = True
        return self.local()

    def _conferir(self, fb, eu, meta, chave) -> bytes | None:
        if not isinstance(meta, dict):
            # /school/wifi apagado no console: recomeça do zero (§9).
            self._esquecer("a escola recomeçou o Wi-Fi")
            return None
        kcv = meta.get("kcv")
        if kcv is None:
            # Meta de antes do kcv: só quem criou a chave pode dizer qual é.
            if meta.get("de") == eu:
                try:
                    fb.side_request("PUT", f"{BASE}/meta/kcv", wifi_kcv(chave))
                    log.info("kcv do Wi-Fi da escola gravado")
                except FirebaseError as error:
                    log.warning("kcv do Wi-Fi da escola não subiu: %s", error)
            return chave
        if not _kcv_ok(kcv, chave):
            self._esquecer("a chave guardada não é a da escola")
            return None
        self.conferida = True
        return chave

    def _esquecer(self, motivo):
        log.warning("chave do Wi-Fi da escola descartada: %s", motivo)
        self.storage.set(STORE_CHAVE, None)

    def _receber(self, fb, identidade, kcv) -> bytes | None:
        """De outro PC (chaves/) ou do celular de um professor (entregas/). Com
        kcv vale só a chave que bate com ele; sem kcv, só a de outro PC."""
        eu = identidade["deviceId"]
        entrega = fb.side_get(f"{BASE}/chaves/{eu}")
        if isinstance(entrega, dict):
            chave = self._abrir(fb, identidade, entrega)
            if chave is not None and (kcv is None or _kcv_ok(kcv, chave)):
                log.info("chave do Wi-Fi da escola recebida de %s", entrega.get("de"))
                return chave
            if kcv is not None:
                # Entrega que não é a chave da escola: sai, e um PC que tem a certa entrega de novo.
                try:
                    fb.side_request("DELETE", f"{BASE}/chaves/{eu}")
                except FirebaseError as error:
                    log.warning("entrega errada do Wi-Fi não saiu: %s", error)
        if kcv is None:
            return None
        guardioes = fb.side_get(f"{BASE}/entregas/{eu}")
        for _uid, item in sorted((guardioes if isinstance(guardioes, dict) else {}).items()):
            if not isinstance(item, dict):
                continue
            chave = _abrir_selada(identidade["key"], item.get("pub"), item.get("env"))
            if chave is not None and _kcv_ok(kcv, chave):
                log.info("chave do Wi-Fi da escola recebida do celular de um professor")
                return chave
        return None

    def _publicar(self, fb, identidade):
        # Confere no Firebase: /school/wifi apagado no console leva a pública junto.
        caminho = f"{BASE}/pubs/{identidade['deviceId']}"
        if fb.side_get(caminho) != identidade["pub"]:
            fb.side_request("PUT", caminho, identidade["pub"])

    def _abrir(self, fb, identidade, entrega) -> bytes | None:
        de, envelope = entrega.get("de"), entrega.get("env")
        if not isinstance(de, str) or not isinstance(envelope, str):
            return None
        return _abrir_selada(identidade["key"], fb.side_get(f"{BASE}/pubs/{de}"), envelope)

    def distribuir(self, fb, identidade, chave: bytes) -> int:
        """Sela a chave para cada PC da escola que publicou a pública e ainda não
        a tem, e para cada celular guardião que ainda não a tem."""
        pubs = fb.side_get(f"{BASE}/pubs")
        entregues = fb.side_get(f"{BASE}/chaves", {"shallow": "true"})
        guardioes = fb.side_get(f"{BASE}/guardioes")
        pubs = pubs if isinstance(pubs, dict) else {}
        entregues = entregues if isinstance(entregues, dict) else {}
        guardioes = guardioes if isinstance(guardioes, dict) else {}
        destinos = [(f"{BASE}/chaves/{device_id}", pub) for device_id, pub in sorted(pubs.items())
                    if device_id not in entregues]
        destinos += [(f"{BASE}/guardioes/{uid}/chave", g.get("pub")) for uid, g in sorted(guardioes.items())
                     if isinstance(g, dict) and "chave" not in g]
        feitas = 0
        for caminho, pub in destinos:
            if not isinstance(pub, str):
                continue
            try:
                envelope = seal(derive_wifi_wrap_key(identidade["key"], pub), {"v": 1, "k": b64url_encode(chave)})
            except (ValueError, TypeError):
                continue
            try:
                fb.side_request("PUT", caminho, {"de": identidade["deviceId"], "env": envelope})
            except Exception as error:  # noqa: BLE001 - destino que saiu da escola ou id torto
                # Sem resposta do servidor (a rede caiu) os destinos seguintes falhariam igual.
                if isinstance(error, FirebaseError) and error.status is None:
                    raise
                log.warning("entrega da chave do Wi-Fi recusada (%s): %s", caminho, error)
                continue
            feitas += 1
            if feitas >= MAX_ENTREGAS:
                break
        return feitas


# ---- a sincronização -------------------------------------------------------------


def _pode_subir(local) -> bool:
    """Rede que a escola não tem sobe depois de conectar: senha digitada errado fica aqui."""
    return bool(local.ok_ms) or CLASSE[local.dados["seguranca"]] == "aberta"


class WifiEscola:
    def __init__(self, storage, get_fb, get_identity, escola, agora_ms,
                 pasta=CONEXOES, timestamps=TIMESTAMPS, marca=MARCA, nmcli=_nmcli, monotonic=time.monotonic):
        self.storage = storage
        self.get_fb = get_fb
        self.get_identity = get_identity
        self.escola = escola
        self.agora_ms = agora_ms
        self.pasta = pasta
        self.timestamps = timestamps
        self.marca = marca
        self.nmcli = nmcli
        self.monotonic = monotonic
        self.chave = ChaveDaFrota(storage)
        self._assinatura = None
        self._proxima = None
        self._bloqueado_ate = None
        self._marcado = None
        # O pedido chega pelo socket de administração, fora do laço lateral.
        self._pedidos = threading.Lock()

    def tick(self):
        if not self.escola():
            self._marcar(False)
            return
        # PC da escola: a Central pede o "Esquecer" ao agente também sem internet e
        # antes de a chave chegar; o pedido vale na sincronização que vier.
        self._marcar(True)
        agora = self.monotonic()
        if self._bloqueado_ate is not None and agora < self._bloqueado_ate:
            return
        if assinatura(self.pasta) == self._assinatura and self._proxima is not None and agora < self._proxima:
            return
        fb = self.get_fb()
        identidade = self.get_identity()
        if fb is None or not fb.id_token or not identidade:
            return
        # Falha de qualquer tipo, também a que não é do Firebase, tenta de novo em 1 min.
        self._proxima = agora + 60
        try:
            tem_chave = self.sincronizar(fb, identidade)
        except FirebaseError as error:
            if error.status in (401, 403):
                # PC recém-pareado, antes de o app pôr no roster, ainda não tem a
                # chave: pergunta de novo em 1 min, como quem espera a entrega.
                espera = AUTH_BACKOFF_S if self.chave.local() is not None else SEM_CHAVE_S
                self._bloqueado_ate = agora + espera
                log.warning("Wi-Fi da escola negado (%s); nova tentativa em %d min", error.status, espera // 60)
            else:
                log.warning("Wi-Fi da escola: %s", error)
            return
        finally:
            # Perfil que mudou e sincronização que falhou: a próxima espera o 1 min.
            self._assinatura = assinatura(self.pasta)
        self._proxima = agora + (SYNC_S if tem_chave else SEM_CHAVE_S)

    def pedir_esquecer(self, uuid_) -> bool:
        """O "Esquecer" da Central, antes de apagar o perfil: a rede dele sai das
        outras unidades quando este perfil sumir daqui. Guardado até a
        sincronização que vê o perfil sumir, por uma semana no máximo."""
        if not isinstance(uuid_, str) or not _UUID.match(uuid_):
            return False
        rede = rede_do_perfil(uuid_, self.pasta)
        if rede is None:
            return False
        with self._pedidos:
            pedidos = self._esquecidas()
            pedidos[uuid_] = {"rede": rede, "ms": self.agora_ms()}
            mais_novos = sorted(pedidos.items(), key=lambda pedido: pedido[1]["ms"])[-MAX_REDES:]
            self.storage.set(STORE_ESQUECER, dict(mais_novos))
        log.info("rede esquecida na Central de Configurações: sai das outras unidades")
        return True

    def pedir_preferir(self, uuid_, preferida) -> bool:
        """A chave "Preferida" da Central: vale já nesta unidade e, na próxima
        sincronização, em todas as da escola. Sem internet ou sem a chave, o pedido
        espera."""
        if not isinstance(uuid_, str) or not _UUID.match(uuid_) or not isinstance(preferida, bool):
            return False
        rede = rede_do_perfil(uuid_, self.pasta)
        if rede is None:
            return False
        with self._pedidos:
            ids = set(self._preferidas())
            if preferida:
                ids.add(rede)
            else:
                ids.discard(rede)
            lista = sorted(ids)[:MAX_REDES]
            self.storage.set(STORE_PREFERIR, {"ids": lista, "ms": self.agora_ms()})
        aplicar_preferidas(lista, self.pasta, self.nmcli)
        log.info("rede %s na Central de Configurações", "preferida" if preferida else "deixou de ser preferida")
        return True

    def _preferidas(self) -> list:
        """A lista que vale aqui: o pedido da Central que ainda não subiu, ou a da escola."""
        pedido = self.storage.get(STORE_PREFERIR)
        if isinstance(pedido, dict) and isinstance(pedido.get("ids"), list):
            return pedido["ids"]
        vigente = self.storage.get(STORE_PREFERIDAS)
        return vigente["ids"] if isinstance(vigente, dict) and isinstance(vigente.get("ids"), list) else []

    def _sincronizar_preferidas(self, fb, chave, escola, ilegivel):
        """Vale a mudança mais nova: o pedido da Central daqui ou a lista da escola.
        A lista que esta versão não lê fica como está, e o pedido espera."""
        with self._pedidos:
            pedido = self.storage.get(STORE_PREFERIR)
        if not (isinstance(pedido, dict) and isinstance(pedido.get("ids"), list) and isinstance(pedido.get("ms"), int)):
            pedido = None
        subiu = False
        if pedido is not None and not ilegivel and (escola is None or pedido["ms"] > escola["ts"]):
            envelope = seal(chave, {"v": 1, "id": PREFERIDAS, "preferidas": pedido["ids"]})
            fb.side_request("PUT", f"{BASE}/redes/{PREFERIDAS}", {"env": envelope, "ts": {".sv": "timestamp"}})
            subiu = True
        with self._pedidos:
            # Pedido que chega durante a subida fica para a próxima.
            if subiu and self.storage.get(STORE_PREFERIR) == pedido:
                self.storage.set(STORE_PREFERIR, None)
                self.storage.set(STORE_PREFERIDAS, {"ids": pedido["ids"]})
            elif not subiu and escola is not None:
                if pedido is not None and self.storage.get(STORE_PREFERIR) == pedido and not ilegivel:
                    self.storage.set(STORE_PREFERIR, None)
                self.storage.set(STORE_PREFERIDAS, {"ids": escola["ids"]})
            lista = self._preferidas()
        aplicar_preferidas(lista, self.pasta, self.nmcli)

    def _esquecidas(self) -> dict:
        """Os pedidos da Central por uuid do perfil, menos os que passaram do prazo."""
        pedidos = self.storage.get(STORE_ESQUECER)
        limite = self.agora_ms() - PRAZO_ESQUECER_MS
        return {uuid_: pedido for uuid_, pedido in (pedidos if isinstance(pedidos, dict) else {}).items()
                if isinstance(pedido, dict) and isinstance(pedido.get("rede"), str)
                and isinstance(pedido.get("ms"), int) and pedido["ms"] > limite}

    def sincronizar(self, fb, identidade) -> bool:
        chave = self.chave.garantir(fb, identidade)
        if chave is None:
            return False
        escola, ilegiveis, preferidas = self._baixar(fb, chave, self.chave.conferida)
        # Pedido que chega durante a leitura dos perfis só é respondido depois dela:
        # o perfil dele some depois e fica para a próxima vez.
        with self._pedidos:
            pedidos = self._esquecidas()
            locais, presentes, incompletos, uuids = redes_locais(self.pasta, self.timestamps)
        # Vale o perfil que a Central esqueceu: outro perfil da mesma rede que ficou não segura o pedido.
        esquecidas = {}
        for uuid_, pedido in pedidos.items():
            if uuid_ not in uuids:
                esquecidas[pedido["rede"]] = max(esquecidas.get(pedido["rede"], 0), pedido["ms"])
        registro = dict(self.storage.get(STORE_REGISTRO) or {})
        # Horas do NM e dos arquivos no relógio do servidor, o mesmo do `ts` da escola.
        desvio = self.agora_ms() - int(time.time() * 1000)
        for local in [*locais.values(), *incompletos.values()]:
            # O NM guarda a hora por perfil, não por senha, e grava a senha digitada
            # antes de testar: só conta a conexão depois da última gravação do perfil.
            conectou = local.ok_ms > 0 and local.ok_ms // 1000 >= local.mtime_ms // 1000
            local.mtime_ms += desvio
            local.ok_ms = local.ok_ms + desvio if conectou else 0
        if ilegiveis:
            log.warning("%d rede(s) da escola que esta versão não lê ficam como estão", len(ilegiveis))
        for rede in sorted((set(escola) | set(locais)) - ilegiveis)[:MAX_REDES]:
            novo = self._decidir(fb, chave, rede, escola.get(rede), locais.get(rede), registro.get(rede),
                                 presentes, incompletos.get(rede), esquecidas.get(rede))
            if novo is not None:
                registro[rede] = novo
        self.storage.set(STORE_REGISTRO, registro)
        self._fechar_pedidos(pedidos, uuids, ilegiveis)
        self._sincronizar_preferidas(fb, chave, preferidas, PREFERIDAS in ilegiveis)
        self.chave.distribuir(fb, identidade, chave)
        return True

    def _fechar_pedidos(self, vistos, uuids, ilegiveis):
        """Pedido cujo perfil sumiu já valeu, menos o de rede que esta versão não lê
        na escola, que espera; o de perfil que continua aqui perde a validade em 10 min."""
        agora = self.agora_ms()
        with self._pedidos:
            pedidos = self._esquecidas()
            for uuid_, pedido in vistos.items():
                if pedidos.get(uuid_) != pedido:
                    continue
                if uuid_ in uuids:
                    if agora - pedido["ms"] > ESPERA_ESQUECER_MS:
                        del pedidos[uuid_]
                elif pedido["rede"] not in ilegiveis:
                    del pedidos[uuid_]
            if pedidos != (self.storage.get(STORE_ESQUECER) or {}):
                self.storage.set(STORE_ESQUECER, pedidos or None)

    def _decidir(self, fb, chave, rede, escola, local, registro, presentes, incompleto, esquecida):
        """Uma rede: sobe, aplica, apaga ou deixa como está. Devolve o registro novo."""
        agora = self.agora_ms()
        if escola is None:
            if local is None:
                return None
            # A que já veio da escola (recomeço pelo console) volta para ela sem esperar conectar.
            if not _pode_subir(local) and (registro or {}).get("h") != resumo(local.dados):
                return registro
            self._subir(fb, chave, rede, local.dados, local.ok_ms)
            return {"h": resumo(local.dados), "ts": agora}
        if escola["apagada"]:
            if local is None:
                return {"h": None, "ts": escola["ts"]}
            # Regravada sem mudar o que viaja ("Conectar automaticamente", o NM
            # completando o arquivo) não é salva de novo: o "Esquecer" vale.
            if local.mtime_ms <= escola["ts"] or (registro or {}).get("h") == resumo(local.dados):
                apagar_local(local, self.nmcli)
                return {"h": None, "ts": escola["ts"]}
            # Salva de novo depois de esquecida: volta para todas, também depois de conectar.
            if not _pode_subir(local):
                return registro
            self._subir(fb, chave, rede, local.dados, local.ok_ms)
            return {"h": resumo(local.dados), "ts": agora}
        h_escola = resumo(escola["dados"])
        if local is None:
            # Esquecida na Central: sai das outras mesmo que sobre aqui outro perfil
            # dela (sem a senha, com certificado), e esse não é completado. Versão
            # salva em outra unidade depois do pedido (que ficou guardado sem internet) vence.
            if esquecida is not None and (escola["ts"] <= esquecida or (registro or {}).get("h") == h_escola):
                self._subir_apagada(fb, chave, rede)
                log.info("rede esquecida nesta unidade: some das outras também")
                return {"h": None, "ts": agora}
            # Perfil da mesma rede sem a senha para todas as contas (pedido de senha
            # cancelado, chaveiro): a da escola completa o mesmo perfil.
            if incompleto is not None:
                if gravar_local(escola["dados"], incompleto, self.pasta, self.nmcli):
                    return {"h": h_escola, "ts": escola["ts"]}
                return registro
            # Com certificado desta unidade: não é rede esquecida, nem pede um segundo perfil.
            if rede in presentes:
                return registro
            # Sumiu sem o "Esquecer" da Central (login que falhou, nmcli): volta.
            if gravar_local(escola["dados"], None, self.pasta, self.nmcli):
                return {"h": h_escola, "ts": escola["ts"]}
            return registro
        h_local = resumo(local.dados)
        if h_local == h_escola:
            # A da escola nunca conectou (subiu de quem só a recebeu, no recomeço):
            # sem o ok daqui, a senha errada noutra unidade não voltaria à dela.
            if escola["ok"] == 0 and local.ok_ms > 0:
                self._subir(fb, chave, rede, local.dados, local.ok_ms)
                return {"h": h_local, "ts": agora}
            return {"h": h_escola, "ts": max(escola["ts"], (registro or {}).get("ts") or 0)}
        mudou_aqui = registro is None or registro.get("h") != h_local
        mudou_la = registro is None or registro.get("h") != h_escola
        if not mudou_aqui:
            subir = False
        elif not mudou_la:
            # Senha nova sobe depois de conectar com ela; a que não conecta fica um
            # tempo (pode ser a senha nova da rede) e depois volta a da escola.
            if local.ok_ms:
                subir = local.ok_ms > escola["ok"] or escola["ok"] == 0
                if not subir:
                    return registro
            elif escola["ok"] and agora - local.mtime_ms > ESPERA_CONECTAR_MS:
                subir = False
            else:
                return registro
        elif local.ok_ms != escola["ok"]:
            subir = local.ok_ms > escola["ok"]
        else:
            subir = local.mtime_ms > escola["ts"]
        if subir:
            self._subir(fb, chave, rede, local.dados, local.ok_ms)
            return {"h": h_local, "ts": agora}
        if gravar_local(escola["dados"], local, self.pasta, self.nmcli):
            return {"h": h_escola, "ts": escola["ts"]}
        return registro

    def _baixar(self, fb, chave, conferida) -> tuple[dict, set, dict | None]:
        """As redes da escola, os ids que existem mas esta unidade não lê (formato
        novo; sem o kcv, também outra chave), que ela não sobrescreve, e a lista de
        preferidas."""
        no = fb.side_get(f"{BASE}/redes")
        redes, ilegiveis, preferidas = {}, set(), None
        for rede, item in (no if isinstance(no, dict) else {}).items():
            if not isinstance(item, dict) or not isinstance(item.get("ts"), (int, float)):
                ilegiveis.add(rede)
                continue
            try:
                conteudo = open_envelope(chave, item.get("env"))
            except Exception:  # noqa: BLE001 - envelope torto ou de outra chave
                # Com o kcv, o que não abre é de uma chave que não é a da escola
                # (PC de antes do recomeço): vale como rede que a escola não tem.
                if not conferida:
                    ilegiveis.add(rede)
                continue
            if not isinstance(conteudo, dict) or conteudo.get("v") != 1 or conteudo.get("id") != rede:
                ilegiveis.add(rede)
                continue
            if rede == PREFERIDAS:
                ids = conteudo.get("preferidas")
                if isinstance(ids, list) and all(isinstance(i, str) and _ID.match(i) for i in ids):
                    preferidas = {"ids": sorted(set(ids))[:MAX_REDES], "ts": int(item["ts"])}
                else:
                    ilegiveis.add(rede)
                continue
            if conteudo.get("apagada") is True:
                redes[rede] = {"apagada": True, "ts": int(item["ts"])}
                continue
            dados, ok = conteudo.get("dados"), conteudo.get("ok")
            if not validar(dados) or rede_id(dados) != rede or not isinstance(ok, int) or isinstance(ok, bool):
                ilegiveis.add(rede)
                continue
            redes[rede] = {"apagada": False, "dados": dados, "ok": ok, "ts": int(item["ts"])}
        return redes, ilegiveis, preferidas

    def _subir(self, fb, chave, rede, dados, ok_ms):
        envelope = seal(chave, {"v": 1, "id": rede, "dados": dados, "ok": int(ok_ms)})
        fb.side_request("PUT", f"{BASE}/redes/{rede}", {"env": envelope, "ts": {".sv": "timestamp"}})

    def _subir_apagada(self, fb, chave, rede):
        envelope = seal(chave, {"v": 1, "id": rede, "apagada": True})
        fb.side_request("PUT", f"{BASE}/redes/{rede}", {"env": envelope, "ts": {".sv": "timestamp"}})

    def _marcar(self, ligado: bool):
        if ligado == self._marcado:
            return
        try:
            if ligado:
                with open(self.marca, "w", encoding="ascii") as arquivo:
                    arquivo.write("1\n")
                os.chmod(self.marca, 0o644)
            else:
                os.unlink(self.marca)
        except FileNotFoundError:
            pass
        except OSError as error:
            log.warning("marca do Wi-Fi da escola: %s", error)
            return
        self._marcado = ligado
