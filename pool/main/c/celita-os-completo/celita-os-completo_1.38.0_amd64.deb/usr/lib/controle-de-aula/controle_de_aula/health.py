"""Saúde da frota: o health_report em /devices/{id}/health (docs/protocolo.md §3).

O PC publica o que pede manutenção (firmware, atualização, bateria, disco,
eMMC e rede com senha errada) num envelope que repousa no banco, para o app
listar a frota mesmo com o PC desligado. Confere a cada 15 minutos e grava
quando o conteúdo muda, quando o vínculo muda ou a cada 24 horas. Nunca URL,
título ou conta: só o estado da máquina.
"""

import json
import logging
import threading
import time

from . import protocol
from .firebase import FirebaseError

log = logging.getLogger("controle-de-aula.health")

CHECK_S = 15 * 60
REFRESH_S = 24 * 60 * 60
# Rules antigas (sem health) negam a gravação: tenta de novo em 1 h.
DENIED_S = 60 * 60
UPDATE_STATES = ("erro", "verificando", "baixando", "baixado", "atualizado", "instalando")
STORAGE_WEAR = ("normal", "aviso", "urgente")
SHUTDOWN = {"limpo": "clean", "abrupto": "abrupt"}


def _number(value, low, high):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not low <= value <= high:
        return None
    return value


def _text(value, limit: int) -> str | None:
    if not isinstance(value, str):
        return None
    return value.strip()[:limit] or None


def _volume(raw) -> dict | None:
    if not isinstance(raw, dict):
        return None
    free, total = _number(raw.get("livre_gb"), 0, 1e6), _number(raw.get("total_gb"), 0, 1e6)
    return None if free is None or total is None else {"freeGb": free, "totalGb": total}


def build_payload(raw: dict) -> dict:
    """Leituras cruas do Diagnostico.saude_da_maquina → payload do protocolo."""
    update = raw.get("atualizacao") if isinstance(raw.get("atualizacao"), dict) else {}
    battery = raw.get("bateria") if isinstance(raw.get("bateria"), dict) else {}
    disk = raw.get("disco") if isinstance(raw.get("disco"), dict) else {}
    wear = (raw.get("emmc") or {}).get("fim_de_vida") if isinstance(raw.get("emmc"), dict) else None
    networks = raw.get("wifi_recusado") if isinstance(raw.get("wifi_recusado"), list) else []
    fields = {
        "firmware": _text(raw.get("bios"), protocol.MAX_HEALTH_FIRMWARE),
        "model": _text(raw.get("modelo"), protocol.MAX_HEALTH_MODEL),
        "update": {
            "state": update.get("estado") if update.get("estado") in UPDATE_STATES else None,
            "reboot": True if update.get("reiniciar") == "sim" else None,
        },
        "lastShutdown": SHUTDOWN.get(raw.get("fim_anterior")),
        "battery": {
            "health": _number(battery.get("saude"), 0, 100),
            "cycles": _number(battery.get("ciclos"), 0, 100000),
        },
        "disk": {"root": _volume(disk.get("raiz")), "home": _volume(disk.get("home"))},
        "storageWear": wear if wear in STORAGE_WEAR else None,
        "wifi": [{"ssid": ssid, "reason": "wrong_key"}
                 for ssid in (_text(n, protocol.MAX_HEALTH_SSID) for n in networks) if ssid
                 ][:protocol.MAX_HEALTH_WIFI],
    }
    return {"v": protocol.PROTOCOL_VERSION, "type": protocol.HEALTH_REPORT, **_compact(fields)}


def _compact(value):
    if not isinstance(value, dict):
        return value
    compacted = {key: _compact(item) for key, item in value.items()}
    return {key: item for key, item in compacted.items() if item not in (None, {}, [])}


def _in_thread(target):
    def run():
        try:
            target()
        except Exception as error:  # noqa: BLE001 - a próxima conferência tenta de novo
            log.warning("saúde: %s", error)
    threading.Thread(target=run, name="health", daemon=True).start()


class HealthReporter:
    def __init__(self, collect, monotonic=time.monotonic, spawn=_in_thread):
        self._collect = collect
        self._monotonic = monotonic
        self._spawn = spawn
        self._lock = threading.Lock()
        self._busy = False
        self._next = 0.0
        self._sent = None
        self._sent_at = 0.0

    def tick(self, client):
        """Chamado pelo laço lateral; `client` é o CloudClient vigente ou None."""
        if client is None or not client.running:
            return
        now = self._monotonic()
        with self._lock:
            if self._busy or now < self._next:
                return
            self._busy = True
        self._spawn(lambda: self._publish(client, now))

    def _publish(self, client, now: float):
        wait = CHECK_S
        try:
            payload = build_payload(self._collect())
            # O sid entra na conta: vínculo novo tem chave nova, e o envelope
            # antigo o professor novo não abre.
            current = (client.sid, json.dumps(payload, sort_keys=True))
            if current != self._sent or now - self._sent_at >= REFRESH_S:
                client.put_health(payload)
                self._sent, self._sent_at = current, now
        except FirebaseError as error:
            if error.status in (401, 403):
                wait = DENIED_S
                log.warning("saúde negada pelas rules; nova tentativa em 1 h")
            else:
                log.info("saúde não subiu: %s", error)
        finally:
            with self._lock:
                self._busy = False
                self._next = now + wait
