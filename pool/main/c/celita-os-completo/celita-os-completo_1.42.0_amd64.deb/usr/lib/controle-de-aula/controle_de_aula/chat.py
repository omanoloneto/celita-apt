"""Chat do aluno no Celita: histórico no agente e o socket da janela.

O histórico vive aqui, em memória, por Session.key (≤ 100 itens), e não na
janela: fechar a janela não perde nada, e logout, troca de sessão, fim de aula
ou reinício do agente apagam tudo. A janela `chat-aluno` é só uma vista que
fala com o agente por `/run/controle-de-aula/aluno.sock`, uma mensagem JSON
por linha; só o uid da sessão controlada ativa é atendido.
"""

import logging
import queue
import threading
import time

from . import protocol, up

log = logging.getLogger("controle-de-aula.chat")

ALUNO_SOCKET_PATH = "/run/controle-de-aula/aluno.sock"
ALUNO_MAX_MESSAGE = 4096
CHAT_UNIT = "controle-de-aula-chat"
CHAT_BIN = "/usr/lib/controle-de-aula/chat-aluno"
ABRIR_INTERVALO_S = 5
# Envios esperando a rede; além disso a janela recebe "falhou" na hora.
FILA_MAX = 32
TEXTO_SEM_ENVIO = "Não foi possível enviar agora. Tente de novo."
TEXTO_SEM_NOME = "Antes de escrever, diga seu nome e seu ano."
TEXTO_SEM_PARA = "Escolha para quem mandar a mensagem."
EQUIPE_RELER_S = 60


def ler_equipe(raw, agora_ms: int, com_monitoras: bool) -> list:
    """/school/equipe → [{id, nome, papel, online}], online primeiro."""
    itens = []
    for uid, valor in (raw if isinstance(raw, dict) else {}).items():
        if not isinstance(uid, str) or not up.UID_RE.match(uid) or not isinstance(valor, dict):
            continue
        nome = up.limpar_linha(valor.get("nome"), protocol.MAX_CHAT_DE)
        papel = valor.get("papel")
        if not nome or papel not in protocol.EQUIPE_PAPEIS or (papel == "monitora" and not com_monitoras):
            continue
        visto = valor.get("visto")
        online = isinstance(visto, (int, float)) and not isinstance(visto, bool) and \
            0 <= agora_ms - visto < protocol.EQUIPE_ONLINE_MS
        itens.append({"id": uid, "nome": nome, "papel": papel, "online": online})
    itens.sort(key=lambda i: (not i["online"], i["nome"].casefold()))
    return itens[: protocol.MAX_EQUIPE]


def hora(ms) -> str:
    try:
        return time.strftime("%H:%M", time.localtime(float(ms) / 1000))
    except (TypeError, ValueError, OverflowError, OSError):
        return ""


def texto_recusa(site: str, motivo: str | None) -> str:
    texto = f"Pedido para abrir {site} não foi liberado."
    if not motivo:
        return texto
    motivo = motivo.strip()
    final = "" if motivo.endswith((".", "!", "?", "…")) else "."
    return f"{texto} Motivo: {motivo}{final}"


def texto_liberado(site: str) -> str:
    return f"O professor liberou {site}."


class Historico:
    """Itens {id, autor: professor|aluno|sistema, de?, texto, ts, estado?}."""

    def __init__(self, limite: int = protocol.CHAT_HISTORICO_PC):
        self.limite = limite
        self._chave = None
        self._itens = []
        self._lock = threading.Lock()

    def _da_sessao(self, chave):
        if chave != self._chave:
            self._chave = chave
            self._itens = []

    def itens(self, chave) -> list:
        with self._lock:
            self._da_sessao(chave)
            return [dict(item) for item in self._itens]

    def adicionar(self, chave, item: dict) -> dict | None:
        """Devolve o item, ou None se o id já existe (reentrega)."""
        with self._lock:
            self._da_sessao(chave)
            if any(i["id"] == item["id"] for i in self._itens):
                return None
            self._itens.append(dict(item))
            del self._itens[: max(0, len(self._itens) - self.limite)]
            return dict(item)

    def achar(self, chave, item_id) -> dict | None:
        with self._lock:
            self._da_sessao(chave)
            for item in self._itens:
                if item["id"] == item_id:
                    return dict(item)
        return None

    def marcar(self, chave, item_id, estado: str):
        with self._lock:
            self._da_sessao(chave)
            for item in self._itens:
                if item["id"] == item_id:
                    item["estado"] = estado

    def ultimo_de(self, chave) -> str | None:
        with self._lock:
            self._da_sessao(chave)
            for item in reversed(self._itens):
                if item["autor"] == "professor" and item.get("de"):
                    return item["de"]
        return None

    def limpar(self):
        with self._lock:
            self._itens = []


class ChatAluno:
    """Lado do agente da janela de chat. Dependências injetadas:

    - `sessions.active()` → sessão controlada ativa ou None;
    - `enviar_up(session, tipo, payload, mid)` → (ok, erro, aviso): o ponto
      único de saída, com limites;
    - `travado()`, `conectado()`, `nome_padrao()`;
    - `abrir(session)`: sobe a janela (serviço transitório, `--sem-foco`);
    - `aluno_da_chamada()` → {nome, ano} que o professor mandou, ou None;
    - `buscar_equipe()` → /school/equipe cru (lança em erro de rede);
    - `monitoras_ok()`: o canal da monitora está ligado neste PC;
    - `enviar_mon(tipo, payload, mid)` → (ok, erro): cópia em mon/up;
    - `fotografar(session, mid)`: foto do rosto para auditoria, nunca exibida.
    """

    def __init__(self, sessions, enviar_up, travado, conectado, nome_padrao, abrir, agora_ms=None,
                 monotonic=time.monotonic, aluno_da_chamada=lambda: None, buscar_equipe=lambda: {},
                 monitoras_ok=lambda: False, enviar_mon=lambda *_a: (False, "sem_chave"),
                 fotografar=lambda *_a: None):
        self.sessions = sessions
        self.enviar_up = enviar_up
        self.travado = travado
        self.conectado = conectado
        self.nome_padrao = nome_padrao
        self.abrir_janela = abrir
        self.agora_ms = agora_ms or (lambda: int(time.time() * 1000))
        self.monotonic = monotonic
        self.server = None  # BridgeServer do aluno.sock, ligado pelo agente
        self.historico = Historico()
        self._abrir_pendente = False
        self._aberto_em = None
        # Chave da sessão que pediu janela dentro do intervalo entre aberturas:
        # o tique do agente abre quando o intervalo passar.
        self._reabrir = None
        self._ultima_conexao = None
        self._fila = queue.Queue(maxsize=FILA_MAX)
        self._worker = None
        self._worker_lock = threading.Lock()
        self._mao_em = {}
        self.aluno_da_chamada = aluno_da_chamada
        self.buscar_equipe = buscar_equipe
        self.monitoras_ok = monitoras_ok
        self.enviar_mon = enviar_mon
        self.fotografar = fotografar
        self._identidade = {}
        self.equipe = []
        self._equipe_em = None
        self._equipe_pedida = False

    # ---- janela conectada ------------------------------------------------------------

    def _cliente(self, session=None):
        session = session or self.sessions.active()
        if session is None or self.server is None:
            return None
        return self.server.client_for_uid(session.uid)

    def _enviar_janela(self, message: dict, session=None) -> bool:
        client = self._cliente(session)
        return bool(client and client.send(message))

    def nome(self, session) -> str:
        return self.historico.ultimo_de(session.key) or self.nome_padrao() or "Professor"

    def _abrir(self, session):
        if self.travado():
            self._abrir_pendente = True
            return
        if self._cliente(session) is not None:
            self._reabrir = None
            return
        now = self.monotonic()
        if self._aberto_em is not None and now - self._aberto_em < ABRIR_INTERVALO_S:
            # A janela acabou de subir (ainda conectando) ou o aluno a fechou
            # agora: confere de novo depois do intervalo, para a mensagem nova
            # não ficar sem janela.
            self._reabrir = session.key
            return
        self._aberto_em = now
        self._abrir_pendente = False
        self._reabrir = None
        try:
            self.abrir_janela(session)
        except Exception as error:  # noqa: BLE001
            log.warning("janela de chat não abriu: %s", error)

    def identidade(self, session) -> tuple:
        """({nome, ano} | None, fixo): a da chamada vale mais que a digitada."""
        da_chamada = self.aluno_da_chamada()
        if da_chamada:
            return da_chamada, True
        return self._identidade.get(session.key), False

    def _mensagem_aluno(self, session) -> dict:
        ident, fixo = self.identidade(session)
        return {"t": "aluno", "nome": (ident or {}).get("nome"), "ano": (ident or {}).get("ano"), "fixo": fixo}

    def aluno_mudou(self):
        session = self.sessions.active()
        if session is not None:
            self._enviar_janela(self._mensagem_aluno(session), session)

    def _pedir_equipe(self, forcar=False):
        if self._equipe_pedida:
            return
        if not forcar and self._equipe_em is not None and self.monotonic() - self._equipe_em < EQUIPE_RELER_S:
            return
        self._equipe_pedida = True
        self._agendar(None, "equipe", None, None)

    def _atualizar_equipe(self):
        try:
            raw = self.buscar_equipe()
        except Exception as error:  # noqa: BLE001 - fica a lista anterior
            log.info("equipe não veio: %s", error)
            return
        finally:
            self._equipe_pedida = False
            self._equipe_em = self.monotonic()
        nova = ler_equipe(raw, self.agora_ms(), self.monitoras_ok())
        if nova != self.equipe:
            self.equipe = nova
            self._enviar_janela({"t": "equipe", "itens": nova})

    def _da_equipe(self, uid) -> dict | None:
        return next((i for i in self.equipe if i["id"] == uid), None)

    def tick(self):
        """Tique do agente (2 s): abre a janela adiada pelo intervalo e relê a
        equipe enquanto a janela está aberta."""
        if self._cliente() is not None:
            self._pedir_equipe()
        chave = self._reabrir
        if chave is None:
            return
        session = self.sessions.active()
        if session is None or session.key != chave:
            self._reabrir = None
            return
        if self._aberto_em is not None and self.monotonic() - self._aberto_em < ABRIR_INTERVALO_S:
            return
        self._abrir(session)

    def _da_sessao_ativa(self, session) -> bool:
        atual = self.sessions.active()
        return atual is not None and atual.key == session.key

    # ---- eventos do agente ---------------------------------------------------------------

    def mensagem_professor(self, session, texto: str, de: str | None, mid: str, ts=None):
        item = {"id": mid, "autor": "professor", "texto": texto,
                "ts": int(ts) if isinstance(ts, (int, float)) and not isinstance(ts, bool) else self.agora_ms()}
        if de:
            item["de"] = de
        novo = self.historico.adicionar(session.key, item)
        if novo is None:
            return
        self._enviar_janela({"t": "chat", "item": novo}, session)
        self._abrir(session)

    def sistema(self, session, texto: str, abrir: bool = False):
        item = self.historico.adicionar(session.key, {"id": up.new_id(), "autor": "sistema", "texto": texto,
                                                     "ts": self.agora_ms()})
        if item is not None:
            self._enviar_janela({"t": "chat", "item": item}, session)
        if abrir:
            self._abrir(session)

    def fim_de_aula(self):
        self.historico.limpar()
        self._abrir_pendente = False
        self._reabrir = None
        self._mao_em = {}
        self._identidade = {}
        if self.server is not None:
            self.server.broadcast({"t": "fechar"})

    def estado_conexao(self, conectado: bool):
        if conectado == self._ultima_conexao:
            return
        self._ultima_conexao = conectado
        self._enviar_janela({"t": "conexao", "conectado": conectado})

    def trava(self, on: bool):
        session = self.sessions.active()
        if session is None:
            return
        self._enviar_janela({"t": "trava", "on": on}, session)
        if not on and self._abrir_pendente:
            self._abrir_pendente = False
            self._abrir(session)

    # ---- mensagens da janela (thread do socket) -------------------------------------------

    def on_message(self, client, message: dict):
        session = self.sessions.active()
        if session is None or client.uid != session.uid:
            client.close()
            return
        kind = message.get("t")
        if kind == "hello":
            levantada = self._mao_recente(session)
            client.send({"t": "historico", "de": self.nome(session), "itens": self.historico.itens(session.key)})
            client.send({"t": "conexao", "conectado": bool(self.conectado())})
            client.send({"t": "trava", "on": bool(self.travado())})
            client.send({"t": "mao", "levantada": levantada})
            client.send(self._mensagem_aluno(session))
            client.send({"t": "equipe", "itens": self.equipe})
            self._pedir_equipe(forcar=True)
        elif kind == "identificar":
            _ident, fixo = self.identidade(session)
            nome = up.limpar_linha(message.get("nome"), protocol.MAX_CHAT_NOME)
            if not fixo and len(nome) >= 2 and up.ano_valido(message.get("ano")):
                self._identidade[session.key] = {"nome": nome, "ano": message["ano"]}
            client.send(self._mensagem_aluno(session))
        elif kind == "chat":
            item_id = message.get("id")
            ident, _fixo = self.identidade(session)
            para = self._da_equipe(message.get("para"))
            if not ident:
                client.send({"t": "aviso", "texto": TEXTO_SEM_NOME})
                return
            if para is None:
                client.send({"t": "aviso", "texto": TEXTO_SEM_PARA})
                return
            payload = up.limpar_payload(protocol.UP_CHAT, {"texto": message.get("texto"), "para": para["id"],
                                                           "nome": ident["nome"], "ano": ident["ano"]})
            if not up.id_valido(item_id) or payload is None:
                return
            item = self.historico.adicionar(session.key, {
                "id": item_id, "autor": "aluno", "texto": payload["texto"], "ts": self.agora_ms(),
                "estado": "enviando", "para": para["id"], "paraNome": para["nome"], "paraPapel": para["papel"],
                "nome": ident["nome"], "ano": ident["ano"]})
            if item is not None:
                self._agendar(session, protocol.UP_CHAT, payload, item_id)
        elif kind == "reenviar":
            item = self.historico.achar(session.key, message.get("id"))
            if item and item["autor"] == "aluno" and item.get("estado") == "falhou":
                self.historico.marcar(session.key, item["id"], "enviando")
                client.send({"t": "estado-msg", "id": item["id"], "estado": "enviando"})
                payload = {k: item[k] for k in ("texto", "para", "nome", "ano") if item.get(k) is not None}
                self._agendar(session, protocol.UP_CHAT, payload, item["id"])
        elif kind == "mao":
            self._agendar(session, protocol.UP_HAND, {}, up.new_id())

    def _mao_recente(self, session) -> bool:
        levantada_em = self._mao_em.get(session.key)
        return levantada_em is not None and self.monotonic() - levantada_em < 10

    # ---- envio (uma thread, na ordem) -----------------------------------------------------

    def _agendar(self, session, tipo, payload, mid):
        with self._worker_lock:
            if self._worker is None:
                self._worker = threading.Thread(target=self._trabalhar, name="chat-up", daemon=True)
                self._worker.start()
        try:
            self._fila.put_nowait((session, tipo, payload, mid))
        except queue.Full:
            # Janela inundando o socket: não acumula, responde já.
            if tipo == protocol.UP_CHAT:
                self.historico.marcar(session.key, mid, "falhou")
                self._enviar_janela({"t": "estado-msg", "id": mid, "estado": "falhou"}, session)

    def _trabalhar(self):
        while True:
            session, tipo, payload, mid = self._fila.get()
            try:
                if tipo == "equipe":
                    self._atualizar_equipe()
                else:
                    self._enviar(session, tipo, payload, mid)
            except Exception as error:  # noqa: BLE001 - a fila nunca morre
                log.warning("envio do chat falhou: %s", error)
            finally:
                self._fila.task_done()

    def drenar(self):
        """Espera os envios agendados terminarem (testes)."""
        self._fila.join()

    def _enviar(self, session, tipo, payload, mid):
        if tipo == protocol.UP_CHAT and payload.get("para"):
            try:
                self.fotografar(session, mid)
            except Exception as error:  # noqa: BLE001 - sem foto, a mensagem vai mesmo assim
                log.warning("foto do chat falhou: %s", error)
        para = self._da_equipe(payload.get("para")) if tipo == protocol.UP_CHAT else None
        ok, erro, aviso = self.enviar_up(session, tipo, payload, mid)
        if ok and para and para["papel"] == "monitora":
            mon_ok, mon_erro = self.enviar_mon(tipo, payload, mid)
            if not mon_ok:
                log.info("cópia para a monitora não subiu: %s", mon_erro)
        if not self._da_sessao_ativa(session):
            # A sessão acabou com o envio em voo: o resultado não pode apagar
            # nem sujar a conversa da sessão nova (o histórico é por sessão).
            return
        if tipo == protocol.UP_CHAT:
            self.historico.marcar(session.key, mid, "enviada" if ok else "falhou")
            self._enviar_janela({"t": "estado-msg", "id": mid, "estado": "enviada" if ok else "falhou"}, session)
            if not ok:
                self._enviar_janela({"t": "aviso", "texto": aviso or TEXTO_SEM_ENVIO}, session)
            return
        if tipo == protocol.UP_HAND:
            if ok:
                self._mao_em = {session.key: self.monotonic()}
                self.sistema(session, f"Você levantou a mão às {hora(self.agora_ms())}")
                self._enviar_janela({"t": "mao", "levantada": True}, session)
            elif erro == "limite":
                self._enviar_janela({"t": "mao", "levantada": True}, session)
            else:
                self._enviar_janela({"t": "mao", "levantada": False}, session)
                self._enviar_janela({"t": "aviso", "texto": aviso or TEXTO_SEM_ENVIO}, session)
