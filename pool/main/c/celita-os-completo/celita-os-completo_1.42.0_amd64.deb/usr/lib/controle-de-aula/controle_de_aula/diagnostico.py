"""Diagnóstico de Wi-Fi e da tampa (pedido de 2026-10-29), ligado pelo app por
algumas horas. A cada minuto o PC registra o Wi-Fi em uso, as redes à volta, a
tampa, a bateria e o diário do NetworkManager, do celita-rede-forte, da tampa,
do logind e do kernel, e sobe para /diag/{deviceId}/{sessão}, que nenhum
cliente lê: só o console do Firebase. O prazo vale entre reinícios (o teste é
fechar a tampa ao ligar), e sem internet os registros esperam numa fila,
porque é quando o Wi-Fi falha que eles importam. Formato em docs/protocolo.md.

A internet veio depois ("o sinal é bom, só a internet é ruim"): o tempo até
sites conhecidos, o ping do roteador e de fora, a velocidade a cada 15 minutos,
o enlace do Wi-Fi, o tráfego e a carga do PC, e o tempo das páginas que o
navegador abriu, que a extensão manda pela ponte enquanto a gravação vale.

Depois, bateria, saúde do PC e uso (pedido de 2026-11-05): o consumo em watts,
o brilho e o sono a cada minuto; a cada hora, a saúde da bateria, o disco, o
desgaste do eMMC, os programas que travaram e o estado do celita-update; e o
programa em foco com o host das abas ativas. Nunca URL, título ou conta.

Para fechar a conta de quem gasta o hardware (pedido de 2026-11-09), o minuto
leva também a CPU por modo (usuário, sistema e espera de E/S), os cinco
processos que mais gastaram CPU fora os do desenho, o que cada disco leu e
gravou, e a GPU: quanto do minuto ela passou acordada e se o navegador está
desenhando por software.
"""

import glob
import json
import logging
import os
import re
import subprocess
import threading
import time

from . import protocol
from .firebase import FirebaseError
from .session import celita_version

log = logging.getLogger("controle-de-aula.diagnostico")

CHAVE = "diagnostico"
INTERVALO_MS = 60 * 1000
FILA_MAX = 240
SUBIDAS_POR_VEZ = 30
MAX_LINHAS = 400
MAX_LINHA = 300
MAX_REGISTRO = 60000
MAX_REDES = 15
LINHAS_BOOT_ANTERIOR = 80
JANELA_INICIAL = "-30min"
TIMEOUT_S = 20
VELOCIDADE_MS = 15 * 60 * 1000
MAX_NAV = 200
# meta/diag recusado (rules antigas) ou sem rede: tenta de novo em 10 min.
PRAZO_RETENTAR_MS = 10 * 60 * 1000
MAX_NAV_MS = 600000
SAUDE_MS = 60 * 60 * 1000
MAX_TRAVAMENTOS = 20
MAX_ABAS = 5
ATUALIZACAO = ("ESTADO", "MENSAGEM", "VERSAO_INSTALADA", "VERSAO_DISPONIVEL", "ULTIMA_VERIFICACAO",
               "ULTIMA_ATUALIZACAO")

SONDAS = (
    ("portal", "http://connectivitycheck.gstatic.com/generate_204"),
    ("google", "https://www.google.com/"),
    ("youtube", "https://www.youtube.com/"),
    ("docs", "https://docs.google.com/"),
)
CURL = ["curl", "-s", "--connect-timeout", "5", "--max-time", "8"]
BAIXAR = "https://speed.cloudflare.com/__down?bytes=5000000"
SUBIR = "https://speed.cloudflare.com/__up"
SUBIR_BYTES = 1_000_000
INTERNET = "1.1.1.1"
ENLACE = {"signal": "sinal", "signal avg": "sinal_medio", "beacon signal avg": "sinal_beacon",
          "tx bitrate": "tx", "rx bitrate": "rx", "tx retries": "tx_repetidos", "tx failed": "tx_falhos",
          "beacon loss": "beacons_perdidos", "expected throughput": "vazao_esperada",
          "connected time": "conectado"}
IPV4 = re.compile(r"\d{1,3}(\.\d{1,3}){3}")
DISPOSITIVO = re.compile(r"[A-Za-z0-9_-][A-Za-z0-9_.-]{0,14}")
HOST = re.compile(r"[a-z0-9._-]{1,253}|\[[0-9a-f:.]{2,45}\]")
ERRO_NAV = re.compile(r"net::ERR_[A-Z0-9_]{1,60}")
PERDA = re.compile(r"([\d.]+)% packet loss")
RTT = re.compile(r"= ([\d.]+)/([\d.]+)/([\d.]+)/")
PRESSAO = re.compile(r"^some avg10=[\d.]+ avg60=([\d.]+)", re.M)
DISCO = re.compile(r"mmcblk\d+|sd[a-z]+|nvme\d+n\d+|vd[a-z]+|zram\d+")
MAIORES_CPU = 5
NAVEGADORES = ("chromium", "chrome", "brave")
GPU_NAVEGADOR = re.compile(r" --(use-angle|use-gl)=([a-z0-9-]{1,30})(?= |$)")
RC6 = "sys/class/drm/card*/gt/gt0/rc6_residency_ms"

UNIDADES = (
    "NetworkManager.service", "wpa_supplicant.service", "celita-rede-forte.service",
    "celita-tampa.service", "systemd-logind.service", "systemd-suspend.service",
    "controle-de-aula-agent.service",
)
# Do kernel e do systemd, só o que fala de tampa, sono, desligamento e Wi-Fi;
# do agente, só o Wi-Fi da escola. Linha que fala de segredo nunca sai.
KERNEL = re.compile(r"PM: |ACPI|\blid\b|suspend|resume|wak|wlan|wlp|iwlwifi|ath\d|mt7|rtw|brcm|"
                    r"deauth|disassoc|authenticat|associat|reboot|power down|watchdog|panic|oops|"
                    r"BUG:|hung_task|cros_ec|out of memory|oom-kill|i915|gpu hang|segfault|traps:|"
                    r"mmc\d|I/O error|EXT4-fs (error|warning)", re.I)
SISTEMA = re.compile(r"sleep|suspend|hibernat|power-?off|reboot|shutdown|shutting down|"
                     r"startup finished|reached target (graphical|multi-user)", re.I)
AGENTE = ("controle-de-aula.wifi:", "controle-de-aula.diagnostico:")
RUIDO = re.compile(r"ACPI: ([A-Z0-9]{4} 0x|Early table|RSDP)|^efi: ")
SEGREDO = re.compile(r"psk|passw|senha|secret|wep-key|private-key", re.I)
SENHA_ERRADA = re.compile(r'ssid="([^"]*)".*reason=WRONG_KEY')
FIM_LIMPO = re.compile(r"reboot: (power down|restarting)|systemd-shutdown|shutting down\.|"
                       r"journal stopped", re.I)


# Compositor e quem mais pinta a tela: o custo deles aparece no "minuto".
PROCESSOS_DESENHO = ("picom", "Xorg", "xfwm4", "xfce4-panel", "chrome", "brave", "chromium")


def _escapado(campo: str) -> str:
    return campo.replace("\\:", ":").replace("\\\\", "\\")


def _campos(linha: str) -> list:
    return [_escapado(c) for c in re.split(r"(?<!\\):", linha)]


def _cortar(texto: str, limite: int = MAX_LINHA) -> str:
    return texto if len(texto) <= limite else texto[: limite - 1] + "…"


def _numero(valor) -> float:
    return float(valor) if isinstance(valor, (int, float)) and not isinstance(valor, bool) else 0.0


def _ms(valor) -> bool:
    return isinstance(valor, int) and not isinstance(valor, bool) and 0 <= valor <= MAX_NAV_MS


def _navegacao(item) -> dict | None:
    if not isinstance(item, dict) or not isinstance(item.get("host"), str) \
            or not HOST.fullmatch(item["host"]) or not _ms(item.get("ms")):
        return None
    valida = {"host": item["host"], "ms": item["ms"]}
    if _ms(item.get("resp")):
        valida["resp"] = item["resp"]
    if isinstance(item.get("erro"), str) and ERRO_NAV.fullmatch(item["erro"]):
        valida["erro"] = item["erro"]
    return valida


def _em_thread(alvo):
    def rodar():
        try:
            alvo()
        except Exception as error:  # noqa: BLE001 - o minuto seguinte tenta de novo
            log.warning("diagnóstico: %s", error)
    threading.Thread(target=rodar, name="diagnostico", daemon=True).start()


class Diagnostico:
    def __init__(self, storage, get_fb, get_identity, agora_ms=None, executar=subprocess.run,
                 raiz: str = "/", fila: str | None = None, versao=celita_version, ao_mudar=None,
                 disparar=_em_thread, uso=None):
        self.storage = storage
        self._get_fb = get_fb
        self._get_identity = get_identity
        self._agora = agora_ms or (lambda: int(time.time() * 1000))
        self._executar = executar
        self._raiz = raiz
        self._fila = fila or os.path.join(os.path.dirname(storage.path), "diagnostico-fila.jsonl")
        self._versao = versao
        self._ao_mudar = ao_mudar or (lambda _ativo: None)
        self._disparar = disparar
        self._uso = uso or (lambda: None)
        self._saude_em = 0
        self._lock = threading.Lock()
        self._ultimo = 0
        self._coletando = False
        self._velocidade_em = 0
        self._nav = []
        self._amostras = {}
        # meta/diag ainda não reflete o estado (sobe no primeiro tick com rede).
        self._prazo_pendente = True
        self._prazo_tentar_em = 0

    # ---- comando do app -----------------------------------------------------------

    def pedir(self, payload: dict) -> dict:
        horas = payload.get("horas")
        if isinstance(horas, bool) or not isinstance(horas, (int, float)) \
                or not 0 <= horas <= protocol.DIAGNOSTICO_MAX_HORAS:
            return {"ok": False, "error": "payload_invalido"}
        with self._lock:
            agora = self._agora()
            estado = self._estado()
            if horas == 0:
                if estado:
                    self._enfileirar(estado, {"tipo": "fim", "t": agora, "motivo": "app"})
                self.storage.set(CHAVE, None)
                self._nav = []
            else:
                ate = agora + int(horas * 3600 * 1000)
                # Pedido com a gravação ligada só muda o prazo: a sessão continua.
                estado = {**estado, "ate": ate} if estado else \
                    {"sessao": str(agora), "ate": ate, "cursor": None, "boot": None}
                self.storage.set(CHAVE, estado)
                self._ultimo = 0
        self._ao_mudar(horas > 0)
        self._publicar_prazo()
        return {"ok": True}

    def ativo(self) -> bool:
        return self.prazo() > 0

    def prazo(self) -> int:
        """Até quando grava, em ms do relógio do PC; 0 = não grava."""
        with self._lock:
            estado = self._estado()
            return estado["ate"] if estado is not None and self._agora() < estado["ate"] else 0

    def _publicar_prazo(self):
        """meta/diag = prazo: o app desabilita o Gravar enquanto o PC grava."""
        fb = self._get_fb()
        identity = self._get_identity()
        if fb is None or not identity:
            self._prazo_pendente = True
            return
        try:
            fb.patch(f"/devices/{identity['deviceId']}/meta", {"diag": self.prazo()})
            self._prazo_pendente = False
        except (FirebaseError, OSError) as error:
            log.warning("meta/diag não subiu (%s); tento de novo em %d min", error, PRAZO_RETENTAR_MS // 60000)
            self._prazo_pendente = True
            self._prazo_tentar_em = self._agora() + PRAZO_RETENTAR_MS

    def navegacao(self, itens):
        """Páginas que a extensão mediu ({t:'nav'}), para o próximo minuto."""
        if not isinstance(itens, list):
            return
        agora = self._agora()
        validas = [{**item, "t": agora} for item in map(_navegacao, itens[:MAX_NAV]) if item]
        with self._lock:
            estado = self._estado()
            if estado is not None and agora < estado["ate"]:
                self._nav = [*self._nav, *validas][-MAX_NAV:]

    # ---- laço lateral -------------------------------------------------------------

    def tick(self):
        coletar, acabou = None, False
        with self._lock:
            estado = self._estado()
            agora = self._agora()
            if estado and agora >= estado["ate"]:
                self._enfileirar(estado, {"tipo": "fim", "t": agora, "motivo": "prazo"})
                self.storage.set(CHAVE, None)
                self._nav = []
                acabou = True
            elif estado and not self._coletando and agora - self._ultimo >= INTERVALO_MS:
                self._ultimo = agora
                self._coletando = True
                coletar = estado
        if acabou:
            self._ao_mudar(False)
            self._publicar_prazo()
        elif self._prazo_pendente and agora >= self._prazo_tentar_em:
            self._publicar_prazo()
        if coletar:
            # Fora do laço lateral: ping, sondas e velocidade levam segundos.
            self._disparar(lambda: self._coletar(coletar, agora))
        self._esvaziar()

    def _estado(self) -> dict | None:
        estado = self.storage.get(CHAVE)
        if not isinstance(estado, dict) or not str(estado.get("sessao", "")).isdigit() \
                or not isinstance(estado.get("ate"), int):
            return None
        return estado

    def _coletar(self, estado: dict, agora: int):
        try:
            boot = (self._ler("proc/sys/kernel/random/boot_id") or "").replace("-", "") or None
            registros = []
            if boot and estado.get("boot") != boot:
                motivo = "inicio" if estado.get("boot") is None else "boot"
                registros.append(self._registro_boot(agora, boot, motivo))
            if agora - self._saude_em >= SAUDE_MS:
                registros.append(self._registro_saude(agora, self._saude_em or agora - SAUDE_MS))
                self._saude_em = agora
            linhas, cursor = self._diario(estado.get("cursor"))
            minuto = {"tipo": "minuto", "t": agora, **self._estado_do_pc(agora)}
            with self._lock:
                atual = self._estado()
                # Parada pelo app durante a coleta: o fim já está na fila.
                if atual is None or atual["sessao"] != estado["sessao"]:
                    return
                nav, self._nav = self._nav, []
                for registro in (*registros, {**minuto, "nav": nav, "log": linhas}):
                    self._enfileirar(atual, registro)
                self.storage.set(CHAVE, {**atual, "boot": boot or atual.get("boot"),
                                         "cursor": cursor or atual.get("cursor")})
        finally:
            with self._lock:
                self._coletando = False

    # ---- o que se registra --------------------------------------------------------

    def _rodar(self, args: list, qualquer_saida: bool = False, entrada: str | None = None) -> str | None:
        try:
            resultado = self._executar(args, capture_output=True, text=True, timeout=TIMEOUT_S,
                                       check=False, input=entrada)
        except (OSError, subprocess.TimeoutExpired):
            return None
        return resultado.stdout if resultado.returncode == 0 or qualquer_saida else None

    def _ler(self, caminho: str) -> str | None:
        try:
            with open(os.path.join(self._raiz, caminho), encoding="utf-8", errors="replace") as arquivo:
                return arquivo.read().strip()
        except OSError:
            return None

    def _estado_do_pc(self, agora: int) -> dict:
        wifi = self._wifi()
        dispositivo, ip = wifi.get("dispositivo"), wifi.get("ip") or []
        energia = self._energia()
        estado = {"wifi": wifi, "redes": self._redes(), "tampa": self._tampa(), "energia": energia,
                  "enlace": self._enlace(dispositivo), "ping": self._pings(ip[1] if len(ip) > 1 else None),
                  "sondas": self._sondas()}
        if agora - self._velocidade_em >= VELOCIDADE_MS:
            self._velocidade_em = agora
            estado["velocidade"] = self._velocidade()
        # Depois da velocidade: o tráfego do minuto que a mediu conta o teste.
        estado.update(trafego=self._trafego(dispositivo, agora), sistema=self._sistema())
        sono, uso = self._sono(agora, energia.get("bateria")), self._uso_atual()
        estado.update({chave: valor for chave, valor in (("sono", sono), ("uso", uso)) if valor})
        return estado

    def _wifi(self) -> dict:
        wifi = {}
        geral = self._rodar(["nmcli", "-t", "-f", "STATE,CONNECTIVITY,WIFI", "general"])
        if geral:
            campos = _campos(geral.splitlines()[0])
            wifi.update(zip(("estado", "conectividade", "radio"), campos))
        for linha in (self._rodar(["nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION",
                                   "device", "status"]) or "").splitlines():
            campos = _campos(linha)
            if len(campos) == 4 and campos[1] == "wifi":
                wifi.update(dispositivo=campos[0], dispositivo_estado=campos[2], conexao=campos[3])
                ip = self._rodar(["nmcli", "-t", "-g", "IP4.ADDRESS,IP4.GATEWAY,IP4.DNS", "device",
                                  "show", campos[0]])
                if ip:
                    linhas = ip.splitlines()
                    wifi["ip"] = [_cortar(v, 60) for v in linhas[:2]]
                    if len(linhas) > 2 and linhas[2]:
                        wifi["dns"] = _cortar(linhas[2], 100)
                # O DNS da Central é global no NetworkManager e passa por cima do
                # da rede, que é o único que o nmcli mostra.
                dns = self._dns_em_uso()
                if dns:
                    wifi["dns"] = dns
                break
        return wifi

    def _dns_em_uso(self) -> str | None:
        servidores = [campos[1] for campos in map(str.split, (self._ler("etc/resolv.conf") or "").splitlines())
                      if len(campos) > 1 and campos[0] == "nameserver"]
        return _cortar(" | ".join(servidores), 100) if servidores else None

    def _redes(self) -> list:
        saida = self._rodar(["nmcli", "-t", "-f", "IN-USE,BSSID,SSID,CHAN,FREQ,SIGNAL,SECURITY",
                             "device", "wifi", "list", "--rescan", "no"])
        redes = []
        for linha in (saida or "").splitlines():
            campos = _campos(linha)
            if len(campos) != 7:
                continue
            usa, bssid, ssid, canal, freq, sinal, seguranca = campos
            redes.append({"ssid": _cortar(ssid, 40), "bssid": bssid, "canal": canal, "freq": freq,
                          "sinal": int(sinal) if sinal.isdigit() else None,
                          "seg": _cortar(seguranca, 30), "usa": usa.strip() == "*"})
        redes.sort(key=lambda rede: (not rede["usa"], -(rede["sinal"] or 0)))
        return redes[:MAX_REDES]

    def _tampa(self) -> str | None:
        for caminho in sorted(glob.glob(os.path.join(self._raiz, "proc/acpi/button/lid/*/state"))):
            texto = self._ler(os.path.relpath(caminho, self._raiz)) or ""
            return texto.split()[-1] if texto.split() else None
        return None

    def _energia(self) -> dict:
        energia = {}
        for pasta in sorted(glob.glob(os.path.join(self._raiz, "sys/class/power_supply/*"))):
            relativo = os.path.relpath(pasta, self._raiz)
            tipo = self._ler(os.path.join(relativo, "type"))
            if tipo == "Battery":
                carga = self._ler(os.path.join(relativo, "capacity"))
                energia["bateria"] = int(carga) if carga and carga.isdigit() else None
                energia["situacao"] = self._ler(os.path.join(relativo, "status"))
                watts = self._watts(relativo)
                if watts is not None:
                    energia["watts"] = watts
            elif tipo == "Mains":
                energia["tomada"] = self._ler(os.path.join(relativo, "online")) == "1"
        brilho = self._brilho()
        if brilho is not None:
            energia["brilho"] = brilho
        return energia

    def _inteiro(self, caminho: str) -> int | None:
        texto = self._ler(caminho) or ""
        return int(texto) if texto.lstrip("-").isdigit() else None

    def _baterias(self) -> list:
        pastas = sorted(glob.glob(os.path.join(self._raiz, "sys/class/power_supply/*")))
        relativos = [os.path.relpath(pasta, self._raiz) for pasta in pastas]
        return [r for r in relativos if self._ler(os.path.join(r, "type")) == "Battery"]

    def _watts(self, bateria: str) -> float | None:
        potencia = self._inteiro(os.path.join(bateria, "power_now"))
        if potencia is None:
            corrente = self._inteiro(os.path.join(bateria, "current_now"))
            tensao = self._inteiro(os.path.join(bateria, "voltage_now"))
            potencia = corrente * tensao // 1_000_000 if corrente is not None and tensao is not None else None
        return round(abs(potencia) / 1_000_000, 1) if potencia is not None else None

    def _brilho(self) -> int | None:
        for pasta in sorted(glob.glob(os.path.join(self._raiz, "sys/class/backlight/*"))):
            relativo = os.path.relpath(pasta, self._raiz)
            atual = self._inteiro(os.path.join(relativo, "brightness"))
            maximo = self._inteiro(os.path.join(relativo, "max_brightness"))
            if atual is not None and maximo:
                return round(100 * atual / maximo)
        return None

    def _sono(self, agora: int, bateria) -> dict | None:
        # O minuto não roda dormindo: o primeiro depois de acordar compara.
        vezes = self._inteiro("sys/power/suspend_stats/success")
        if vezes is None:
            return None
        anterior, self._amostras["sono"] = self._amostras.get("sono"), (vezes, agora, bateria)
        if not anterior or vezes <= anterior[0]:
            return None
        return {"vezes": vezes - anterior[0], "s": round((agora - anterior[1]) / 1000),
                "bateria": [anterior[2], bateria]}

    def _uso_atual(self) -> dict | None:
        try:
            uso = self._uso()
        except Exception as error:  # noqa: BLE001 - sem X ou sem ponte, o minuto segue
            log.debug("uso: %s", error)
            return None
        if not isinstance(uso, dict):
            return None
        valido = {}
        if isinstance(uso.get("app"), str) and uso["app"]:
            valido["app"] = _cortar(uso["app"], 40)
        abas = [h for h in uso.get("abas") or [] if isinstance(h, str) and HOST.fullmatch(h)]
        if abas:
            valido["abas"] = abas[:MAX_ABAS]
        return valido or None

    # ---- saúde do PC, a cada hora -------------------------------------------------

    def _registro_saude(self, agora: int, desde: int) -> dict:
        saude = {"tipo": "saude", "t": agora, "bateria": self._saude_bateria(), "disco": self._disco(),
                 "emmc": self._emmc(), "atualizacao": self._atualizacao(), "travamentos": self._travamentos(desde)}
        return {chave: valor for chave, valor in saude.items() if valor not in (None, [], {})}

    def _saude_bateria(self) -> dict | None:
        for bateria in self._baterias():
            saude = {}
            for prefixo, unidade in (("energy", "wh"), ("charge", "ah")):
                cheia = self._inteiro(os.path.join(bateria, f"{prefixo}_full"))
                fabrica = self._inteiro(os.path.join(bateria, f"{prefixo}_full_design"))
                if cheia and fabrica:
                    saude.update({"saude": round(100 * cheia / fabrica), f"cheia_{unidade}": round(cheia / 1e6, 1),
                                  f"fabrica_{unidade}": round(fabrica / 1e6, 1)})
                    break
            ciclos = self._inteiro(os.path.join(bateria, "cycle_count"))
            if ciclos:
                saude["ciclos"] = ciclos
            modelo = self._ler(os.path.join(bateria, "model_name"))
            if modelo:
                saude["modelo"] = _cortar(modelo, 40)
            return saude or None
        return None

    def _disco(self) -> dict:
        disco, vistos = {}, set()
        for nome, caminho in (("raiz", ""), ("home", "home")):
            try:
                info = os.statvfs(os.path.join(self._raiz, caminho))
                dispositivo = os.stat(os.path.join(self._raiz, caminho)).st_dev
            except OSError:
                continue
            if dispositivo in vistos:
                continue
            vistos.add(dispositivo)
            disco[nome] = {"livre_gb": round(info.f_bavail * info.f_frsize / 1e9, 1),
                           "total_gb": round(info.f_blocks * info.f_frsize / 1e9, 1)}
        return disco

    def _emmc(self) -> dict | None:
        # life_time: 0x01 é 0-10% da vida usada, 0x0B passou do fim; pre_eol:
        # 0x01 normal, 0x02 aviso (80% dos blocos reserva), 0x03 urgente.
        for pasta in sorted(glob.glob(os.path.join(self._raiz, "sys/block/mmcblk*/device"))):
            relativo = os.path.relpath(pasta, self._raiz)
            if self._ler(os.path.join(relativo, "type")) != "MMC":
                continue
            emmc = {"modelo": _cortar(self._ler(os.path.join(relativo, "name")) or "", 40)}
            vida = [int(v, 16) for v in (self._ler(os.path.join(relativo, "life_time")) or "").split()
                    if re.fullmatch(r"0x[0-9a-fA-F]{1,2}", v)]
            if vida:
                emmc["vida"] = ["esgotada" if v >= 0x0B else f"{(v - 1) * 10}-{v * 10}%" for v in vida]
            eol = self._ler(os.path.join(relativo, "pre_eol_info")) or ""
            if re.fullmatch(r"0x0[0-3]", eol):
                emmc["fim_de_vida"] = ("?", "normal", "aviso", "urgente")[int(eol, 16)]
            return emmc
        return None

    def _atualizacao(self, escolhidos=ATUALIZACAO) -> dict:
        campos = {}
        for linha in (self._ler("var/lib/celita-update/status") or "").splitlines():
            chave, _, valor = linha.partition("=")
            if chave in escolhidos and valor:
                campos[chave.lower()] = _cortar(valor, 120)
        return campos

    def saude_da_maquina(self) -> dict:
        """Leituras cruas para o health_report (health.py); nada vai para o /diag."""
        return {"bios": self._ler("sys/class/dmi/id/bios_version"),
                "modelo": self._ler("sys/class/dmi/id/product_name"),
                "bateria": self._saude_bateria(), "disco": self._disco(), "emmc": self._emmc(),
                "atualizacao": self._atualizacao(("ESTADO", "REINICIAR")),
                "fim_anterior": self._como_acabou(self._fim_do_boot_anterior()),
                "wifi_recusado": self._wifi_senha_errada()}

    def _wifi_senha_errada(self) -> list:
        # O wpa_supplicant também acusa WRONG_KEY por sinal fraco: só conta a
        # rede recusada mais de uma vez e que não é a que está em uso.
        entradas = self._entradas(["journalctl", "-b", "-u", "wpa_supplicant.service", "--since=-24h",
                                   "--grep=reason=WRONG_KEY", "-o", "json", "--no-pager", "-q"]) or []
        vezes = {}
        for entrada in entradas:
            achado = SENHA_ERRADA.search(self._mensagem(entrada))
            if achado and achado.group(1):
                vezes[achado.group(1)] = vezes.get(achado.group(1), 0) + 1
        em_uso = {rede["ssid"] for rede in self._redes() if rede["usa"]}
        return sorted(ssid for ssid, n in vezes.items() if n > 1 and ssid not in em_uso)

    def _travamentos(self, desde: int) -> list:
        saida = self._rodar(["coredumpctl", "list", "--no-pager", "--json=short", f"--since=@{desde // 1000}"])
        try:
            dumps = json.loads(saida or "[]")
        except ValueError:
            return []
        travamentos = []
        for dump in dumps if isinstance(dumps, list) else []:
            if isinstance(dump, dict) and isinstance(dump.get("exe"), str):
                travamentos.append({"hora": (self._hora(dump.get("time")) or "")[11:],
                                    "programa": _cortar(os.path.basename(dump["exe"]), 40),
                                    "sinal": dump.get("sig") if isinstance(dump.get("sig"), int) else None})
        return travamentos[-MAX_TRAVAMENTOS:]

    # ---- internet e carga do PC ---------------------------------------------------

    def _sondas(self) -> list:
        # HEAD sem seguir redirecionamento: mede DNS, conexão, TLS e primeiro
        # byte, sem baixar a página.
        alvos = list(SONDAS)
        url = getattr(self._get_fb(), "database_url", None)
        if isinstance(url, str) and url.startswith("https://"):
            alvos.append(("firebase", url + "/.json"))
        args = [*CURL, "-I", "--parallel", "--parallel-immediate", "-w", "%{json}\\n"]
        for _nome, endereco in alvos:
            args += ["-o", "/dev/null", endereco]
        respostas = {d["urlnum"]: d for d in self._jsons(self._rodar(args, qualquer_saida=True))
                     if isinstance(d.get("urlnum"), int)}
        return [{"alvo": nome, **self._tempos(respostas.get(i))} for i, (nome, _e) in enumerate(alvos)]

    @staticmethod
    def _tempos(dados) -> dict:
        if not isinstance(dados, dict):
            return {"erro": "sem resposta"}
        tempos = {"http": dados.get("http_code")}
        for campo, chave in (("dns", "time_namelookup"), ("tcp", "time_connect"), ("tls", "time_appconnect"),
                             ("ttfb", "time_starttransfer"), ("total", "time_total")):
            if _numero(dados.get(chave)) > 0:
                tempos[campo] = round(_numero(dados[chave]) * 1000)
        if isinstance(dados.get("remote_ip"), str) and dados["remote_ip"]:
            tempos["ip"] = dados["remote_ip"][:45]
        if dados.get("exitcode"):
            tempos["erro"] = _cortar(str(dados.get("errormsg") or f"curl {dados['exitcode']}"), 100)
        return tempos

    def _velocidade(self) -> dict:
        saida = [*CURL, "-o", "/dev/null", "-w", "%{json}"]
        baixa = self._jsons(self._rodar([*saida, BAIXAR], qualquer_saida=True))
        sobe = self._jsons(self._rodar([*saida, "--data-binary", "@-", SUBIR], qualquer_saida=True,
                                       entrada="0" * SUBIR_BYTES))
        return {"baixa": self._vazao(baixa, "download"), "sobe": self._vazao(sobe, "upload")}

    @staticmethod
    def _vazao(dados: list, sentido: str) -> dict:
        if not dados:
            return {"erro": "sem resposta"}
        vazao = {"kbps": round(_numero(dados[0].get(f"speed_{sentido}")) * 8 / 1000),
                 "kb": round(_numero(dados[0].get(f"size_{sentido}")) / 1000),
                 "s": round(_numero(dados[0].get("time_total")), 1)}
        if dados[0].get("exitcode"):
            vazao["erro"] = _cortar(str(dados[0].get("errormsg") or f"curl {dados[0]['exitcode']}"), 100)
        return vazao

    def _pings(self, roteador) -> dict:
        alvos = {"internet": INTERNET}
        if isinstance(roteador, str) and IPV4.fullmatch(roteador):
            alvos = {"roteador": roteador, **alvos}
        return {nome: self._ping(ip) for nome, ip in alvos.items()}

    def _ping(self, ip: str) -> dict:
        saida = self._rodar(["ping", "-n", "-q", "-c", "5", "-i", "0.2", "-W", "1", "-w", "3", ip],
                            qualquer_saida=True) or ""
        perda, rtt = PERDA.search(saida), RTT.search(saida)
        if not perda:
            return {"erro": "sem resposta"}
        ping = {"perda": round(float(perda.group(1)))}
        if rtt:
            ping.update(min=float(rtt.group(1)), media=float(rtt.group(2)), max=float(rtt.group(3)))
        return ping

    def _enlace(self, dispositivo) -> dict | None:
        if not isinstance(dispositivo, str) or not DISPOSITIVO.fullmatch(dispositivo):
            return None
        enlace = {}
        for linha in (self._rodar(["iw", "dev", dispositivo, "station", "dump"]) or "").splitlines():
            if linha.startswith("Station "):
                if enlace:
                    break
                enlace["bssid"] = linha.split()[1]
                continue
            chave, _, valor = linha.strip().partition(":")
            if chave in ENLACE:
                enlace[ENLACE[chave]] = _cortar(valor.strip(), 80)
        return enlace or None

    def _trafego(self, dispositivo, agora: int) -> dict | None:
        if not isinstance(dispositivo, str) or not DISPOSITIVO.fullmatch(dispositivo):
            return None
        contadores = [self._ler(f"sys/class/net/{dispositivo}/statistics/{nome}_bytes") for nome in ("rx", "tx")]
        if not all(c and c.isdigit() for c in contadores):
            return None
        rx, tx = (int(c) for c in contadores)
        anterior, self._amostras["trafego"] = self._amostras.get("trafego"), (dispositivo, agora, rx, tx)
        if not anterior or anterior[0] != dispositivo or rx < anterior[2] or tx < anterior[3]:
            return None
        return {"rx_kb": (rx - anterior[2]) // 1000, "tx_kb": (tx - anterior[3]) // 1000,
                "s": round((agora - anterior[1]) / 1000)}

    def _sistema(self) -> dict:
        sistema = {}
        carga = (self._ler("proc/loadavg") or "").split()[:3]
        if len(carga) == 3 and all(re.fullmatch(r"[\d.]+", c) for c in carga):
            sistema["carga"] = [float(c) for c in carga]
        memoria = self._memoria()
        valores = {**self._cpu(), "livre_mb": memoria.get("MemAvailable"),
                   "swap_mb": memoria["SwapTotal"] - memoria["SwapFree"]
                   if {"SwapTotal", "SwapFree"} <= memoria.keys() else None,
                   "pressao": self._pressao(), "temp": self._temperatura(), "processos": self._processos(),
                   **self._cpu_dos_processos(), "disco_io": self._disco_io(), "gpu": self._gpu()}
        sistema.update({chave: valor for chave, valor in valores.items() if valor not in (None, {})})
        return sistema

    def _cpu_dos_processos(self) -> dict:
        """CPU do minuto por nome de processo, em % de um núcleo. O compositor
        (picom) e quem desenha com ele ficam à parte: é o que decide se a frota de
        Celeron fica com cantos e sombra. Dos demais, os que mais gastaram e a
        soma do resto, para a conta fechar com o total."""
        tempos = {}
        for linha in (self._rodar(["ps", "-e", "-o", "pid=,comm=,cputimes="]) or "").splitlines():
            pid, _, resto = linha.strip().partition(" ")
            nome, _, segundos = resto.strip().rpartition(" ")
            nome = nome.strip()
            if nome and pid.isdigit() and segundos.isdigit():
                # kworker/0:1-events, kworker/u8:3-flush: o nome muda com o serviço.
                tempos[int(pid)] = ("kworker" if nome.startswith("kworker/") else nome, int(segundos))
        agora = self._agora()
        anterior, self._amostras["processos"] = self._amostras.get("processos"), (agora, tempos)
        campos = {"compositor": {"picom": any(nome == "picom" for nome, _ in tempos.values())}}
        if not anterior or agora <= anterior[0]:
            return campos
        # Por processo: aba do Chrome que fecha levava o tempo dela e a soma por
        # nome saía negativa; processo novo no minuto conta inteiro.
        gasto = {}
        for pid, (nome, segundos) in tempos.items():
            delta = segundos - anterior[1][pid][1] if pid in anterior[1] else segundos
            gasto[nome] = gasto.get(nome, 0) + max(delta, 0)
        decorrido = (agora - anterior[0]) / 1000
        gasto = {nome: round(100 * segundos / decorrido, 1) for nome, segundos in gasto.items()}
        campos["compositor"]["cpu"] = {nome: uso for nome, uso in gasto.items() if nome in PROCESSOS_DESENHO}
        demais = sorted(((nome, uso) for nome, uso in gasto.items() if nome not in PROCESSOS_DESENHO and uso),
                        key=lambda item: -item[1])
        if tempos:
            campos["cpu_processos"] = {nome[:30]: uso for nome, uso in demais[:MAIORES_CPU]}
            campos["cpu_outros"] = round(sum(uso for _, uso in demais[MAIORES_CPU:]), 1)
        return campos

    def _cpu(self) -> dict:
        """Uso da CPU no minuto e a parte de cada modo, em % do total. A espera de
        E/S separa disco (ou GPU: o i915 espera a fila dela como E/S) de conta."""
        linha = ((self._ler("proc/stat") or "").splitlines() or [""])[0]
        valores = linha.split()[1:9] if linha.startswith("cpu ") else []
        if len(valores) < 5 or not all(v.isdigit() for v in valores):
            return {}
        tempos = [int(v) for v in valores] + [0] * (8 - len(valores))
        anterior, self._amostras["cpu"] = self._amostras.get("cpu"), tempos
        total = sum(tempos) - sum(anterior or tempos)
        if total <= 0:
            return {}
        usuario, nice, sistema, ocioso, espera, irq, softirq, _roubo = (
            atual - antes for atual, antes in zip(tempos, anterior))
        return {"cpu": round(100 * (1 - (ocioso + espera) / total)),
                "cpu_modos": {"usuario": round(100 * (usuario + nice) / total, 1),
                              "sistema": round(100 * (sistema + irq + softirq) / total, 1),
                              "espera": round(100 * espera / total, 1)}}

    def _disco_io(self) -> dict:
        """O que cada disco leu e gravou no minuto e a parte do tempo ocupado.
        Zero também responde: PSI de E/S alto com o disco parado não é disco."""
        contadores = {}
        for linha in (self._ler("proc/diskstats") or "").splitlines():
            campos = linha.split()
            if len(campos) >= 13 and DISCO.fullmatch(campos[2]) and all(c.isdigit() for c in campos[3:13]):
                contadores[campos[2]] = (int(campos[5]), int(campos[9]), int(campos[12]))
        agora = self._agora()
        anterior, self._amostras["disco_io"] = self._amostras.get("disco_io"), (agora, contadores)
        if not anterior or agora <= anterior[0]:
            return {}
        discos = {}
        for nome, atual in contadores.items():
            antes = anterior[1].get(nome)
            if antes and all(a >= b for a, b in zip(atual, antes)):
                lido, gravado, ocupado = (a - b for a, b in zip(atual, antes))
                # Setor do diskstats é sempre de 512 bytes.
                discos[nome] = {"lido_kb": lido // 2, "gravado_kb": gravado // 2,
                                "ocupado": min(round(100 * ocupado / (agora - anterior[0]), 1), 100.0)}
        return discos

    def _gpu(self) -> dict:
        """GPU da Intel: parte do minuto fora do RC6 (acordada) e as flags com
        que o navegador subiu o processo de GPU. Sem flag, é o desenho pela
        placa; com use-angle=swiftshader, WebGL e composição saem da CPU."""
        gpu = {}
        caminhos = sorted(glob.glob(os.path.join(self._raiz, RC6)))
        parado = self._ler(os.path.relpath(caminhos[0], self._raiz)) if caminhos else None
        if parado and parado.isdigit():
            agora = self._agora()
            anterior, self._amostras["gpu"] = self._amostras.get("gpu"), (agora, int(parado))
            if anterior and agora > anterior[0] and int(parado) >= anterior[1]:
                acordada = 1 - (int(parado) - anterior[1]) / (agora - anterior[0])
                gpu["uso"] = round(100 * min(max(acordada, 0), 1), 1)
        for linha in (self._rodar(["ps", "-e", "-o", "args="]) or "").splitlines():
            programa = os.path.basename(linha.split(" ", 1)[0])
            if programa in NAVEGADORES and " --type=gpu-process" in linha:
                gpu["navegador"] = dict(GPU_NAVEGADOR.findall(linha))
                break
        return gpu

    def _memoria(self) -> dict:
        memoria = {}
        for linha in (self._ler("proc/meminfo") or "").splitlines():
            nome, _, valor = linha.partition(":")
            if valor.split() and valor.split()[0].isdigit():
                memoria[nome] = int(valor.split()[0]) // 1024
        return memoria

    def _pressao(self) -> dict:
        pressao = {}
        for nome in ("cpu", "memory", "io"):
            achado = PRESSAO.search(self._ler(f"proc/pressure/{nome}") or "")
            if achado:
                pressao[nome] = float(achado.group(1))
        return pressao

    def _temperatura(self) -> int | None:
        graus = []
        for caminho in glob.glob(os.path.join(self._raiz, "sys/class/thermal/thermal_zone*/temp")):
            texto = self._ler(os.path.relpath(caminho, self._raiz)) or ""
            if texto.lstrip("-").isdigit():
                graus.append(int(texto) // 1000)
        return max(graus) if graus else None

    def _processos(self) -> dict:
        memoria = {}
        for linha in (self._rodar(["ps", "-e", "-o", "comm=,rss="]) or "").splitlines():
            nome, _, rss = linha.strip().rpartition(" ")
            if nome.strip() and rss.isdigit():
                memoria[nome.strip()] = memoria.get(nome.strip(), 0) + int(rss)
        maiores = sorted(memoria.items(), key=lambda item: -item[1])[:5]
        return {nome[:30]: rss // 1024 for nome, rss in maiores}

    def _registro_boot(self, agora: int, boot: str, motivo: str) -> dict:
        uptime = (self._ler("proc/uptime") or "0").split()[0]
        return {
            "tipo": "boot", "t": agora, "motivo": motivo, "boot": boot,
            "ligado_ha_s": int(float(uptime)) if re.fullmatch(r"[0-9.]+", uptime) else None,
            "versao": self._versao(),
            "bios": self._ler("sys/class/dmi/id/bios_version"),
            "modelo": self._ler("sys/class/dmi/id/product_name"),
            "tampa": self._tampa(),
            "boots": self._boots(),
            "anterior": self._boot_anterior(),
        }

    def _boots(self) -> list:
        saida = self._rodar(["journalctl", "--list-boots", "--no-pager", "-q", "-o", "json"])
        try:
            boots = json.loads(saida or "")
        except ValueError:
            return [_cortar(linha, 120) for linha in (saida or "").splitlines()[-6:]]
        if not isinstance(boots, list):
            return []
        return [{"boot": str(b.get("boot_id", ""))[:32],
                 "de": self._hora(b.get("first_entry")), "ate": self._hora(b.get("last_entry"))}
                for b in boots[-6:] if isinstance(b, dict)]

    def _boot_anterior(self) -> dict:
        # Desligamento limpo deixa o systemd-shutdown ou o "reboot:" do kernel no
        # fim; sem eles, o boot anterior acabou na marra (botão segurado).
        fim = self._fim_do_boot_anterior()
        if not fim:
            return {"fim": None, "linhas": []}
        linhas = self._linhas(self._entradas(
            ["journalctl", "-b", "-1", "-n", str(LINHAS_BOOT_ANTERIOR), "-o", "json", "--no-pager",
             "-q", *self._filtro()]))
        return {"fim": self._como_acabou(fim), "ultima": self._hora(fim[-1].get("__REALTIME_TIMESTAMP")),
                "linhas": linhas}

    def _fim_do_boot_anterior(self) -> list:
        return self._entradas(["journalctl", "-b", "-1", "-n", "60", "-o", "json", "--no-pager", "-q"]) or []

    def _como_acabou(self, fim: list) -> str | None:
        if not fim:
            return None
        return "limpo" if any(FIM_LIMPO.search(self._mensagem(e)) for e in fim) else "abrupto"

    def _filtro(self) -> list:
        return [f"_SYSTEMD_UNIT={unidade}" for unidade in UNIDADES] + ["+", "_TRANSPORT=kernel", "+", "_PID=1"]

    def _diario(self, cursor: str | None) -> tuple:
        base = ["journalctl", "-o", "json", "--no-pager", "-q"]
        entradas = None
        if cursor:
            entradas = self._entradas([*base, f"--after-cursor={cursor}", *self._filtro()])
        if entradas is None:
            # Diário girado ou cursor perdido: retoma pelos últimos minutos.
            entradas = self._entradas([*base, f"--since={JANELA_INICIAL if not cursor else '-2min'}",
                                       *self._filtro()]) or []
        novo = entradas[-1].get("__CURSOR") if entradas else None
        return self._linhas(entradas), novo

    def _entradas(self, args: list) -> list | None:
        saida = self._rodar(args)
        return None if saida is None else self._jsons(saida)

    @staticmethod
    def _jsons(saida: str | None) -> list:
        objetos = []
        for linha in (saida or "").splitlines():
            try:
                objeto = json.loads(linha)
            except ValueError:
                continue
            if isinstance(objeto, dict):
                objetos.append(objeto)
        return objetos

    @staticmethod
    def _mensagem(entrada: dict) -> str:
        mensagem = entrada.get("MESSAGE")
        if isinstance(mensagem, list):
            mensagem = bytes(b for b in mensagem if isinstance(b, int) and 0 <= b < 256).decode(
                "utf-8", "replace")
        return mensagem if isinstance(mensagem, str) else ""

    @staticmethod
    def _hora(micros) -> str | None:
        try:
            return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(int(micros) / 1e6))
        except (TypeError, ValueError, OverflowError, OSError):
            return None

    def _relevante(self, entrada: dict, mensagem: str) -> bool:
        if SEGREDO.search(mensagem):
            return False
        if entrada.get("_TRANSPORT") == "kernel":
            return bool(KERNEL.search(mensagem)) and not RUIDO.search(mensagem)
        if entrada.get("_PID") == "1" and not entrada.get("_SYSTEMD_UNIT", "").startswith(UNIDADES):
            return bool(SISTEMA.search(mensagem))
        if entrada.get("_SYSTEMD_UNIT") == "controle-de-aula-agent.service":
            return mensagem.startswith(AGENTE)
        return True

    def _linhas(self, entradas: list | None) -> list:
        linhas, boot = [], None
        for entrada in entradas or []:
            mensagem = self._mensagem(entrada)
            if not self._relevante(entrada, mensagem):
                continue
            if entrada.get("_BOOT_ID") != boot:
                if boot is not None:
                    linhas.append(f"-- boot {str(entrada.get('_BOOT_ID', ''))[:8]} --")
                boot = entrada.get("_BOOT_ID")
            quem = entrada.get("SYSLOG_IDENTIFIER") or entrada.get("_SYSTEMD_UNIT") or "?"
            hora = (self._hora(entrada.get("__REALTIME_TIMESTAMP")) or "")[11:]
            linhas.append(_cortar(f"{hora} {quem}: {mensagem}"))
        if len(linhas) > MAX_LINHAS:
            cabeca = MAX_LINHAS // 4
            linhas = [*linhas[:cabeca], f"-- {len(linhas) - MAX_LINHAS} linhas omitidas --",
                      *linhas[-(MAX_LINHAS - cabeca):]]
        return linhas

    # ---- fila e envio -------------------------------------------------------------

    def _enfileirar(self, estado: dict, registro: dict):
        texto = json.dumps(registro, ensure_ascii=False, separators=(",", ":"))
        while len(texto) > MAX_REGISTRO and registro.get("log"):
            registro = {**registro, "log": registro["log"][len(registro["log"]) // 2:]}
            texto = json.dumps(registro, ensure_ascii=False, separators=(",", ":"))
        if len(texto) > MAX_REGISTRO:
            return
        fila = self._ler_fila()
        fila.append({"sessao": estado["sessao"], "texto": texto})
        self._gravar_fila(fila[-FILA_MAX:])

    def _ler_fila(self) -> list:
        try:
            with open(self._fila, encoding="utf-8") as arquivo:
                itens = [json.loads(linha) for linha in arquivo if linha.strip()]
        except (OSError, ValueError):
            return []
        return [i for i in itens if isinstance(i, dict) and str(i.get("sessao", "")).isdigit()
                and isinstance(i.get("texto"), str)]

    def _gravar_fila(self, fila: list):
        temporario = self._fila + ".tmp"
        try:
            with open(os.open(temporario, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w",
                      encoding="utf-8") as arquivo:
                for item in fila:
                    arquivo.write(json.dumps(item, ensure_ascii=False) + "\n")
            os.replace(temporario, self._fila)
        except OSError as error:
            log.warning("fila do diagnóstico: %s", error)

    def _esvaziar(self):
        fb, identidade = self._get_fb(), self._get_identity()
        if fb is None or not identidade:
            return
        with self._lock:
            fila = self._ler_fila()[:SUBIDAS_POR_VEZ]
        enviados = []
        # Sem a trava durante a rede: um pedido do app não espera o envio.
        for item in fila:
            try:
                fb.side_request("POST", f"/diag/{identidade['deviceId']}/{item['sessao']}", item["texto"])
            except (FirebaseError, OSError):
                break
            enviados.append(item)
        if not enviados:
            return
        with self._lock:
            restante = self._ler_fila()
            while enviados and restante and restante[0] == enviados[0]:
                restante.pop(0)
                enviados.pop(0)
            self._gravar_fila(restante)
