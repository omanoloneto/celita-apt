"""Arquivo da unidade: fotos da câmera e histórico de navegação, cifrados com
a chave do par PC↔escola e guardados 15 dias.

Só coleta com o PC vinculado à escola (bind/teacherUid == school/meta/schoolUid).
Um laço próprio, fora do canal de comandos: nenhuma falha daqui derruba os
streams. Formatos em docs/protocolo.md (foto-v1 e nav-v1).
"""

import base64
import copy
import datetime
import json
import logging
import os
import re
import threading
import time

from . import protocol
from .crypto import seal, seal_photo
from .firebase import FirebaseError, FirebaseSession

log = logging.getLogger("controle-de-aula.archive")

# São Paulo é UTC−3 fixo desde 2019: o dia do arquivo não depende do fuso do PC.
DAY_SHIFT_MS = 3 * 3600 * 1000
CLOCK_THRESHOLD_MS = 2 * 60 * 1000
RETENTION_DAYS = 15
TICK_S = 5
LOGIN_PHOTO_DELAY_MS = 10 * 1000
PERIODIC_MS = 30 * 60 * 1000
RETRY_MS = 60 * 1000
MAX_RETRIES = 3
ATTEMPT_WINDOW_MS = 60 * 1000
FINALIZE_MS = 60 * 1000
NAV_SEND_S = 60
NAV_BATCH_MAX = 50
NAV_QUEUE_MAX = 2000
MAX_NAV_URL = 300
MAX_NAV_TITLE = 120
MAX_ENVELOPE = 64 * 1024
MAX_REPORT_EVENTS = 100
PHOTO_QUEUE_MAX = 48
RETENTION_EVERY_S = 6 * 3600
RETRY_LATER_S = 10 * 60
SCHOOL_RETRY_S = 60
AUTH_BACKOFF_S = 10 * 60
QUEUE_PRUNE_S = 60
FUTURE_TOLERANCE_MS = 60 * 1000

DAY_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$")
PHOTO_FILE_RE = re.compile(r"^([0-9]{13})_([A-Za-z0-9_-]{22})_([0-9]{4}-[0-9]{2}-[0-9]{2})\.bin$")

PHOTO_DIR = "fotos-pendentes"
NAV_FILE = "nav-pendente.json"
STATE_KEY = "arquivo"
SCHOOL_KEY = "arquivoEscola"


def day_of(ts_ms: int) -> str | None:
    try:
        moment = datetime.datetime.fromtimestamp((int(ts_ms) - DAY_SHIFT_MS) // 1000, tz=datetime.timezone.utc)
    except (ValueError, OverflowError, OSError):
        return None
    return moment.strftime("%Y-%m-%d")


def days_before(day: str, count: int) -> str:
    return (datetime.date.fromisoformat(day) - datetime.timedelta(days=count)).isoformat()


def expired(day: str, today: str) -> bool:
    return day <= days_before(today, RETENTION_DAYS)


def ts13(ts_ms: int) -> str:
    return f"{int(ts_ms):013d}"


def new_photo_id() -> str:
    return base64.urlsafe_b64encode(os.urandom(16)).decode("ascii").rstrip("=")


class Clock:
    """Desvio do relógio do PC medido pelo Date das respostas do Firebase.
    Só vale acima de 2 min: abaixo disso o relógio local é bom o bastante."""

    def __init__(self):
        self._measured_ms = 0
        self._lock = threading.Lock()

    def observe(self, server_ms: int, local_ms: int):
        with self._lock:
            self._measured_ms = int(server_ms) - int(local_ms)

    @property
    def offset_ms(self) -> int:
        with self._lock:
            measured = self._measured_ms
        return measured if abs(measured) > CLOCK_THRESHOLD_MS else 0

    def fix(self, local_ms: int) -> int:
        return int(local_ms) + self.offset_ms

    def local_ms(self) -> int:
        return int(time.time() * 1000)

    def now_ms(self) -> int:
        return self.fix(self.local_ms())


class Gate:
    """Backoff de 10 min por funcionalidade em 401/403 persistente."""

    def __init__(self, name: str):
        self.name = name
        self._until = None

    def open(self) -> bool:
        return self._until is None or time.monotonic() >= self._until

    def failed(self, error: FirebaseError):
        if error.status in (401, 403):
            self._until = time.monotonic() + AUTH_BACKOFF_S
            log.warning("%s negado (%s); nova tentativa em 10 min", self.name, error.status)
        else:
            log.debug("%s falhou: %s", self.name, error)


def _write_private(path: str, data: bytes):
    temporary = f"{path}.tmp"
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600)
    try:
        os.write(fd, data)
    finally:
        os.close(fd)
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)


class PhotoQueue:
    """Fotos já cifradas esperando upload: nome = ts13_r_dia.bin, 0600 em dir 0700."""

    def __init__(self, directory: str):
        self.directory = directory

    def _ensure(self):
        os.makedirs(self.directory, mode=0o700, exist_ok=True)
        os.chmod(self.directory, 0o700)

    def save(self, ts: int, r: str, day: str, data: bytes):
        self._ensure()
        _write_private(os.path.join(self.directory, f"{ts13(ts)}_{r}_{day}.bin"), data)

    def items(self) -> list:
        try:
            names = os.listdir(self.directory)
        except OSError:
            return []
        found = []
        for name in names:
            match = PHOTO_FILE_RE.match(name)
            if match:
                found.append({"ts": match.group(1), "r": match.group(2), "day": match.group(3),
                              "path": os.path.join(self.directory, name)})
        return sorted(found, key=lambda item: item["ts"])

    @staticmethod
    def read(item: dict) -> bytes | None:
        try:
            with open(item["path"], "rb") as handle:
                return handle.read()
        except OSError:
            return None

    @staticmethod
    def remove(item: dict):
        try:
            os.unlink(item["path"])
        except OSError:
            pass

    def prune(self, today: str):
        items = self.items()
        for item in items:
            if expired(item["day"], today):
                self.remove(item)
        items = [item for item in items if not expired(item["day"], today)]
        for item in items[: max(0, len(items) - PHOTO_QUEUE_MAX)]:
            self.remove(item)

    def clear(self):
        for item in self.items():
            self.remove(item)


class NavQueue:
    """Eventos finalizados que ainda não subiram, em ordem de ts, persistidos.
    `ts` é o que sai do PC (corrigido); `local` é o do relógio do PC, que é o
    dos cursores e do dedup."""

    def __init__(self, path: str):
        self.path = path
        self._items = self._load()

    def _load(self) -> list:
        try:
            with open(self.path, encoding="utf-8") as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            return []
        return [item for item in data if self._valid(item)] if isinstance(data, list) else []

    @staticmethod
    def _valid(item) -> bool:
        return (isinstance(item, dict)
                and all(isinstance(item.get(field), int) and not isinstance(item.get(field), bool)
                        for field in ("ts", "local"))
                and day_of(item["ts"]) is not None)

    def _save(self):
        if not self._items:
            try:
                os.unlink(self.path)
            except OSError:
                pass
            return
        os.makedirs(os.path.dirname(self.path), mode=0o700, exist_ok=True)
        _write_private(self.path, json.dumps(self._items, ensure_ascii=False).encode("utf-8"))

    @staticmethod
    def key(item: dict) -> str:
        return f"{item['local']}|{item['url']}"

    def items(self) -> list:
        return list(self._items)

    def keys(self) -> set:
        return {self.key(item) for item in self._items}

    def add(self, items: list):
        items = [item for item in items if self._valid(item)]
        self._items = sorted(self._items + items, key=lambda item: item["ts"])[-NAV_QUEUE_MAX:]
        self._save()

    def remove(self, items: list):
        gone = {self.key(item) for item in items}
        self._items = [item for item in self._items if self.key(item) not in gone]
        self._save()

    def prune(self, today: str):
        kept = [item for item in self._items if not expired(day_of(item["ts"]), today)]
        if len(kept) != len(self._items):
            self._items = kept
            self._save()

    def clear(self):
        self._items = []
        self._save()


def _event_key(event: dict) -> str:
    return f"{event['ts']}|{event['url']}"


def _after(event: dict, cursor: int, dedup: list) -> bool:
    return event["ts"] > cursor or (event["ts"] == cursor and _event_key(event) not in dedup)


def _advance(record: dict, cursor: str, dedup: str, event: dict):
    if event["ts"] > record[cursor]:
        record[cursor], record[dedup] = event["ts"], [_event_key(event)]
    elif event["ts"] == record[cursor] and _event_key(event) not in record[dedup]:
        record[dedup].append(_event_key(event))


def classify(url: str, rules: dict) -> str | None:
    """Bloqueio tem precedência sobre aviso."""
    for rule in rules.get("rules") or []:
        if protocol.rule_matches(rule.get("pattern"), url):
            return "bloqueado"
    for rule in rules.get("alerts") or []:
        if protocol.rule_matches(rule.get("pattern"), url):
            return "alerta"
    return None


def nav_batches(items: list) -> list:
    """Lotes de até 50 eventos da mesma sessão e do mesmo dia, em ordem."""
    batches, current = [], []
    for item in items:
        if current and (len(current) >= NAV_BATCH_MAX or day_of(item["ts"]) != day_of(current[0]["ts"])
                        or (item["user"], item["login"]) != (current[0]["user"], current[0]["login"])):
            batches.append(current)
            current = []
        current.append(item)
    if current:
        batches.append(current)
    return batches


def nav_object(batch: list) -> dict:
    events = []
    for item in batch:
        event = {"ts": item["ts"], "url": item["url"], "title": item["title"]}
        for extra in ("acao", "foto"):
            if item.get(extra) is not None:
                event[extra] = item[extra]
        events.append(event)
    return {"v": 1, "type": "archived_nav", "user": batch[0]["user"], "login": batch[0]["login"], "events": events}


class Archiver:
    """Estado e passos do arquivo. `tick()` é um passo do laço lateral do agente,
    que acorda a cada 5 s ou quando chega relatório (`wake`)."""

    def __init__(self, storage, clock: Clock, get_fb, get_link, sessions, bucket: str | None,
                 state_dir: str, capture):
        self.storage = storage
        self.clock = clock
        self.get_fb = get_fb
        # () -> {"deviceId", "key", "teacherUid"} | None
        self.get_link = get_link
        self.sessions = sessions
        self.bucket = bucket
        self.capture = capture
        self.photos = PhotoQueue(os.path.join(state_dir, PHOTO_DIR))
        self.nav = NavQueue(os.path.join(state_dir, NAV_FILE))
        self.wake = threading.Event()
        self.gates = {name: Gate(name) for name in ("escola", "fotos", "historico", "retencao")}
        self._lock = threading.RLock()
        self._report_lock = threading.Lock()
        self._report = None
        self._school_recheck = True
        self._school_retry_at = None
        self._retention_at = None
        self._nav_sent_at = None
        self._pruned_at = None
        self._discarded = False

    # ---- entradas de fora do laço ----------------------------------------------

    def offer_report(self, uid: int, events):
        """Relatório da ponte da sessão ativa (thread da ponte: só guarda e acorda)."""
        events = events if isinstance(events, list) else []
        with self._report_lock:
            self._report = {"uid": uid, "events": events[-MAX_REPORT_EVENTS:]}
        self.wake.set()

    def connected(self):
        self._school_recheck = True
        self._school_retry_at = None
        self._retention_at = None
        self.wake.set()

    def reset(self):
        """Desvincular: descarta filas e cursores; o que já subiu fica (a retenção cuida)."""
        with self._lock:
            self.photos.clear()
            self.nav.clear()
            self.storage.set(STATE_KEY, None)
            self.storage.set(SCHOOL_KEY, None)
            with self._report_lock:
                self._report = None
            self._school_recheck = True
            self._discarded = True

    # ---- laço ------------------------------------------------------------------------

    # O estado.json é serializado por outras threads: o registro nunca é
    # mexido no lugar, só em cópia gravada inteira.
    def _load_record(self) -> dict | None:
        record = self.storage.get(STATE_KEY)
        return copy.deepcopy(record) if isinstance(record, dict) else None

    def _save_record(self, record: dict | None):
        self.storage.set(STATE_KEY, copy.deepcopy(record) if record is not None else None)

    def _online_fb(self):
        fb = self.get_fb()
        return fb if fb is not None and fb.id_token else None

    def tick(self):
        with self._lock:
            link = self.get_link()
            if not link:
                return
            now = self.clock.now_ms()
            fb = self._online_fb()
            if fb is not None:
                self._check_school(fb, link)
            school = self._school_ok(link)
            if school is True:
                self._discarded = False
                try:
                    self._prune_queues(now)
                except (OSError, ValueError) as error:
                    log.warning("limpeza das filas falhou: %s", error)
                self._step_session(link, now)
                fb = self._online_fb()
                if fb is not None:
                    self._drain_photos(fb, link)
                    self._send_nav(fb, link, now)
            elif school is False and not self._discarded:
                self.photos.clear()
                self.nav.clear()
                self.storage.set(STATE_KEY, None)
                self._discarded = True
            fb = self._online_fb()
            if fb is not None:
                self._retention(fb, link, now)

    # ---- escola ----------------------------------------------------------------------

    def _school_ok(self, link: dict) -> bool | None:
        cached = self.storage.get(SCHOOL_KEY)
        if isinstance(cached, dict) and cached.get("teacherUid") == link["teacherUid"]:
            return cached.get("ok") is True
        return None

    def _check_school(self, fb, link: dict):
        cached = self._school_ok(link)
        if not self._school_recheck and cached is not None:
            return
        if self._school_retry_at is not None and time.monotonic() < self._school_retry_at:
            return
        if not self.gates["escola"].open():
            return
        try:
            school_uid = fb.side_get("/school/meta/schoolUid")
        except FirebaseError as error:
            self.gates["escola"].failed(error)
            self._school_retry_at = time.monotonic() + SCHOOL_RETRY_S
            return
        self._school_recheck = False
        ok = isinstance(school_uid, str) and bool(school_uid) and school_uid == link["teacherUid"]
        if ok != cached:
            log.info("arquivo da unidade %s", "ligado (PC da escola)" if ok else "desligado (PC fora da escola)")
        self.storage.set(SCHOOL_KEY, {"teacherUid": link["teacherUid"], "ok": ok})

    # ---- sessão, fotos e tentativas ---------------------------------------------------

    def _record(self, session, now: int) -> dict | None:
        record = self._load_record()
        if session is None:
            # Sessão sumida (logout ou tela bloqueada): fecha o último evento,
            # mas guarda os cursores para a mesma sessão voltar sem repetir nada.
            if record is not None and not record.get("ended"):
                self._end_session(record, now)
                record["ended"] = True
                self._save_record(record)
            return None
        if record is not None and record.get("key") == session.key:
            if record.get("ended"):
                record["ended"] = False
                self._save_record(record)
            return record
        if record is not None and not record.get("ended"):
            self._end_session(record, now)
        # Comparações no relógio local (o mesmo da extensão e do logind): uma
        # mudança de desvio não reclassifica eventos. `login` corrigido é só o que sai.
        login_local = session.realtime_ms or self.clock.local_ms()
        record = {
            "key": session.key, "user": session.user, "uid": session.uid,
            "loginLocal": login_local, "login": self.clock.fix(login_local),
            "controlled": session.controlled, "ended": False,
            "exam": login_local, "examDedup": [], "sent": login_local, "sentDedup": [], "marks": {},
            "photo": {"k": 0, "retry": 0, "due": now + LOGIN_PHOTO_DELAY_MS},
            "attempt": None,
        }
        self._save_record(record)
        return record

    def _step_session(self, link: dict, now: int):
        session = self.sessions.active_any()
        record = self._record(session, now)
        if record is None:
            return
        changed = self._step_photo(link, record, now)
        events = self._current_events(record)
        if events is not None:
            changed = self._examine(link, record, events) or changed
            changed = self._collect(record, events, self.clock.local_ms(), ended=False) or changed
        if changed:
            self._save_record(record)

    def _current_events(self, record: dict) -> list | None:
        if not record.get("controlled"):
            return None
        with self._report_lock:
            report = self._report
        if not report or report["uid"] != record.get("uid"):
            return None
        events = []
        # O relatório vem da conta do aluno: ts no futuro cegaria os cursores.
        latest = self.clock.local_ms() + FUTURE_TOLERANCE_MS
        for raw in report["events"]:
            if not isinstance(raw, dict) or not protocol.is_safe_http_url(raw.get("url")):
                continue
            ts = raw.get("ts")
            if not isinstance(ts, (int, float)) or isinstance(ts, bool) or not record["loginLocal"] <= ts <= latest:
                continue
            title = raw.get("title")
            events.append({"ts": int(ts), "url": raw["url"][:MAX_NAV_URL],
                           "title": title[:MAX_NAV_TITLE] if isinstance(title, str) else ""})
        return sorted(events, key=lambda event: event["ts"])

    def _photos_enabled(self) -> bool:
        return bool(self.bucket)

    def _step_photo(self, link: dict, record: dict, now: int) -> bool:
        photo = record["photo"]
        if now < photo["due"] or not self._photos_enabled():
            return False
        motivo = "login" if photo["k"] == 0 else "periodica"
        taken = self._take_photo(link, record, motivo, None)
        if taken is None and photo["retry"] < MAX_RETRIES:
            photo["retry"] += 1
            photo["due"] = now + RETRY_MS
        else:
            # O agendamento é sempre login + 30 min·k: retentativa não o empurra.
            k = max(photo["k"] + 1, (now - record["login"]) // PERIODIC_MS + 1)
            record["photo"] = {"k": k, "retry": 0, "due": record["login"] + k * PERIODIC_MS}
        return True

    def _take_photo(self, link: dict, record: dict, motivo: str, url: str | None) -> int | None:
        jpeg, _error = self.capture()
        if not jpeg:
            return None
        ts = self.clock.now_ms()
        header = {"v": 1, "type": "archived_photo", "ts": ts, "motivo": motivo,
                  "user": record["user"], "login": record["login"]}
        if url:
            header["url"] = url[:MAX_NAV_URL]
        try:
            self.photos.save(ts, new_photo_id(), day_of(ts), seal_photo(link["key"], header, jpeg))
        except OSError as error:
            log.warning("foto não foi guardada: %s", error)
            return None
        return ts

    def _examine(self, link: dict, record: dict, events: list) -> bool:
        rules = self.storage.get("rules") or {}
        changed = False
        for event in events:
            if not _after(event, record["exam"], record["examDedup"]):
                continue
            acao = classify(event["url"], rules if isinstance(rules, dict) else {})
            if acao:
                mark = {"acao": acao}
                foto = self._attempt_photo(link, record, acao, event["url"])
                if foto is not None:
                    mark["foto"] = foto
                record["marks"][_event_key(event)] = mark
            _advance(record, "exam", "examDedup", event)
            changed = True
        return changed

    def _attempt_photo(self, link: dict, record: dict, acao: str, url: str) -> int | None:
        now = self.clock.now_ms()
        last = record.get("attempt")
        if isinstance(last, dict) and now - last.get("at", 0) < ATTEMPT_WINDOW_MS:
            return last.get("foto")
        foto = self._take_photo(link, record, acao, url) if self._photos_enabled() else None
        record["attempt"] = {"at": now, "foto": foto}
        return foto

    # ---- histórico -------------------------------------------------------------------

    def _collect(self, record: dict, events: list, now: int, ended: bool) -> bool:
        if not events:
            return False
        last_key = _event_key(events[-1])
        queued = self.nav.keys()
        fresh = []
        for event in events:
            key = _event_key(event)
            if key in queued:
                continue
            if not _after(event, record["sent"], record["sentDedup"]):
                continue
            # O último pode ainda ganhar título (a extensão preenche depois).
            if key == last_key and not ended and now - event["ts"] < FINALIZE_MS:
                continue
            item = {**event, "ts": self.clock.fix(event["ts"]), "local": event["ts"],
                    "user": record["user"], "login": record["login"]}
            item.update(record["marks"].pop(key, {}))
            fresh.append(item)
        if fresh:
            self.nav.add(fresh)
        return bool(fresh)

    def _end_session(self, record: dict, now: int):
        events = self._current_events(record)
        if events:
            self._collect(record, events, now, ended=True)
        with self._report_lock:
            self._report = None

    def _send_nav(self, fb, link: dict, now: int):
        if not self.nav.items() or not self.gates["historico"].open():
            return
        clock = time.monotonic()
        if (len(self.nav.items()) < NAV_BATCH_MAX and self._nav_sent_at is not None
                and clock - self._nav_sent_at < NAV_SEND_S):
            return
        self._nav_sent_at = clock
        while self.nav.items():
            batch = nav_batches(self.nav.items())[0]
            env = seal(link["key"], nav_object(batch))
            while len(env) >= MAX_ENVELOPE and len(batch) > 1:
                batch = batch[: len(batch) // 2]
                env = seal(link["key"], nav_object(batch))
            if len(env) < MAX_ENVELOPE:
                try:
                    fb.side_request("POST", f"/archive/{link['deviceId']}/nav/{day_of(batch[0]['ts'])}",
                                    {"env": env, "ts": FirebaseSession.server_timestamp()})
                except FirebaseError as error:
                    self.gates["historico"].failed(error)
                    return
            self.nav.remove(batch)
            record = self._load_record()
            if record is not None and (batch[0]["user"], batch[0]["login"]) == (record["user"], record["login"]):
                for item in batch:
                    _advance(record, "sent", "sentDedup", {"ts": item["local"], "url": item["url"]})
                self._save_record(record)

    def _drain_photos(self, fb, link: dict):
        if not self._photos_enabled():
            return
        for item in self.photos.items():
            if not self.gates["fotos"].open():
                return
            data = self.photos.read(item)
            if data is None:
                continue
            uid = fb.uid
            try:
                fb.upload_object(self.bucket, f"fotos/{uid}/{item['day']}/{item['ts']}_{item['r']}.bin", data)
                fb.side_request("PUT", f"/archive/{link['deviceId']}/fotos/{item['day']}/{item['ts']}",
                                {"u": uid, "r": item["r"]})
            except FirebaseError as error:
                self.gates["fotos"].failed(error)
                return
            self.photos.remove(item)

    # ---- retenção --------------------------------------------------------------------

    def _prune_queues(self, now: int):
        clock = time.monotonic()
        if self._pruned_at is not None and clock - self._pruned_at < QUEUE_PRUNE_S:
            return
        self._pruned_at = clock
        today = day_of(now)
        if today is None:
            return
        self.photos.prune(today)
        self.nav.prune(today)

    def _retention(self, fb, link: dict, now: int):
        clock = time.monotonic()
        if self._retention_at is not None and clock < self._retention_at:
            return
        if not self.gates["retencao"].open():
            return
        today = day_of(now)
        base = f"/archive/{link['deviceId']}"
        updates = {}
        try:
            for kind in ("nav", "fotos"):
                days = fb.side_get(f"{base}/{kind}", params={"shallow": "true"})
                for day in (days if isinstance(days, dict) else {}):
                    if DAY_RE.match(day) and expired(day, today):
                        updates[f"{kind}/{day}"] = None
            if updates:
                fb.side_request("PATCH", base, updates)
        except FirebaseError as error:
            self.gates["retencao"].failed(error)
            self._retention_at = clock + RETRY_LATER_S
            return
        self._retention_at = clock + RETENTION_EVERY_S
