"""Papel do professor no Celita OS: quem manda comandos, lê relatórios e
gerencia os PCs pareados. Reaproveita criptografia, anti-replay e transporte do
agente, que já têm paridade testada com a extensão e com o celular."""
