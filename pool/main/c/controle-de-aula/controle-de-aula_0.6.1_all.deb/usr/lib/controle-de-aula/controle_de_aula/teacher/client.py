"""Cliente do professor: o papel inverso do agente, com os mesmos módulos.

Um stream por PC no nó inteiro `/devices/{id}` (as regras liberam a leitura ao
professor vinculado) e um no roster. Comandos saem selados com a chave de
sessão de cada PC e o cabeçalho anti-replay no relógio do servidor, exatamente
como o celular faz — dois professores alternando no mesmo PC não se
envenenam, e um replay é rejeitado pelo guard do PC.
"""

import base64
import json
import logging
import threading
import time

from .. import protocol
from ..crypto import derive_session_key, open_envelope, public_key_b64url, seal
from ..firebase import FirebaseSession
from . import commands
from .sessions import SessionRegistry

log = logging.getLogger("controle-de-aula.teacher")

STATE_KINDS = {
    protocol.SET_RULES: "rules",
    protocol.SET_WALLPAPER: "wallpaper",
    protocol.SET_CLASS_VIEW: "classview",
    protocol.SET_UNIT: "unit",
}


def parse_qr_payload(raw: str) -> dict | None:
    """QR v4 da extensão e do agente: {v, id, pub, tok, label}."""
    try:
        data = json.loads((raw or "").strip())
    except (TypeError, ValueError):
        return None
    if not isinstance(data, dict) or data.get("v") != 4:
        return None
    fields = {}
    for key, name in (("id", "device_id"), ("pub", "pub"), ("tok", "token")):
        value = data.get(key)
        if not isinstance(value, str) or not value or len(value) > 64:
            return None
        fields[name] = value
    label = data.get("label")
    fields["label"] = label if isinstance(label, str) and label else "Chromebook"
    return fields


class TeacherClient:
    def __init__(
        self,
        config: dict,
        private_key,
        teacher_name: str = "Professor",
        school_uid: str | None = None,
        load_auth=None,
        save_auth=None,
        session_factory=None,
    ):
        self.private_key = private_key
        self.teacher_name = teacher_name
        self.school_uid = school_uid
        self.registry = SessionRegistry()
        self.on_snapshot = None
        self.on_ack = None
        self.state_commands_for = None
        self._session_factory = session_factory or (
            lambda: FirebaseSession(config["apiKey"], config["databaseURL"], load_auth, save_auth)
        )
        self.fb = None
        self._roster_stream = None
        self._device_streams = {}
        self._first_report = {}
        self._server_offset_ms = 0
        self._last_sid = 0
        self._lock = threading.RLock()

    # ---- ciclo de vida ------------------------------------------------------------

    @property
    def teacher_uid(self) -> str | None:
        return self.fb.uid if self.fb else None

    @property
    def owner_uid(self) -> str:
        return self.school_uid or self.teacher_uid

    @property
    def roster_path(self) -> str:
        return "/school/devices" if self.school_uid else f"/teachers/{self.teacher_uid}/devices"

    def start(self):
        self.fb = self._session_factory()
        self.fb.sign_in()
        self._calibrate_clock()
        self._roster_stream = self.fb.stream(self.roster_path, self._on_roster_event)

    def stop(self):
        with self._lock:
            streams = list(self._device_streams.values())
            self._device_streams.clear()
        for stream in streams:
            stream.close()
        if self._roster_stream is not None:
            self._roster_stream.close()
        if self.fb is not None:
            self.fb.stop()

    def now_server_ms(self) -> int:
        return int(time.time() * 1000) + self._server_offset_ms

    def _calibrate_clock(self):
        # O REST não expõe .info/serverTimeOffset. Gravar o carimbo do servidor
        # num nó próprio e ler de volta dá o mesmo desvio.
        path = f"/teachers/{self.teacher_uid}/clock"
        try:
            local = int(time.time() * 1000)
            self.fb.put(path, FirebaseSession.server_timestamp())
            server = self.fb.get(path)
            if isinstance(server, (int, float)):
                self._server_offset_ms = int(server) - local
        except Exception as error:  # noqa: BLE001
            log.warning("relógio do servidor indisponível: %s", error)

    def _next_sid(self) -> int:
        with self._lock:
            now = self.now_server_ms()
            self._last_sid = now if now > self._last_sid else self._last_sid + 1
            return self._last_sid

    # ---- roster ---------------------------------------------------------------------

    def _on_roster_event(self, event: dict):
        path, data = event.get("path"), event.get("data")
        if path == "/":
            ids = set(data.keys()) if isinstance(data, dict) else set()
            for device_id in ids:
                self._attach(device_id)
            for device_id in list(self._device_streams):
                if device_id not in ids:
                    self._detach(device_id, remove_session=True)
        elif isinstance(path, str) and path.count("/") == 1:
            device_id = path[1:]
            if data:
                self._attach(device_id)
            else:
                self._detach(device_id, remove_session=True)

    # ---- por PC ---------------------------------------------------------------------

    def _attach(self, device_id: str):
        with self._lock:
            if device_id in self._device_streams:
                return
            self._device_streams[device_id] = None
        self._first_report[device_id] = True
        if self.registry.by_id(device_id) is None:
            # App reaberto: a chave de sessão é derivada de novo do meta/pub.
            meta = self.fb.get(f"/devices/{device_id}/meta")
            pub = meta.get("pub") if isinstance(meta, dict) else None
            if not isinstance(pub, str):
                self._detach(device_id)
                return
            try:
                key = derive_session_key(self.private_key, pub)
            except (ValueError, TypeError):
                self._detach(device_id)
                return
            label = meta.get("label") if isinstance(meta.get("label"), str) else "Chromebook"
            self.registry.bind(device_id, label, key)
        stream = self.fb.stream(
            f"/devices/{device_id}",
            lambda event: self._on_device_event(device_id, event),
        )
        with self._lock:
            if device_id in self._device_streams:
                self._device_streams[device_id] = stream
            else:
                stream.close()

    def _detach(self, device_id: str, remove_session: bool = False):
        with self._lock:
            stream = self._device_streams.pop(device_id, None)
        if stream is not None:
            stream.close()
        self._first_report.pop(device_id, None)
        if remove_session:
            self.registry.remove(device_id)

    def _on_device_event(self, device_id: str, event: dict):
        path, data = event.get("path"), event.get("data")
        if path == "/":
            node = data if isinstance(data, dict) else {}
            if "bind" in node and node.get("bind") is None:
                return self._device_unbound(device_id)
            self._route_meta(device_id, node.get("meta"))
            presence = node.get("presence")
            if isinstance(presence, dict):
                self._route_presence(device_id, presence.get("lastSeen"))
            self._route_report(device_id, node.get("report"))
            self._route_snapshot(device_id, node.get("snapshot"))
            acks = node.get("ack")
            if isinstance(acks, dict):
                for push_id, envelope in acks.items():
                    self._route_ack(device_id, push_id, envelope)
            return
        if path == "/bind":
            if data is None:
                self._device_unbound(device_id)
        elif path == "/presence/lastSeen":
            self._route_presence(device_id, data)
        elif path == "/presence" and isinstance(data, dict):
            self._route_presence(device_id, data.get("lastSeen"))
        elif path == "/report":
            self._route_report(device_id, data)
        elif path == "/snapshot":
            self._route_snapshot(device_id, data)
        elif isinstance(path, str) and path.startswith("/ack/"):
            self._route_ack(device_id, path[len("/ack/"):], data)
        elif path == "/ack" and isinstance(data, dict):
            for push_id, envelope in data.items():
                self._route_ack(device_id, push_id, envelope)
        elif path == "/meta":
            self._route_meta(device_id, data)
        elif path == "/meta/label" and isinstance(data, str):
            self._route_meta(device_id, {"label": data})
        elif path == "/meta/ext" and isinstance(data, str):
            self._route_meta(device_id, {"ext": data})

    def _device_unbound(self, device_id: str):
        # Aluno desvinculou pelo próprio PC: some do roster e da lista.
        self._detach(device_id, remove_session=True)
        self._remove_from_rosters(device_id)

    def _route_meta(self, device_id: str, meta):
        session = self.registry.by_id(device_id)
        if session is None or not isinstance(meta, dict):
            return
        changed = False
        label, ext = meta.get("label"), meta.get("ext")
        if isinstance(label, str) and label and session.label != label:
            session.label, changed = label, True
        if isinstance(ext, str) and session.ext_version != ext:
            session.ext_version, changed = ext, True
        if changed and self.registry.on_change:
            self.registry.on_change()

    def _route_presence(self, device_id: str, last_seen):
        if isinstance(last_seen, (int, float)):
            self.registry.touch_server_ts(device_id, int(last_seen))

    def _open(self, session, envelope):
        try:
            return open_envelope(session.session_key, envelope)
        except Exception:  # noqa: BLE001
            return None  # ilegível: corrida de re-pareamento

    def _route_report(self, device_id: str, node):
        session = self.registry.by_id(device_id)
        if session is None or not isinstance(node, dict) or not isinstance(node.get("env"), str):
            return
        message = self._open(session, node["env"])
        if not isinstance(message, dict) or message.get("type") != protocol.TAB_REPORT:
            return
        # O primeiro relatório depois de abrir pode ser antigo e é aceito sem
        # janela de tempo; ao vivo vale a janela. sid/seq valem sempre.
        first = self._first_report.get(device_id, True)
        self._first_report[device_id] = False
        now = int(time.time() * 1000)
        ts = now if first else message.get("ts", 0)
        if not session.report_guard.accept(message.get("sid", 0), message.get("seq", 0), ts, now):
            return
        server_ts = node.get("ts")
        fresh = self.registry.apply_report(
            device_id, message, int(server_ts) if isinstance(server_ts, (int, float)) else None
        )
        return fresh

    def _route_snapshot(self, device_id: str, node):
        session = self.registry.by_id(device_id)
        if session is None or not isinstance(node, dict) or not isinstance(node.get("env"), str):
            return
        message = self._open(session, node["env"])
        if not isinstance(message, dict):
            return
        kind = message.get("type")
        if kind not in (protocol.CAMERA_SNAPSHOT, protocol.SCREEN_SNAPSHOT):
            return
        raw = message.get("jpegB64")
        if not isinstance(raw, str) or not raw:
            return
        try:
            jpeg = base64.b64decode(raw, validate=True)
        except (ValueError, TypeError):
            return
        if self.on_snapshot is not None:
            self.on_snapshot(device_id, kind, jpeg)

    def _route_ack(self, device_id: str, push_id: str, envelope):
        session = self.registry.by_id(device_id)
        if session is None or not isinstance(envelope, str):
            return
        message = self._open(session, envelope)
        if isinstance(message, dict):
            now = int(time.time() * 1000)
            if session.ack_guard.accept(
                message.get("sid", 0), message.get("seq", 0), message.get("ts", now), now
            ):
                ack = commands.parse_ack(message)
                if ack is not None:
                    if not ack["ok"]:
                        log.info("ack com erro de %s: %s (%s)", device_id, ack["error"], ack["id"])
                    if self.on_ack is not None:
                        self.on_ack(device_id, ack)
        # Consome sempre, legível ou não: ack é descartável.
        try:
            self.fb.delete(f"/devices/{device_id}/ack/{push_id}")
        except Exception:  # noqa: BLE001
            pass

    # ---- pareamento -----------------------------------------------------------------

    def pair(self, qr: dict, numero: int | None = None):
        """O passo do professor no QR: grava o bind (as regras validam o token e
        o primeiro dono), o roster e o estado vigente."""
        key = derive_session_key(self.private_key, qr["pub"])
        bind = {
            "teacherUid": self.owner_uid,
            "teacherPub": public_key_b64url(self.private_key),
            "teacherName": self.teacher_name,
            "token": qr["token"],
            "ts": FirebaseSession.server_timestamp(),
        }
        if numero is not None:
            bind["numero"] = numero
        device_id = qr["device_id"]
        label = f"Unidade {numero}" if numero is not None else qr["label"]
        # A sessão entra ANTES de gravar o roster: o stream do roster dispara
        # um attach em outra thread, e sem a sessão ele iria buscar meta/pub
        # e desistir, deixando o PC sem stream.
        self.registry.bind(device_id, label, key)
        self.fb.put(f"/devices/{device_id}/bind", bind)
        self.fb.put(f"{self.roster_path}/{device_id}", True)
        if self.school_uid:
            # Roster pessoal em paralelo: um app antigo continua enxergando.
            self.fb.put(f"/teachers/{self.teacher_uid}/devices/{device_id}", True)
        self._attach(device_id)
        for command in (self.state_commands_for(device_id) if self.state_commands_for else []):
            self.set_state(device_id, command)

    def forget(self, device_id: str):
        self._detach(device_id, remove_session=True)
        self.fb.delete(f"/devices/{device_id}/bind")
        self._remove_from_rosters(device_id)

    def _remove_from_rosters(self, device_id: str):
        for path in {f"{self.roster_path}/{device_id}", f"/teachers/{self.teacher_uid}/devices/{device_id}"}:
            try:
                self.fb.delete(path)
            except Exception:  # noqa: BLE001
                pass

    # ---- saída ----------------------------------------------------------------------

    def _seal_for(self, session, command: dict) -> str:
        return seal(
            session.session_key,
            {"sid": self._next_sid(), "seq": 1, "ts": self.now_server_ms(), **command},
        )

    def send(self, device_id: str, command: dict):
        session = self.registry.by_id(device_id)
        if session is None:
            return None
        return self.fb.push(f"/devices/{device_id}/cmd", self._seal_for(session, command))

    def send_all(self, command: dict):
        # O PC do professor fica fora de todo broadcast, como no celular.
        for session in self.registry.all:
            if session.device_id != self.registry.teacher_pc_id:
                self.send(session.device_id, command)

    def set_state(self, device_id: str, command: dict):
        session = self.registry.by_id(device_id)
        kind = STATE_KINDS.get(command.get("type"))
        if session is None or kind is None:
            raise ValueError(f"não é comando de estado: {command.get('type')}")
        self.fb.put(f"/devices/{device_id}/state/{kind}", self._seal_for(session, command))

    def set_state_all(self, command: dict):
        for session in self.registry.all:
            if session.device_id != self.registry.teacher_pc_id:
                self.set_state(session.device_id, command)

    def clear_state(self, device_id: str, kind: str):
        self.fb.delete(f"/devices/{device_id}/state/{kind}")

    def publish_wallpaper(self, jpeg: bytes) -> str:
        """Publica o blob uma vez para a turma e devolve o hash a mandar por PC."""
        if len(jpeg) > 4 * 1024 * 1024:
            raise ValueError("imagem_grande")
        import hashlib

        hash_hex = hashlib.sha256(jpeg).hexdigest()[:8]
        self.fb.put(
            f"/wallpapers/{self.owner_uid}",
            {"hash": hash_hex, "jpeg": base64.b64encode(jpeg).decode(), "ts": FirebaseSession.server_timestamp()},
        )
        return hash_hex
