"""Comandos do professor, na forma exata que o app do celular envia.

Cada builder devolve o mesmo dicionário que `command.dart` monta: o PC não tem
como saber se quem mandou foi o celular ou o Celita OS, e é assim que precisa
ser. O cabeçalho anti-replay (sid, seq, ts) é acrescentado na selagem, não aqui.
"""

from .. import protocol

_counter = 0


def next_command_id() -> str:
    global _counter
    _counter = (_counter + 1) % 1_000_000_000
    return f"a{_counter}"


def _command(kind: str, payload: dict) -> dict:
    return {"v": protocol.PROTOCOL_VERSION, "type": kind, "id": next_command_id(), "payload": payload}


def open_url(url: str, new_tab: bool = True, focus: bool = True) -> dict:
    return _command(protocol.OPEN_URL, {"url": url, "newTab": new_tab, "focus": focus})


def close_all_tabs(close_windows: bool = False) -> dict:
    return _command(protocol.CLOSE_ALL_TABS, {"closeWindows": close_windows})


def show_message(title: str, body: str, popup: bool = False, sender: str | None = None) -> dict:
    payload = {"title": title, "body": body}
    if popup:
        payload["popup"] = True
        if sender is not None:
            payload["de"] = sender
    return _command(protocol.SHOW_MESSAGE, payload)


def close_tabs(domain: str | None = None, url: str | None = None) -> dict:
    if (domain is None) == (url is None):
        raise ValueError("informe domain OU url")
    return _command(protocol.CLOSE_TABS, {"domain": domain} if domain is not None else {"url": url})


def set_rules(rules, rev: int) -> dict:
    # Só regras de bloqueio viajam; as de alerta são avaliadas no professor.
    block = [
        {"pattern": rule["pattern"]}
        for rule in rules
        if isinstance(rule, dict) and rule.get("action", "block") == "block" and rule.get("pattern")
    ][: protocol.MAX_RULES]
    return _command(protocol.SET_RULES, {"rev": rev, "rules": block})


def set_unit(rev: int, numero: int) -> dict:
    return _command(protocol.SET_UNIT, {"rev": rev, "numero": numero})


def set_wallpaper(hash_hex: str) -> dict:
    return _command(protocol.SET_WALLPAPER, {"hash": hash_hex})


def capture_camera() -> dict:
    return _command(protocol.CAPTURE_CAMERA, {})


def capture_screen() -> dict:
    return _command(protocol.CAPTURE_SCREEN, {})


def parse_ack(message) -> dict | None:
    if not isinstance(message, dict) or message.get("type") != protocol.ACK:
        return None
    command_id, ok = message.get("id"), message.get("ok")
    if not isinstance(command_id, str) or not isinstance(ok, bool):
        return None
    error = message.get("error")
    return {"id": command_id, "ok": ok, "error": error if isinstance(error, str) else None}
