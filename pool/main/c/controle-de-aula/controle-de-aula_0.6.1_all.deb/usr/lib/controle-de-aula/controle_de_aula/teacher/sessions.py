"""Um PC pareado é uma sessão: chave AES derivada, guardas anti-replay e o
último estado reportado. Espelho de `session_registry.dart`."""

from ..replay import ReplayGuard

MAX_HISTORY_PER_PC = 200
# Batida de presença a cada 25 s; duas perdidas mais folga.
ONLINE_WINDOW_MS = 60_000


class PcSession:
    def __init__(self, device_id: str, label: str, session_key: bytes):
        self.device_id = device_id
        self.label = label
        self.session_key = session_key
        self.ext_version = None
        self.last_seen_ms = 0
        self.report_guard = ReplayGuard()
        self.ack_guard = ReplayGuard()
        self.tabs = []
        self.apps = []
        self.user = None
        self.history = []
        self.last_report_ms = None
        self.alert = None
        self.report_applied = False

    @property
    def active_tab(self):
        return next((tab for tab in self.tabs if tab.get("active")), None)

    def online(self, now_server_ms: int) -> bool:
        return now_server_ms - self.last_seen_ms < ONLINE_WINDOW_MS


class SessionRegistry:
    def __init__(self):
        self._by_id = {}
        self.teacher_pc_id = None
        self.on_change = None
        self.evaluate_alert = None

    def bind(self, device_id: str, label: str, session_key: bytes) -> PcSession:
        session = self._by_id.get(device_id)
        if session is None:
            session = PcSession(device_id, label, session_key)
            self._by_id[device_id] = session
        else:
            session.label = label
            session.session_key = session_key
        self._notify()
        return session

    def by_id(self, device_id: str) -> PcSession | None:
        return self._by_id.get(device_id)

    def remove(self, device_id: str):
        if self._by_id.pop(device_id, None) is not None:
            self._notify()

    @property
    def all(self) -> list:
        return list(self._by_id.values())

    def touch_server_ts(self, device_id: str, server_ms: int):
        session = self._by_id.get(device_id)
        if session is not None and server_ms > session.last_seen_ms:
            session.last_seen_ms = server_ms
            self._notify()

    def apply_report(self, device_id: str, report: dict, report_at_ms: int | None):
        session = self._by_id.get(device_id)
        if session is None:
            return []
        session.tabs = list(report.get("tabs") or [])
        session.apps = list(report.get("apps") or [])
        session.user = report.get("user")
        session.last_report_ms = report_at_ms
        # Eventos do primeiro relatório são velhos: entram no histórico sem
        # virar aviso. O PC do professor não tem histórico nem alerta.
        fresh = []
        if device_id != self.teacher_pc_id:
            seen = {(event.get("ts"), event.get("url")) for event in session.history}
            for event in report.get("events") or []:
                key = (event.get("ts"), event.get("url"))
                if key in seen:
                    continue
                seen.add(key)
                session.history.append(event)
                if session.report_applied:
                    fresh.append(event)
            del session.history[:-MAX_HISTORY_PER_PC]
            if self.evaluate_alert is not None:
                session.alert = self.evaluate_alert(device_id, session.tabs)
        session.report_applied = True
        self._notify()
        return fresh

    def _notify(self):
        if self.on_change is not None:
            self.on_change()
