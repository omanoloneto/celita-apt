"""Janela GTK do professor; recebe estado pelo socket, sem polling de Firebase."""

import json
import socket
import subprocess
import threading

from .bridge import ADMIN_SOCKET_PATH


# Janela nova fora de tela cheia: fração da área do monitor, como nos apps C
# (CELITA_WINDOW_AREA do design system); o xfwm4 centraliza.
WINDOW_AREA = 0.40


def default_window_size(gdk, min_width: int, min_height: int) -> tuple:
    width, height = 1366, 720
    display = gdk.Display.get_default()
    monitor = display.get_primary_monitor() or display.get_monitor(0) if display else None
    if monitor is not None:
        area = monitor.get_workarea()
        width, height = area.width, area.height
    side = WINDOW_AREA ** 0.5
    return (max(min(min_width, width), min(width, int(width * side))),
            max(min(min_height, height), min(height, int(height * side))))


def qr_payload(pairing: dict) -> str:
    """Mesmo JSON v4 de makeQrPayload na extensão e no leitor do celular."""
    return json.dumps({"v": 4, "id": pairing["deviceId"], "pub": pairing["pub"],
                       "tok": pairing["token"], "label": pairing.get("label") or ""},
                      ensure_ascii=False, separators=(",", ":"))


class Connection:
    def __init__(self, on_message):
        self.on_message = on_message
        self.socket = None
        self.closed = threading.Event()
        self.write_lock = threading.Lock()

    def send(self, kind):
        with self.write_lock:
            try:
                if self.socket is None:
                    return False
                self.socket.sendall((json.dumps({"t": kind}) + "\n").encode())
                return True
            except OSError:
                return False

    def run(self):
        while not self.closed.is_set():
            connection = None
            try:
                connection = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                connection.settimeout(5)
                connection.connect(ADMIN_SOCKET_PATH)
                connection.settimeout(None)
                self.socket = connection
                self.send("hello")
                with connection.makefile("rb") as reader:
                    while not self.closed.is_set():
                        line = reader.readline(65537)
                        if not line or len(line) > 65536:
                            break
                        message = json.loads(line)
                        if isinstance(message, dict):
                            self.on_message(message)
            except (OSError, ValueError):
                pass
            finally:
                self.socket = None
                if connection:
                    connection.close()
            if not self.closed.is_set():
                self.on_message({"t": "unavailable"})
                self.closed.wait(5)

    def close(self):
        self.closed.set()
        if self.socket:
            try:
                self.socket.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass


def main():
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gtk, Pango

    class Window(Gtk.ApplicationWindow):
        def __init__(self, app):
            super().__init__(application=app, title="Controle de Aula")
            self.set_wmclass("controle-de-aula", "controle-de-aula")
            self.set_icon_name("computer")
            self.set_default_size(*default_window_size(Gdk, 640, 480))
            self.set_position(Gtk.WindowPosition.CENTER)
            self.last_qr = None
            self.connection = Connection(lambda msg: GLib.idle_add(self.update_state, msg))
            self.connect("destroy", lambda *_: self.connection.close())

            outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=24)
            outer.set_border_width(32)
            self.add(outer)

            heading = Gtk.Box(spacing=16)
            icon = Gtk.Image.new_from_icon_name("computer", Gtk.IconSize.DIALOG)
            heading.pack_start(icon, False, False, 0)
            titles = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            titles.pack_start(self.label("Controle de Aula", 24, True), False, False, 0)
            titles.pack_start(self.label("Conecte este computador ao aplicativo do professor."), False, False, 0)
            heading.pack_start(titles, True, True, 0)
            outer.pack_start(heading, False, False, 0)

            content = Gtk.Box(spacing=24)
            content.set_vexpand(True)
            outer.pack_start(content, True, True, 0)

            self.qr_frame = Gtk.Frame()
            qr_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
            qr_box.set_border_width(20)
            self.qr_frame.add(qr_box)
            self.qr_image = Gtk.Image.new_from_icon_name("network-transmit-receive-symbolic", Gtk.IconSize.DIALOG)
            self.qr_image.set_size_request(240, 240)
            self.visual = Gtk.Stack()
            self.visual.add_named(self.qr_image, "image")
            self.spinner = Gtk.Spinner()
            self.spinner.set_size_request(40, 40)
            self.spinner.set_halign(Gtk.Align.CENTER)
            self.spinner.set_valign(Gtk.Align.CENTER)
            self.spinner.get_accessible().set_name("Conexão em andamento")
            self.visual.add_named(self.spinner, "loading")
            qr_box.pack_start(self.visual, True, True, 0)
            self.qr_caption = self.label("Preparando conexão…", 12)
            self.qr_caption.set_xalign(0.5)
            qr_box.pack_start(self.qr_caption, False, False, 0)
            content.pack_start(self.qr_frame, False, False, 0)

            detail = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
            detail.set_size_request(300, -1)
            detail.set_valign(Gtk.Align.CENTER)
            self.status = self.label("Conectando…", 17, True)
            self.computer = self.label("Este computador", 14, True)
            self.teacher = self.label("")
            self.instructions = self.label("Aguarde enquanto buscamos o estado da conexão.")
            self.instructions.set_width_chars(32)
            self.instructions.set_max_width_chars(38)
            detail.pack_start(self.status, False, False, 0)
            detail.pack_start(self.computer, False, False, 0)
            detail.pack_start(self.teacher, False, False, 0)
            detail.pack_start(self.instructions, False, False, 0)
            content.pack_start(detail, True, True, 0)

            bottom = Gtk.Box(spacing=12)
            outer.pack_start(bottom, False, False, 0)
            self.reconnect = Gtk.Button.new_with_label("Reconectar")
            self.reconnect.connect("clicked", self.reconnect_clicked)
            self.reconnect.set_no_show_all(True)
            bottom.pack_start(self.reconnect, False, False, 0)
            self.unbind = Gtk.Button.new_with_label("Desvincular computador")
            self.unbind.connect("clicked", self.unbind_clicked)
            self.unbind.set_no_show_all(True)
            bottom.pack_start(self.unbind, False, False, 0)
            close = Gtk.Button.new_with_label("Fechar")
            close.connect("clicked", lambda *_: self.close())
            bottom.pack_end(close, False, False, 0)
            self.show_all()
            self.show_loading("Preparando conexão…")
            threading.Thread(target=self.connection.run, name="teacher-app", daemon=True).start()

        @staticmethod
        def label(text, size=13, bold=False):
            label = Gtk.Label(label=text, xalign=0)
            label.set_line_wrap(True)
            label.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
            attributes = Pango.AttrList()
            attributes.insert(Pango.attr_size_new_absolute(size * Pango.SCALE))
            if bold:
                attributes.insert(Pango.attr_weight_new(Pango.Weight.SEMIBOLD))
            label.set_attributes(attributes)
            return label

        def update_state(self, message):
            if self.connection.closed.is_set():
                return False
            if message.get("t") == "unavailable":
                self.status.set_text("Conexão indisponível")
                self.instructions.set_text("Não foi possível acessar a conexão deste computador. Reinicie o computador e abra o Controle de Aula novamente. Esta janela também tenta reconectar automaticamente.")
                self.reconnect.hide()
                self.unbind.hide()
                self.teacher.hide()
                self.show_placeholder("network-offline-symbolic", "Aguardando o serviço")
                return False
            if message.get("t") != "admin-state":
                return False
            status = message.get("status") or {}
            state = status.get("state")
            bound = bool(message.get("bound"))
            self.computer.set_text(status.get("label") or "Este computador")
            teacher = status.get("teacher") or "Professor"
            self.teacher.set_text("Vinculado a " + teacher)
            self.teacher.set_visible(bound or state == "configuring")
            self.reconnect.set_visible(state != "configuring")
            self.unbind.set_visible(bound)
            if state == "connected":
                self.status.set_text("Pronto para a aula")
                self.instructions.set_text("O professor já pode gerenciar este computador pelo aplicativo. Você pode fechar esta janela; a conexão continua ativa.")
                self.show_placeholder("emblem-ok-symbolic", "Computador conectado")
            elif state == "pairing" and message.get("pairing"):
                self.status.set_text("Vincular ao professor")
                self.instructions.set_text("1. Abra o Controle de Aula no celular.\n\n2. Escolha adicionar um computador.\n\n3. Aponte a câmera para este código.")
                self.show_qr(message["pairing"])
            elif state == "configuring":
                self.status.set_text("Configurando…")
                self.instructions.set_text("Pareamento recebido. Estamos preparando este computador para a aula. A conexão será confirmada automaticamente.")
                self.show_loading("Pareamento recebido")
            else:
                self.status.set_text("Conectando…")
                self.instructions.set_text("Estamos conectando este computador ao aplicativo do professor. Aguarde; a conexão é confirmada automaticamente.")
                self.show_loading("Aguardando conexão")
            return False

        def show_loading(self, caption):
            self.last_qr = None
            self.visual.set_visible_child_name("loading")
            self.qr_caption.set_text(caption)
            self.spinner.start()

        def show_placeholder(self, icon, caption):
            self.spinner.stop()
            self.visual.set_visible_child_name("image")
            self.last_qr = None
            self.qr_image.set_from_icon_name(icon, Gtk.IconSize.DIALOG)
            self.qr_caption.set_text(caption)

        def show_qr(self, pairing):
            self.spinner.stop()
            self.visual.set_visible_child_name("image")
            payload = qr_payload(pairing)
            if self.last_qr == payload:
                return
            try:
                data = subprocess.run(["qrencode", "-t", "PNG", "-s", "5", "-m", "4", "-o", "-"],
                                      input=payload.encode(), capture_output=True, check=True, timeout=5).stdout
                loader = GdkPixbuf.PixbufLoader.new_with_type("png")
                loader.write(data)
                loader.close()
                # QR sem reamostragem: módulos continuam nítidos ao escanear.
                self.qr_image.set_from_pixbuf(loader.get_pixbuf())
                self.qr_caption.set_text("Escaneie pelo celular do professor")
                self.last_qr = payload
            except (OSError, subprocess.SubprocessError, GLib.Error):
                self.show_placeholder("dialog-warning-symbolic", "Código indisponível")
                self.instructions.set_text("Não foi possível gerar o código. Feche e abra o Controle de Aula. Se continuar, reinstale o pacote do Celita OS.")

        def reconnect_clicked(self, _button):
            if self.connection.send("reconnect"):
                self.status.set_text("Reconectando…")
                self.show_loading("Aguardando conexão")

        def unbind_clicked(self, _button):
            dialog = Gtk.MessageDialog(transient_for=self, modal=True,
                                       message_type=Gtk.MessageType.QUESTION,
                                       buttons=Gtk.ButtonsType.NONE,
                                       text="Desvincular este computador?")
            dialog.format_secondary_text("O professor deixará de controlar este computador. Para conectar novamente, será preciso escanear um novo código.")
            dialog.add_button("Cancelar", Gtk.ResponseType.CANCEL)
            dialog.add_button("Desvincular", Gtk.ResponseType.ACCEPT)
            response = dialog.run()
            dialog.destroy()
            if response == Gtk.ResponseType.ACCEPT:
                self.connection.send("unbind")

    application = Gtk.Application(application_id="br.escola.celita.ControleDeAula", flags=Gio.ApplicationFlags.FLAGS_NONE)

    def activate(app):
        window = app.get_active_window()
        if window:
            window.present()
        else:
            Window(app)

    application.connect("activate", activate)
    return application.run([])
