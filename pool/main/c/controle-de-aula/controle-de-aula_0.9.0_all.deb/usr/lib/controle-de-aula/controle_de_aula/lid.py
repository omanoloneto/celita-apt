"""Tampa fechada numa conta de aluno encerra a sessão antes de o computador
suspender. O logind avisa "PrepareForSleep" e espera quem segura uma trava de
atraso; o agente segura uma, derruba as sessões controladas e solta. Ao
acordar, a tela de login. Conta de professor não é tocada."""

import logging
import os
import threading
import time

from .session import _controlled_users, _loginctl

log = logging.getLogger("controle-de-aula.lid")

TERMINATE_WAIT_S = 3.0


def controlled_sessions() -> list:
    """Ids das sessões gráficas (ativas ou não) de contas controladas."""
    controlled = _controlled_users()
    if not controlled:
        return []
    found = []
    for line in _loginctl("list-sessions", "--no-legend").splitlines():
        fields = line.split()
        if not fields:
            continue
        props = _loginctl("show-session", fields[0], "-p", "Class", "-p", "Name")
        values = dict(item.split("=", 1) for item in props.splitlines() if "=" in item)
        if values.get("Class") == "user" and values.get("Name") in controlled:
            found.append(fields[0])
    return found


def terminate_sessions(session_ids: list, wait_s: float = TERMINATE_WAIT_S):
    for session_id in session_ids:
        _loginctl("terminate-session", session_id)
    deadline = time.monotonic() + wait_s
    while time.monotonic() < deadline:
        alive = [s for s in session_ids if "Id=" in _loginctl("show-session", s, "-p", "Id")]
        if not alive:
            return
        time.sleep(0.2)


class LidLogout:
    def __init__(self, inhibit=None, release=None, sessions=None, terminate=None):
        self.inhibit = inhibit
        self.release = release or os.close
        self.sessions = sessions or controlled_sessions
        self.terminate = terminate or terminate_sessions
        self.lock = None

    def start(self):
        threading.Thread(target=self._run, name="lid-logout", daemon=True).start()

    def _run(self):
        try:
            import gi
            gi.require_version("Gio", "2.0")
            from gi.repository import Gio, GLib
        except (ImportError, ValueError) as error:
            log.warning("sem GLib, tampa fechada não encerra sessões: %s", error)
            return
        try:
            bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
            proxy = Gio.DBusProxy.new_sync(
                bus, Gio.DBusProxyFlags.NONE, None, "org.freedesktop.login1",
                "/org/freedesktop/login1", "org.freedesktop.login1.Manager", None,
            )
        except GLib.Error as error:
            log.warning("logind indisponível, tampa fechada não encerra sessões: %s", error)
            return

        def inhibit():
            _, fds = proxy.call_with_unix_fd_list_sync(
                "Inhibit",
                GLib.Variant("(ssss)", ("sleep", "Controle de Aula", "Encerrar a sessão do aluno antes de suspender", "delay")),
                Gio.DBusCallFlags.NONE, -1, None, None,
            )
            return fds.get(0)

        self.inhibit = self.inhibit or inhibit
        proxy.connect("g-signal", lambda _proxy, _sender, name, params: self.on_signal(name, params.unpack()))
        self.take_lock()
        GLib.MainLoop().run()

    def take_lock(self):
        if self.lock is not None:
            return
        try:
            self.lock = self.inhibit()
        except Exception as error:  # noqa: BLE001
            log.warning("trava de suspensão recusada: %s", error)

    def release_lock(self):
        lock, self.lock = self.lock, None
        if lock is not None:
            try:
                self.release(lock)
            except OSError:
                pass

    def on_signal(self, name: str, params: tuple):
        if name != "PrepareForSleep":
            return
        if params and params[0]:
            try:
                ids = self.sessions()
                if ids:
                    log.info("tampa fechada: encerrando sessão de aluno %s", ", ".join(ids))
                    self.terminate(ids)
            finally:
                self.release_lock()
        else:
            self.take_lock()
