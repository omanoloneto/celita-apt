"""Login Google sem SDK: OAuth de app instalado (loopback + PKCE) no navegador
do próprio computador, e o id_token vinculado à conta Firebase do professor.
O client id de "app para computador" fica em firebase.json; sem ele a conta
Google não está disponível, e o app diz isso em vez de falhar."""

import base64
import hashlib
import json
import logging
import os
import secrets
import subprocess
import threading
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer

log = logging.getLogger("controle-de-aula.teacher.auth")

GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
SCOPES = "openid email profile"
LOGIN_TIMEOUT_S = 300

DONE_PAGE = """<!doctype html><meta charset="utf-8"><title>Controle de Aula</title>
<body style="font-family:sans-serif;padding:40px"><h2>Pronto</h2>
<p>Pode voltar para o Controle de Aula. Esta aba pode ser fechada.</p></body>"""
FAIL_PAGE = """<!doctype html><meta charset="utf-8"><title>Controle de Aula</title>
<body style="font-family:sans-serif;padding:40px"><h2>Login não concluído</h2>
<p>Volte para o Controle de Aula e tente de novo.</p></body>"""


class GoogleLogin:
    def __init__(self, client_id: str, client_secret: str | None,
                 auth_url: str = GOOGLE_AUTH_URL, token_url: str = GOOGLE_TOKEN_URL, open_browser=None):
        self.client_id = client_id
        self.client_secret = client_secret
        self.auth_url = auth_url
        self.token_url = token_url
        self.open_browser = open_browser or self._xdg_open
        self.cancelled = threading.Event()

    @staticmethod
    def _xdg_open(url: str):
        subprocess.Popen(["xdg-open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def cancel(self):
        self.cancelled.set()

    def run(self, timeout_s: float = LOGIN_TIMEOUT_S) -> str:
        """Bloqueia até o navegador voltar com o código; devolve o id_token."""
        verifier = base64.urlsafe_b64encode(os.urandom(32)).decode().rstrip("=")
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip("=")
        state = secrets.token_urlsafe(16)
        result = {}
        got = threading.Event()

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_):
                pass

            def do_GET(self):
                query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                ok = query.get("state", [None])[0] == state and "code" in query
                if ok:
                    result["code"] = query["code"][0]
                body = (DONE_PAGE if ok else FAIL_PAGE).encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                if ok:
                    got.set()

        server = HTTPServer(("127.0.0.1", 0), Handler)
        server.timeout = 0.5
        redirect_uri = f"http://127.0.0.1:{server.server_port}/"
        params = {
            "client_id": self.client_id, "redirect_uri": redirect_uri, "response_type": "code",
            "scope": SCOPES, "code_challenge": challenge, "code_challenge_method": "S256",
            "state": state, "access_type": "online", "prompt": "select_account",
        }
        self.open_browser(f"{self.auth_url}?{urllib.parse.urlencode(params)}")
        try:
            waited = 0.0
            while not got.is_set() and not self.cancelled.is_set() and waited < timeout_s:
                server.handle_request()
                waited += server.timeout
        finally:
            server.server_close()
        if "code" not in result:
            raise TimeoutError("login_cancelado")
        return self.exchange(result["code"], verifier, redirect_uri)

    def exchange(self, code: str, verifier: str, redirect_uri: str) -> str:
        form = {
            "code": code, "client_id": self.client_id, "code_verifier": verifier,
            "grant_type": "authorization_code", "redirect_uri": redirect_uri,
        }
        if self.client_secret:
            form["client_secret"] = self.client_secret
        request = urllib.request.Request(
            self.token_url, data=urllib.parse.urlencode(form).encode(),
            headers={"Content-Type": "application/x-www-form-urlencoded"}, method="POST",
        )
        with urllib.request.urlopen(request, timeout=20) as response:
            data = json.loads(response.read().decode("utf-8"))
        token = data.get("id_token")
        if not isinstance(token, str) or not token:
            raise ValueError("sem_id_token")
        return token
