"""Login entregue pelo celular: o app do Celita mostra um QR com uma chave
efêmera e um canal; o celular, já logado no Google, cifra um id_token fresco e
a chave do professor para esse canal em `/handoff/{canal}`. O app entra na
mesma conta e adota a chave — vira o mesmo professor do celular, sem cliente
OAuth no PC."""

import json
import secrets

from ..crypto import derive_session_key, generate_private_key, open_envelope, public_key_b64url

CHANNEL_BYTES = 16
MAX_KEYS_LEN = 200
MAX_NAME_LEN = 40


class LoginHandoff:
    def __init__(self):
        self.private_key = generate_private_key()
        self.channel = secrets.token_urlsafe(CHANNEL_BYTES)

    @property
    def path(self) -> str:
        return f"/handoff/{self.channel}"

    def qr_payload(self) -> str:
        return json.dumps({"v": 1, "t": "login", "c": self.channel, "pub": public_key_b64url(self.private_key)},
                          separators=(",", ":"))

    def open(self, node) -> dict | None:
        """Devolve {idToken, keys, teacherName, schoolUid} ou None se o nó não é
        um handoff válido para esta chave."""
        if not isinstance(node, dict) or not isinstance(node.get("pub"), str) or not isinstance(node.get("env"), str):
            return None
        try:
            key = derive_session_key(self.private_key, node["pub"])
            message = open_envelope(key, node["env"])
        except Exception:  # noqa: BLE001
            return None
        if not isinstance(message, dict) or message.get("v") != 1:
            return None
        id_token, keys = message.get("idToken"), message.get("keys")
        if not isinstance(id_token, str) or not id_token or not isinstance(keys, str) or not 0 < len(keys) <= MAX_KEYS_LEN:
            return None
        name = message.get("teacherName")
        school = message.get("schoolUid")
        return {
            "idToken": id_token,
            "keys": keys,
            "teacherName": name.strip()[:MAX_NAME_LEN] if isinstance(name, str) and name.strip() else None,
            "schoolUid": school if isinstance(school, str) and school else None,
        }
