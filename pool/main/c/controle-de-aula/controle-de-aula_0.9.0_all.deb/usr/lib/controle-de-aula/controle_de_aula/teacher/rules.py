"""Regras de domínio (bloquear/avisar). Espelho de `domain_rules.dart`: o
casamento tem de ser idêntico ao da extensão, vetores em protocolo.md §3.2."""

import re
from urllib.parse import urlsplit

BLOCK = "block"
ALERT = "alert"
MAX_RULES = 1000
MAX_PATTERN = 200


def normalize_pattern(raw: str) -> str:
    text = (raw or "").strip().lower()
    text = re.sub(r"^https?://", "", text)
    slash = text.find("/")
    host = text if slash == -1 else text[:slash]
    rest = "" if slash == -1 else text[slash:]
    colon = host.find(":")
    if colon != -1:
        host = host[:colon]
    text = re.sub(r"/+$", "", host + rest)
    return text[:MAX_PATTERN]


def host_matches(host: str, pattern: str) -> bool:
    return host == pattern or host.endswith("." + pattern)


def rule_matches(pattern: str, url: str) -> bool:
    if not pattern:
        return False
    try:
        parts = urlsplit(url)
    except ValueError:
        return False
    if parts.scheme not in ("http", "https"):
        return False
    host = (parts.hostname or "").lower()
    if not host:
        return False
    slash = pattern.find("/")
    if slash == -1:
        return host_matches(host, pattern)
    return host_matches(host, pattern[:slash]) and parts.path.lower().startswith(pattern[slash:])


def find_rule(rules: list, url: str, actions: set | None = None) -> dict | None:
    for rule in rules:
        if actions is not None and rule.get("action") not in actions:
            continue
        if rule_matches(rule.get("pattern", ""), url):
            return rule
    return None


def sanitize_rule(raw) -> dict | None:
    if not isinstance(raw, dict):
        return None
    pattern = raw.get("pattern")
    if not isinstance(pattern, str) or not pattern:
        return None
    return {"pattern": pattern, "action": ALERT if raw.get("action") == ALERT else BLOCK}
