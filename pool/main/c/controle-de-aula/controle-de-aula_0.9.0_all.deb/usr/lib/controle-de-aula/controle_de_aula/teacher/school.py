"""Workspace da escola: uma chave para todos os professores e stores
compartilhados em `/school/stores/{k}`. Espelho de `school_keys.dart` e
`school_sync.dart`: modelo aberto (qualquer login Google entra), envelope
`{json}` cifrado com chave derivada da keypair da escola, LWW por rev."""

import hashlib
import json
import logging
import threading

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.serialization import Encoding, NoEncryption, PrivateFormat

from ..crypto import SALT, open_envelope, seal
from ..firebase import FirebaseSession
from .stores import FILE_NAMES, FILE_RULES, FILE_UNITS

log = logging.getLogger("controle-de-aula.teacher.school")

STORE_INFO = b"school-store-v1"
# Chave lógica -> arquivo espelhado. Turmas ficam de fora: o app do Celita não
# tem a aba Turmas; o arquivo continua íntegro no banco para o celular.
SHARED_STORES = {"rules": FILE_RULES, "units": FILE_UNITS, "names": FILE_NAMES}
PUSH_DEBOUNCE_S = 1.0


def school_store_key(private_key) -> bytes:
    raw = private_key.private_bytes(Encoding.Raw, PrivateFormat.Raw, NoEncryption())
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=SALT, info=STORE_INFO).derive(raw)


class SchoolKeys:
    def __init__(self, fb: FirebaseSession):
        self.fb = fb

    def download(self) -> dict | None:
        keys = self.fb.get("/school/keypair/keys")
        uid = self.fb.get("/school/meta/schoolUid")
        if not isinstance(keys, str) or not isinstance(uid, str):
            return None
        return {"keys": keys, "schoolUid": uid}

    def publish(self, uid: str, raw_keys: str) -> str | None:
        """Fundador, uma vez. Idempotente com a mesma chave; outra chave = erro."""
        existing = self.download()
        if existing is not None:
            return None if existing["keys"] == raw_keys else "A escola já foi criada por outro professor — use \"Entrar\"."
        self.fb.put("/school/meta", {"schoolUid": uid, "criadoEm": FirebaseSession.server_timestamp()})
        self.fb.put("/school/keypair", {"keys": raw_keys, "ts": FirebaseSession.server_timestamp()})
        return None


class SchoolSync:
    """Núcleo puro (prepare_push/apply_remote) separado do que toca o banco."""

    def __init__(self, key: bytes, now_server_ms, read_file, write_file):
        self.key = key
        self.now_server_ms = now_server_ms
        self.read_file = read_file
        self.write_file = write_file
        self.on_remote = None
        self._last_rev = {}
        self._last_hash = {}
        self._timers = {}
        self._streams = []
        self._fb = None
        self._lock = threading.Lock()

    @staticmethod
    def _hash(text: str) -> str:
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    def prepare_push(self, kind: str) -> dict | None:
        text = self.read_file(SHARED_STORES[kind])
        if text is None:
            return None
        digest = self._hash(text)
        with self._lock:
            if self._last_hash.get(kind) == digest:
                return None
            rev = self.now_server_ms()
            self._last_rev[kind] = rev
            self._last_hash[kind] = digest
        return {"rev": rev, "env": seal(self.key, {"json": text})}

    def apply_remote(self, kind: str, rev, env) -> bool:
        if kind not in SHARED_STORES or not isinstance(rev, (int, float)) or not isinstance(env, str):
            return False
        with self._lock:
            if rev <= self._last_rev.get(kind, -1):
                return False
        try:
            message = open_envelope(self.key, env)
        except Exception:  # noqa: BLE001
            log.warning("store %s da escola ilegível", kind)
            return False
        text = message.get("json") if isinstance(message, dict) else None
        if not isinstance(text, str):
            return False
        try:
            json.loads(text)
        except ValueError:
            return False
        with self._lock:
            self._last_rev[kind] = rev
            self._last_hash[kind] = self._hash(text)
        self.write_file(SHARED_STORES[kind], text)
        if self.on_remote is not None:
            self.on_remote(kind)
        return True

    # ---- banco ------------------------------------------------------------

    def start(self, fb: FirebaseSession):
        self._fb = fb
        for kind in SHARED_STORES:
            self._streams.append(fb.stream(f"/school/stores/{kind}", lambda event, k=kind: self._on_event(k, event)))

    def stop(self):
        for stream in self._streams:
            stream.close()
        self._streams.clear()
        with self._lock:
            timers = list(self._timers.values())
            self._timers.clear()
        for timer in timers:
            timer.cancel()

    def _on_event(self, kind: str, event: dict):
        if event.get("path") != "/":
            # Só escrita inteira {rev, env} é válida; um pedaço é ignorado até
            # o próximo set completo.
            return
        data = event.get("data")
        if isinstance(data, dict):
            self.apply_remote(kind, data.get("rev"), data.get("env"))

    def schedule_push(self, kind: str):
        with self._lock:
            timer = self._timers.pop(kind, None)
            if timer is not None:
                timer.cancel()
            timer = threading.Timer(PUSH_DEBOUNCE_S, self._push_now, args=(kind,))
            timer.daemon = True
            self._timers[kind] = timer
        timer.start()

    def _push_now(self, kind: str):
        with self._lock:
            self._timers.pop(kind, None)
        try:
            payload = self.prepare_push(kind)
            if payload is not None and self._fb is not None:
                self._fb.put(f"/school/stores/{kind}", payload)
        except Exception as error:  # noqa: BLE001
            log.warning("push do store %s falhou: %s", kind, error)

    def push_all(self):
        for kind in SHARED_STORES:
            self._push_now(kind)
