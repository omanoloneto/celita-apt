# Fragmento sourceado pelo /usr/bin/voges. Conta controlada é conta sem senha:
# o Gerenciador de Usuários põe essas contas no grupo nopasswdlogin, e é ele o
# critério. Quem instala o pacote é o administrador e tem senha, logo fica fora.
if id -Gn 2>/dev/null | tr ' ' '\n' | grep -qx nopasswdlogin; then
    VOGES_EXTENSIONS="$VOGES_EXTENSIONS,/usr/share/controle-de-aula/extension"
    # Aluno abre muitas abas dos mesmos poucos sites (Classroom, Docs, o site da
    # escola). Um processo por site, em vez de um por aba, medido com 10 abas em
    # 3 sites: 19 -> 12 processos e 523 -> 446 MB, sem custo de abertura. O
    # isolamento entre sites diferentes continua.
    set -- --process-per-site "$@"
fi
